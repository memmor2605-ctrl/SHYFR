import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.shyfr.app"
    compileSdk = 36
    defaultConfig {
        // Domyślny przekaźnik publiczny (adres onion v3), ustawiany przy budowaniu: gradle -PshyfrDefaultRelay=xxxx.onion. Pusty = brak domyślnego.
        buildConfigField("String", "DEFAULT_RELAY", "\"${(project.findProperty("shyfrDefaultRelay") as String? ?: "").trim()}\"")
        applicationId = "com.shyfr.app"
        minSdk = 29
        targetSdk = 36
        versionCode = 118
        versionName = "1.1.0-rc17"
    }
    // Podpisanie wydania: utwórz keystore.properties (storeFile, storePassword, keyAlias, keyPassword). Plik nie trafia do repozytorium.
    val ksFile = rootProject.file("keystore.properties")
    signingConfigs {
        create("release") {
            if (ksFile.exists()) {
                val p = Properties()
                ksFile.inputStream().use { p.load(it) }
                storeFile = rootProject.file(p.getProperty("storeFile"))
                storePassword = p.getProperty("storePassword")
                keyAlias = p.getProperty("keyAlias")
                keyPassword = p.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (ksFile.exists()) signingConfig = signingConfigs.getByName("release")
        }
    }
    lint { abortOnError = false }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
kotlin {
    compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) }
}
dependencies {
    testImplementation("junit:junit:4.13.2")
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.fragment:fragment-ktx:1.8.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("com.lambdapioneer.argon2kt:argon2kt:1.5.0")
    implementation("net.zetetic:sqlcipher-android:4.5.6@aar")
    implementation("androidx.sqlite:sqlite-ktx:2.4.0")
    // Etap 2: Tor. Sprawdź najnowsze wersje na https://github.com/guardianproject/tor-android
    implementation("info.guardianproject:tor-android:0.4.9.6")
    implementation("info.guardianproject:jtorctl:0.4.5.7")
    implementation("androidx.localbroadcastmanager:localbroadcastmanager:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Etap 3: krypto (X25519), QR, kamera
    implementation("com.google.crypto.tink:tink-android:1.15.0")
    implementation("com.google.zxing:core:3.5.3")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    implementation("com.google.mlkit:barcode-scanning:17.3.0") // wersja wbudowana, bez Google Play Services
}
