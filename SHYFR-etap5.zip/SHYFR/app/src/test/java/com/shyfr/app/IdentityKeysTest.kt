package com.shyfr.app

import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Ed25519Verify
import com.shyfr.app.feed.PublicKeys
import com.shyfr.app.social.IdentityKeys
import com.shyfr.app.social.IdentityKind
import com.shyfr.app.social.Pseudonym
import org.junit.Assert.*
import org.junit.Test

class IdentityKeysTest {
    private val master = ByteArray(32) { it.toByte() }
    private fun pub(k: IdentityKind, i: Int, m: ByteArray = master) = IdentityKeys.publicHex(m, k, i)

    @Test fun derivationIsDeterministic() = assertEquals(pub(IdentityKind.PUBLIC, 0), pub(IdentityKind.PUBLIC, 0))

    @Test fun everyKindAndIndexGetsItsOwnKey() {
        val all = listOf(pub(IdentityKind.PUBLIC, 0), pub(IdentityKind.PRIVATE, 0), pub(IdentityKind.ANON, 0), pub(IdentityKind.ANON, 1), pub(IdentityKind.PUBLIC, 1))
        assertEquals(all.size, all.toSet().size)
    }

    @Test fun differentVaultsGiveDifferentKeys() =
        assertNotEquals(pub(IdentityKind.ANON, 0), pub(IdentityKind.ANON, 0, ByteArray(32) { (it + 1).toByte() }))

    @Test fun anonymousKeyIsNotACommunityKey() {
        val anon = IdentityKeys.signing(master, IdentityKind.ANON, 0).publicKey
        for (i in 0..3) assertFalse(anon.contentEquals(PublicKeys.derive(master, "x.onion", "0000000000000000", i).publicKey))
    }

    @Test fun signingAndAgreementKeysAreSeparate() {
        val sign = IdentityKeys.signing(master, IdentityKind.PRIVATE, 0)
        val agree = IdentityKeys.agreementPriv(master, IdentityKind.PRIVATE, 0)
        assertFalse(agree.contentEquals(sign.privateKey))
        assertEquals(32, agree.size)
    }

    @Test fun signatureVerifies() {
        val kp = IdentityKeys.signing(master, IdentityKind.PUBLIC, 0)
        val msg = "post".toByteArray()
        val sig = Ed25519Sign(kp.privateKey).sign(msg)
        Ed25519Verify(kp.publicKey).verify(sig, msg)
        assertThrows(java.security.GeneralSecurityException::class.java) { Ed25519Verify(kp.publicKey).verify(sig, "inny".toByteArray()) }
    }

    @Test fun pseudonymHasExpectedShapeAndVaries() {
        val names = (1..30).map { Pseudonym.random() }
        names.forEach { assertTrue(it, Regex("^\\p{L}+-\\d{4}$").matches(it)) }
        assertTrue(names.toSet().size > 1)
    }
}
