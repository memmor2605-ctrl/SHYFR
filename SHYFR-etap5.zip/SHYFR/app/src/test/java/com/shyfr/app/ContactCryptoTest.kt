package com.shyfr.app

import com.google.crypto.tink.subtle.X25519
import com.shyfr.app.feed.ContactCrypto
import com.shyfr.app.feed.PublicKeys
import org.junit.Assert.*
import org.junit.Test

class ContactCryptoTest {
    private val master = ByteArray(32) { (it * 3 + 1).toByte() }

    @Test fun sealOpenRoundtrip() {
        val priv = PublicKeys.inboxPriv(master, "r.onion", "aaaaaaaaaaaaaaaa", 0)
        val pub = X25519.publicFromPrivate(priv)
        val sealed = ContactCrypto.seal(pub, "Cześć, możemy pogadać?".toByteArray(Charsets.UTF_8))
        assertEquals("Cześć, możemy pogadać?", String(ContactCrypto.open(priv, sealed)!!, Charsets.UTF_8))
        assertFalse(sealed.contains("Cześć"))
    }

    @Test fun otherKeyCannotOpen() {
        val priv = PublicKeys.inboxPriv(master, "r.onion", "aaaaaaaaaaaaaaaa", 0)
        val other = PublicKeys.inboxPriv(master, "r.onion", "bbbbbbbbbbbbbbbb", 0)
        val sealed = ContactCrypto.seal(X25519.publicFromPrivate(priv), "tajne".toByteArray())
        assertNull(ContactCrypto.open(other, sealed))
    }

    @Test fun tamperedOrGarbageIsRejected() {
        val priv = PublicKeys.inboxPriv(master, "r.onion", "aaaaaaaaaaaaaaaa", 0)
        val sealed = ContactCrypto.seal(X25519.publicFromPrivate(priv), "x".toByteArray())
        val flipped = sealed.dropLast(2) + (if (sealed.takeLast(2) == "AA") "BB" else "AA")
        assertNull(ContactCrypto.open(priv, flipped))
        assertNull(ContactCrypto.open(priv, "nie-base64!!"))
        assertNull(ContactCrypto.open(priv, ""))
    }

    @Test fun requestKeysAreDistinctPerRequest() {
        val a = PublicKeys.requestPriv(master, "r.onion", "aaaaaaaaaaaaaaaa", "t", 0)
        val b = PublicKeys.requestPriv(master, "r.onion", "aaaaaaaaaaaaaaaa", "t", 1)
        assertFalse(a.contentEquals(b))
        assertArrayEquals(a, PublicKeys.requestPriv(master, "r.onion", "aaaaaaaaaaaaaaaa", "t", 0))
    }
}
