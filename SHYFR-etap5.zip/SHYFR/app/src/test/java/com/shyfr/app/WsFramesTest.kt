package com.shyfr.app

import com.shyfr.app.nostr.WsFrames
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.IOException

class WsFramesTest {
    @Test fun acceptKeyMatchesRfc6455Example() =
        assertEquals("s3pPLMBiTxaQ9kYGzzhZRbK+xOo=", WsFrames.acceptKey("dGhlIHNhbXBsZSBub25jZQ=="))

    private fun roundTrip(n: Int, mask: Boolean) {
        val p = ByteArray(n) { (it * 31).toByte() }
        val f = WsFrames.read(ByteArrayInputStream(WsFrames.encode(WsFrames.OP_TEXT, p, mask)))
        assertTrue(f.fin); assertEquals(WsFrames.OP_TEXT, f.opcode); assertArrayEquals(p, f.payload)
    }
    @Test fun roundTripAllLengthClasses() { for (n in listOf(0, 1, 125, 126, 127, 65535, 65536, 70000)) { roundTrip(n, true); roundTrip(n, false) } }

    @Test fun maskedFrameDiffersOnTheWire() {
        val p = "abcdefgh".toByteArray()
        val enc = WsFrames.encode(WsFrames.OP_TEXT, p, true)
        assertEquals(0x80, enc[1].toInt() and 0x80); assertFalse(enc.copyOfRange(6, enc.size).contentEquals(p))
    }

    @Test fun fragmentedFramesKeepFinFlagAndOpcode() {
        val a = WsFrames.read(ByteArrayInputStream(WsFrames.encode(WsFrames.OP_TEXT, "ab".toByteArray(), true, fin = false)))
        val b = WsFrames.read(ByteArrayInputStream(WsFrames.encode(WsFrames.OP_CONT, "cd".toByteArray(), true, fin = true)))
        assertFalse(a.fin); assertEquals(WsFrames.OP_TEXT, a.opcode); assertTrue(b.fin); assertEquals(WsFrames.OP_CONT, b.opcode)
    }

    @Test fun oversizedAndTruncatedFramesAreRejected() {
        assertThrows(IOException::class.java) { WsFrames.read(ByteArrayInputStream(WsFrames.encode(WsFrames.OP_TEXT, ByteArray(300), false)), maxPayload = 100) }
        val enc = WsFrames.encode(WsFrames.OP_TEXT, ByteArray(50), false)
        assertThrows(IOException::class.java) { WsFrames.read(ByteArrayInputStream(enc.copyOf(20))) }
        assertThrows(IOException::class.java) { WsFrames.read(ByteArrayInputStream(ByteArray(0))) }
    }
}
