package com.shyfr.app

import com.google.crypto.tink.subtle.X25519
import com.shyfr.app.net.Mailbox
import org.junit.Assert.*
import org.junit.Test

class MailboxKeyTest {
    private val aPriv = X25519.generatePrivateKey(); private val aPub = X25519.publicFromPrivate(aPriv)
    private val bPriv = X25519.generatePrivateKey(); private val bPub = X25519.publicFromPrivate(bPriv)

    @Test fun senderAndRecipientDeriveTheSameBoxKey() {
        val sendAB = Mailbox.deriveBoxKey(aPriv, aPub, bPub, outgoing = true)   // A pisze do B
        val recvAtB = Mailbox.deriveBoxKey(bPriv, bPub, aPub, outgoing = false) // B odbiera od A
        assertArrayEquals(sendAB.publicKey, recvAtB.publicKey)
        assertArrayEquals(sendAB.privateKey, recvAtB.privateKey)
    }

    @Test fun directionsAreSeparate() {
        val ab = Mailbox.deriveBoxKey(aPriv, aPub, bPub, outgoing = true)
        val ba = Mailbox.deriveBoxKey(aPriv, aPub, bPub, outgoing = false)
        assertFalse(ab.publicKey.contentEquals(ba.publicKey))
        val recvAtA = Mailbox.deriveBoxKey(bPriv, bPub, aPub, outgoing = true) // B pisze do A
        assertArrayEquals(ba.publicKey, recvAtA.publicKey)
    }

    @Test fun thirdPartyCannotDeriveIt() {
        val cPriv = X25519.generatePrivateKey(); val cPub = X25519.publicFromPrivate(cPriv)
        val ab = Mailbox.deriveBoxKey(aPriv, aPub, bPub, outgoing = true)
        val guess = Mailbox.deriveBoxKey(cPriv, cPub, bPub, outgoing = true)
        assertFalse(ab.publicKey.contentEquals(guess.publicKey))
    }
}
