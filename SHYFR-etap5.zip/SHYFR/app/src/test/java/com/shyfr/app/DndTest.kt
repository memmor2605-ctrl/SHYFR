package com.shyfr.app

import com.shyfr.app.session.Dnd
import org.junit.Assert.*
import org.junit.Test

class DndTest {
    @Test fun windowAcrossMidnight() {
        assertTrue(Dnd.isQuiet(23, 22, 7)); assertTrue(Dnd.isQuiet(0, 22, 7)); assertTrue(Dnd.isQuiet(6, 22, 7)); assertTrue(Dnd.isQuiet(22, 22, 7))
        assertFalse(Dnd.isQuiet(7, 22, 7)); assertFalse(Dnd.isQuiet(12, 22, 7)); assertFalse(Dnd.isQuiet(21, 22, 7))
    }
    @Test fun windowWithinOneDay() {
        assertTrue(Dnd.isQuiet(13, 12, 14)); assertFalse(Dnd.isQuiet(14, 12, 14)); assertFalse(Dnd.isQuiet(11, 12, 14))
    }
    @Test fun emptyWindowIsNeverQuiet() { for (h in 0..23) assertFalse(Dnd.isQuiet(h, 8, 8)) }
}
