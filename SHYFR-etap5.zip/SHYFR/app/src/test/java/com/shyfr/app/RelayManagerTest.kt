package com.shyfr.app

import com.shyfr.app.nostr.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.junit.After
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

enum class Mode { OK, DEAD, SILENT, AUTH, REJECT, NO_OK, SLOW_AFTER_PROBE }

class FakeRelay(val url: String, @Volatile var mode: Mode = Mode.OK) {
    val events = ConcurrentHashMap<String, NostrEvent>()
    val connects = AtomicInteger()
    val reqs = AtomicInteger()
    val links = CopyOnWriteArrayList<FakeLink>()
}

class FakeLink(private val relay: FakeRelay) : RelayLink {
    private val ch = Channel<String>(Channel.UNLIMITED)
    override val url get() = relay.url
    override val incoming: ReceiveChannel<String> get() = ch
    private fun matches(f: org.json.JSONObject, e: NostrEvent): Boolean {
        f.optJSONArray("kinds")?.let { k -> if ((0 until k.length()).none { k.getInt(it) == e.kind }) return false }
        f.optJSONArray("authors")?.let { a -> if ((0 until a.length()).none { a.getString(it) == e.pubkey }) return false }
        f.optJSONArray("#t")?.let { a -> if ((0 until a.length()).none { a.getString(it) in e.tagValues("t") }) return false }
        if (f.has("since") && e.createdAt < f.getLong("since")) return false
        if (f.has("until") && e.createdAt > f.getLong("until")) return false
        return true
    }
    override suspend fun send(text: String) {
        val a = JSONArray(text)
        when (a.getString(0)) {
            "REQ" -> {
                val n = relay.reqs.incrementAndGet(); val sub = a.getString(1)
                when {
                    relay.mode == Mode.SILENT -> {}
                    relay.mode == Mode.SLOW_AFTER_PROBE && n > 1 -> {}
                    relay.mode == Mode.AUTH -> ch.trySend("[\"CLOSED\",\"$sub\",\"auth-required: log in\"]")
                    else -> {
                        val filters = (2 until a.length()).map { a.getJSONObject(it) }
                        relay.events.values.filter { e -> filters.any { matches(it, e) } }.sortedByDescending { it.createdAt }.forEach { ch.trySend("[\"EVENT\",\"$sub\",${it.toWireJson()}]") }
                        ch.trySend("[\"EOSE\",\"$sub\"]")
                    }
                }
            }
            "EVENT" -> {
                val e = NostrWire.eventFrom(a.getJSONObject(1))!!
                when (relay.mode) {
                    Mode.REJECT -> ch.trySend("[\"OK\",\"${e.id}\",false,\"blocked: not allowed\"]")
                    Mode.NO_OK -> {}
                    else -> { relay.events[e.id] = e; ch.trySend("[\"OK\",\"${e.id}\",true,\"\"]") }
                }
            }
        }
    }
    override fun close() { ch.close() }
    fun drop() { ch.close() }
}

class FakeConnector(val relays: Map<String, FakeRelay>) : RelayConnector {
    override suspend fun connect(url: String): RelayLink {
        val r = relays[url] ?: throw IOException("nieznany")
        r.connects.incrementAndGet()
        if (r.mode == Mode.DEAD) throw IOException("martwy")
        return FakeLink(r).also { r.links.add(it) }
    }
}

class MemMem(var urls: List<String> = emptyList()) : RelayMemory {
    override fun load() = urls
    override fun save(urls: List<String>) { this.urls = urls }
}

class RelayManagerTest {
    private val cfg = RelayConfig(target = 4, connectTimeoutMs = 600, probeTimeoutMs = 300, publishTimeoutMs = 300, queryTimeoutMs = 600, backoffBaseMs = 50, backoffMaxMs = 400, healthIntervalMs = 100_000)
    private val managers = ArrayList<RelayManager>()
    private val sk = NostrEvent.unhex("0000000000000000000000000000000000000000000000000000000000000003")

    @After fun tearDown() { managers.forEach { it.shutdown() } }

    private fun urls(n: Int) = (1..n).map { "wss://r$it.test" }
    private fun net(n: Int, modes: Map<Int, Mode> = emptyMap()) = urls(n).withIndex().associate { (i, u) -> u to FakeRelay(u, modes[i + 1] ?: Mode.OK) }
    private fun mgr(net: Map<String, FakeRelay>, mem: MemMem = MemMem(), c: RelayConfig = cfg) =
        RelayManager(net.keys.toList(), FakeConnector(net), mem, c, rnd = java.util.Random(7)).also { managers.add(it) }
    private fun note(text: String, ts: Long, tag: String = "shyfr") = NostrEvent.create(sk, 1, listOf(listOf("t", tag)), text, ts, ByteArray(32))
    private suspend fun waitUntil(ms: Long = 1500, cond: () -> Boolean) { val end = System.currentTimeMillis() + ms; while (!cond() && System.currentTimeMillis() < end) delay(10) }

    @Test fun connectsToTheTargetNumberOfIndependentRelays() = runBlocking {
        val n = net(8); val m = mgr(n); m.ensure()
        assertEquals(4, m.connectedUrls().size)
        assertEquals(NetState.ONLINE, m.status.value.state)
    }

    @Test fun skipsDeadSilentAndLoginRequiredRelays() = runBlocking {
        val n = net(8, mapOf(1 to Mode.DEAD, 2 to Mode.DEAD, 3 to Mode.DEAD, 4 to Mode.AUTH, 5 to Mode.SILENT))
        val m = mgr(n); m.ensure()
        assertEquals(setOf("wss://r6.test", "wss://r7.test", "wss://r8.test"), m.connectedUrls().toSet())
        val authBefore = n["wss://r4.test"]!!.connects.get()
        m.ensure()
        assertEquals("przekaźnik wymagający logowania nie jest ponawiany", authBefore, n["wss://r4.test"]!!.connects.get())
    }

    @Test fun worksWithOnlyOneRelayAlive() = runBlocking {
        val n = net(5, mapOf(1 to Mode.DEAD, 2 to Mode.DEAD, 3 to Mode.DEAD, 4 to Mode.DEAD))
        val m = mgr(n); m.ensure()
        assertEquals(listOf("wss://r5.test"), m.connectedUrls())
    }

    @Test fun replacesARelayThatDrops() = runBlocking {
        val n = net(6); val m = mgr(n, c = cfg.copy(target = 3)); m.ensure()
        val before = m.connectedUrls().toSet(); assertEquals(3, before.size)
        val victim = before.first(); n[victim]!!.links.forEach { it.drop() }
        waitUntil { m.connectedUrls().size < 3 }
        m.ensure()
        assertEquals(3, m.connectedUrls().size)
        assertFalse("zamiast upuszczonego wybrany jest inny", victim in m.connectedUrls())
    }

    @Test fun recoversAutomaticallyWhenRelaysComeBack() = runBlocking {
        val n = net(3, mapOf(1 to Mode.DEAD, 2 to Mode.DEAD, 3 to Mode.DEAD)); val m = mgr(n); m.ensure()
        assertEquals(NetState.OFFLINE, m.status.value.state)
        n.values.forEach { it.mode = Mode.OK }
        delay(120)   // dłużej niż opóźnienie ponowienia
        m.ensure()
        assertEquals(NetState.ONLINE, m.status.value.state); assertEquals(3, m.connectedUrls().size)
    }

    @Test fun rememberedRelaysAreTriedFirst() = runBlocking {
        val n = net(8); val mem = MemMem(listOf("wss://r3.test", "wss://r5.test"))
        val m = mgr(n, mem, cfg.copy(target = 2)); m.ensure()
        assertEquals(setOf("wss://r3.test", "wss://r5.test"), m.connectedUrls().toSet())
        assertTrue(mem.urls.containsAll(listOf("wss://r3.test", "wss://r5.test")))
    }

    @Test fun networkChangeReconnectsWithoutWaiting() = runBlocking {
        val n = net(4); val m = mgr(n); m.ensure()
        m.networkChanged()
        assertEquals(0, m.connectedUrls().size)
        m.ensure()
        assertEquals(4, m.connectedUrls().size)
        assertTrue(n.values.all { it.connects.get() >= 2 })
    }

    @Test fun publishSucceedsOnPartialFailureAndReportsExactCounts() = runBlocking {
        val n = net(3, mapOf(2 to Mode.NO_OK)); val m = mgr(n); m.ensure()
        n["wss://r3.test"]!!.mode = Mode.REJECT
        val e = note("witaj", 1000)
        val r = m.publish(e)
        assertTrue(r.success); assertEquals(1, r.accepted); assertEquals(1, r.rejected); assertEquals(1, r.noAnswer); assertEquals(3, r.attempted)
        assertTrue(n["wss://r1.test"]!!.events.containsKey(e.id)); assertFalse(n["wss://r3.test"]!!.events.containsKey(e.id))
    }

    @Test fun publishFailsWhenEveryRelayRejects() = runBlocking {
        val n = net(3); val m = mgr(n); m.ensure(); n.values.forEach { it.mode = Mode.REJECT }
        val r = m.publish(note("x", 1))
        assertFalse(r.success); assertEquals(0, r.accepted); assertEquals(3, r.rejected)
    }

    @Test fun publishWithoutAnyConnectionIsNotReportedAsSuccess() = runBlocking {
        val n = net(3, mapOf(1 to Mode.DEAD, 2 to Mode.DEAD, 3 to Mode.DEAD)); val m = mgr(n)
        val r = m.publish(note("x", 1))
        assertTrue(r.noConnection); assertFalse(r.success)
    }

    @Test fun queryDeduplicatesAndDropsForgedEvents() = runBlocking {
        val n = net(3); val m = mgr(n); m.ensure()
        val real = note("prawdziwy", 2000)
        n.values.forEach { it.events[real.id] = real }
        val forged = real.copy(id = NostrEvent.computeId(real.pubkey, 2001, 1, real.tags, "podrobiony"), createdAt = 2001, content = "podrobiony")  // zły podpis
        n["wss://r2.test"]!!.events[forged.id] = forged
        val res = m.query(listOf(Filter(kinds = listOf(1), limit = 10)))
        assertEquals(listOf(real.id), res.events.map { it.id })
        assertEquals(3, res.asked); assertEquals(3, res.answered)
    }

    @Test fun queryMergesDifferentEventsFromDifferentRelaysNewestFirst() = runBlocking {
        val n = net(3); val m = mgr(n); m.ensure()
        val a = note("a", 100); val b = note("b", 300); val c = note("c", 200)
        n["wss://r1.test"]!!.events[a.id] = a; n["wss://r2.test"]!!.events[b.id] = b; n["wss://r3.test"]!!.events[c.id] = c
        assertEquals(listOf(b.id, c.id, a.id), m.query(listOf(Filter(kinds = listOf(1)))).events.map { it.id })
    }

    @Test fun queryAppliesFiltersAndToleratesASlowRelay() = runBlocking {
        val n = net(3, mapOf(3 to Mode.SLOW_AFTER_PROBE)); val m = mgr(n); m.ensure()
        val mine = note("tag", 10, "shyfr"); val other = note("inny", 11, "inne")
        n.values.forEach { it.events[mine.id] = mine; it.events[other.id] = other }
        val res = m.query(listOf(Filter(kinds = listOf(1), tags = mapOf("t" to listOf("shyfr")))))
        assertEquals(listOf(mine.id), res.events.map { it.id })
        assertEquals(3, res.asked); assertEquals(2, res.answered)
    }

    @Test fun diagnosticsExplainWhyARelayWasNotUsed() = runBlocking {
        val n = net(4, mapOf(1 to Mode.DEAD, 2 to Mode.AUTH, 3 to Mode.SILENT)); val m = mgr(n); m.ensure()
        val d = m.diagnostics().associateBy { it.url }
        assertTrue(d["wss://r4.test"]!!.connected)
        assertEquals("martwy", d["wss://r1.test"]!!.lastError)
        assertTrue(d["wss://r2.test"]!!.banned); assertTrue(d["wss://r2.test"]!!.lastError.contains("logowania"))
        assertTrue(d["wss://r3.test"]!!.lastError.contains("odpowiedzi"))
        assertEquals("połączony przekaźnik jest pierwszy", "wss://r4.test", m.diagnostics().first().url)
    }

    @Test fun backoffGrowsAndIsCapped() {
        val m = mgr(net(1))
        assertEquals(0L, m.backoffMs(0))
        assertTrue(m.backoffMs(1) in 50L..60L); assertTrue(m.backoffMs(3) in 200L..240L)
        assertTrue(m.backoffMs(40) in 400L..480L)
        assertTrue(m.backoffMs(2) > m.backoffMs(1) / 2)
    }

    @Test fun wireParsingToleratesGarbage() {
        assertNull(NostrWire.parse("nie json")); assertNull(NostrWire.parse("[]")); assertNull(NostrWire.parse("[\"EVENT\",\"s\",{}]"))
        assertEquals(RelayMsg.Eose("s"), NostrWire.parse("[\"EOSE\",\"s\"]"))
        assertEquals(RelayMsg.Ok("i", true, ""), NostrWire.parse("[\"OK\",\"i\",true]"))
        assertEquals(RelayMsg.Closed("s", "auth-required: x"), NostrWire.parse("[\"CLOSED\",\"s\",\"auth-required: x\"]"))
        val e = note("hej", 5)
        assertEquals(e, (NostrWire.parse("[\"EVENT\",\"s\",${e.toWireJson()}]") as RelayMsg.Event).ev)
    }

    @Test fun filterJson() {
        assertEquals("{\"kinds\":[1],\"limit\":5,\"#t\":[\"shyfr\"]}", Filter(kinds = listOf(1), limit = 5, tags = mapOf("t" to listOf("shyfr"))).toJson())
        assertEquals("[\"REQ\",\"x\",{\"kinds\":[0]},{\"kinds\":[3]}]", NostrWire.reqMsg("x", listOf(Filter(kinds = listOf(0)), Filter(kinds = listOf(3)))))
    }
}
