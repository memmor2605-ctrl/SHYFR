package com.shyfr.app

import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Ed25519Verify
import com.shyfr.app.feed.PublicKeys
import com.shyfr.app.feed.PublicProto
import org.junit.Assert.*
import org.junit.Test

/** Wektory testowe wygenerowane przez relay/shyfr_relay.py (Python) — zgodność klient ↔ przekaźnik. */
class PublicProtoTest {
    private val msg = PublicProto.sigMsg("post.create", "0123456789abcdef", "ogólny", "post", "", "", "Cześć #SHYFR", "", "1700000000000")

    @Test fun sigMsgMatchesPython() {
        assertEquals("SHYFR1|post.create|MDEyMzQ1Njc4OWFiY2RlZg|b2fDs2xueQ|cG9zdA|||Q3plxZvEhyAjU0hZRlI||MTcwMDAwMDAwMDAwMA", String(msg, Charsets.UTF_8))
    }

    @Test fun ed25519MatchesPythonVector() {
        val seed = ByteArray(32) { it.toByte() }
        val kp = Ed25519Sign.KeyPair.newKeyPairFromSeed(seed)
        assertEquals("03a107bff3ce10be1d70dd18e74bc09967e4d6309ba50d5f1ddc8664125531b8", PublicProto.hex(kp.publicKey))
        val sig = PublicKeys.sign(kp, msg)
        assertEquals("bd918f10981a7d1c4429d81d40f27639c21c42afedcca6d8c2d52a269ad150dee2ffeea3e7cab4d7618bc85e5ed19b8beee0459853b022ace97c461208ef1703", PublicProto.hex(sig))
        Ed25519Verify(kp.publicKey).verify(sig, msg)
    }

    @Test fun powMatchesPython() {
        assertEquals(1051L, PublicProto.solvePow(msg, 10))
        assertTrue(PublicProto.powOk(msg, 1051L, 10))
        assertFalse(PublicProto.powOk(msg, 1050L, 10))
    }

    @Test fun keysAreDeterministicAndSeparatedPerCommunity() {
        val master = ByteArray(32) { (it * 7).toByte() }
        val a1 = PublicKeys.derive(master, "relay.onion", "aaaaaaaaaaaaaaaa", 0)
        val a2 = PublicKeys.derive(master, "relay.onion", "aaaaaaaaaaaaaaaa", 0)
        val b = PublicKeys.derive(master, "relay.onion", "bbbbbbbbbbbbbbbb", 0)
        val a1new = PublicKeys.derive(master, "relay.onion", "aaaaaaaaaaaaaaaa", 1)
        val other = PublicKeys.derive(master, "inny.onion", "aaaaaaaaaaaaaaaa", 0)
        assertArrayEquals(a1.publicKey, a2.publicKey)
        assertFalse(a1.publicKey.contentEquals(b.publicKey))
        assertFalse(a1.publicKey.contentEquals(a1new.publicKey))
        assertFalse(a1.publicKey.contentEquals(other.publicKey))
        // klucz nie zawiera surowego klucza sejfu
        assertFalse(PublicProto.hex(a1.privateKey).contains(PublicProto.hex(master)))
    }

    @Test fun inviteParsing() {
        assertEquals("0123456789abcdef" to "ABCD1234efgh", PublicProto.parseInvite("shyfr-c:0123456789abcdef:ABCD1234efgh"))
        assertEquals("0123456789abcdef" to "", PublicProto.parseInvite(" 0123456789abcdef "))
        assertNull(PublicProto.parseInvite("shyfr-c:zzz:abc"))
    }

    @Test fun onionNormalization() {
        val onion = "a".repeat(56) + ".onion"
        assertEquals(onion, PublicProto.normalizeOnion("http://" + onion.uppercase() + "/"))
        assertNull(PublicProto.normalizeOnion("example.com"))
        assertNull(PublicProto.normalizeOnion("abc.onion"))
    }
}
