package com.shyfr.app

import com.shyfr.app.nostr.NostrEvent
import org.junit.Assert.*
import org.junit.Test

class NostrEventTest {
    private val pub = "f9308a019258c31049344f85f89d5229b531c845836f99b08601f113bce036f9"
    private val tags = listOf(listOf("t", "shyfr"), listOf("e", "ab".repeat(32)))
    private val content = "Cześć \"świat\"\nlinia2\t\\ \u0001 koniec"

    // Identyfikator i podpis policzone niezależnie w Pythonie z regułami NIP-01
    private val expectedId = "637d608c311a0f6df88f0e58652cefe677a098a209fca2600e7e993354625ce3"
    private val expectedSig = "e256fb80a91c337ebe9783c291f27684e4a86c8e4c34474bcadd0175ef94601c3ae3ce07492677dbcd016f19175eee0a00790cfb39626818373c4e077c9b2ffe"

    @Test fun idMatchesIndependentComputation() =
        assertEquals(expectedId, NostrEvent.computeId(pub, 1700000000, 1, tags, content))

    @Test fun createdEventIsDeterministicWithFixedAux() {
        val sk = NostrEvent.unhex("0000000000000000000000000000000000000000000000000000000000000003")
        val e = NostrEvent.create(sk, 1, tags, content, 1700000000, ByteArray(32))
        assertEquals(expectedId, e.id); assertEquals(expectedSig, e.sig); assertEquals(pub, e.pubkey)
        assertTrue(e.isValid())
    }

    @Test fun eventFromOtherImplementationVerifies() =
        assertTrue(NostrEvent(expectedId, pub, 1700000000, 1, tags, content, expectedSig).isValid())

    @Test fun anyChangeInvalidatesTheEvent() {
        val e = NostrEvent(expectedId, pub, 1700000000, 1, tags, content, expectedSig)
        assertFalse(e.copy(content = content + "!").isValid())
        assertFalse(e.copy(createdAt = 1700000001).isValid())
        assertFalse(e.copy(kind = 7).isValid())
        assertFalse(e.copy(tags = emptyList()).isValid())
        assertFalse(e.copy(sig = expectedSig.replaceRange(0, 2, "00")).isValid())
        assertFalse(e.copy(id = "00".repeat(32)).isValid())
        assertFalse(e.copy(pubkey = "zz").isValid())      // zły hex nie może wywrócić aplikacji
    }

    @Test fun serializationUsesOnlyNip01Escapes() {
        val s = NostrEvent.serializeForId(pub, 1, 1, emptyList(), "a\"b\\c\nd\re\tf\bg\u000Ch\u0001")
        assertTrue(s.endsWith("\"a\\\"b\\\\c\\nd\\re\\tf\\bg\\fh\u0001\"]"))
    }

    @Test fun wireJsonIsEscapedForAnyParser() {
        val j = NostrEvent(expectedId, pub, 1700000000, 1, tags, content, expectedSig).toWireJson()
        assertTrue(j.contains("\\u0001")); assertFalse(j.contains("\u0001"))
        assertTrue(j.startsWith("{\"id\":\"$expectedId\"")); assertTrue(j.contains("\"created_at\":1700000000"))
    }

    @Test fun tagValues() = assertEquals(listOf("shyfr"), NostrEvent(expectedId, pub, 1, 1, tags, "", expectedSig).tagValues("t"))
}
