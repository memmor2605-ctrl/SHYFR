package com.shyfr.app

import com.shyfr.app.session.Prefs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BridgeParseTest {
    @Test fun acceptsPlainBridge() {
        val (lines, err) = Prefs.parseBridges("bridge 1.2.3.4:443 0123456789ABCDEF0123456789ABCDEF01234567")
        assertEquals(1, lines.size); assertEquals(null, err)
    }
    @Test fun rejectsInjection() {
        val (lines, err) = Prefs.parseBridges("1.2.3.4:443\nUseBridges 0")
        assertTrue(lines.isEmpty()); assertNotNull(err)
    }
    @Test fun rejectsPluggableTransports() {
        assertNotNull(Prefs.parseBridges("obfs4 1.2.3.4:443").second)
    }
}
