package com.shyfr.app

import com.shyfr.app.nostr.NostrEvent
import com.shyfr.app.nostr.NostrKeys
import com.shyfr.app.nostr.Schnorr
import org.junit.Assert.*
import org.junit.Test

class SchnorrTest {
    private fun h(s: String) = NostrEvent.unhex(s.lowercase())

    // Oficjalne wektory BIP-340 (0 i 1)
    @Test fun bip340Vector0() {
        val sk = h("0000000000000000000000000000000000000000000000000000000000000003")
        assertEquals("f9308a019258c31049344f85f89d5229b531c845836f99b08601f113bce036f9", NostrEvent.hex(Schnorr.publicKey(sk)))
        val sig = Schnorr.sign(ByteArray(32), sk, ByteArray(32))
        val exp = "e907831f80848d1069a5371b402410364bdf1c5f8307b0084c55f1ce2dca821525f66a4a85ea8b71e482a74f382d2ce5ebeee8fdb2172f477df4900d310536c0"
        assertEquals(exp, NostrEvent.hex(sig))
        assertTrue(Schnorr.verify(ByteArray(32), h("f9308a019258c31049344f85f89d5229b531c845836f99b08601f113bce036f9"), h(exp)))
    }

    @Test fun bip340Vector1() {
        val sk = h("B7E151628AED2A6ABF7158809CF4F3C762E7160F38B4DA56A784D9045190CFEF")
        val msg = h("243F6A8885A308D313198A2E03707344A4093822299F31D0082EFA98EC4E6C89")
        val aux = h("0000000000000000000000000000000000000000000000000000000000000001")
        val exp = "6896bd60eeae296db48a229ff71dfe071bde413e6d43f917dc8dcf8c78de33418906d11ac976abccb20b091292bff4ea897efcb639ea871cfa95f6de339e4b0a"
        assertEquals("dff1d77f2a671c5f36183726db2341be58feae1da2deced843240f7b502ba659", NostrEvent.hex(Schnorr.publicKey(sk)))
        assertEquals(exp, NostrEvent.hex(Schnorr.sign(msg, sk, aux)))
        assertTrue(Schnorr.verify(msg, Schnorr.publicKey(sk), h(exp)))
    }

    // Wynik policzony niezależną implementacją w Pythonie (sprawdzoną na tych samych wektorach)
    @Test fun crossCheckedWithPythonImplementation() {
        val sk = h("0000000000000000000000000000000000000000000000000000000000000007")
        val msg = h("65f90dc65e8904c73cd77feea31cbb91b2a87256398e776786ac303d3e408379")
        assertEquals("5cbdf0646e5db4eaa398f365f2ea7a0e3d419b7e0330e39ce92bddedcac4f9bc", NostrEvent.hex(Schnorr.publicKey(sk)))
        assertEquals("6fd26bc73b4cac014c4b9acfc7ad0118e9fef239898200022496fbf87bc8e489cd15386a5355c5d19e4736fd9f11ba6b9c5dcd0b053615d0231bb3e4b8e15e3e",
            NostrEvent.hex(Schnorr.sign(msg, sk, ByteArray(32))))
    }

    @Test fun tamperedSignatureOrMessageFails() {
        val sk = h("0000000000000000000000000000000000000000000000000000000000000003")
        val pub = Schnorr.publicKey(sk); val msg = ByteArray(32) { it.toByte() }
        val sig = Schnorr.sign(msg, sk)
        assertTrue(Schnorr.verify(msg, pub, sig))
        val bad = sig.copyOf(); bad[40] = (bad[40].toInt() xor 1).toByte()
        assertFalse(Schnorr.verify(msg, pub, bad))
        assertFalse(Schnorr.verify(ByteArray(32) { 1 }, pub, sig))
        assertFalse(Schnorr.verify(msg, Schnorr.publicKey(h("0000000000000000000000000000000000000000000000000000000000000005")), sig))
        assertFalse(Schnorr.verify(msg, pub, sig.copyOf(63)))
        assertFalse(Schnorr.verify(msg, ByteArray(32) { 0xFF.toByte() }, sig))   // x poza krzywą / >= p
    }

    @Test fun invalidSecretsAreRejected() {
        assertFalse(Schnorr.isValidSecret(ByteArray(32)))
        assertFalse(Schnorr.isValidSecret(Schnorr.N.toByteArray().let { b -> ByteArray(32).also { System.arraycopy(b, b.size - 32, it, 0, 32) } }))
        assertFalse(Schnorr.isValidSecret(ByteArray(31) { 1 }))
        assertTrue(Schnorr.isValidSecret(ByteArray(32) { 1 }))
    }

    @Test fun nostrKeysAreDeterministicAndPerIdentity() {
        val m = ByteArray(32) { it.toByte() }
        assertArrayEquals(NostrKeys.secretFor(m, "pub", 0), NostrKeys.secretFor(m, "pub", 0))
        assertFalse(NostrKeys.secretFor(m, "pub", 0).contentEquals(NostrKeys.secretFor(m, "anon", 0)))
        assertFalse(NostrKeys.secretFor(m, "anon", 0).contentEquals(NostrKeys.secretFor(m, "anon", 1)))
        assertTrue(Schnorr.isValidSecret(NostrKeys.secretFor(m, "prv", 3)))
    }
}
