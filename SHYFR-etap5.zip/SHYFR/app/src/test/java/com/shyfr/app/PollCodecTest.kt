package com.shyfr.app

import com.shyfr.app.net.PollCodec
import org.junit.Assert.*
import org.junit.Test

class PollCodecTest {
    @Test fun roundTrip() {
        val body = PollCodec.encode("Kiedy się spotykamy?", listOf("Piątek", "Sobota", " Niedziela "))!!
        assertEquals("Kiedy się spotykamy?" to listOf("Piątek", "Sobota", "Niedziela"), PollCodec.decode(body))
        assertTrue(body.startsWith("📊"))
    }

    @Test fun plainTextIsNeverTreatedAsPoll() {
        assertNull(PollCodec.decode("📊 pytanie\nA\nB"))   // bez znaku zerowej szerokości
        assertNull(PollCodec.decode("zwykła wiadomość\nz kilkoma\nliniami"))
    }

    @Test fun validation() {
        assertNull(PollCodec.encode("", listOf("A", "B")))
        assertNull(PollCodec.encode("Q", listOf("A")))
        assertNull(PollCodec.encode("Q", listOf("A", "A")))                       // powtórzone opcje
        assertNull(PollCodec.encode("Q", (1..7).map { "o$it" }))                  // za dużo opcji
        assertNull(PollCodec.encode("Q", listOf("A", "x".repeat(61))))            // za długa opcja
        assertNull(PollCodec.encode("q".repeat(201), listOf("A", "B")))
        assertNotNull(PollCodec.encode("Q", (1..6).map { "o$it" }))
    }

    @Test fun newlinesInsideFieldsCannotInjectOptions() {
        val body = PollCodec.encode("Q\nfałszywa opcja", listOf("A", "B"))!!
        assertEquals(2, PollCodec.decode(body)!!.second.size)
    }
}
