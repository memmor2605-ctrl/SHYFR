package com.shyfr.app

import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Ed25519Verify
import com.shyfr.app.account.AccountCrypto
import org.junit.Assert.*
import org.junit.Test

class AccountCryptoTest {
    private val root = ByteArray(32) { (it * 7).toByte() }
    private val master = ByteArray(32) { (255 - it).toByte() }

    @Test fun sealAndOpenRoundTrip() {
        val k = AccountCrypto.keysFromRoot(root)
        val blob = AccountCrypto.seal(master, k, 1)
        assertArrayEquals(master, AccountCrypto.open(blob, k, 1))
    }

    @Test fun wrongPasswordCannotOpen() {
        val blob = AccountCrypto.seal(master, AccountCrypto.keysFromRoot(root), 1)
        val other = AccountCrypto.keysFromRoot(ByteArray(32) { 9 })
        assertNull(AccountCrypto.open(blob, other, 1))
    }

    @Test fun versionAndTamperingAreDetected() {
        val k = AccountCrypto.keysFromRoot(root)
        val blob = AccountCrypto.seal(master, k, 3)
        assertNull(AccountCrypto.open(blob, k, 4))
        val raw = java.util.Base64.getUrlDecoder().decode(blob); raw[raw.size - 1] = (raw[raw.size - 1].toInt() xor 1).toByte()
        assertNull(AccountCrypto.open(java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(raw), k, 3))
        assertNull(AccountCrypto.open("nie-koperta", k, 3))
        assertNull(AccountCrypto.open("", k, 3))
    }

    @Test fun envelopeNeverContainsThePlainMasterKey() {
        val k = AccountCrypto.keysFromRoot(root)
        val raw = java.util.Base64.getUrlDecoder().decode(AccountCrypto.seal(master, k, 1))
        val hex = raw.joinToString("") { "%02x".format(it) }
        assertFalse(hex.contains(master.joinToString("") { "%02x".format(it) }))
    }

    @Test fun nonceIsFreshForEverySeal() =
        assertNotEquals(AccountCrypto.seal(master, AccountCrypto.keysFromRoot(root), 1), AccountCrypto.seal(master, AccountCrypto.keysFromRoot(root), 1))

    @Test fun derivedValuesAreIndependentAndDeterministic() {
        val a = AccountCrypto.keysFromRoot(root); val b = AccountCrypto.keysFromRoot(root)
        assertEquals(a.lookup, b.lookup); assertArrayEquals(a.wrapKey, b.wrapKey); assertArrayEquals(a.signing.publicKey, b.signing.publicKey)
        assertEquals(64, a.lookup.length)
        assertFalse(a.wrapKey.contentEquals(a.signing.privateKey))
        assertNotEquals(a.lookup, AccountCrypto.keysFromRoot(ByteArray(32) { 1 }).lookup)
    }

    @Test fun signingKeyWorks() {
        val k = AccountCrypto.keysFromRoot(root); val m = "x".toByteArray()
        Ed25519Verify(k.signing.publicKey).verify(Ed25519Sign(k.signing.privateKey).sign(m), m)
    }

    @Test fun saltDependsOnlyOnNormalizedLogin() {
        assertArrayEquals(AccountCrypto.saltFor("Ala "), AccountCrypto.saltFor("ala"))
        assertFalse(AccountCrypto.saltFor("ala").contentEquals(AccountCrypto.saltFor("ola")))
        assertEquals(16, AccountCrypto.saltFor("ala").size)
    }

    @Test fun passwordStrengthRules() {
        fun p(s: String, login: String = "ala") = AccountCrypto.strengthProblem(s.toCharArray(), login)
        assertNotNull(p("krótkie1A!"))
        assertNotNull(p("aaaaaaaaaaaaaaaa"))
        assertNotNull(p("passwordpassword"))
        assertNotNull(p("xxalaxx-Hasło-123", "alaxx"))
        assertNotNull(p("tylkomałelitery"))                // 15 znaków, jedna klasa
        assertNull(p("tylkomałelitery-i-dłuższe"))         // 16+ znaków
        assertNull(p("Kot-Pije-Mleko-7"))
    }
}
