package com.shyfr.app.session

import android.content.Context
import com.shyfr.app.Trace
import com.shyfr.app.net.NodeService
import com.shyfr.app.net.NodeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/**
 * Wspólny sygnał blokady. Dwa tryby:
 *  - blokada ekranu (domyślnie, gdy włączone „Tor w tle”): interfejs wraca do logowania, ale Tor i odbiór wiadomości
 *    działają dalej, więc znajomy widzi Cię jako online. Klucz zostaje w RAM procesu.
 *  - pełna blokada (full = true albo wyłączone „Tor w tle”): klucz znika z RAM, Tor się zatrzymuje.
 */
object AppState {
    val lockTick = MutableStateFlow(0)
    fun lock(ctx: Context, full: Boolean = false) {
        val keepNode = !full && Prefs.bgNode(ctx) && Session.get() != null && NodeService.state.value !is NodeState.Stopped
        Trace.log(if (keepNode) "lock: ekran zablokowany, węzeł działa w tle" else "lock: pełna blokada, zatrzymuję Tora (full=$full)")
        if (!keepNode) { Session.clear(); NodeService.stop(ctx) }
        lockTick.update { it + 1 }
    }
}
