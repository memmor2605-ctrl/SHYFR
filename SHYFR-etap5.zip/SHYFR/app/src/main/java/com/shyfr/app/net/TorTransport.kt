package com.shyfr.app.net

import java.net.Socket

/**
 * Jedyna warstwa dotykająca biblioteki Tor. Reszta aplikacji zna tylko ten interfejs,
 * więc zmiana biblioteki (tor-android -> Arti) dotyczy jednego pliku.
 */
interface TorTransport {
    /** Uruchamia Tora i zwraca stan postępu (0-100) przez callback. */
    suspend fun start(onProgress: (Int) -> Unit)

    /**
     * Publikuje usługę onion v3 kierującą wirtualny port [virtualPort] na lokalny [localPort].
     * [existingKey] = zapisany klucz prywatny (lub null przy pierwszym starcie).
     * Zwraca parę (adres .onion, klucz prywatny do zapisania).
     */
    suspend fun publishService(virtualPort: Int, localPort: Int, existingKey: String?): Pair<String, String>

    /** Łączy z innym użytkownikiem przez Tora (SOCKS). Rozwiązywanie nazw tylko w Torze. */
    suspend fun connect(onion: String, port: Int): Socket

    /** Wywoływane, gdy proces Tora zginie niespodziewanie (węzeł startuje wtedy od nowa). */
    var onDeath: (() -> Unit)?

    /** Czy Tor ma działające obwody (watchdog restartuje węzeł, gdy nie). */
    fun isHealthy(): Boolean

    /** Po zmianie sieci: kazuje Torowi porzucić stare obwody i zbudować nowe (SIGNAL NEWNET). Zwraca true, jeśli się udało. */
    fun newNetwork(): Boolean

    fun stop()
}
