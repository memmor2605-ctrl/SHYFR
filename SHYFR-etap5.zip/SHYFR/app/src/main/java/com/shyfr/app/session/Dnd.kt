package com.shyfr.app.session

/** Tryb „nie przeszkadzać”: w ustawionych godzinach aplikacja nie pokazuje powiadomień (wiadomości nadal dochodzą). */
object Dnd {
    /** Czy godzina [hour] (0-23) mieści się w oknie [start, end); okno może przechodzić przez północ (np. 22 → 7). */
    fun isQuiet(hour: Int, start: Int, end: Int): Boolean = when {
        start == end -> false
        start < end -> hour in start until end
        else -> hour >= start || hour < end
    }
}
