package com.shyfr.app.nostr

import android.content.Context
import com.shyfr.app.session.Session
import com.shyfr.app.social.IdentityKind
import com.shyfr.app.social.Rel
import com.shyfr.app.social.SocialIdentity
import com.shyfr.app.social.SocialStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

enum class FeedKind { SHYFR, FOLLOWING, ALL }
data class NostrProfile(val name: String, val about: String)
data class FeedPage(val notes: List<NostrEvent>, val asked: Int, val answered: Int)
data class Reactions(val count: Int, val mine: Boolean)
data class Published(val event: NostrEvent, val result: PublishResult)

/**
 * Publiczny feed na Nostr. Wpisy są PUBLICZNE: operatorzy przekaźników widzą treść i metadane, a Tor ukrywa tylko adres IP.
 * Każda tożsamość SHYFR ma własny klucz Nostr (wyprowadzany z klucza konta), więc anonimowa nie łączy się z publiczną.
 * Obserwowania wpisuje się do listy publicznej (NIP-02) tylko dla tożsamości publicznej; dla prywatnej i anonimowej lista zostaje lokalna.
 */
class NostrFeedRepo(private val ctx: Context, private val mgr: RelayManager) {
    private val store = SocialStore(ctx)
    private val profiles = HashMap<String, NostrProfile>()

    private fun secret(id: SocialIdentity): ByteArray = NostrKeys.secretFor(Session.get() ?: error("Konto zablokowane"), id.kind.code, id.idx)
    suspend fun pubOf(id: SocialIdentity): String = withContext(Dispatchers.Default) { NostrKeys.publicHex(secret(id)) }

    private val hashtag = Regex("(?<![\\p{L}\\p{N}_])#([\\p{L}\\p{N}_]{2,40})")

    private suspend fun sign(id: SocialIdentity, kind: Int, tags: List<List<String>>, content: String): NostrEvent =
        withContext(Dispatchers.Default) { NostrEvent.create(secret(id), kind, tags, content) }

    /** Reguły NIP-10: odpowiedź wskazuje wątek (root) i wpis, na który odpowiada (reply). */
    private fun replyTags(to: NostrEvent): List<List<String>> {
        val root = to.tags.firstOrNull { it.size >= 4 && it[0] == "e" && it[3] == "root" }?.get(1)
        return if (root == null) listOf(listOf("e", to.id, "", "root"), listOf("p", to.pubkey))
        else listOf(listOf("e", root, "", "root"), listOf("e", to.id, "", "reply"), listOf("p", to.pubkey))
    }

    suspend fun publishNote(id: SocialIdentity, text: String, replyTo: NostrEvent? = null): Published {
        val body = text.trim()
        require(body.isNotEmpty() && body.length <= 2000) { "Wpis ma od 1 do 2000 znaków." }
        val tags = ArrayList<List<String>>()
        tags += listOf("t", "shyfr"); tags += listOf("client", "SHYFR")
        hashtag.findAll(body).map { it.groupValues[1].lowercase() }.distinct().filter { it != "shyfr" }.take(10).forEach { tags += listOf("t", it) }
        if (replyTo != null) tags += replyTags(replyTo)
        val ev = sign(id, 1, tags, body)
        return Published(ev, mgr.publish(ev))
    }

    suspend fun feed(kind: FeedKind, id: SocialIdentity, until: Long? = null, limit: Int = 40): FeedPage {
        val base = when (kind) {
            FeedKind.SHYFR -> Filter(kinds = listOf(1), tags = mapOf("t" to listOf("shyfr")), until = until, limit = limit)
            FeedKind.ALL -> Filter(kinds = listOf(1), until = until, limit = limit)
            FeedKind.FOLLOWING -> {
                val authors = withContext(Dispatchers.IO) { store.peers(id.id, Rel.FOLLOW) }.take(200)
                if (authors.isEmpty()) return FeedPage(emptyList(), 0, 0)
                Filter(kinds = listOf(1), authors = authors, until = until, limit = limit)
            }
        }
        val r = mgr.query(listOf(base))
        val hidden = withContext(Dispatchers.IO) { (store.peers(id.id, Rel.BLOCK) + store.peers(id.id, Rel.MUTE)).toSet() }
        val notes = r.events.filter { e -> e.pubkey !in hidden && e.tags.none { it.firstOrNull() == "e" } }   // tylko wpisy główne, bez odpowiedzi
        return FeedPage(notes, r.asked, r.answered)
    }

    suspend fun replies(note: NostrEvent): List<NostrEvent> =
        mgr.query(listOf(Filter(kinds = listOf(1), tags = mapOf("e" to listOf(note.id)), limit = 100))).events
            .filter { e -> e.tags.any { it.size >= 2 && it[0] == "e" && it[1] == note.id } }.sortedBy { it.createdAt }

    suspend fun profiles(pubs: Collection<String>): Map<String, NostrProfile> {
        val need = pubs.filter { it !in profiles }.distinct().take(100)
        if (need.isNotEmpty()) {
            val ev = mgr.query(listOf(Filter(kinds = listOf(0), authors = need, limit = need.size * 2))).events
            ev.groupBy { it.pubkey }.forEach { (pub, list) ->
                val newest = list.maxByOrNull { it.createdAt } ?: return@forEach
                runCatching { JSONObject(newest.content) }.getOrNull()?.let { j ->
                    profiles[pub] = NostrProfile(j.optString("name").take(40), j.optString("about").take(300))
                }
            }
        }
        return pubs.mapNotNull { p -> profiles[p]?.let { p to it } }.toMap()
    }

    suspend fun setProfile(id: SocialIdentity, name: String, about: String): PublishResult {
        val content = JSONObject().put("name", name.trim().take(40)).put("about", about.trim().take(300)).toString()
        return mgr.publish(sign(id, 0, emptyList(), content)).also { if (it.success) profiles[pubOf(id)] = NostrProfile(name.trim(), about.trim()) }
    }

    suspend fun reactions(ids: List<String>, me: String): Map<String, Reactions> {
        if (ids.isEmpty()) return emptyMap()
        val ev = mgr.query(listOf(Filter(kinds = listOf(7), tags = mapOf("e" to ids.take(100)), limit = 500))).events.filter { it.content != "-" }
        val out = HashMap<String, Reactions>()
        for (id in ids) {
            val mine = ev.filter { e -> e.tags.any { it.size >= 2 && it[0] == "e" && it[1] == id } }
            out[id] = Reactions(mine.distinctBy { it.pubkey }.size, mine.any { it.pubkey == me })
        }
        return out
    }

    suspend fun react(id: SocialIdentity, note: NostrEvent): PublishResult =
        mgr.publish(sign(id, 7, listOf(listOf("e", note.id), listOf("p", note.pubkey)), "+"))

    fun isFollowing(id: SocialIdentity, pub: String) = store.has(id.id, pub, Rel.FOLLOW)

    /** Obserwowanie zapisuje się lokalnie; dla tożsamości publicznej także na liście publicznej (NIP-02). */
    suspend fun setFollow(id: SocialIdentity, pub: String, on: Boolean): PublishResult? {
        withContext(Dispatchers.IO) { store.setRel(id.id, pub, Rel.FOLLOW, on) }
        if (id.kind != IdentityKind.PUBLIC) return null
        val all = withContext(Dispatchers.IO) { store.peers(id.id, Rel.FOLLOW) }
        return mgr.publish(sign(id, 3, all.map { listOf("p", it) }, ""))
    }
}
