package com.shyfr.app.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.shyfr.app.Trace
import java.net.Inet6Address

/**
 * Obserwuje zmianę sieci (Wi-Fi ↔ komórkowa ↔ inne Wi-Fi). Tor sam wykrywa zerwane połączenia dopiero po minutach,
 * więc przy zmianie sieci wysyłamy mu SIGNAL NEWNET (świeże obwody) i ponownie sprawdzamy osiągalność adresu onion.
 */
object NetMonitor {
    @Volatile var description: String = "brak danych"
    @Volatile var changedAt: Long = 0L
    private var callback: ConnectivityManager.NetworkCallback? = null
    private var lastNet: Network? = null
    private var lastValidated = false

    private fun describe(cm: ConnectivityManager, n: Network): String {
        val c = cm.getNetworkCapabilities(n) ?: return "nieznana"
        val type = when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "komórkowa"
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "inna"
        }
        val ok = if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "internet potwierdzony" else "internet niepotwierdzony"
        return "$type, $ok" + if (hasGlobalIpv6(cm, n)) ", IPv6" else ""
    }

    private fun hasGlobalIpv6(cm: ConnectivityManager, n: Network): Boolean {
        val lp = cm.getLinkProperties(n) ?: return false
        return lp.linkAddresses.any {
            val a = it.address
            a is Inet6Address && !a.isLinkLocalAddress && !a.isSiteLocalAddress && !a.isLoopbackAddress && !a.isMulticastAddress
        }
    }

    /** Czy aktywna sieć ma globalny adres IPv6 (wtedy włączamy IPv6 w Torze; w sieciach tylko-IPv6 bez tego Tor się nie połączy). */
    fun hasGlobalIpv6(ctx: Context): Boolean = runCatching {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        cm.activeNetwork?.let { hasGlobalIpv6(cm, it) } ?: false
    }.getOrDefault(false)

    fun current(ctx: Context): String = runCatching {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        cm.activeNetwork?.let { describe(cm, it) } ?: "brak sieci"
    }.getOrDefault("nieznana")

    /** [onChange] jest wołane przy faktycznej zmianie sieci (nie przy pierwszym zgłoszeniu po rejestracji). */
    @Synchronized fun start(ctx: Context, onChange: (String) -> Unit) {
        stop(ctx)
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return
        lastNet = null; lastValidated = false
        description = current(ctx)
        Trace.log("sieć: $description")
        val cb = object : ConnectivityManager.NetworkCallback() {
            private fun handle(n: Network, validatedNow: Boolean) {
                val d = describe(cm, n)
                val changed = lastNet != null && (lastNet != n || (!lastValidated && validatedNow))
                lastNet = n; lastValidated = validatedNow; description = d
                if (changed) { changedAt = System.currentTimeMillis(); Trace.log("sieć zmieniona: $d"); onChange(d) }
            }
            override fun onAvailable(network: Network) {
                handle(network, cm.getNetworkCapabilities(network)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true)
            }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                handle(network, caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
            }
            override fun onLost(network: Network) {
                if (network == lastNet) { description = "brak sieci"; Trace.log("sieć utracona") }
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(cb); callback = cb }.onFailure { Trace.log("sieć: nie można obserwować: $it") }
    }

    @Synchronized fun stop(ctx: Context) {
        val cb = callback ?: return
        runCatching { ctx.getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb) }
        callback = null
    }
}
