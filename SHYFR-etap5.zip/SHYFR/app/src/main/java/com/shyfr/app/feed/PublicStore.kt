package com.shyfr.app.feed

import android.content.Context
import com.shyfr.app.session.Session
import com.shyfr.app.vault.Db
import net.zetetic.database.sqlcipher.SQLiteDatabase

data class Membership(val relay: String, val cid: String, val name: String, val vis: String, val nick: String, val keyIdx: Int, val role: String, val bio: String = "", val isPublic: Boolean = false) {
    val isStaff get() = role == "owner" || role == "mod"
}
data class Bookmark(val id: String, val cid: String, val author: String, val nick: String, val text: String, val ts: Long)

/** Lokalne dane warstwy publicznej (w zaszyfrowanej bazie SHYFR). Klucze prywatne NIE są tu zapisywane: wyprowadza je PublicKeys. */
class PublicStore(private val ctx: Context) {
    private fun <T> db(block: (SQLiteDatabase) -> T): T {
        val k = Session.get() ?: error("Konto zablokowane")
        val d = Db.open(ctx, k)
        try { return block(d) } finally { d.close() }
    }
    private fun SQLiteDatabase.q(sql: String, vararg args: Any?): android.database.Cursor =
        if (args.isEmpty()) rawQuery(sql) else rawQuery(sql, *args)

    private fun read(c: android.database.Cursor) = Membership(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getString(3) ?: "public", c.getString(4) ?: "", c.getInt(5), c.getString(6) ?: "member", c.getString(7) ?: "", c.getInt(8) == 1)
    private val cols = "relay,cid,name,vis,nick,key_idx,role,bio,is_public"

    fun memberships(relay: String): List<Membership> = db { d ->
        d.q("SELECT $cols FROM pub_membership WHERE relay=? ORDER BY joined DESC", relay).use { c -> buildList { while (c.moveToNext()) add(read(c)) } }
    }
    fun membership(relay: String, cid: String): Membership? = db { d ->
        d.q("SELECT $cols FROM pub_membership WHERE relay=? AND cid=?", relay, cid).use { if (it.moveToFirst()) read(it) else null }
    }
    fun upsert(m: Membership) = db { d ->
        val old = d.q("SELECT nick,key_idx FROM pub_membership WHERE relay=? AND cid=?", m.relay, m.cid).use { if (it.moveToFirst()) it.getString(0) to it.getInt(1) else null }
        if (old == null) d.execSQL("INSERT INTO pub_membership(relay,cid,name,vis,nick,key_idx,role,joined) VALUES(?,?,?,?,?,?,?,?)",
            arrayOf<Any?>(m.relay, m.cid, m.name, m.vis, m.nick, m.keyIdx, m.role, System.currentTimeMillis()))
        else d.execSQL("UPDATE pub_membership SET name=?, vis=?, role=? WHERE relay=? AND cid=?", arrayOf<Any?>(m.name, m.vis, m.role, m.relay, m.cid))
    }
    fun setNick(relay: String, cid: String, nick: String) = db { d ->
        d.execSQL("UPDATE pub_membership SET nick=? WHERE relay=? AND cid=?", arrayOf<Any?>(nick, relay, cid))
    }
    fun setPublic(relay: String, cid: String, bio: String, public: Boolean) = db { d ->
        d.execSQL("UPDATE pub_membership SET bio=?, is_public=? WHERE relay=? AND cid=?", arrayOf<Any?>(bio, if (public) 1 else 0, relay, cid))
    }
    /** Nowa tożsamość w społeczności: kolejny indeks klucza. Poprzednie wpisy zostają pod starym kluczem (nie da się ich „przenieść”). */
    fun rotateKey(relay: String, cid: String): Int = db { d ->
        d.execSQL("UPDATE pub_membership SET key_idx=key_idx+1, nick='', role='member', bio='', is_public=0 WHERE relay=? AND cid=?", arrayOf<Any?>(relay, cid))
        d.q("SELECT key_idx FROM pub_membership WHERE relay=? AND cid=?", relay, cid).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }
    fun remove(relay: String, cid: String) = db { d ->
        d.execSQL("DELETE FROM pub_membership WHERE relay=? AND cid=?", arrayOf<Any?>(relay, cid))
    }

    fun bookmarks(): List<Bookmark> = db { d ->
        d.q("SELECT post_id,cid,author,nick,text,ts FROM pub_bookmarks ORDER BY added DESC").use { c ->
            buildList { while (c.moveToNext()) add(Bookmark(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "", c.getLong(5))) }
        }
    }
    fun isBookmarked(id: String): Boolean = db { d -> d.q("SELECT 1 FROM pub_bookmarks WHERE post_id=?", id).use { it.moveToFirst() } }
    /** Zwraca true, jeśli wpis jest teraz zapisany. */
    fun toggleBookmark(b: Bookmark): Boolean = db { d ->
        if (d.q("SELECT 1 FROM pub_bookmarks WHERE post_id=?", b.id).use { it.moveToFirst() }) {
            d.execSQL("DELETE FROM pub_bookmarks WHERE post_id=?", arrayOf<Any?>(b.id)); false
        } else {
            d.execSQL("INSERT OR REPLACE INTO pub_bookmarks(post_id,cid,author,nick,text,ts,added) VALUES(?,?,?,?,?,?,?)",
                arrayOf<Any?>(b.id, b.cid, b.author, b.nick, b.text, b.ts, System.currentTimeMillis())); true
        }
    }

    fun nextReqN(relay: String, cid: String, target: String): Int = db { d ->
        d.q("SELECT COUNT(*) FROM pub_requests WHERE relay=? AND cid=? AND target=?", relay, cid, target).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }
    fun addRequest(relay: String, cid: String, reqId: String, target: String, n: Int) = db { d ->
        d.execSQL("INSERT OR IGNORE INTO pub_requests(relay,cid,req_id,target,n,ts,handled) VALUES(?,?,?,?,?,?,0)", arrayOf<Any?>(relay, cid, reqId, target, n, System.currentTimeMillis()))
    }
    /** Numer klucza odpowiedzi dla prośby albo null, jeśli prośby nie wysłano z tego telefonu. */
    fun requestN(relay: String, reqId: String): Int? = db { d ->
        d.q("SELECT n FROM pub_requests WHERE relay=? AND req_id=?", relay, reqId).use { if (it.moveToFirst()) it.getInt(0) else null }
    }
    fun isHandled(relay: String, reqId: String): Boolean = db { d ->
        d.q("SELECT handled FROM pub_requests WHERE relay=? AND req_id=?", relay, reqId).use { it.moveToFirst() && it.getInt(0) == 1 }
    }
    fun markHandled(relay: String, reqId: String) = db { d ->
        d.execSQL("UPDATE pub_requests SET handled=1 WHERE relay=? AND req_id=?", arrayOf<Any?>(relay, reqId))
    }

    fun likedIds(): Set<String> = db { d -> d.q("SELECT post_id FROM pub_reacted WHERE emoji='❤'").use { c -> buildSet { while (c.moveToNext()) add(c.getString(0)) } } }
    fun savedIds(): Set<String> = db { d -> d.q("SELECT post_id FROM pub_bookmarks").use { c -> buildSet { while (c.moveToNext()) add(c.getString(0)) } } }

    fun reacted(postId: String, emoji: String): Boolean = db { d -> d.q("SELECT 1 FROM pub_reacted WHERE post_id=? AND emoji=?", postId, emoji).use { it.moveToFirst() } }
    fun setReacted(postId: String, emoji: String, on: Boolean) = db { d ->
        if (on) d.execSQL("INSERT OR IGNORE INTO pub_reacted(post_id,emoji) VALUES(?,?)", arrayOf<Any?>(postId, emoji))
        else d.execSQL("DELETE FROM pub_reacted WHERE post_id=? AND emoji=?", arrayOf<Any?>(postId, emoji))
    }
}
