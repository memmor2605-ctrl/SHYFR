package com.shyfr.app.nostr

import java.math.BigInteger
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Podpisy Schnorr BIP-340 na krzywej secp256k1 (wymagane przez Nostr). Czysty Kotlin na BigInteger, bez natywnych bibliotek.
 * Współrzędne Jacobiego (jedno odwrócenie na wynik). Sprawdzone na oficjalnych wektorach BIP-340 (patrz SchnorrTest).
 * Uwaga: BigInteger nie działa w stałym czasie; wystarcza do kluczy na własnym telefonie, nie jest to moduł pod ataki z bliska.
 */
object Schnorr {
    private val P = BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F", 16)
    val N: BigInteger = BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141", 16)
    private val GX = BigInteger("79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798", 16)
    private val GY = BigInteger("483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8", 16)
    private val ONE = BigInteger.ONE
    private val THREE = BigInteger.valueOf(3)

    private class J(val x: BigInteger, val y: BigInteger, val z: BigInteger)
    private val INF = J(ONE, ONE, BigInteger.ZERO)

    private fun dbl(a: J): J {
        if (a.z.signum() == 0 || a.y.signum() == 0) return INF
        val aa = a.x.multiply(a.x).mod(P)
        val b = a.y.multiply(a.y).mod(P)
        val c = b.multiply(b).mod(P)
        val xb = a.x.add(b)
        val d = xb.multiply(xb).subtract(aa).subtract(c).shiftLeft(1).mod(P)
        val e = aa.multiply(THREE).mod(P)
        val f = e.multiply(e).mod(P)
        val x3 = f.subtract(d.shiftLeft(1)).mod(P)
        val y3 = e.multiply(d.subtract(x3)).subtract(c.shiftLeft(3)).mod(P)
        val z3 = a.y.multiply(a.z).shiftLeft(1).mod(P)
        return J(x3, y3, z3)
    }

    private fun add(a: J, b: J): J {
        if (a.z.signum() == 0) return b
        if (b.z.signum() == 0) return a
        val z1z1 = a.z.multiply(a.z).mod(P)
        val z2z2 = b.z.multiply(b.z).mod(P)
        val u1 = a.x.multiply(z2z2).mod(P)
        val u2 = b.x.multiply(z1z1).mod(P)
        val s1 = a.y.multiply(b.z).mod(P).multiply(z2z2).mod(P)
        val s2 = b.y.multiply(a.z).mod(P).multiply(z1z1).mod(P)
        val h = u2.subtract(u1).mod(P)
        val r = s2.subtract(s1).mod(P)
        if (h.signum() == 0) return if (r.signum() == 0) dbl(a) else INF
        val hh = h.multiply(h).mod(P)
        val hhh = h.multiply(hh).mod(P)
        val v = u1.multiply(hh).mod(P)
        val x3 = r.multiply(r).subtract(hhh).subtract(v.shiftLeft(1)).mod(P)
        val y3 = r.multiply(v.subtract(x3)).subtract(s1.multiply(hhh)).mod(P)
        val z3 = a.z.multiply(b.z).mod(P).multiply(h).mod(P)
        return J(x3, y3, z3)
    }

    private fun mul(px: BigInteger, py: BigInteger, k: BigInteger): J {
        var r = INF
        var q = J(px, py, ONE)
        for (i in 0 until 256) {
            if (k.testBit(i)) r = add(r, q)
            q = dbl(q)
        }
        return r
    }

    private fun affine(j: J): Pair<BigInteger, BigInteger>? {
        if (j.z.signum() == 0) return null
        val zi = j.z.modInverse(P)
        val z2 = zi.multiply(zi).mod(P)
        return j.x.multiply(z2).mod(P) to j.y.multiply(z2).mod(P).multiply(zi).mod(P)
    }

    private fun liftX(x: BigInteger): Pair<BigInteger, BigInteger>? {
        if (x >= P) return null
        val y2 = x.pow(3).add(BigInteger.valueOf(7)).mod(P)
        val y = y2.modPow(P.add(ONE).shiftRight(2), P)
        if (y.multiply(y).mod(P) != y2) return null
        return x to (if (y.testBit(0)) P.subtract(y) else y)
    }

    private fun tagged(tag: String, vararg parts: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        val t = md.digest(tag.toByteArray(Charsets.UTF_8))
        md.reset(); md.update(t); md.update(t); parts.forEach(md::update)
        return md.digest()
    }

    private fun int(b: ByteArray) = BigInteger(1, b)
    private fun b32(v: BigInteger): ByteArray {
        val raw = v.toByteArray()
        val out = ByteArray(32)
        val n = minOf(raw.size, 32)
        System.arraycopy(raw, raw.size - n, out, 32 - n, n)
        return out
    }

    fun isValidSecret(sk: ByteArray): Boolean = sk.size == 32 && int(sk).let { it.signum() > 0 && it < N }

    /** Klucz publiczny x-only (32 bajty), tak jak w Nostr. */
    fun publicKey(sk: ByteArray): ByteArray {
        require(isValidSecret(sk)) { "Zły klucz prywatny" }
        return b32(affine(mul(GX, GY, int(sk)))!!.first)
    }

    fun sign(msg: ByteArray, sk: ByteArray, aux: ByteArray = ByteArray(32).also(SecureRandom()::nextBytes)): ByteArray {
        require(msg.size == 32 && aux.size == 32) { "Zły rozmiar danych" }
        require(isValidSecret(sk)) { "Zły klucz prywatny" }
        val d0 = int(sk)
        val pt = affine(mul(GX, GY, d0))!!
        val d = if (pt.second.testBit(0)) N.subtract(d0) else d0
        val px = b32(pt.first)
        val auxHash = tagged("BIP0340/aux", aux)
        val t = b32(d).also { for (i in 0 until 32) it[i] = (it[i].toInt() xor auxHash[i].toInt()).toByte() }
        val k0 = int(tagged("BIP0340/nonce", t, px, msg)).mod(N)
        require(k0.signum() != 0) { "Zły nonce" }
        val r = affine(mul(GX, GY, k0))!!
        val k = if (r.second.testBit(0)) N.subtract(k0) else k0
        val rx = b32(r.first)
        val e = int(tagged("BIP0340/challenge", rx, px, msg)).mod(N)
        return rx + b32(k.add(e.multiply(d)).mod(N))
    }

    fun verify(msg: ByteArray, pub: ByteArray, sig: ByteArray): Boolean {
        if (msg.size != 32 || pub.size != 32 || sig.size != 64) return false
        val pt = liftX(int(pub)) ?: return false
        val r = int(sig.copyOfRange(0, 32))
        val s = int(sig.copyOfRange(32, 64))
        if (r >= P || s >= N) return false
        val e = int(tagged("BIP0340/challenge", sig.copyOfRange(0, 32), pub, msg)).mod(N)
        val sg = mul(GX, GY, s)
        val ep = mul(pt.first, pt.second, N.subtract(e).mod(N))
        val rr = affine(add(sg, ep)) ?: return false
        return !rr.second.testBit(0) && rr.first == r
    }
}
