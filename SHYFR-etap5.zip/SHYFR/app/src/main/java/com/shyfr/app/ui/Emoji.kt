package com.shyfr.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun e(s: String) = s.trim().split(Regex("\\s+"))

/** Wbudowany wybór emoji (bez zależności zewnętrznych): ikona zakładki + lista. */
val EMOJI_CATEGORIES: List<Pair<String, List<String>>> = listOf(
    "😀" to e("😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😋 😛 😜 🤪 😝 🤗 🤭 🤫 🤔 😐 😑 😶 🙄 😏 😬 😌 😔 😪 😴 😷 🤒 🤕 🤢 🤧 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 💀 💩 🤡 👻 👽 🤖"),
    "👍" to e("👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 🤝 🙏 ✍️ 💪 👏 🙌 👐 🤲 🫶 🫡 🫰 💅 🧠 👀 👁 👄 👃 👂"),
    "❤️" to e("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ☮️ ✨ 🌟 ⭐ 💫 🔥 💥 💯 ✅ ❌ ❓ ❗ 💤 💢 💬 💭"),
    "🐶" to e("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🦆 🦉 🐺 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🐙 🦀 🐠 🐬 🐳 🦈 🌸 🌹 🌻 🌲 🌴 🍀 🌍 🌙 ☀️ ⛅ 🌧 ⚡ ❄️ 🌈"),
    "🍕" to e("🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🥦 🥕 🌽 🥔 🍞 🧀 🍳 🥞 🥓 🍔 🍟 🍕 🌭 🌮 🍝 🍜 🍣 🍤 🍦 🍩 🍪 🎂 🍰 🍫 🍬 ☕ 🍵 🍺 🍻 🥂 🍷 🍸"),
    "⚽" to e("⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🥊 🎯 🎮 🎲 🎵 🎶 🎤 🎧 🎸 🎹 🎬 📷 🏆 🥇 🎉 🎊 🎁 🎈 🚗 ✈️ 🚀 ⛵ 🏠 🏖 🏔 📱 💻 ⌚ 💡 🔑 🔒 🔓 📌 📎 ✏️ 📚 💰 💳 ⏰ 🔔"),
)

@Composable
fun EmojiGrid(modifier: Modifier = Modifier, accent: Color, onPick: (String) -> Unit) {
    var cat by remember { mutableIntStateOf(0) }
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            EMOJI_CATEGORIES.forEachIndexed { i, (icon, _) ->
                Text(icon, fontSize = 20.sp, modifier = Modifier.clip(CircleShape)
                    .background(if (i == cat) accent.copy(alpha = .25f) else Color.Transparent)
                    .clickable { cat = i }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
        LazyVerticalGrid(GridCells.Adaptive(46.dp), Modifier.fillMaxSize().padding(horizontal = 6.dp)) {
            items(EMOJI_CATEGORIES[cat].second) { em ->
                Box(Modifier.size(46.dp).clickable { onPick(em) }, contentAlignment = Alignment.Center) { Text(em, fontSize = 26.sp) }
            }
        }
    }
}
