package com.shyfr.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.feed.Membership
import com.shyfr.app.feed.Post
import com.shyfr.app.feed.PublicRepo
import kotlinx.coroutines.launch

/** Elementy wspólne dla ekranów Feed i Społeczności. */

internal fun authorLabel(p: Post, mine: Boolean): String =
    (if (p.nick.isNotBlank()) p.nick else "Anonimowy uczestnik") + if (mine) " (Ty)" else ""

@Composable
private fun MenuRow(label: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(label) }, onClick = onClick)
}

@Composable
internal fun SmallAction(label: String, active: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp)) {
        Text(label, fontSize = 13.sp, color = if (active) MaterialTheme.colorScheme.primary else ShMuted)
    }
}

/** Karta wpisu. Menu zwraca klucz: copy, edit, delete, report, pin, ban. */
@Composable
internal fun PostCard(
    p: Post, communityName: String, mine: Boolean, staff: Boolean, saved: Boolean, liked: Boolean,
    onLike: () -> Unit, onOpen: () -> Unit, onRepost: (quote: Boolean) -> Unit, onSave: () -> Unit, onMenu: (String) -> Unit, onReact: (String) -> Unit = {}, myVote: Int? = null, onVote: (Int) -> Unit = {}
) {
    var menu by remember { mutableStateOf(false) }
    var rep by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(ShSurface.copy(alpha = .85f)).clickable(onClick = onOpen).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (p.nick.isBlank()) IconAvatar(Ic.Person, 38.dp) else Avatar(authorLabel(p, false), 0, "", 38.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(authorLabel(p, mine), fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(listOf(communityName, "#" + p.channel, fmtTime(p.ts)).filter { it.isNotBlank() }.joinToString(" · ") + if (p.edited > 0) " · edytowano" else "",
                    fontSize = 11.sp, color = ShMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (p.pinned) Icon24(Ic.Pin, ShMuted, 14.dp)
            Box {
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { menu = true }.a11y("Więcej opcji wpisu"), contentAlignment = Alignment.Center) { Icon24(Ic.More, ShMuted, 20.dp) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    MenuRow("Kopiuj tekst") { menu = false; onMenu("copy") }
                    MenuRow("Kopiuj link do wpisu") { menu = false; onMenu("link") }
                    if (mine && !p.deleted) { MenuRow("Edytuj") { menu = false; onMenu("edit") }; MenuRow("Usuń") { menu = false; onMenu("delete") } }
                    if (p.nick.isNotBlank() && p.author.isNotEmpty() && !p.deleted) MenuRow("Profil autora") { menu = false; onMenu("profile") }
                    if (!mine) MenuRow("Zgłoś") { menu = false; onMenu("report") }
                    if (!mine && !p.deleted && p.author.isNotEmpty()) MenuRow("Poproś o kontakt") { menu = false; onMenu("contact") }
                    if (staff && p.parent.isEmpty()) MenuRow(if (p.pinned) "Odepnij" else "Przypnij") { menu = false; onMenu("pin") }
                    if (staff && !mine && !p.deleted) { MenuRow("Usuń (moderacja)") { menu = false; onMenu("delete") }; MenuRow("Zablokuj autora w społeczności") { menu = false; onMenu("ban") } }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (p.kind == "repost") Text("↻ Udostępniono dalej", fontSize = 12.sp, color = ShMuted)
        if (p.deleted) Text("Wpis usunięty", color = ShMuted, fontSize = 14.sp)
        else if (p.text.isNotBlank()) Text(p.text, fontSize = 15.sp)
        if (p.kind == "poll" && p.pollOptions.isNotEmpty() && !p.deleted) {
            val total = p.pollVotes.sum().coerceAtLeast(1)
            Spacer(Modifier.height(6.dp))
            p.pollOptions.forEachIndexed { i, o ->
                val n = p.pollVotes.getOrElse(i) { 0 }
                val sel = myVote == i
                Box(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(ShSurfaceHi.copy(alpha = .6f)).clickable { onVote(i) }) {
                    Box(Modifier.fillMaxWidth(n.toFloat() / total).height(36.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = if (sel) .35f else .18f)))
                    Row(Modifier.fillMaxWidth().height(36.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text((if (sel) "✓ " else "") + o, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${n * 100 / total}% · $n", fontSize = 12.sp, color = ShMuted)
                    }
                }
            }
            Text("Głosów: ${p.pollVotes.sum()} · możesz zmienić głos. Przekaźnik widzi, na co głosuje Twój klucz tej społeczności.", fontSize = 11.sp, color = ShMuted)
        }
        if ((p.kind == "repost" || p.kind == "quote") && p.refText != null) {
            Spacer(Modifier.height(8.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(ShSurfaceHi.copy(alpha = .7f)).padding(10.dp)) {
                Text(if ((p.refNick ?: "").isNotBlank()) p.refNick!! else "Anonimowy uczestnik", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Text(p.refText, fontSize = 13.sp, color = ShMuted, maxLines = 4, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            SmallAction("Lubię " + p.reactions.values.sum(), liked, onLike)
            Box {
                SmallAction("＋", false) { picker = true }
                DropdownMenu(expanded = picker, onDismissRequest = { picker = false }) {
                    listOf("👍", "😂", "😮", "😢", "🔥").forEach { e -> MenuRow(e) { picker = false; onReact(e) } }
                }
            }
            SmallAction("Komentarze ${p.comments}", false, onOpen)
            Box {
                SmallAction("↻ ${p.reposts}") { rep = true }
                DropdownMenu(expanded = rep, onDismissRequest = { rep = false }) {
                    MenuRow("Udostępnij dalej") { rep = false; onRepost(false) }
                    MenuRow("Cytuj") { rep = false; onRepost(true) }
                }
            }
            Spacer(Modifier.weight(1f))
            SmallAction(if (saved) "Zapisano" else "Zapisz", saved, onSave)
        }
    }
}

@Composable
internal fun EmptyState(title: String, text: String, action: String? = null, onAction: () -> Unit = {}) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(text, color = ShMuted, fontSize = 14.sp)
        if (action != null) { Spacer(Modifier.height(16.dp)); Button(onClick = onAction) { Text(action) } }
    }
}

/** Wątek: wpis i komentarze, z możliwością odpowiedzi (anonimowo lub pod pseudonimem społeczności). */
@Composable
internal fun ThreadDialog(repo: PublicRepo, post: Post, myPub: String, onDismiss: () -> Unit, onError: (String) -> Unit, onChanged: () -> Unit) {
    val scope = rememberCoroutineScope()
    var comments by remember { mutableStateOf<List<Post>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var text by remember { mutableStateOf("") }
    var anon by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var replyTo by remember { mutableStateOf<Post?>(null) }
    LaunchedEffect(reload) {
        loading = true
        try { comments = repo.comments(post.cid, post.id) } catch (e: Exception) { onError(e.message ?: "Błąd") }
        loading = false
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Wątek") },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(authorLabel(post, post.author == myPub), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(if (post.deleted) "Wpis usunięty" else post.text, fontSize = 15.sp)
                Spacer(Modifier.height(1.dp).fillMaxWidth().background(ShMuted.copy(alpha = .25f)))
                if (loading) CircularProgressIndicator(Modifier.size(24.dp))
                else if (comments.isEmpty()) Text("Brak komentarzy.", color = ShMuted, fontSize = 13.sp)
                comments.forEach { c -> CommentNode(repo, c, 0, myPub, reload) { replyTo = it } }
                replyTo?.let { r ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Odpowiedź do: " + authorLabel(r, r.author == myPub) + " – " + r.text.take(40), fontSize = 12.sp, color = ShMuted, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = { replyTo = null }) { Text("Anuluj") }
                    }
                }
                OutlinedTextField(text, { if (it.length <= 2000) text = it }, label = { Text(if (replyTo == null) "Twój komentarz" else "Twoja odpowiedź") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = anon, onClick = { anon = true }, label = { Text("Anonimowo") })
                    FilterChip(selected = !anon, onClick = { anon = false }, label = { Text("Pseudonim") })
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && text.isNotBlank(), onClick = {
                busy = true
                scope.launch {
                    try { repo.publish(post.cid, post.channel, text, anon, "comment", (replyTo ?: post).id); text = ""; replyTo = null; reload++; onChanged() }
                    catch (e: Exception) { onError(e.message ?: "Błąd") }
                    busy = false
                }
            }) { Text("Wyślij") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zamknij") } }
    )
}

/** Nowy wpis albo cytat ([quoteOf] != null: społeczność i kanał są z góry ustalone). */
@Composable
internal fun ComposeDialog(repo: PublicRepo, joined: List<Membership>, quoteOf: Post?, startCid: String?, onDismiss: () -> Unit, onDone: () -> Unit, onError: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var cid by remember { mutableStateOf(quoteOf?.cid ?: startCid ?: joined.firstOrNull()?.cid) }
    var channels by remember { mutableStateOf(listOf("ogólny")) }
    var channel by remember { mutableStateOf(quoteOf?.channel ?: "ogólny") }
    var text by remember { mutableStateOf("") }
    var anon by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var poll by remember { mutableStateOf(false) }
    val options = remember { mutableStateListOf("", "") }
    val m = joined.firstOrNull { it.cid == cid }
    LaunchedEffect(cid) {
        val c = cid ?: return@LaunchedEffect
        if (quoteOf == null) runCatching { repo.communityInfo(c) }.onSuccess { i ->
            channels = i.channels.map { it.name }.ifEmpty { listOf("ogólny") }
            if (channel !in channels) channel = channels.first()
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (quoteOf != null) "Cytuj wpis" else "Nowy wpis") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (joined.isEmpty()) Text("Najpierw dołącz do społeczności.", color = ShMuted)
                if (quoteOf == null && joined.isNotEmpty()) {
                    Text("Społeczność", fontSize = 12.sp, color = ShMuted)
                    Row(Modifier.horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        joined.forEach { j -> FilterChip(selected = cid == j.cid, onClick = { cid = j.cid }, label = { Text(j.name.ifBlank { j.cid.take(6) }) }) }
                    }
                    Text("Kanał", fontSize = 12.sp, color = ShMuted)
                    Row(Modifier.horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        channels.forEach { c -> FilterChip(selected = channel == c, onClick = { channel = c }, label = { Text("#$c") }) }
                    }
                } else if (quoteOf != null) {
                    Text("Cytujesz: " + quoteOf.text.take(120), fontSize = 12.sp, color = ShMuted)
                }
                Text("Jako kto publikujesz", fontSize = 12.sp, color = ShMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = anon, onClick = { anon = true }, label = { Text("Anonimowo") })
                    FilterChip(selected = !anon, onClick = { anon = false }, label = { Text(if (m?.nick.isNullOrBlank()) "Pseudonim (nie ustawiono)" else m!!.nick) })
                }
                Text(if (anon) "Wpis pojawi się jako „Anonimowy uczestnik”. Przekaźnik widzi tylko klucz tej społeczności, nie Twoją tożsamość." else "Pseudonim jest przypisany tylko do tej społeczności.", fontSize = 11.sp, color = ShMuted)
                if (quoteOf == null) FilterChip(selected = poll, onClick = { poll = !poll }, label = { Text("Ankieta") })
                OutlinedTextField(text, { if (it.length <= (if (poll) 300 else 2000)) text = it }, label = { Text(if (poll) "Pytanie" else "Treść (hashtagi: #temat)") }, modifier = Modifier.fillMaxWidth(), minLines = if (poll) 2 else 4)
                if (poll) {
                    options.forEachIndexed { i, o ->
                        OutlinedTextField(o, { if (it.length <= 80) options[i] = it }, label = { Text("Opcja ${i + 1}") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    Row {
                        if (options.size < 6) TextButton(onClick = { options.add("") }) { Text("＋ Opcja") }
                        if (options.size > 2) TextButton(onClick = { options.removeAt(options.size - 1) }) { Text("− Opcja") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && text.isNotBlank() && cid != null && (!poll || options.count { it.isNotBlank() } >= 2), onClick = {
                val c = cid ?: return@TextButton
                busy = true
                scope.launch {
                    try {
                        if (quoteOf != null) repo.publish(c, quoteOf.channel, text, anon, "quote", "", quoteOf.id)
                        else if (poll) repo.createPoll(c, channel, text, options.toList(), anon)
                        else repo.publish(c, channel, text, anon)
                        onDone()
                    } catch (e: Exception) { onError(e.message ?: "Błąd"); busy = false }
                }
            }) { Text(if (busy) "Wysyłanie…" else "Opublikuj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Anuluj") } }
    )
}

private fun Modifier.horizontalScrollCompat(): Modifier = composed { this.horizontalScroll(rememberScrollState()) }


/** Podgląd publicznego profilu autora w danej społeczności (albo własnego „oczami obcego”). */
@Composable
internal fun ProfileDialog(repo: PublicRepo, cid: String, authorPub: String, onDismiss: () -> Unit) {
    var loading by remember { mutableStateOf(true) }
    var profile by remember { mutableStateOf<com.shyfr.app.feed.PublicProfile?>(null) }
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(cid, authorPub) {
        loading = true
        try {
            profile = repo.profileOf(cid, authorPub)
            if (profile != null) posts = repo.authorPosts(cid, authorPub)
        } catch (e: Exception) { error = e.message ?: "Błąd" }
        loading = false
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(profile?.nick ?: "Profil") },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when {
                    loading -> CircularProgressIndicator(Modifier.size(24.dp))
                    error != null -> Text(error ?: "", color = ShMuted)
                    profile == null -> Text("Autor nie ma publicznego profilu w tej społeczności.", color = ShMuted)
                    else -> {
                        val p = profile!!
                        if (p.about.isNotBlank()) Text(p.about, fontSize = 14.sp)
                        Text((if (p.joined > 0) "W społeczności od ${fmtTime(p.joined)} · " else "") + "${p.posts} wpisów", fontSize = 12.sp, color = ShMuted)
                        Text("Profil jest powiązany tylko z tą społecznością. Nie daje prawa do prywatnych wiadomości: kontakt wymaga zgody autora.", fontSize = 11.sp, color = ShMuted)
                        posts.forEach { x ->
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ShSurfaceHi.copy(alpha = .6f)).padding(10.dp)) {
                                Text(x.text, fontSize = 14.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                                Text("#${x.channel} · ${fmtTime(x.ts)}", fontSize = 11.sp, color = ShMuted)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zamknij") } }
    )
}


/** Komentarz z odpowiedziami (do 4 poziomów wcięcia na ekranie; przekaźnik dopuszcza głębokość 6). */
@Composable
private fun CommentNode(repo: PublicRepo, c: Post, depth: Int, myPub: String, reloadKey: Int, onReply: (Post) -> Unit) {
    var open by remember(c.id) { mutableStateOf(false) }
    var kids by remember(c.id, reloadKey) { mutableStateOf<List<Post>?>(null) }
    LaunchedEffect(open, reloadKey) {
        if (open) kids = try { repo.comments(c.cid, c.id) } catch (e: Exception) { emptyList() }
    }
    Column(Modifier.fillMaxWidth().padding(start = (depth * 10).dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ShSurfaceHi.copy(alpha = .6f)).padding(10.dp)) {
            Text(authorLabel(c, c.author == myPub) + " · " + fmtTime(c.ts), fontSize = 11.sp, color = ShMuted)
            Text(if (c.deleted) "Komentarz usunięty" else c.text, fontSize = 14.sp)
        }
        Row {
            if (!c.deleted) SmallAction("Odpowiedz") { onReply(c) }
            if (c.comments > 0) SmallAction(if (open) "Ukryj odpowiedzi" else "Odpowiedzi (${c.comments})") { open = !open }
        }
        if (open) kids?.forEach { CommentNode(repo, it, minOf(depth + 1, 4), myPub, reloadKey, onReply) }
    }
}
