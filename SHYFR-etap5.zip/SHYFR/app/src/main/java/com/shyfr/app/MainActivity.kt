package com.shyfr.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.shyfr.app.session.AppState
import com.shyfr.app.session.Prefs
import com.shyfr.app.session.Session
import com.shyfr.app.ui.ShyfrApp
import kotlinx.coroutines.flow.MutableStateFlow

/** Link shyfr://join/... otwarty z zewnątrz trafia tu i czeka na odblokowanie konta. */
object Deeplink { val pending = MutableStateFlow<String?>(null) }

class MainActivity : FragmentActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val lockRunnable = Runnable { AppState.lock(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyScreenSecurity()
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        handle(intent)
        setContent { ShyfrApp(applicationContext, this) }
    }

    /** Aplikacja opuszczona (ekran wygaszony, inna aplikacja): po zadanym czasie klucz znika z RAM. */
    override fun onStop() {
        super.onStop()
        com.shyfr.app.net.Presence.foreground = false
        Prefs.setLastActive(this, System.currentTimeMillis())
        if (Session.get() != null) handler.postDelayed(lockRunnable, Prefs.lockSeconds(this) * 1000L)
    }
    override fun onStart() {
        super.onStart(); handler.removeCallbacks(lockRunnable)
        com.shyfr.app.net.Presence.foreground = true
        com.shyfr.app.net.Presence.kick.trySend(Unit)
    }

    private fun applyScreenSecurity() {
        if (Prefs.screenSecurity(this)) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    private fun handle(i: Intent?) {
        i?.data?.toString()?.takeIf { it.startsWith("shyfr://join/") }?.let { Deeplink.pending.value = it }
    }
}
