package com.shyfr.app.nostr

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import com.shyfr.app.net.NodeRuntime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.Socket
import java.net.URI
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/** Połączenie WebSocket z przekaźnikiem; podtrzymywane pingiem, a cisza dłuższa niż 100 s oznacza martwe łącze. */
class WsLink(override val url: String, private val ws: WsSession, scope: CoroutineScope) : RelayLink {
    private val ch = Channel<String>(Channel.UNLIMITED)
    override val incoming: ReceiveChannel<String> get() = ch
    private val ping: Job

    init {
        scope.launch(Dispatchers.IO) {
            try { while (true) { val m = ws.readMessage() ?: break; ch.trySend(m) } }
            catch (e: Exception) { /* koniec połączenia lub cisza */ }
            finally { ch.close(); ws.close() }
        }
        ping = scope.launch(Dispatchers.IO) {
            while (true) { delay(45_000); try { ws.sendPing() } catch (e: Exception) { ws.close(); break } }
        }
    }

    override suspend fun send(text: String) = withContext(Dispatchers.IO) { ws.sendText(text) }
    override fun close() { ping.cancel(); ws.close() }
}

/**
 * Łączy z publicznym przekaźnikiem przez Tora (SOCKS, nazwy rozwiązuje Tor), a dla wss:// dokłada TLS z weryfikacją nazwy hosta.
 * Zwykły ws:// jest dozwolony tylko dla adresów .onion (szyfruje je sam Tor). Nie zakładamy, że każdy przekaźnik jest osiągalny przez Tora.
 */
class TorWsConnector : RelayConnector {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override suspend fun connect(url: String): RelayLink = withContext(Dispatchers.IO) {
        val uri = URI(url)
        val host = uri.host ?: throw IOException("Zły adres")
        val tls = uri.scheme == "wss"
        if (!tls && !host.endsWith(".onion")) throw IOException("Niezabezpieczone połączenie jest niedozwolone")
        val port = if (uri.port > 0) uri.port else if (tls) 443 else 80
        val tor = NodeRuntime.transport ?: throw IOException("Sieć nie jest jeszcze gotowa")
        var sock: Socket = tor.connect(host, port)
        try {
            currentCoroutineContext().ensureActive()   // przekroczony czas: zamknij gniazdo, które mogło się połączyć po anulowaniu
            sock.soTimeout = 20_000
            if (tls) {
                val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(sock, host, port, true) as SSLSocket
                sock = ssl
                ssl.startHandshake()
                if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(host, ssl.session)) throw IOException("Certyfikat nie pasuje do adresu")
            }
            val ws = WsSession(sock)
            ws.handshake(host + (if (uri.port > 0) ":${uri.port}" else ""), (uri.rawPath ?: "").ifEmpty { "/" })
            sock.soTimeout = 100_000
            WsLink(url, ws, scope)
        } catch (e: Throwable) { runCatching { sock.close() }; throw e }
    }
}

private class PrefsMemory(ctx: Context) : RelayMemory {
    private val sp = ctx.getSharedPreferences("shyfr_nostr", Context.MODE_PRIVATE)
    override fun load(): List<String> = sp.getString("relays", "")!!.split('\n').filter { it.startsWith("wss://") || it.startsWith("ws://") }
    override fun save(urls: List<String>) { sp.edit().putString("relays", urls.joinToString("\n")).apply() }
}

/**
 * Jeden wspólny zarządca na aplikację. Działa tylko, gdy ekran go potrzebuje (acquire/release), a po zwolnieniu wyłącza się
 * po 2 minutach, żeby nie zużywać baterii. Zapamiętane przekaźniki wracają przy następnym uruchomieniu.
 * Adresy startowe to znane, publiczne i darmowe przekaźniki; ich działanie sprawdzamy na bieżąco, nie zakładamy go.
 */
object NostrHub {
    val BOOTSTRAP = listOf(
        "wss://relay.damus.io", "wss://nos.lol", "wss://relay.primal.net", "wss://relay.snort.social", "wss://relay.nostr.net",
        "wss://nostr.mom", "wss://offchain.pub", "wss://nostr.oxtr.dev", "wss://nostr-pub.wellorder.net"
    )
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var mgr: RelayManager? = null
    private var holders = 0
    private var stopJob: Job? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    @Synchronized fun manager(ctx: Context): RelayManager = mgr ?: RelayManager(BOOTSTRAP, TorWsConnector(), PrefsMemory(ctx.applicationContext)).also { mgr = it }

    @Synchronized fun acquire(ctx: Context): RelayManager {
        holders++; stopJob?.cancel(); stopJob = null
        val m = manager(ctx); m.start()
        if (netCb == null) {
            val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var first = true
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { if (first) { first = false; return }; scope.launch { delay(4_000); mgr?.networkChanged() } }
                override fun onLost(network: Network) { mgr?.networkChanged() }
            }
            runCatching { cm.registerDefaultNetworkCallback(cb); netCb = cb }
        }
        return m
    }

    @Synchronized fun release(ctx: Context) {
        holders = maxOf(0, holders - 1)
        if (holders > 0) return
        stopJob = scope.launch {
            delay(120_000)
            synchronized(this@NostrHub) {
                if (holders == 0) {
                    mgr?.shutdown(); mgr = null
                    netCb?.let { runCatching { (ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } }
                    netCb = null
                }
            }
        }
    }
}
