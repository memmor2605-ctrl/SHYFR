package com.shyfr.app.crypto

import com.google.crypto.tink.subtle.Hkdf
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Double Ratchet według specyfikacji Signal (X25519, HKDF-SHA256, HMAC-SHA256, AES-256-GCM).
 * Obiekt ładujemy z bazy, wykonujemy operację i zapisujemy stan dopiero po sukcesie,
 * więc sfałszowana wiadomość nie psuje sesji.
 * UWAGA: własna implementacja według specyfikacji, niezaudytowana. Przed wydaniem: audyt lub libsignal.
 */
class Ratchet private constructor(
    private var dhsPriv: ByteArray, private var dhsPub: ByteArray, private var dhr: ByteArray?,
    private var rk: ByteArray, private var cks: ByteArray?, private var ckr: ByteArray?,
    private var ns: Int, private var nr: Int, private var pn: Int,
    private val skipped: LinkedHashMap<String, ByteArray>
) {
    class Header(val dh: ByteArray, val pn: Int, val n: Int) {
        fun bytes(): ByteArray {
            val b = ByteArrayOutputStream(); val o = DataOutputStream(b)
            o.write(dh); o.writeInt(pn); o.writeInt(n); return b.toByteArray()
        }
    }

    fun encrypt(plain: ByteArray, ad: ByteArray): Pair<Header, ByteArray> {
        val c = cks ?: throw IllegalStateException("Brak łańcucha wysyłania")
        val (next, mk) = kdfCk(c); cks = next
        val h = Header(dhsPub, pn, ns); ns++
        return h to aead(mk, plain, ad + h.bytes(), true)
    }

    fun decrypt(h: Header, ct: ByteArray, ad: ByteArray): ByteArray {
        skipped.remove(skKey(h.dh, h.n))?.let { return aead(it, ct, ad + h.bytes(), false) }
        if (dhr == null || !h.dh.contentEquals(dhr!!)) { skip(h.pn); dhRatchet(h) }
        skip(h.n)
        val (next, mk) = kdfCk(ckr ?: throw IllegalStateException("Brak łańcucha odbioru"))
        ckr = next; nr++
        return aead(mk, ct, ad + h.bytes(), false)
    }

    private fun skip(until: Int) {
        if (until - nr > MAX_SKIP) throw IllegalStateException("Zbyt wiele pominiętych wiadomości")
        val c = ckr ?: return
        var chain = c
        while (nr < until) {
            val (next, mk) = kdfCk(chain); chain = next
            skipped[skKey(dhr!!, nr)] = mk; nr++
        }
        ckr = chain
        while (skipped.size > MAX_STORED) skipped.remove(skipped.keys.first())
    }

    private fun dhRatchet(h: Header) {
        pn = ns; ns = 0; nr = 0
        dhr = h.dh
        val (rk1, ck1) = kdfRk(rk, Keys.dh(dhsPriv, dhr!!)); rk = rk1; ckr = ck1
        dhsPriv = Keys.newPriv(); dhsPub = Keys.pub(dhsPriv)
        val (rk2, ck2) = kdfRk(rk, Keys.dh(dhsPriv, dhr!!)); rk = rk2; cks = ck2
    }

    fun serialize(): ByteArray {
        val b = ByteArrayOutputStream(); val o = DataOutputStream(b)
        o.writeByte(1); o.write(dhsPriv); o.write(dhsPub); wOpt(o, dhr); o.write(rk)
        wOpt(o, cks); wOpt(o, ckr); o.writeInt(ns); o.writeInt(nr); o.writeInt(pn)
        o.writeInt(skipped.size)
        for ((k, v) in skipped) { o.writeUTF(k); o.write(v) }
        return b.toByteArray()
    }

    companion object {
        private const val MAX_SKIP = 1000
        private const val MAX_STORED = 2000

        /** Inicjator (osoba, która dołączyła): zna publiczny klucz tożsamości zapraszającego. */
        fun initInitiator(sk: ByteArray, peerPub: ByteArray): Ratchet {
            val priv = Keys.newPriv(); val pub = Keys.pub(priv)
            val (rk, ck) = kdfRk(sk, Keys.dh(priv, peerPub))
            return Ratchet(priv, pub, peerPub, rk, ck, null, 0, 0, 0, LinkedHashMap())
        }

        /** Odpowiadający (zapraszający): jego klucz tożsamości jest pierwszym kluczem ratchetu. */
        fun initResponder(sk: ByteArray, idPriv: ByteArray, idPub: ByteArray): Ratchet =
            Ratchet(idPriv, idPub, null, sk, null, null, 0, 0, 0, LinkedHashMap())

        fun deserialize(data: ByteArray): Ratchet {
            val i = DataInputStream(ByteArrayInputStream(data))
            require(i.readUnsignedByte() == 1)
            val priv = rd(i); val pub = rd(i); val dhr = rOpt(i); val rk = rd(i)
            val cks = rOpt(i); val ckr = rOpt(i)
            val ns = i.readInt(); val nr = i.readInt(); val pn = i.readInt()
            val map = LinkedHashMap<String, ByteArray>()
            repeat(i.readInt()) { val k = i.readUTF(); map[k] = rd(i) }
            return Ratchet(priv, pub, dhr, rk, cks, ckr, ns, nr, pn, map)
        }

        private fun rd(i: DataInputStream) = ByteArray(32).also { i.readFully(it) }
        private fun rOpt(i: DataInputStream) = if (i.readBoolean()) rd(i) else null
        private fun wOpt(o: DataOutputStream, v: ByteArray?) { o.writeBoolean(v != null); if (v != null) o.write(v) }
        private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
        private fun skKey(dh: ByteArray, n: Int) = hex(dh) + ":" + n

        private fun kdfRk(rk: ByteArray, dhOut: ByteArray): Pair<ByteArray, ByteArray> {
            val o = Hkdf.computeHkdf("HmacSha256", dhOut, rk, "SHYFR-rk".toByteArray(), 64)
            return o.copyOfRange(0, 32) to o.copyOfRange(32, 64)
        }
        private fun kdfCk(ck: ByteArray): Pair<ByteArray, ByteArray> =
            Keys.hmac(ck, byteArrayOf(2)) to Keys.hmac(ck, byteArrayOf(1)) // (następny ck, klucz wiadomości)

        private fun aead(mk: ByteArray, data: ByteArray, ad: ByteArray, enc: Boolean): ByteArray {
            val o = Hkdf.computeHkdf("HmacSha256", mk, ByteArray(32), "SHYFR-msg".toByteArray(), 44)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(if (enc) Cipher.ENCRYPT_MODE else Cipher.DECRYPT_MODE,
                SecretKeySpec(o, 0, 32, "AES"), GCMParameterSpec(128, o.copyOfRange(32, 44)))
            c.updateAAD(ad)
            return c.doFinal(data) // klucz wiadomości jest jednorazowy, więc stały nonce z HKDF jest bezpieczny
        }
    }
}
