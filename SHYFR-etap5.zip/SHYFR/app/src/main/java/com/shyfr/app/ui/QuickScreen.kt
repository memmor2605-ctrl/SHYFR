package com.shyfr.app.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.shyfr.app.vault.PinResult
import com.shyfr.app.vault.QuickUnlock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Frost: Color @Composable get() = MaterialTheme.colorScheme.primary

/** Ekran szybkiego odblokowania: odcisk palca (uruchamia się sam) albo PIN. onKey jest wywoływany z wątku tła. */
@Composable
fun QuickScreen(
    ctx: Context, activity: FragmentActivity, quick: QuickUnlock,
    onKey: (ByteArray) -> Unit, onUsePassword: () -> Unit,
    externalError: String? = null
) {
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val bioOk = remember { quick.bioEnabled() && Bio.available(ctx) }
    LaunchedEffect(externalError) { if (externalError != null) msg = externalError }

    fun tryBio() {
        val c = quick.bioUnlockCipher()
        if (c == null) { msg = "Odcisk palca wyłączony (zmieniono odciski w telefonie). Użyj PIN-u lub hasła."; return }
        Bio.prompt(activity, c, "Odblokuj SHYFR",
            onOk = { cipher ->
                scope.launch(Dispatchers.Default) {
                    try {
                        val key = quick.finishBioUnlock(cipher)
                        withContext(Dispatchers.Main) { onKey(key) }
                    } catch (_: Throwable) {
                        withContext(Dispatchers.Main) { msg = "Nie udało się odblokować odciskiem palca. Użyj PIN-u lub hasła." }
                    }
                }
            },
            onFail = { m -> msg = m.ifBlank { null } })
    }
    // Podpowiedź biometryczna tylko, gdy aktywność jest na pierwszym planie (ON_RESUME). Wywołanie z tła kończyło się cichym błędem.
    DisposableEffect(bioOk) {
        var fired = false
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME && bioOk && !fired) { fired = true; tryBio() }
        }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }

    Column(Modifier.fillMaxSize().padding(28.dp).imePadding(), verticalArrangement = Arrangement.Center) {
        LogoHeader(110.dp)
        Spacer(Modifier.height(24.dp))
        if (quick.pinEnabled()) {
            OutlinedTextField(pin, { if (it.length <= 12 && it.all(Char::isDigit)) pin = it },
                label = { Text("PIN") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(enabled = !busy && pin.length >= 6, modifier = Modifier.fillMaxWidth().height(52.dp), onClick = {
                busy = true; msg = null
                scope.launch(Dispatchers.Default) {
                    val chars = pin.toCharArray()
                    try {
                        when (val r = quick.unlockWithPin(chars)) {
                            is PinResult.Ok -> withContext(Dispatchers.Main) { onKey(r.key) }
                            is PinResult.Wrong -> withContext(Dispatchers.Main) {
                                msg = "Błędny PIN. Pozostało prób: ${r.left}"; pin = ""
                            }
                            PinResult.Disabled -> withContext(Dispatchers.Main) {
                                msg = "PIN wyłączony po zbyt wielu błędach. Użyj loginu i hasła."
                                onUsePassword()
                            }
                        }
                    } catch (t: Throwable) {
                        withContext(Dispatchers.Main) { msg = "Nie udało się odblokować PIN-em. Użyj hasła głównego." }
                    } finally {
                        chars.fill('\u0000')
                        withContext(Dispatchers.Main) { busy = false }
                    }
                }
            }) { Text("Odblokuj PINem") }
        }
        if (bioOk) {
            Spacer(Modifier.height(12.dp))
            OutlinedButton(modifier = Modifier.fillMaxWidth().height(52.dp), onClick = { tryBio() }) { Text("Użyj odcisku palca") }
        }
        msg?.let { Spacer(Modifier.height(12.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(20.dp))
        TextButton(onClick = onUsePassword) { Text("Użyj loginu i hasła") }
    }
}
