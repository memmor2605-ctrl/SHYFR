package com.shyfr.app.feed

import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Hkdf

/**
 * Osobny klucz Ed25519 dla każdej społeczności (i przekaźnika), wyprowadzany z klucza głównego sejfu.
 * Dzięki temu: (1) nie ma żadnego globalnego identyfikatora w rekordach publicznych, (2) klucze różnych
 * społeczności są od siebie niezależne i nie da się ich powiązać bez klucza głównego, (3) nie trzeba
 * przechowywać kluczy prywatnych: odtwarzają się po przywróceniu konta. [index] pozwala założyć „nową tożsamość”.
 */
object PublicKeys {
    fun derive(master: ByteArray, relay: String, cid: String, index: Int): Ed25519Sign.KeyPair {
        val seed = Hkdf.computeHkdf("HmacSha256", master, ByteArray(0), "shyfr-pub-v1|$relay|$cid|$index".toByteArray(Charsets.UTF_8), 32)
        return Ed25519Sign.KeyPair.newKeyPairFromSeed(seed)
    }

    /** Prywatny klucz X25519 „skrzynki” autora w danej społeczności (do odbioru próśb o kontakt). */
    fun inboxPriv(master: ByteArray, relay: String, cid: String, index: Int): ByteArray =
        Hkdf.computeHkdf("HmacSha256", master, ByteArray(0), "shyfr-inbox-v1|$relay|$cid|$index".toByteArray(Charsets.UTF_8), 32)

    /** Jednorazowy klucz X25519 odpowiedzi dla n-tej prośby do danego autora (nie wymaga zapisu klucza prywatnego). */
    fun requestPriv(master: ByteArray, relay: String, cid: String, target: String, n: Int): ByteArray =
        Hkdf.computeHkdf("HmacSha256", master, ByteArray(0), "shyfr-reqkey-v1|$relay|$cid|$target|$n".toByteArray(Charsets.UTF_8), 32)

    fun sign(kp: Ed25519Sign.KeyPair, msg: ByteArray): ByteArray = Ed25519Sign(kp.privateKey).sign(msg)
}
