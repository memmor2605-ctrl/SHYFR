package com.shyfr.app.nostr

import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/** Ramki WebSocket (RFC 6455): kodowanie i dekodowanie, bez żadnych zależności. */
object WsFrames {
    const val GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
    const val OP_CONT = 0; const val OP_TEXT = 1; const val OP_BIN = 2; const val OP_CLOSE = 8; const val OP_PING = 9; const val OP_PONG = 10
    const val MAX_PAYLOAD = 2_000_000
    private val rng = SecureRandom()

    class Frame(val fin: Boolean, val opcode: Int, val payload: ByteArray)

    fun acceptKey(key: String): String =
        Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1").digest((key + GUID).toByteArray(Charsets.US_ASCII)))

    fun encode(opcode: Int, payload: ByteArray, mask: Boolean, fin: Boolean = true): ByteArray {
        val out = ByteArrayOutputStream(payload.size + 14)
        out.write((if (fin) 0x80 else 0) or opcode)
        val m = if (mask) 0x80 else 0
        when {
            payload.size < 126 -> out.write(m or payload.size)
            payload.size <= 0xFFFF -> { out.write(m or 126); out.write(payload.size shr 8); out.write(payload.size and 0xFF) }
            else -> { out.write(m or 127); for (i in 7 downTo 0) out.write(((payload.size.toLong() shr (8 * i)) and 0xFF).toInt()) }
        }
        if (mask) {
            val key = ByteArray(4).also(rng::nextBytes)
            out.write(key)
            out.write(ByteArray(payload.size) { (payload[it].toInt() xor key[it % 4].toInt()).toByte() })
        } else out.write(payload)
        return out.toByteArray()
    }

    private fun readFully(i: InputStream, n: Int): ByteArray {
        val b = ByteArray(n); var off = 0
        while (off < n) { val r = i.read(b, off, n - off); if (r < 0) throw EOFException("Połączenie zamknięte"); off += r }
        return b
    }

    fun read(input: InputStream, maxPayload: Int = MAX_PAYLOAD): Frame {
        val h = readFully(input, 2)
        val fin = h[0].toInt() and 0x80 != 0
        val opcode = h[0].toInt() and 0x0F
        val masked = h[1].toInt() and 0x80 != 0
        var len = (h[1].toInt() and 0x7F).toLong()
        if (len == 126L) readFully(input, 2).let { len = ((it[0].toInt() and 0xFF) shl 8 or (it[1].toInt() and 0xFF)).toLong() }
        else if (len == 127L) readFully(input, 8).let { b -> len = 0; for (x in b) len = (len shl 8) or (x.toLong() and 0xFF) }
        if (len < 0 || len > maxPayload) throw IOException("Ramka za duża")
        val key = if (masked) readFully(input, 4) else null
        val p = readFully(input, len.toInt())
        if (key != null) for (i in p.indices) p[i] = (p[i].toInt() xor key[i % 4].toInt()).toByte()
        return Frame(fin, opcode, p)
    }
}

/** Sesja WebSocket na gotowym gnieździe (Tor + TLS już ustawione przez wywołującego). */
class WsSession(private val socket: Socket, private val input: InputStream = socket.getInputStream(), private val output: OutputStream = socket.getOutputStream()) {
    private val lock = Any()

    fun handshake(host: String, path: String = "/") {
        val key = Base64.getEncoder().encodeToString(ByteArray(16).also(SecureRandom()::nextBytes))
        val req = "GET $path HTTP/1.1\r\nHost: $host\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: $key\r\nSec-WebSocket-Version: 13\r\nUser-Agent: SHYFR\r\n\r\n"
        synchronized(lock) { output.write(req.toByteArray(Charsets.US_ASCII)); output.flush() }
        val head = StringBuilder()
        while (!head.endsWith("\r\n\r\n")) {
            val b = input.read(); if (b < 0) throw EOFException("Brak odpowiedzi serwera")
            head.append(b.toChar()); if (head.length > 16_384) throw IOException("Za długi nagłówek")
        }
        val lines = head.toString().split("\r\n")
        if (!lines[0].contains(" 101")) throw IOException("Serwer nie przyjął WebSocket: " + lines[0].take(60))
        val accept = lines.firstOrNull { it.startsWith("sec-websocket-accept:", ignoreCase = true) }?.substringAfter(':')?.trim()
        if (accept != WsFrames.acceptKey(key)) throw IOException("Zły klucz akceptacji")
    }

    fun sendText(text: String) = synchronized(lock) { output.write(WsFrames.encode(WsFrames.OP_TEXT, text.toByteArray(Charsets.UTF_8), true)); output.flush() }

    /** Następna wiadomość tekstowa albo null po zamknięciu. Ping obsługuje samodzielnie. */
    fun readMessage(): String? {
        var buf: ByteArrayOutputStream? = null
        while (true) {
            val f = WsFrames.read(input)
            when (f.opcode) {
                WsFrames.OP_PING -> synchronized(lock) { output.write(WsFrames.encode(WsFrames.OP_PONG, f.payload, true)); output.flush() }
                WsFrames.OP_PONG -> {}
                WsFrames.OP_CLOSE -> { runCatching { synchronized(lock) { output.write(WsFrames.encode(WsFrames.OP_CLOSE, f.payload, true)); output.flush() } }; return null }
                WsFrames.OP_TEXT, WsFrames.OP_CONT, WsFrames.OP_BIN -> {
                    if (f.opcode == WsFrames.OP_TEXT) buf = ByteArrayOutputStream()
                    if (f.opcode == WsFrames.OP_BIN) { if (f.fin) continue else { buf = null; continue } }
                    val b = buf ?: continue
                    b.write(f.payload); if (b.size() > WsFrames.MAX_PAYLOAD) throw IOException("Wiadomość za duża")
                    if (f.fin) return b.toString(Charsets.UTF_8.name())
                }
            }
        }
    }

    fun sendPing() = synchronized(lock) { output.write(WsFrames.encode(WsFrames.OP_PING, ByteArray(0), true)); output.flush() }

    fun close() { runCatching { socket.close() } }
}
