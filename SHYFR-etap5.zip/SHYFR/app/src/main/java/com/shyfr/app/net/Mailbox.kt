package com.shyfr.app.net

import android.content.Context
import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Hkdf
import com.shyfr.app.Trace
import com.shyfr.app.crypto.Keys
import com.shyfr.app.feed.PublicKeys
import com.shyfr.app.feed.PublicProto
import com.shyfr.app.feed.RelayClient
import com.shyfr.app.session.Prefs
import com.shyfr.app.vault.Contact
import com.shyfr.app.vault.Store
import org.json.JSONArray
import org.json.JSONObject

/**
 * Skrzynka na przekaźniku (store-and-forward): gdy bezpośrednie połączenie P2P przez Tora się nie uda (druga osoba offline,
 * zła sieć), zaszyfrowana ramka trafia do jednokierunkowej skrzynki pary, skąd odbiorca pobiera ją przy najbliższym sprawdzeniu.
 *
 * - Ramka jest tą samą ramką Double Ratchet, którą wysłalibyśmy bezpośrednio. Przekaźnik widzi tylko szyfrogram, rozmiar i czas.
 * - Identyfikator skrzynki to klucz publiczny Ed25519 wyprowadzony przez OBU rozmówców ze wspólnego sekretu (X25519 + HKDF), osobno
 *   dla każdego kierunku. Pisać i czytać może wyłącznie ta para; identyfikator nie ujawnia ani kluczy tożsamości, ani adresów onion.
 * - Oba telefony muszą mieć wpisany TEN SAM przekaźnik. Duplikaty (ramka dotarła i bezpośrednio, i skrzynką) są odrzucane po identyfikatorze nagłówka.
 * - Ramki większe niż [MAX_FRAME] (np. duże pliki) zostają przy P2P.
 */
class Mailbox(private val ctx: Context) {
    private val client = RelayClient(ctx)
    private val store = Store(ctx)

    suspend fun put(c: Contact, frame: ByteArray): Boolean {
        if (!enabled(ctx) || frame.size > MAX_FRAME) return false
        return try {
            val (priv, pub) = store.keys()
            val kp = deriveBoxKey(priv, pub, c.pubkey, outgoing = true)
            val data = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(frame)
            client.act("mbox.put", kp, "box" to PublicProto.hex(kp.publicKey), "data" to data)
            true
        } catch (e: Exception) {
            Trace.log("skrzynka: wysyłka nieudana (${e.javaClass.simpleName}: ${(e.message ?: "").take(60)})")
            false
        }
    }

    /** Pobiera ramki od wszystkich kontaktów jednym zapytaniem i przetwarza je jak ramki z gniazda. Zwraca liczbę przetworzonych. */
    suspend fun pollAll(m: Messenger): Int {
        if (!enabled(ctx)) return 0
        val contacts = store.contacts().filter { !it.blocked }
        if (contacts.isEmpty()) return 0
        val (priv, pub) = store.keys()
        val keys = HashMap<String, Ed25519Sign.KeyPair>()
        for (c in contacts) { val kp = deriveBoxKey(priv, pub, c.pubkey, outgoing = false); keys[PublicProto.hex(kp.publicKey)] = kp }
        val ts = System.currentTimeMillis().toString()
        val items = JSONArray()
        for ((id, kp) in keys) items.put(JSONObject().put("box", id).put("after", "0").put("ts", ts)
            .put("sig", PublicProto.hex(PublicKeys.sign(kp, PublicProto.sigMsg("pull", id, "0", ts)))))
        val results = client.postJson("/v1/mbox/pull", JSONObject().put("items", items).toString()).optJSONObject("results") ?: return 0
        var done = 0
        for (id in results.keys()) {
            val kp = keys[id] ?: continue
            val arr = results.getJSONArray(id)
            var ackUpTo = 0L
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val seq = o.getLong("seq")
                val ok = try { m.handleFrameBlob(java.util.Base64.getUrlDecoder().decode(o.getString("data"))) } catch (e: Exception) { false }
                if (!ok) {
                    // ramki, której nie da się przetworzyć (np. sesja jeszcze nieustanowiona), nie kasujemy od razu; po 3 próbach ją porzucamy
                    val n = (failures[seq] ?: 0) + 1
                    failures[seq] = n
                    if (n < 3) break
                    Trace.log("skrzynka: porzucam nieprzetwarzalną ramkę po $n próbach")
                }
                ackUpTo = seq; done++
            }
            if (ackUpTo > 0) runCatching { client.act("mbox.ack", kp, "box" to id, "upto" to ackUpTo.toString()) }
        }
        if (failures.size > 500) failures.clear()
        return done
    }

    companion object {
        const val MAX_FRAME = 64_000
        private val failures = java.util.concurrent.ConcurrentHashMap<Long, Int>()

        fun enabled(ctx: Context): Boolean = Prefs.relayOnion(ctx) != null

        /** Ten sam klucz po obu stronach: nadawca używa (ja→on), odbiorca (on→ja). Czysta funkcja, testowana jednostkowo. */
        fun deriveBoxKey(myPriv: ByteArray, myPub: ByteArray, theirPub: ByteArray, outgoing: Boolean): Ed25519Sign.KeyPair {
            val shared = Keys.dh(myPriv, theirPub)
            val from = if (outgoing) myPub else theirPub
            val to = if (outgoing) theirPub else myPub
            val info = ("shyfr-mbox-v1|" + PublicProto.hex(from) + "|" + PublicProto.hex(to)).toByteArray(Charsets.UTF_8)
            val seed = Hkdf.computeHkdf("HmacSha256", shared, ByteArray(0), info, 32)
            shared.fill(0)
            return Ed25519Sign.KeyPair.newKeyPairFromSeed(seed)
        }
    }
}
