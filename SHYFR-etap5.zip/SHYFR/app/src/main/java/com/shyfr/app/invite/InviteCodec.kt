package com.shyfr.app.invite

import android.util.Base64

/** Format zaproszenia: shyfr://join/<base64url( ver(1) | onion(56) | pubkey(32) | sekret(32) )> */
object InviteCodec {
    const val PREFIX = "shyfr://join/"
    private val ONION = Regex("^[a-z2-7]{56}$")
    private const val FLAGS = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    class Payload(val onion: String, val pub: ByteArray, val secret: ByteArray)

    fun encode(p: Payload): String {
        val host = p.onion.removeSuffix(".onion")
        require(ONION.matches(host) && p.pub.size == 32 && p.secret.size == 32)
        val bytes = byteArrayOf(1) + host.toByteArray(Charsets.US_ASCII) + p.pub + p.secret
        return PREFIX + Base64.encodeToString(bytes, FLAGS)
    }

    fun decode(link: String): Payload? = try {
        val t = link.trim()
        if (!t.startsWith(PREFIX)) null else {
            val b = Base64.decode(t.removePrefix(PREFIX), FLAGS)
            val host = String(b, 1, 56, Charsets.US_ASCII)
            if (b.size != 121 || b[0] != 1.toByte() || !ONION.matches(host)) null
            else Payload("$host.onion", b.copyOfRange(57, 89), b.copyOfRange(89, 121))
        }
    } catch (e: Exception) { null }
}
