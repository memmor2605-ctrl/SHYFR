package com.shyfr.app.session

import android.content.Context

/** Stan UI współdzielony między ekranami (bez przekazywania parametrów przez całe drzewo). */
object UiState { val fontLevel = kotlinx.coroutines.flow.MutableStateFlow(1) }

/** Ustawienia niewrażliwe (bez kluczy i danych rozmów). */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("shyfr_settings", Context.MODE_PRIVATE)
    fun lockSeconds(c: Context) = p(c).getInt("lock_s", 60)
    /** 0 = systemowy, 1 = ciemny, 2 = jasny */
    fun theme(c: Context) = p(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) = p(c).edit().putInt("theme", v).apply()
    /** Blokada zrzutów ekranu i podglądu w przełączniku aplikacji (FLAG_SECURE). Domyślnie włączona. */
    fun screenSecurity(c: Context) = p(c).getBoolean("screen_security", true)
    fun setScreenSecurity(c: Context, v: Boolean) = p(c).edit().putBoolean("screen_security", v).apply()
    /** Potwierdzenia przeczytania (✓✓). Wyłączone = nie wysyłasz ich, ale też nie widzisz cudzych (jak w Signal). */
    fun readReceipts(c: Context) = p(c).getBoolean("read_receipts", true)
    fun setReadReceipts(c: Context, v: Boolean) = p(c).edit().putBoolean("read_receipts", v).apply()
    /** Domyślny czas znikania dla NOWYCH kontaktów (0 = wyłączone). */
    fun defaultTtl(c: Context) = p(c).getInt("default_ttl", 0)
    fun setDefaultTtl(c: Context, v: Int) = p(c).edit().putInt("default_ttl", v).apply()
    /** Rozmiar czcionki: 0 = mały, 1 = normalny, 2 = duży, 3 = bardzo duży. */
    fun fontLevel(c: Context) = p(c).getInt("font_level", 1).coerceIn(0, 3)
    fun setFontLevel(c: Context, v: Int) = p(c).edit().putInt("font_level", v).apply()
    /** Pokazuj kontaktom, że jestem aktywny/online (i widzieć ich status). Wyłączone = brak statusu w obie strony. */
    fun presenceShare(c: Context) = p(c).getBoolean("presence_share", true)
    fun setPresenceShare(c: Context, v: Boolean) = p(c).edit().putBoolean("presence_share", v).apply()
    /** Powiadamiaj rozmówcę o moim zrzucie ekranu, nagraniu ekranu, eksporcie rozmowy i zapisie pliku. */
    fun notifyCapture(c: Context) = p(c).getBoolean("notify_capture", true)
    fun setNotifyCapture(c: Context, v: Boolean) = p(c).edit().putBoolean("notify_capture", v).apply()
    /** Kiedy aplikacja była ostatnio na pierwszym planie (do statusu „ostatnio aktywny”). */
    fun lastActive(c: Context) = p(c).getLong("last_active", 0L)
    fun setLastActive(c: Context, ts: Long) = p(c).edit().putLong("last_active", ts).apply()
    /** Ostatnia udana kopia zapasowa (ms), 0 = nigdy. */
    fun lastBackup(c: Context) = p(c).getLong("last_backup", 0L)
    fun setLastBackup(c: Context, ts: Long) = p(c).edit().putLong("last_backup", ts).apply()
    fun onboarded(c: Context) = p(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context) = p(c).edit().putBoolean("onboarded", true).apply()
    /** Tor i odbiór wiadomości działają po zablokowaniu ekranu aplikacji (klucz zostaje w RAM procesu). */
    fun bgNode(c: Context) = p(c).getBoolean("bg_node", true)
    fun setBgNode(c: Context, v: Boolean) = p(c).edit().putBoolean("bg_node", v).apply()
    /** Adres przekaźnika publicznego (usługa onion v3). Pusty = warstwa publiczna wyłączona. */
    /**
     * Adres przekaźnika: wybór użytkownika, a gdy go nie ustawił, domyślny wbudowany w wersję (BuildConfig.DEFAULT_RELAY).
     * Pusty zapis = użytkownik świadomie wyłączył przekaźnik (domyślny nie wraca sam).
     */
    fun relayOnion(c: Context): String? {
        val sp = p(c)
        if (sp.contains("relay_onion")) return sp.getString("relay_onion", null)?.takeIf { it.isNotBlank() }
        return defaultRelay()
    }
    fun defaultRelay(): String? = com.shyfr.app.feed.PublicProto.normalizeOnion(com.shyfr.app.BuildConfig.DEFAULT_RELAY)
    fun usingDefaultRelay(c: Context): Boolean = !p(c).contains("relay_onion") && defaultRelay() != null
    /** null = wyłącz przekaźnik; [resetToDefault] przywraca domyślny. */
    fun setRelayOnion(c: Context, v: String?) = p(c).edit().putString("relay_onion", v ?: "").apply()
    fun resetRelayToDefault(c: Context) = p(c).edit().remove("relay_onion").apply()
    /** Znacznik czasu ostatniego otwarcia ekranu Aktywność (do wyróżniania nowych zdarzeń). */
    fun activitySeen(c: Context): Long = p(c).getLong("act_seen", 0L)
    fun setActivitySeen(c: Context, v: Long) = p(c).edit().putLong("act_seen", v).apply()
    /** Społeczności z wyciszonymi powiadomieniami o aktywności. */
    fun mutedCommunities(c: Context): Set<String> = (p(c).getStringSet("muted_comm", emptySet()) ?: emptySet()).toSet()
    fun setCommunityMuted(c: Context, cid: String, muted: Boolean) {
        val s = HashSet(mutedCommunities(c)); if (muted) s.add(cid) else s.remove(cid)
        p(c).edit().putStringSet("muted_comm", s).apply()
    }
    // ---- tryb „nie przeszkadzać”
    fun dndEnabled(c: Context) = p(c).getBoolean("dnd_on", false)
    fun dndStart(c: Context) = p(c).getInt("dnd_start", 22)
    fun dndEnd(c: Context) = p(c).getInt("dnd_end", 7)
    fun setDnd(c: Context, on: Boolean, start: Int, end: Int) = p(c).edit().putBoolean("dnd_on", on).putInt("dnd_start", start).putInt("dnd_end", end).apply()
    /** Czy teraz obowiązuje cisza (powiadomienia nie są pokazywane). */
    fun quietNow(c: Context): Boolean =
        dndEnabled(c) && Dnd.isQuiet(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY), dndStart(c), dndEnd(c))
    /** Dodatkowe przekaźniki dla skrzynki wiadomości prywatnych (odporność na awarię jednego). Adresy onion v3, max 3 razem z głównym. */
    fun extraRelays(c: Context): List<String> = (p(c).getString("relay_extra", "") ?: "").split(",", "\n", " ").mapNotNull { com.shyfr.app.feed.PublicProto.normalizeOnion(it) }.distinct()
    fun setExtraRelays(c: Context, relays: List<String>) = p(c).edit().putString("relay_extra", relays.joinToString(",")).apply()
    /** Wszystkie przekaźniki skrzynki w kolejności: główny, potem dodatkowe (do 3). */
    fun mailboxRelays(c: Context): List<String> = (listOfNotNull(relayOnion(c)) + extraRelays(c)).distinct().take(3)
    fun setLockSeconds(c: Context, s: Int) = p(c).edit().putInt("lock_s", s).apply()

    // ---- Mosty Tor (zwykłe; obfs4/snowflake wymagają dodatkowej biblioteki) ----
    fun bridgesText(c: Context): String = p(c).getString("bridges", "") ?: ""
    fun bridges(c: Context): List<String> = bridgesText(c).lines().map { it.trim() }.filter { it.isNotEmpty() }
    fun setBridges(c: Context, lines: List<String>) = p(c).edit().putString("bridges", lines.joinToString("\n")).apply()

    private val BRIDGE_RE = Regex("^(\\d{1,3}(\\.\\d{1,3}){3}|\\[[0-9a-fA-F:]+\\]):\\d{1,5}(\\s+[0-9A-Fa-f]{40})?$")

    /** Zwraca (poprawne linie, komunikat błędu lub null). Cudzysłowy i inne znaki są odrzucane (brak wstrzyknięć do konfiguracji). */
    fun parseBridges(text: String): Pair<List<String>, String?> {
        val out = ArrayList<String>()
        for (raw in text.lines()) {
            var l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("bridge ", ignoreCase = true)) l = l.substring(7).trim()
            if (Regex("^(obfs4|snowflake|meek|webtunnel|scramblesuit)\\b", RegexOption.IGNORE_CASE).containsMatchIn(l))
                return emptyList<String>() to "Obsługiwane są zwykłe mosty: IP:port [odcisk]."
            if (!BRIDGE_RE.matches(l)) return emptyList<String>() to "Nieprawidłowy most: $l"
            out.add(l)
        }
        return out to null
    }
}
