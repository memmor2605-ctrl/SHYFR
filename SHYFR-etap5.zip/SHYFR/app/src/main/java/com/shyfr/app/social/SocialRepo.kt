package com.shyfr.app.social

import android.content.Context
import com.google.crypto.tink.subtle.Ed25519Sign
import com.shyfr.app.feed.PublicProto
import com.shyfr.app.feed.RelayClient
import com.shyfr.app.feed.RelayException
import com.shyfr.app.session.Session
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class SocialUser(val pub: String, val handle: String, val name: String, val vis: String, val state: String, val ts: Long, val bio: String = "")
data class SocialProfileInfo(
    val pub: String, val handle: String, val name: String, val bio: String, val vis: String,
    val followers: Int?, val following: Int?, val youFollow: String, val followsYou: Boolean,
    val discover: Boolean, val hideFollowers: Boolean, val hideFollowing: Boolean
)
data class SocialEvent(val type: String, val pub: String, val handle: String, val name: String, val ts: Long)

/**
 * Obserwowanie przez przekaźnik. Każda akcja jest podpisana kluczem WYBRANEJ tożsamości, więc tożsamości
 * nie mieszają obserwujących. Przekaźnik widzi krawędzie grafu (patrz relay/README.md); lokalne listy
 * (wyciszeni, bliscy znajomi, ulubieni) zostają tylko w telefonie.
 */
class SocialRepo(private val ctx: Context) {
    private val client = RelayClient(ctx)
    private val store = SocialStore(ctx)

    private fun key(id: SocialIdentity): Ed25519Sign.KeyPair {
        val m = Session.get() ?: throw RelayException("Konto zablokowane.")
        return IdentityKeys.signing(m, id.kind, id.idx)
    }
    suspend fun pubOf(id: SocialIdentity): String = withContext(Dispatchers.IO) { PublicProto.hex(key(id).publicKey) }
    suspend fun activeIdentity(): SocialIdentity = withContext(Dispatchers.IO) {
        val a = store.ensureDefaults(""); a
    }

    private fun users(o: JSONObject): List<SocialUser> {
        val a = o.optJSONArray("users") ?: return emptyList()
        return (0 until a.length()).map { i ->
            val u = a.getJSONObject(i)
            SocialUser(u.getString("pub"), u.optString("handle"), u.optString("name"), u.optString("vis"), u.optString("state"), u.optLong("ts"), u.optString("bio"))
        }
    }

    private fun profile(o: JSONObject) = SocialProfileInfo(
        o.getString("pub"), o.optString("handle"), o.optString("name"), o.optString("bio"), o.optString("vis"),
        if (o.isNull("followers")) null else o.optInt("followers"), if (o.isNull("following")) null else o.optInt("following"),
        o.optString("you_follow"), o.optBoolean("follows_you"),
        o.optInt("discover") == 1, o.optInt("hide_followers") == 1, o.optInt("hide_following") == 1
    )

    suspend fun myProfile(id: SocialIdentity): SocialProfileInfo? {
        val k = withContext(Dispatchers.IO) { key(id) }
        return try { profile(client.get("/v1/social/profile?pub=${PublicProto.hex(k.publicKey)}", k)) }
        catch (e: RelayException) { if (e.code == 404) null else throw e }
    }

    suspend fun setProfile(id: SocialIdentity, handle: String, name: String, bio: String, discover: Boolean, hideFollowers: Boolean, hideFollowing: Boolean) {
        val vis = when (id.kind) { IdentityKind.PUBLIC -> "public"; IdentityKind.PRIVATE -> "private"; IdentityKind.ANON -> "anon" }
        client.act("social.profile", withContext(Dispatchers.IO) { key(id) },
            "handle" to handle, "name" to name.trim(), "bio" to bio.trim(), "vis" to vis,
            "discover" to if (discover) "1" else "0", "hide_followers" to if (hideFollowers) "1" else "0", "hide_following" to if (hideFollowing) "1" else "0")
    }

    suspend fun follow(id: SocialIdentity, target: String, on: Boolean): String =
        client.act("social.follow", withContext(Dispatchers.IO) { key(id) }, "target" to target, "on" to if (on) "1" else "0").optString("state")

    suspend fun decide(id: SocialIdentity, follower: String, accept: Boolean) {
        client.act("social.decide", withContext(Dispatchers.IO) { key(id) }, "follower" to follower, "accept" to if (accept) "1" else "0")
    }

    suspend fun block(id: SocialIdentity, target: String, on: Boolean) {
        client.act("social.block", withContext(Dispatchers.IO) { key(id) }, "target" to target, "on" to if (on) "1" else "0")
    }

    suspend fun list(id: SocialIdentity, kind: String, q: String = ""): List<SocialUser> {
        val k = withContext(Dispatchers.IO) { key(id) }
        return users(client.get("/v1/social/$kind?pub=${PublicProto.hex(k.publicKey)}&limit=50&q=${RelayClient.q(q)}", k))
    }

    suspend fun requests(id: SocialIdentity): List<SocialUser> {
        val o = client.get("/v1/social/requests", withContext(Dispatchers.IO) { key(id) })
        val a = o.optJSONArray("requests") ?: return emptyList()
        return (0 until a.length()).map { i -> a.getJSONObject(i).let { SocialUser(it.getString("pub"), it.optString("handle"), it.optString("name"), it.optString("vis"), "pending", it.optLong("ts")) } }
    }

    suspend fun search(id: SocialIdentity, q: String): List<SocialUser> =
        users(client.get("/v1/social/search?q=${RelayClient.q(q)}", withContext(Dispatchers.IO) { key(id) }))

    suspend fun notifs(id: SocialIdentity, since: Long = 0): List<SocialEvent> {
        val a = client.get("/v1/social/notifs?since=$since", withContext(Dispatchers.IO) { key(id) }).optJSONArray("events") ?: return emptyList()
        return (0 until a.length()).map { i -> a.getJSONObject(i).let { SocialEvent(it.optString("type"), it.optString("pub"), it.optString("handle"), it.optString("name"), it.optLong("ts")) } }
    }
}
