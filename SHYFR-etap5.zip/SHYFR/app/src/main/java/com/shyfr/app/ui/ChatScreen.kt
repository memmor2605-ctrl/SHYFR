package com.shyfr.app.ui

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import java.io.File
import androidx.compose.animation.core.animate
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.IntOffset
import androidx.fragment.app.FragmentActivity
import com.shyfr.app.net.Presence
import kotlin.math.roundToInt
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import com.shyfr.app.crypto.Keys
import com.shyfr.app.net.Messenger
import com.shyfr.app.net.NodeRuntime
import com.shyfr.app.session.Prefs
import com.shyfr.app.vault.Contact
import com.shyfr.app.vault.Msg
import com.shyfr.app.vault.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val TTLS = listOf(0 to "wył.", 3600 to "1 godz.", 86400 to "24 godz.", 604800 to "7 dni")
private val QUICK_REACTIONS = listOf("👍", "❤️", "😂", "😮", "😢", "🙏")

private val DAY_FMT = java.text.SimpleDateFormat("d MMMM yyyy", java.util.Locale("pl"))
private fun dayKey(ts: Long): Long {
    val c = java.util.Calendar.getInstance().apply { timeInMillis = ts }
    return c.get(java.util.Calendar.YEAR) * 400L + c.get(java.util.Calendar.DAY_OF_YEAR)
}
private fun dayLabel(ts: Long): String {
    val now = System.currentTimeMillis()
    return when (dayKey(ts)) { dayKey(now) -> "Dziś"; dayKey(now - 86_400_000L) -> "Wczoraj"; else -> DAY_FMT.format(java.util.Date(ts)) }
}

/**
 * Przeciągnięcie dymku w prawo = odpowiedź (jak w Messengerze). Przy progu telefon delikatnie wibruje,
 * a dymek wraca na miejsce. Zwykłe dotknięcie i przytrzymanie dalej działają, bo przeciągnięcie reaguje dopiero po przekroczeniu progu ruchu.
 */
@Composable
private fun SwipeToReply(enabled: Boolean, accent: Color, onReply: () -> Unit, content: @Composable () -> Unit) {
    if (!enabled) { content(); return }
    var dragX by remember { mutableFloatStateOf(0f) }
    var fired by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val trigger = with(density) { 56.dp.toPx() }
    val maxPull = with(density) { 88.dp.toPx() }
    fun settle() { scope.launch { animate(dragX, 0f) { v, _ -> dragX = v } } }
    Box(Modifier.fillMaxWidth().pointerInput(Unit) {
        detectHorizontalDragGestures(
            onDragStart = { fired = false },
            onDragEnd = { settle() },
            onDragCancel = { settle() },
            onHorizontalDrag = { change, dx ->
                change.consume()
                dragX = (dragX + dx * 0.7f).coerceIn(0f, maxPull)
                if (!fired && dragX >= trigger) {
                    fired = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onReply()
                }
            }
        )
    }) {
        val progress = (dragX / trigger).coerceIn(0f, 1f)
        Box(Modifier.align(Alignment.CenterStart).padding(start = 14.dp).size(30.dp).graphicsLayer { alpha = progress; scaleX = .6f + .4f * progress; scaleY = .6f + .4f * progress }
            .clip(CircleShape).background(accent.copy(alpha = .25f)), contentAlignment = Alignment.Center) { Icon24(Ic.Reply, accent, 16.dp) }
        Box(Modifier.offset { IntOffset(dragX.roundToInt(), 0) }) { content() }
    }
}

@Composable
private fun SheetAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color = Color.Unspecified, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon24(icon, if (color == Color.Unspecified) ShSilver else color, 20.dp, Modifier.padding(end = 14.dp))
        Text(label, fontSize = 15.sp, color = color)
    }
}

private fun preview(m: Msg): String = if (m.deleted) "Wiadomość usunięta" else m.body.take(80)

@Composable
private fun AudioAttachment(ctx: Context, id: String, name: String) {
    var playing by remember(id) { mutableStateOf(false) }
    var player by remember(id) { mutableStateOf<MediaPlayer?>(null) }
    val scope = rememberCoroutineScope()
    val activePlayer by rememberUpdatedState(player)
    DisposableEffect(id) {
        onDispose { runCatching { activePlayer?.release() }; File(ctx.cacheDir, "shyfr-audio-$id.m4a").delete() }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            val current = player
            if (current != null) {
                if (current.isPlaying) { current.pause(); playing = false }
                else { current.start(); playing = true }
            } else {
                scope.launch {
                    val file = runCatching {
                        withContext(Dispatchers.IO) {
                            File(ctx.cacheDir, "shyfr-audio-$id.m4a").also {
                                if (!it.exists()) it.writeBytes(Store(ctx).attBytes(id))
                            }
                        }
                    }.getOrNull()
                    val prepared = file?.let { runCatching { MediaPlayer.create(ctx, Uri.fromFile(it)) }.getOrNull() }
                    if (prepared == null) {
                        playing = false
                    } else {
                        prepared.setOnCompletionListener { mp -> mp.seekTo(0); playing = false }
                        player = prepared
                        prepared.start()
                        playing = true
                    }
                }
            }
        }) { Text(if (playing) "Pauza" else "Odtwórz") }
        Column {
            Text("Wiadomość głosowa", fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(name, fontSize = 11.sp, color = ShMuted, maxLines = 1)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(ctx: Context, activity: FragmentActivity?, contact: Contact, onBack: () -> Unit) {
    val ver by NodeRuntime.messagesVersion.collectAsState()
    val cver by NodeRuntime.contactsVersion.collectAsState()
    // Aktualny stan kontaktu (motyw, pseudonimy, obecność, tryb zrzutów) — odświeżany po każdej zmianie.
    val live by produceState(contact, cver) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).contact(contact.id) }.getOrNull() ?: contact }
    }
    var nowTs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(20_000); nowTs = System.currentTimeMillis() } }
    val pal = chatPalette(live.theme)
    val msgs by produceState(emptyList<Msg>(), ver) {
        value = withContext(Dispatchers.IO) {
            runCatching { Store(ctx).also { it.markRead(contact.id) }.messages(contact.id) }.getOrDefault(emptyList())
        }
    }
    val pollVotes by produceState(emptyMap<String, Pair<Int?, Int?>>(), ver) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).pollVotes(contact.id) }.getOrDefault(emptyMap()) }
    }
    var creatingPoll by remember { mutableStateOf(false) }
    val photo by produceState<ByteArray?>(null, cver) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).contactAvatar(contact.id) }.getOrNull() }
    }
    var text by remember { mutableStateOf("") }
    var draftLoaded by remember(contact.id) { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var searchQ by remember { mutableStateOf("") }
    var onlyStarred by remember { mutableStateOf(false) }
    var starTick by remember { mutableIntStateOf(0) }
    var forwardMsg by remember { mutableStateOf<Msg?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var openLink by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current
    val starred by produceState(emptySet<Long>(), ver, starTick) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).starredIds(contact.id) }.getOrDefault(emptySet()) }
    }
    var err by remember { mutableStateOf<String?>(null) }
    var ttl by remember { mutableIntStateOf(contact.ttl) }
    var label by remember { mutableStateOf(contact.label) }
    val partnerName = live.chatNick.ifBlank { label }
    var verified by remember { mutableStateOf(contact.verified) }
    var muted by remember { mutableStateOf(contact.muted) }
    var details by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showAttach by remember { mutableStateOf(false) }
    var viewImage by remember { mutableStateOf<String?>(null) }
    var saveTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var menuFor by remember { mutableStateOf<Msg?>(null) }
    var replyTo by remember { mutableStateOf<Msg?>(null) }
    var showEmoji by remember { mutableStateOf(false) }
    var showVerify by remember { mutableStateOf(false) }
    var scanVerify by remember { mutableStateOf(false) }
    var verifyMismatch by remember { mutableStateOf(false) }
    var warnDismissed by remember(contact.id) { mutableStateOf(false) }
    var emojiTarget by remember { mutableStateOf<Msg?>(null) }
    var editing by remember { mutableStateOf<Msg?>(null) }
    var confirmExport by remember { mutableStateOf(false) }
    val exportScope = rememberCoroutineScope()
    val exportDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) exportScope.launch(Dispatchers.IO) {
            runCatching {
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                val sb = StringBuilder("Rozmowa SHYFR z: $label\n\n")
                Store(ctx).messages(contact.id).filter { !it.deleted && !it.sys && it.att == null && it.body.isNotBlank() }.forEach {
                    sb.append("[").append(fmt.format(java.util.Date(it.ts))).append("] ")
                        .append(if (it.outgoing) "Ja" else label).append(": ").append(it.body).append("\n")
                }
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(sb.toString().toByteArray()) }
                Messenger(ctx).sendNotice(contact.id, Messenger.NOTICE_EXPORT)
            }.onFailure { err = "Nie udało się wyeksportować rozmowy." }
        }
    }
    val safety by produceState("", contact.id) {
        value = withContext(Dispatchers.IO) { runCatching { Keys.safetyNumber(Store(ctx).keys().second, contact.pubkey) }.getOrDefault("") }
    }
    val scope = rememberCoroutineScope()
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    var isRecording by remember { mutableStateOf(false) }

    fun beginVoiceRecording() {
        try {
            val file = File(ctx.cacheDir, "voice-${System.currentTimeMillis()}.m4a")
            val r = MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(96000)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recordingFile = file
            isRecording = true
            err = null
        } catch (t: Throwable) {
            runCatching { recorder?.release() }
            recorder = null; isRecording = false
            err = "Nie udało się rozpocząć nagrywania: ${t.message ?: "błąd mikrofonu"}"
        }
    }
    val recordPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) beginVoiceRecording() else err = "Aby nagrać wiadomość głosową, zezwól na dostęp do mikrofonu."
    }
    fun finishVoiceRecording(send: Boolean) {
        val r = recorder
        val file = recordingFile
        recorder = null; isRecording = false
        runCatching { r?.stop() }.onFailure { err = "Nagranie jest zbyt krótkie lub nie udało się go zakończyć." }
        runCatching { r?.release() }
        if (send && file != null && file.exists() && file.length() > 0L) {
            scope.launch(Dispatchers.IO) {
                val result = runCatching {
                    val bytes = file.readBytes()
                    Messenger(ctx).sendAttachment(contact.id, "wiadomosc-glosowa.m4a", "audio/mp4", bytes, false)
                }.getOrElse { "Nie udało się wysłać wiadomości głosowej." }
                withContext(Dispatchers.Main) {
                    err = result
                    NodeRuntime.messagesVersion.update { it + 1 }
                    file.delete()
                    recordingFile = null
                }
            }
        } else {
            file?.delete()
            recordingFile = null
        }
    }
    val activeRecorder by rememberUpdatedState(recorder)
    val activeRecordingFile by rememberUpdatedState(recordingFile)
    DisposableEffect(Unit) {
        onDispose {
            runCatching { activeRecorder?.stop() }
            runCatching { activeRecorder?.release() }
            activeRecordingFile?.delete()
        }
    }

    fun sendUri(uri: Uri, asImage: Boolean) {
        scope.launch(Dispatchers.IO) {
            err = try {
                val p = Attachments.prepare(ctx, uri, asImage)
                Messenger(ctx).sendAttachment(contact.id, p.name, p.mime, p.bytes, p.image)
            } catch (e: IllegalArgumentException) { e.message } catch (e: Throwable) { "Nie udało się wysłać pliku." }
        }
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) sendUri(uri, true) }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) sendUri(uri, false) }
    val saveDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val t = saveTarget
        if (uri != null && t != null) scope.launch(Dispatchers.IO) {
            runCatching {
                val bytes = Store(ctx).attBytes(t.first)
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                Messenger(ctx).sendNotice(contact.id, Messenger.NOTICE_SAVED)
            }.onFailure { err = "Nie udało się zapisać pliku." }
        }
    }

    LaunchedEffect(contact.id) {
        val d = withContext(Dispatchers.IO) { runCatching { Store(ctx).draft(contact.id) }.getOrDefault("") }
        if (text.isEmpty()) text = d
        draftLoaded = true
    }
    LaunchedEffect(text, draftLoaded) {
        if (!draftLoaded) return@LaunchedEffect
        kotlinx.coroutines.delay(500)
        withContext(Dispatchers.IO) { runCatching { Store(ctx).setDraft(contact.id, text) } }
        NodeRuntime.contactsVersion.update { it + 1 }
    }
    LaunchedEffect(msgs) {
        if (!Prefs.readReceipts(ctx)) return@LaunchedEffect
        val last = msgs.lastOrNull { !it.outgoing && !it.deleted && it.mid != null } ?: return@LaunchedEffect
        val mid = last.mid ?: return@LaunchedEffect
        withContext(Dispatchers.IO) {
            runCatching {
                val st = Store(ctx)
                if (st.lastReceipt(contact.id) != mid && Messenger(ctx).sendRead(contact.id, mid)) st.setLastReceipt(contact.id, mid)
            }
        }
    }
    var emojiInput by remember(live.qEmoji) { mutableStateOf(live.qEmoji) }
    var nickPeerInput by remember(live.chatNick) { mutableStateOf(live.chatNick) }
    var nickMeInput by remember(live.myNick) { mutableStateOf(live.myNick) }
    /** Zapisuje personalizację lokalnie i wysyła ją rozmówcy (motyw, emoji i pseudonimy są wspólne). */
    fun applyLook(theme: Int) {
        val e = emojiInput.trim().take(8); val np = nickPeerInput.trim().take(24); val nm = nickMeInput.trim().take(24)
        scope.launch(Dispatchers.IO) {
            runCatching { Store(ctx).setChatLook(contact.id, theme, e, np, nm); Messenger(ctx).sendLook(contact.id, theme, e, np, nm) }
            NodeRuntime.contactsVersion.update { it + 1 }
        }
    }
    val quickEmoji = live.qEmoji.ifBlank { "👍" }

    // ---- Ochrona zrzutów ekranu dla tej rozmowy: 0 = jak w Ustawieniach, 1 = blokuj, 2 = zezwalaj i powiadamiaj ----
    val blocked = when (live.capMode) { 1 -> true; 2 -> false; else -> Prefs.screenSecurity(ctx) }
    DisposableEffect(blocked, activity) {
        val w = activity?.window
        if (blocked) w?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        else w?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        onDispose {
            // wyjście z rozmowy przywraca globalne ustawienie
            if (Prefs.screenSecurity(ctx)) w?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
            else w?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    // Gdy zrzuty są dozwolone, a rozmówca ma być informowany: nasłuch zrzutu (Android 14+) i nagrywania ekranu (Android 15+).
    DisposableEffect(blocked, activity) {
        val act = activity
        var unregister: () -> Unit = {}
        if (act != null && !blocked && Prefs.notifyCapture(ctx)) {
            val exec = ContextCompat.getMainExecutor(ctx)
            var lastShot = 0L
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                val cb = android.app.Activity.ScreenCaptureCallback {
                    val t = System.currentTimeMillis()
                    if (t - lastShot > 3_000) {
                        lastShot = t
                        scope.launch(Dispatchers.IO) { runCatching { Messenger(ctx).sendNotice(contact.id, Messenger.NOTICE_SCREENSHOT) } }
                    }
                }
                runCatching { act.registerScreenCaptureCallback(exec, cb) }
                val prev = unregister
                unregister = { prev(); runCatching { act.unregisterScreenCaptureCallback(cb) } }
            }
            if (android.os.Build.VERSION.SDK_INT >= 35) {
                val rc = java.util.function.Consumer<Int> { state ->
                    if (state == android.view.WindowManager.SCREEN_RECORDING_STATE_VISIBLE) {
                        scope.launch(Dispatchers.IO) { runCatching { Messenger(ctx).sendNotice(contact.id, Messenger.NOTICE_RECORDING) } }
                    }
                }
                runCatching { act.windowManager.addScreenRecordingCallback(exec, rc) }
                val prev = unregister
                unregister = { prev(); runCatching { act.windowManager.removeScreenRecordingCallback(rc) } }
            }
        }
        onDispose { unregister() }
    }

    val shownMsgs = msgs
        .let { l -> if (onlyStarred) l.filter { it.id in starred } else l }
        .let { l -> if (searching && searchQ.isNotBlank()) l.filter { !it.deleted && it.body.contains(searchQ, true) } else l }

    Column(Modifier.fillMaxSize().background(pal.bg).imePadding()) {
        // Nagłówek
        Row(Modifier.fillMaxWidth().background(ShSurface).padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconTap(Ic.Back, "Wróć", onClick = onBack)
            val online = Presence.isOnline(live, nowTs)
            Avatar(partnerName, live.color, live.emoji, 42.dp, photo, online = online)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(partnerName, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f, fill = false)); if (verified) { Spacer(Modifier.width(6.dp)); Icon24(Ic.Shield, ShMuted, 14.dp) } }
                val status = Presence.label(live, nowTs)
                if (status != null) Text(status, fontSize = 12.sp, color = if (online) Color(0xFF3DDC84) else ShMuted, maxLines = 1)
                else if (live.about.isNotBlank()) Text(live.about, fontSize = 12.sp, color = ShMuted, maxLines = 1)
            }
            IconTap(Ic.Search, "Szukaj w rozmowie") { searching = !searching; if (!searching) searchQ = "" }
            IconTap(if (details) Ic.Close else Ic.Info, if (details) "Zamknij szczegóły" else "Szczegóły rozmowy") { details = !details }
        }
        HorizontalDivider(color = ShLine, thickness = 0.5.dp)
        if (!verified && !live.blocked && !warnDismissed) {
            Row(Modifier.fillMaxWidth().background(ShSurfaceHi).padding(start = 14.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Kontakt niezweryfikowany. Porównaj kod bezpieczeństwa, zanim wyślesz poufne dane.", fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { details = true }) { Text("Weryfikuj", fontSize = 12.sp) }
                IconTap(Ic.Close, "Ukryj ostrzeżenie", size = 18.dp) { warnDismissed = true }
            }
        }
        if (searching) {
            Row(Modifier.fillMaxWidth().background(ShSurface).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(searchQ, { searchQ = it }, singleLine = true, modifier = Modifier.weight(1f),
                    placeholder = { Text("Szukaj w tej rozmowie") }, shape = RoundedCornerShape(18.dp))
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = onlyStarred, onClick = { onlyStarred = !onlyStarred }, label = { Text("Gwiazdki") })
                Spacer(Modifier.width(8.dp))
                Text(if (searchQ.isBlank() && !onlyStarred) "" else "${shownMsgs.size}", color = ShMuted, fontSize = 13.sp)
            }
        }

        if (details) Column(Modifier.fillMaxWidth().heightIn(max = 480.dp).verticalScroll(rememberScrollState()).background(ShSurfaceHi).padding(14.dp)) {
            Text("PERSONALIZACJA", fontSize = 11.sp, color = pal.accent, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text("Motyw, emoji i pseudonimy są wspólne: rozmówca zobaczy je u siebie.", fontSize = 12.sp, color = ShMuted)
            Spacer(Modifier.height(10.dp))
            Text("Motyw rozmowy: ${pal.name}", fontSize = 12.sp, color = ShMuted)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (i in 0 until CHAT_THEME_COUNT) {
                    val pp = chatPalette(i)
                    val sel = live.theme == i
                    Box(Modifier.size(42.dp).clip(CircleShape).background(pp.out)
                        .border(if (sel) 3.dp else 1.dp, if (sel) pp.accent else ShMuted.copy(alpha = .4f), CircleShape)
                        .clickable { applyLook(i) }, contentAlignment = Alignment.Center) {
                        Box(Modifier.size(15.dp).clip(CircleShape).background(pp.accent))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Szybkie emoji (przycisk obok pola wiadomości i pierwsza reakcja)", fontSize = 12.sp, color = ShMuted)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("👍", "❤️", "😂", "🔥", "😮", "🙏", "👌", "🎉").forEach { e ->
                    FilterChip(selected = emojiInput == e, onClick = { emojiInput = e; applyLook(live.theme) }, label = { Text(e, fontSize = 18.sp) })
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(nickPeerInput, { nickPeerInput = it.take(24) }, label = { Text("Pseudonim rozmówcy w tej rozmowie") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(nickMeInput, { nickMeInput = it.take(24) }, label = { Text("Twój pseudonim (widzi go rozmówca)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { applyLook(live.theme) }) { Text("Zapisz pseudonimy i emoji") }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("PRYWATNOŚĆ", fontSize = 11.sp, color = pal.accent, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(6.dp))
            Text("Zrzuty ekranu w tej rozmowie", fontSize = 12.sp, color = ShMuted)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0 to "Jak w Ustawieniach", 1 to "Blokuj", 2 to "Zezwalaj + powiadom").forEach { (m, l) ->
                    FilterChip(selected = live.capMode == m, onClick = {
                        scope.launch(Dispatchers.IO) { runCatching { Store(ctx).setCapMode(contact.id, m) }; NodeRuntime.contactsVersion.update { it + 1 } }
                    }, label = { Text(l, fontSize = 12.sp) })
                }
            }
            Text(
                when (live.capMode) {
                    1 -> "Zrzuty i nagrywanie ekranu są zablokowane w tej rozmowie, eksport do pliku jest wyłączony, a treść wiadomości jest ukryta na liście rozmów."
                    2 -> "Zrzuty są dozwolone, ale rozmówca dostaje komunikat, gdy zrobisz zrzut, nagrasz ekran, wyeksportujesz rozmowę lub zapiszesz plik."
                    else -> "Obowiązuje ustawienie globalne (Ustawienia → Ochrona ekranu)."
                }, fontSize = 12.sp, color = ShMuted)
            Text("Uwaga: żadna aplikacja nie powstrzyma zdjęcia ekranu innym telefonem ani zmodyfikowanej wersji aplikacji po drugiej stronie. Ochrona to bariera i sygnał ostrzegawczy, nie gwarancja.",
                fontSize = 11.sp, color = ShMuted.copy(alpha = .8f))
            Spacer(Modifier.height(10.dp))
            Text("Znikanie wiadomości", fontSize = 12.sp, color = ShMuted)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TTLS.forEach { (s, l) ->
                    FilterChip(selected = ttl == s, onClick = {
                        ttl = s
                        scope.launch(Dispatchers.IO) { Store(ctx).setTtl(contact.id, s); Messenger(ctx).sendTtl(contact.id, s) }
                    }, label = { Text(l, fontSize = 12.sp) })
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("KONTAKT", fontSize = 11.sp, color = pal.accent, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            OutlinedTextField(label, { label = it }, label = { Text("Nazwa kontaktu (tylko u Ciebie)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { scope.launch(Dispatchers.IO) { Store(ctx).rename(contact.id, label); NodeRuntime.contactsVersion.update { it + 1 } } }) { Text("Zapisz nazwę") }
            Spacer(Modifier.height(4.dp))
            Text("Kod bezpieczeństwa. Porównajcie go na żywo lub innym zaufanym kanałem. Jeśli się zgadza, nikt nie podszywa się pod rozmówcę.",
                fontSize = 12.sp, color = ShMuted)
            Spacer(Modifier.height(6.dp))
            safety.split(" ").chunked(5).forEach { Text(it.joinToString("  "), fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp) }
            OutlinedButton(onClick = { showVerify = true }, modifier = Modifier.fillMaxWidth()) { Text("Zweryfikuj kodem QR") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = verified, onCheckedChange = { v ->
                    verified = v
                    scope.launch(Dispatchers.IO) { Store(ctx).setVerified(contact.id, v); NodeRuntime.contactsVersion.update { it + 1 } }
                })
                Spacer(Modifier.width(8.dp)); Text("Zweryfikowano")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = muted, onCheckedChange = { v ->
                    muted = v
                    scope.launch(Dispatchers.IO) { Store(ctx).setMuted(contact.id, v); NodeRuntime.contactsVersion.update { it + 1 } }
                })
                Spacer(Modifier.width(8.dp)); Text("Wycisz powiadomienia")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = live.blocked, onCheckedChange = { v ->
                    scope.launch(Dispatchers.IO) { Store(ctx).setBlocked(contact.id, v); NodeRuntime.contactsVersion.update { it + 1 } }
                })
                Spacer(Modifier.width(8.dp)); Text("Zablokuj kontakt")
            }
            if (live.capMode != 1) TextButton(onClick = { confirmExport = true }) { Text("Eksportuj rozmowę (.txt)") }
            TextButton(onClick = { confirmClear = true }) { Text("Wyczyść historię rozmowy") }
            TextButton(onClick = { confirmDelete = true }) { Text("Usuń kontakt i rozmowę", color = MaterialTheme.colorScheme.error) }
        }

        // Wiadomości
        val rev = shownMsgs.reversed()
        val listState = rememberLazyListState()
        LaunchedEffect(rev.firstOrNull()?.id) { if (listState.firstVisibleItemIndex <= 1) listState.animateScrollToItem(0) }
        val pinnedMsgs = shownMsgs.filter { it.pinned && !it.deleted }
        if (pinnedMsgs.isNotEmpty()) {
            val last = pinnedMsgs.last()
            Row(Modifier.fillMaxWidth().background(ShSurface.copy(alpha = .9f)).clickable {
                val idx = rev.indexOfFirst { it.id == last.id }
                if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
            }.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon24(Ic.Pin, ShMuted, 16.dp)
                Spacer(Modifier.width(8.dp))
                Text((if (last.att != null) "Załącznik" else last.body).ifBlank { "Wiadomość" }, fontSize = 13.sp, maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (pinnedMsgs.size > 1) Text("${pinnedMsgs.size}", fontSize = 12.sp, color = ShMuted)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 10.dp), state = listState, reverseLayout = true) {
            itemsIndexed(rev, key = { _, m -> m.id }) { i, m ->
                val older = rev.getOrNull(i + 1)
                val showDay = older == null || dayKey(older.ts) != dayKey(m.ts)
                val grouped = older != null && !showDay && !older.sys && !m.sys && older.outgoing == m.outgoing
                Column(Modifier.fillMaxWidth()) {
                    if (showDay) Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                        Text(dayLabel(m.ts), fontSize = 11.sp, color = ShMuted,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(ShSurface.copy(alpha = .8f)).padding(horizontal = 12.dp, vertical = 4.dp))
                    }
                    if (m.sys) {
                        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 24.dp), contentAlignment = Alignment.Center) {
                            Text(m.body, fontSize = 12.sp, color = ShMuted, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(ShSurface.copy(alpha = .9f)).padding(horizontal = 12.dp, vertical = 6.dp))
                        }
                    } else SwipeToReply(enabled = m.mid != null && !m.deleted, accent = pal.accent,
                        onReply = { replyTo = m; editing = null }) {
                        Row(Modifier.fillMaxWidth().padding(top = if (grouped) 2.dp else 8.dp),
                            horizontalArrangement = if (m.outgoing) Arrangement.End else Arrangement.Start) {
                            val a = m.att
                            Column(
                                Modifier.widthIn(max = 300.dp)
                                    .background(
                                        if (m.outgoing) pal.out else pal.inBubble,
                                        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp,
                                            bottomEnd = if (m.outgoing) 5.dp else 18.dp, bottomStart = if (m.outgoing) 18.dp else 5.dp))
                                    .combinedClickable(
                                        onClick = {
                                            if (a != null && a.done) {
                                                if (a.image) viewImage = a.id
                                                else { saveTarget = a.id to a.name; saveDoc.launch(a.name) }
                                            }
                                        },
                                        onLongClick = { menuFor = m }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                // cytat odpowiedzi
                                if (m.replyMid != null && !m.deleted) {
                                    Row(Modifier.padding(bottom = 6.dp).height(androidx.compose.foundation.layout.IntrinsicSize.Min)
                                        .clip(RoundedCornerShape(8.dp)).background(ShQuote)
                                        .clickable {
                                            val idx = rev.indexOfFirst { it.mid == m.replyMid }
                                            if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
                                        }) {
                                        Box(Modifier.width(3.dp).fillMaxHeight().background(pal.accent, RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp)))
                                        Column(Modifier.padding(8.dp)) {
                                            Text(if (m.replyOut) "Ty" else partnerName, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = pal.accent)
                                            Text(
                                                when {
                                                    m.replyBody == null -> "Wiadomość niedostępna"
                                                    m.replyBody.isBlank() -> "Wiadomość usunięta"
                                                    else -> m.replyBody.take(80)
                                                },
                                                fontSize = 12.sp, color = ShMuted, maxLines = 2
                                            )
                                        }
                                    }
                                }
                                when {
                                    m.deleted -> Text("Wiadomość usunięta", color = ShMuted, fontSize = 14.sp, fontStyle = FontStyle.Italic)
                                    a != null && a.done && a.mime.startsWith("audio/") -> {
                                        AudioAttachment(ctx, a.id, a.name)
                                    }
                                    a != null && a.image && a.done -> {
                                        val bmp by produceState<ImageBitmap?>(null, a.id) {
                                            value = withContext(Dispatchers.IO) {
                                                runCatching { Attachments.decodeSampled(Store(ctx).attBytes(a.id), 700)?.asImageBitmap() }.getOrNull()
                                            }
                                        }
                                        val b = bmp
                                        if (b != null) Image(b, contentDescription = "Zdjęcie", contentScale = ContentScale.FillWidth,
                                            modifier = Modifier.widthIn(max = 240.dp).clip(RoundedCornerShape(10.dp)))
                                        else Text("Ładowanie zdjęcia…", color = ShMuted)
                                    }
                                    a != null -> Column {
                                        Text(a.name, color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp)
                                        Text(Attachments.humanSize(a.size) + " · dotknij, aby zapisać", fontSize = 11.sp, color = ShMuted)
                                    }
                                    com.shyfr.app.net.PollCodec.decode(m.body) != null && m.mid != null -> {
                                        val (q, opts) = com.shyfr.app.net.PollCodec.decode(m.body)!!
                                        val v = pollVotes[m.mid]
                                        val counts = opts.indices.map { i -> (if (v?.first == i) 1 else 0) + (if (v?.second == i) 1 else 0) }
                                        val total = counts.sum().coerceAtLeast(1)
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(q, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                                            opts.forEachIndexed { i, o ->
                                                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(ShQuote)
                                                    .clickable { scope.launch(Dispatchers.IO) { Messenger(ctx).votePoll(contact.id, m.mid!!, i) } }) {
                                                    Box(Modifier.fillMaxWidth(counts[i].toFloat() / total).height(34.dp).background(pal.accent.copy(alpha = if (v?.first == i) .4f else .2f)))
                                                    Row(Modifier.fillMaxWidth().height(34.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                                        Text((if (v?.first == i) "✓ " else "") + o, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1)
                                                        Text("${counts[i]}", fontSize = 12.sp, color = ShMuted)
                                                    }
                                                }
                                            }
                                            Text("Głosują obie osoby, głos można zmienić.", fontSize = 11.sp, color = ShMuted)
                                        }
                                    }
                                    else -> Text(richText(m.body, MaterialTheme.colorScheme.primary, ShSurface), color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp)
                                }
                                if (m.reactions.isNotEmpty()) {
                                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        m.reactions.entries.forEach { (e, n) ->
                                            Text(if (n > 1) "$e $n" else e, fontSize = 13.sp,
                                                modifier = Modifier.clip(RoundedCornerShape(50)).background(ShQuote).padding(horizontal = 7.dp, vertical = 2.dp))
                                        }
                                    }
                                }
                                Text(
                                    fmtTime(m.ts) + (if (m.edited && !m.deleted) "  · edytowano" else "") +
                                        if (m.outgoing) (if (m.read) "  ✓✓" else if (m.delivered) "  ✓" else if (m.failed) "  ✗ nie dostarczono" else "  …") else "",
                                    fontSize = 10.sp, color = ShMuted, modifier = Modifier.align(Alignment.End))
                            }
                        }
                    }
                }
            }
        }
        if (listState.firstVisibleItemIndex > 3) {
            Box(Modifier.align(Alignment.BottomEnd).padding(14.dp).size(44.dp).clip(CircleShape).background(ShSurface)
                .border(1.dp, pal.accent.copy(alpha = .5f), CircleShape)
                .clickable { scope.launch { listState.animateScrollToItem(0) } }, contentAlignment = Alignment.Center) {
                Icon24(Ic.Down, pal.accent, 22.dp)
            }
        }
        }

        err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp)) }

        // pasek odpowiedzi / edycji
        val re = replyTo; val ed = editing
        if (re != null || ed != null) {
            Row(Modifier.fillMaxWidth().background(ShSurfaceHi).padding(start = 14.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (ed != null) "Edycja wiadomości" else "Odpowiedź dla: " + (if (re!!.outgoing) "Ciebie" else partnerName),
                        fontSize = 12.sp, color = ShSilver, fontWeight = FontWeight.SemiBold)
                    Text(preview((ed ?: re)!!), fontSize = 12.sp, color = ShMuted, maxLines = 1)
                }
                IconTap(Ic.Close, "Anuluj", size = 18.dp) { replyTo = null; if (editing != null) { editing = null; text = "" } }
            }
        }

        if (isRecording) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("● Nagrywanie wiadomości głosowej", color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { finishVoiceRecording(false) }) { Text("Anuluj") }
            }
        }
        if (live.blocked) {
            Row(Modifier.fillMaxWidth().background(ShSurface).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Kontakt zablokowany. Jego wiadomości są odrzucane.", fontSize = 13.sp, color = ShMuted, modifier = Modifier.weight(1f))
                TextButton(onClick = { scope.launch(Dispatchers.IO) { Store(ctx).setBlocked(contact.id, false); NodeRuntime.contactsVersion.update { it + 1 } } }) { Text("Odblokuj") }
            }
        } else {
        val hasText = text.isNotBlank()
        val onAccent = if (pal.accent.luminance() > 0.5f) Color(0xFF0B1220) else Color.White
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.Bottom) {
            Box(Modifier.size(46.dp).clip(CircleShape).background(ShSurfaceHi).clickable { showAttach = true }, contentAlignment = Alignment.Center) {
                Icon24(Ic.Add, pal.accent, 22.dp)
            }
            Spacer(Modifier.width(6.dp))
            if (!hasText || isRecording) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(if (isRecording) MaterialTheme.colorScheme.error else ShSurfaceHi)
                    .clickable {
                        if (isRecording) finishVoiceRecording(true)
                        else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                            beginVoiceRecording()
                        else recordPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }, contentAlignment = Alignment.Center) {
                    if (isRecording) Box(Modifier.size(14.dp).background(Color.White, RoundedCornerShape(3.dp))) else Icon24(Ic.Mic, pal.accent, 22.dp)
                }
                Spacer(Modifier.width(6.dp))
            }
            TextField(text, { text = it }, modifier = Modifier.weight(1f), placeholder = { Text("Wiadomość") },
                shape = RoundedCornerShape(24.dp), maxLines = 5,
                trailingIcon = { Box(Modifier.clip(CircleShape).clickable { showEmoji = !showEmoji }.padding(8.dp)) { Icon24(if (showEmoji) Ic.Keyboard else Ic.Smile, pal.accent, 22.dp) } },
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent,
                    focusedContainerColor = ShSurfaceHi, unfocusedContainerColor = ShSurfaceHi))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(46.dp).clip(CircleShape).background(if (hasText) pal.accent else ShSurfaceHi)
                .clickable(enabled = !isRecording) {
                    if (hasText) {
                        val t = text
                        val e = editing; val r = replyTo
                        scope.launch(Dispatchers.IO) {
                            val ok = if (e?.mid != null) Messenger(ctx).edit(contact.id, e.mid, t)
                            else Messenger(ctx).sendText(contact.id, t, r?.mid)
                            if (ok) { text = ""; err = null; replyTo = null; editing = null }
                            else err = "Szyfrowanie jeszcze się ustala. Spróbuj za chwilę, gdy znajomy będzie online."
                        }
                    } else {
                        // pusty tekst: jednym dotknięciem wysyłamy szybkie emoji rozmowy
                        scope.launch(Dispatchers.IO) {
                            val ok = Messenger(ctx).sendText(contact.id, quickEmoji, null)
                            err = if (ok) null else "Szyfrowanie jeszcze się ustala. Spróbuj za chwilę, gdy znajomy będzie online."
                        }
                    }
                }, contentAlignment = Alignment.Center) {
                if (hasText) Icon24(if (editing != null) Ic.Check else Ic.Send, onAccent, 22.dp) else Text(quickEmoji, fontSize = 23.sp)
            }
        }
        if (showEmoji) EmojiGrid(Modifier.fillMaxWidth().height(260.dp).background(ShSurface), pal.accent) { text += it }
        }
    }

    // menu wiadomości (przytrzymanie dymku): panel dolny
    menuFor?.let { m ->
        ModalBottomSheet(onDismissRequest = { menuFor = null }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = ShSurface) {
            Column(Modifier.padding(horizontal = 14.dp).padding(bottom = 24.dp).verticalScroll(rememberScrollState())) {
                if (m.mid != null && !m.deleted) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(ShSurfaceHi).padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        (listOf(live.qEmoji).filter { it.isNotBlank() } + QUICK_REACTIONS).distinct().take(6).forEach { e ->
                            Text(e, fontSize = 26.sp, modifier = Modifier.clip(CircleShape)
                                .background(if (m.myReaction == e) pal.accent.copy(alpha = .3f) else Color.Transparent)
                                .clickable {
                                    menuFor = null
                                    scope.launch(Dispatchers.IO) { Messenger(ctx).react(contact.id, m.mid, if (m.myReaction == e) null else e) }
                                }.padding(8.dp))
                        }
                        Text("＋", fontSize = 24.sp, color = pal.accent, modifier = Modifier.clip(CircleShape)
                            .clickable { menuFor = null; emojiTarget = m }.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    SheetAction(Ic.Reply, "Odpowiedz") { menuFor = null; replyTo = m; editing = null }
                    SheetAction(Ic.Pin, if (m.pinned) "Odepnij" else "Przypnij") {
                        menuFor = null
                        scope.launch(Dispatchers.IO) { Messenger(ctx).pin(contact.id, m.mid, !m.pinned) }
                    }
                    if (m.outgoing && m.att == null) SheetAction(Ic.Edit, "Edytuj") { menuFor = null; editing = m; replyTo = null; text = m.body }
                }
                if (!m.deleted && m.att == null && m.body.isNotBlank()) {
                    SheetAction(Ic.Copy, "Kopiuj") { menuFor = null; clipboard.setText(AnnotatedString(m.body)) }
                    SheetAction(Ic.Forward, "Przekaż dalej") { menuFor = null; forwardMsg = m }
                    firstLink(m.body)?.let { link -> SheetAction(Ic.Link, "Otwórz link") { menuFor = null; openLink = link } }
                }
                if (!m.deleted) SheetAction(Ic.Star, if (m.id in starred) "Usuń gwiazdkę" else "Oznacz gwiazdką") {
                    menuFor = null
                    val now = m.id !in starred
                    scope.launch(Dispatchers.IO) { Store(ctx).setStarred(m.id, now); starTick++ }
                }
                SheetAction(Ic.Delete, "Usuń u mnie") {
                    menuFor = null
                    scope.launch(Dispatchers.IO) { Store(ctx).deleteLocal(m.id); NodeRuntime.messagesVersion.update { it + 1 } }
                }
                if (m.outgoing && m.mid != null && !m.deleted)
                    SheetAction(Ic.Block, "Usuń u wszystkich", MaterialTheme.colorScheme.error) {
                        menuFor = null
                        scope.launch(Dispatchers.IO) { Messenger(ctx).deleteForAll(contact.id, m.mid) }
                    }
                if (m.outgoing && !m.delivered && !m.deleted && m.att == null) {
                    if (m.failed) SheetAction(Ic.Refresh, "Wyślij ponownie") {
                        menuFor = null
                        scope.launch(Dispatchers.IO) {
                            Store(ctx).cancelOutgoing(m.id)
                            val ok = Messenger(ctx).sendText(contact.id, m.body, m.replyMid)
                            if (!ok) err = "Nie udało się wysłać ponownie."
                            NodeRuntime.messagesVersion.update { it + 1 }
                        }
                    }
                    SheetAction(Ic.Close, "Anuluj wysyłanie", MaterialTheme.colorScheme.error) {
                        menuFor = null
                        scope.launch(Dispatchers.IO) { Store(ctx).cancelOutgoing(m.id); NodeRuntime.messagesVersion.update { it + 1 } }
                    }
                }
                if (m.outgoing && !m.deleted) {
                    val st = if (m.read) "Przeczytano" else if (m.delivered) "Dostarczono" else if (m.failed) "Nie dostarczono" else "Wysyłanie"
                    Text("$st · " + java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale("pl")).format(java.util.Date(m.ts)),
                        fontSize = 12.sp, color = ShMuted, modifier = Modifier.padding(start = 12.dp, top = 10.dp))
                }
            }
        }
    }
    emojiTarget?.let { m ->
        ModalBottomSheet(onDismissRequest = { emojiTarget = null }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = ShSurface) {
            EmojiGrid(Modifier.fillMaxWidth().height(340.dp), pal.accent) { e ->
                emojiTarget = null
                val mid = m.mid
                if (mid != null) scope.launch(Dispatchers.IO) { Messenger(ctx).react(contact.id, mid, if (m.myReaction == e) null else e) }
            }
        }
    }

    val camPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scanVerify = true else err = "Zezwól na dostęp do aparatu, aby zeskanować kod."
    }
    val verifyPayload = "shyfr-verify:" + safety.replace(" ", "")
    if (showVerify && safety.isNotBlank()) AlertDialog(
        onDismissRequest = { showVerify = false },
        title = { Text("Weryfikacja kontaktu") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                val qr = remember(verifyPayload) { qrBitmap(verifyPayload, 600).asImageBitmap() }
                Image(qr, "Kod weryfikacyjny", Modifier.size(240.dp))
                Spacer(Modifier.height(8.dp))
                Text("Rozmówca skanuje ten kod, a Ty jego. Kody muszą być takie same.", fontSize = 13.sp, color = ShMuted)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                showVerify = false
                if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) scanVerify = true
                else camPermission.launch(Manifest.permission.CAMERA)
            }) { Text("Skanuj kod rozmówcy") }
        },
        dismissButton = { TextButton(onClick = { showVerify = false }) { Text("Zamknij") } }
    )
    if (scanVerify) Dialog(onDismissRequest = { scanVerify = false },
        properties = DialogProperties(usePlatformDefaultWidth = false, securePolicy = SecureFlagPolicy.SecureOn)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            QrScanner { code ->
                if (scanVerify) {
                    scanVerify = false
                    if (code == verifyPayload) {
                        verified = true
                        scope.launch(Dispatchers.IO) { Store(ctx).setVerified(contact.id, true); NodeRuntime.contactsVersion.update { it + 1 } }
                    } else verifyMismatch = true
                }
            }
            Button(onClick = { scanVerify = false }, modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp)) { Text("Anuluj") }
        }
    }
    if (verifyMismatch) AlertDialog(
        onDismissRequest = { verifyMismatch = false },
        title = { Text("Kody się różnią") },
        text = { Text("Ten kod nie pasuje do tej rozmowy. Ktoś może podszywać się pod rozmówcę albo zeskanowano inny kontakt. Nie wysyłaj poufnych danych.") },
        confirmButton = { TextButton(onClick = { verifyMismatch = false }) { Text("OK") } }
    )

    forwardMsg?.let { fm ->
        val all by produceState(emptyList<Contact>()) {
            value = withContext(Dispatchers.IO) { runCatching { Store(ctx).contacts().filter { it.id != contact.id } }.getOrDefault(emptyList()) }
        }
        AlertDialog(
            onDismissRequest = { forwardMsg = null },
            title = { Text("Przekaż do…") },
            text = {
                Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    if (all.isEmpty()) Text("Brak innych kontaktów.", color = ShMuted)
                    all.forEach { c ->
                        TextButton(modifier = Modifier.fillMaxWidth(), onClick = {
                            forwardMsg = null
                            scope.launch(Dispatchers.IO) {
                                val ok = Messenger(ctx).sendText(c.id, fm.body, null)
                                err = if (ok) null else "Nie udało się przekazać — szyfrowanie z ${c.label} jeszcze się ustala."
                            }
                        }) { Text(c.label, modifier = Modifier.fillMaxWidth()) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { forwardMsg = null }) { Text("Anuluj") } }
        )
    }
    openLink?.let { link ->
        AlertDialog(
            onDismissRequest = { openLink = null },
            title = { Text("Otworzyć link?") },
            text = { Text("$link\n\nLink otworzy się w zwykłej przeglądarce telefonu — poza siecią Tor. Strona zobaczy Twój adres IP. Otwieraj tylko linki od zaufanych osób.") },
            confirmButton = { TextButton(onClick = {
                openLink = null
                runCatching {
                    ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(link)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }) { Text("Otwórz") } },
            dismissButton = { TextButton(onClick = { openLink = null }) { Text("Anuluj") } }
        )
    }
    if (confirmExport) AlertDialog(
        onDismissRequest = { confirmExport = false },
        title = { Text("Eksport rozmowy") },
        text = { Text("Plik tekstowy NIE jest szyfrowany i opuści sejf SHYFR. Zawiera tylko wiadomości tekstowe (bez załączników). Zapisz go w bezpiecznym miejscu.") },
        confirmButton = { TextButton(onClick = { confirmExport = false; exportDoc.launch("shyfr-" + label.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".txt") }) { Text("Zapisz plik") } },
        dismissButton = { TextButton(onClick = { confirmExport = false }) { Text("Anuluj") } }
    )
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Wyczyścić historię?") },
        text = { Text("Wszystkie wiadomości i załączniki z tej rozmowy znikną z tego telefonu. Kontakt i szyfrowanie zostają. Rozmówca zachowa swoją kopię.") },
        confirmButton = { TextButton(onClick = {
            confirmClear = false
            scope.launch(Dispatchers.IO) { runCatching { Store(ctx).clearChat(contact.id) }; NodeRuntime.messagesVersion.update { it + 1 }; NodeRuntime.contactsVersion.update { it + 1 } }
        }) { Text("Wyczyść", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Anuluj") } }
    )

    if (creatingPoll) {
        var q by remember { mutableStateOf("") }
        val opts = remember { mutableStateListOf("", "") }
        AlertDialog(
            onDismissRequest = { creatingPoll = false },
            title = { Text("Nowa ankieta") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(q, { if (it.length <= 200) q = it }, label = { Text("Pytanie") }, modifier = Modifier.fillMaxWidth())
                    opts.forEachIndexed { i, o -> OutlinedTextField(o, { if (it.length <= 60) opts[i] = it }, label = { Text("Opcja ${i + 1}") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                    Row {
                        if (opts.size < 6) TextButton(onClick = { opts.add("") }) { Text("＋ Opcja") }
                        if (opts.size > 2) TextButton(onClick = { opts.removeAt(opts.size - 1) }) { Text("− Opcja") }
                    }
                    Text("Ankieta jest zwykłą, szyfrowaną wiadomością. Głosujecie Wy dwoje; starsze wersje aplikacji pokażą ją jako tekst.", fontSize = 11.sp, color = ShMuted)
                }
            },
            confirmButton = {
                TextButton(enabled = q.isNotBlank() && opts.count { it.isNotBlank() } >= 2, onClick = {
                    val question = q; val options = opts.toList(); creatingPoll = false
                    scope.launch(Dispatchers.IO) { Messenger(ctx).sendPoll(contact.id, question, options) }
                }) { Text("Wyślij") }
            },
            dismissButton = { TextButton(onClick = { creatingPoll = false }) { Text("Anuluj") } }
        )
    }

    if (showAttach) AlertDialog(
        onDismissRequest = { showAttach = false },
        title = { Text("Wyślij") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(modifier = Modifier.fillMaxWidth(), onClick = { showAttach = false; pickImage.launch("image/*") }) { Text("Zdjęcie") }
                OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { showAttach = false; pickFile.launch("*/*") }) { Text("Plik") }
                OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { showAttach = false; creatingPoll = true }) { Text("Ankieta") }
                Text("Zdjęcia są przeskalowane, a dane EXIF (w tym lokalizacja) usuwane. Pliki idą bez zmian i mogą zawierać metadane. Limit 8 MB.",
                    fontSize = 12.sp, color = ShMuted)
            }
        },
        confirmButton = { TextButton(onClick = { showAttach = false }) { Text("Zamknij") } }
    )

    viewImage?.let { id ->
        Dialog(onDismissRequest = { viewImage = null },
            properties = DialogProperties(usePlatformDefaultWidth = false, securePolicy = SecureFlagPolicy.SecureOn)) {
            val big by produceState<ImageBitmap?>(null, id) {
                value = withContext(Dispatchers.IO) {
                    runCatching { Attachments.decodeSampled(Store(ctx).attBytes(id), 2048)?.asImageBitmap() }.getOrNull()
                }
            }
            Column(Modifier.fillMaxSize().background(Color.Black), horizontalAlignment = Alignment.CenterHorizontally) {
                val b = big
                if (b != null) Image(b, contentDescription = "Zdjęcie", contentScale = ContentScale.Fit,
                    modifier = Modifier.weight(1f).fillMaxWidth())
                else Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("ładowanie…", color = ShMuted) }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(12.dp)) {
                    OutlinedButton(onClick = { saveTarget = id to "zdjecie.jpg"; saveDoc.launch("zdjecie.jpg") }) { Text("Zapisz") }
                    Button(onClick = { viewImage = null }) { Text("Zamknij") }
                }
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Usunąć kontakt?") },
        text = { Text("Rozmowa, klucze sesji i kolejka wiadomości zostaną usunięte. Aby wrócić do rozmowy, trzeba dodać się od nowa.") },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                scope.launch(Dispatchers.IO) {
                    Store(ctx).deleteContact(contact.id)
                    NodeRuntime.contactsVersion.update { it + 1 }
                    withContext(Dispatchers.Main) { onBack() }
                }
            }) { Text("Usuń") }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Anuluj") } }
    )
}
