package com.shyfr.app.net

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.shyfr.app.Trace
import com.shyfr.app.session.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Tor działa w osobnym procesie (TorHostService). Tu mamy tylko klienta: polecenia kontrolne
 * (ADD_ONION, GETINFO...) lecą przez Messenger, a połączenia do sieci idą zwykłym SOCKS-em po loopbacku.
 * Metody blokujące (call/raw/info) wolno wywoływać wyłącznie poza głównym wątkiem.
 */
class TorAndroidTransport(private val ctx: Context) : TorTransport {
    override var onDeath: (() -> Unit)? = null

    @Volatile private var host: Messenger? = null
    @Volatile private var dead = false
    @Volatile private var stopping = false
    @Volatile private var socksCache: String? = null
    private var conn: ServiceConnection? = null
    private val pending = ConcurrentHashMap<Int, ArrayBlockingQueue<Bundle>>()
    private val ids = AtomicInteger(1)
    private val replyMessenger = Messenger(Handler(Looper.getMainLooper()) { m ->
        pending.remove(m.arg1)?.offer(m.data ?: Bundle())
        true
    })

    companion object { @Volatile private var lastServiceId: String? = null }

    private fun markDead() {
        if (stopping || dead) return
        dead = true
        Trace.log("proces Tora (:tor) zakończył się niespodziewanie")
        // Zapobiega samoczynnemu wskrzeszaniu TorService przez system (pętla restartów)
        runCatching { ctx.stopService(Intent().setClassName(ctx, "org.torproject.jni.TorService")) }
        pending.values.forEach { it.offer(Bundle().apply { putString("error", "Tor zakończył się") }) }
        onDeath?.invoke()
    }

    private fun call(what: Int, value: String, timeoutMs: Long = 30_000): Bundle {
        if (dead) throw IOException("Proces Tora zakończył się")
        val h = host ?: throw IOException("Host Tora niedostępny")
        val id = ids.getAndIncrement()
        val q = ArrayBlockingQueue<Bundle>(1)
        pending[id] = q
        val m = Message.obtain(null, what, id, 0).also { it.replyTo = replyMessenger; it.data = Bundle().apply { putString("v", value) } }
        try { h.send(m) } catch (e: Exception) { pending.remove(id); throw IOException("Host Tora nie odpowiada", e) }
        val res = q.poll(timeoutMs, TimeUnit.MILLISECONDS)
        if (res == null) { pending.remove(id); throw IOException("Brak odpowiedzi od Tora") }
        res.getString("error")?.let { throw IOException(it) }
        return res
    }
    private fun raw(cmd: String): String = call(TorHostService.OP_RAW, cmd).getString("text") ?: ""
    private fun info(key: String, timeoutMs: Long = 30_000): String = call(TorHostService.OP_INFO, key, timeoutMs).getString("text") ?: ""

    override suspend fun start(onProgress: (Int) -> Unit) {
        withContext(Dispatchers.Main) {
            val c = object : ServiceConnection {
                override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
                    Trace.log("host Tora połączony (proces :tor)")
                    host = Messenger(b)
                    runCatching { b?.linkToDeath({ markDead() }, 0) }
                }
                override fun onServiceDisconnected(n: ComponentName?) { host = null; markDead() }
                override fun onBindingDied(n: ComponentName?) { host = null; markDead() }
            }
            conn = c
            Trace.log("bindService(TorHostService)")
            if (!ctx.bindService(Intent(ctx, TorHostService::class.java), c, Context.BIND_AUTO_CREATE))
                error("Nie udało się uruchomić hosta Tora")
        }
        // 1) czekamy na gotowość połączenia kontrolnego
        val deadline = System.currentTimeMillis() + 180_000
        while (true) {
            if (dead) error("Proces Tora zakończył się podczas startu")
            val ready = host != null && runCatching { call(TorHostService.OP_READY, "", 10_000).getBoolean("ok") }.getOrDefault(false)
            if (ready) { Trace.log("połączenie kontrolne gotowe"); break }
            if (System.currentTimeMillis() > deadline) error("Tor nie uruchomił się w 3 minuty")
            delay(500)
        }
        // log Tora do pliku w cache (tylko diagnostyka; czyszczony po zamknięciu raportu)
        runCatching {
            val f = java.io.File(ctx.cacheDir, "tor.log"); f.delete()
            raw("SETCONF Log=\"notice file ${f.absolutePath}\"")
        }.onFailure { Trace.log("log Tora: błąd $it") }
        // 2) mosty (tylko gdy użytkownik je podał: SETCONF bez potrzeby nie jest wysyłany)
        val bridges = Prefs.bridges(ctx)
        if (bridges.isNotEmpty()) {
            Trace.log("mosty: ustawiam ${bridges.size}")
            runCatching { raw("SETCONF UseBridges=1 " + bridges.joinToString(" ") { "Bridge=\"$it\"" }) }
                .onFailure { Trace.log("SETCONF błąd: $it") }
        }
        // 2b) IPv6: tylko gdy sieć ma globalny adres IPv6 (sieci tylko-IPv6 są inaczej nieosiągalne dla Tora)
        if (NetMonitor.hasGlobalIpv6(ctx)) {
            Trace.log("IPv6: włączam ClientUseIPv6")
            runCatching { raw("SETCONF ClientUseIPv6=1") }.onFailure { Trace.log("SETCONF IPv6 błąd: $it") }
        }
        // 3) pełne zestawienie obwodów (bootstrap 100%)
        var last = -1
        while (true) {
            if (dead) error("Proces Tora zakończył się podczas łączenia (bootstrap ${last}%)")
            val phase = runCatching { info("status/bootstrap-phase", 10_000) }.getOrNull()
            val p = phase?.let { Regex("PROGRESS=(\\d+)").find(it)?.groupValues?.get(1)?.toIntOrNull() }
            if (p != null && p != last) { last = p; onProgress(p); Trace.log("bootstrap $p%") }
            if (p != null && p >= 100) return
            if (System.currentTimeMillis() > deadline) error("Tor nie zestawił połączenia w 3 minuty (bootstrap ${last}%)")
            delay(1000)
        }
    }

    override suspend fun publishService(virtualPort: Int, localPort: Int, existingKey: String?): Pair<String, String> =
        withContext(Dispatchers.IO) {
            val keySpec = existingKey ?: "NEW:ED25519-V3"
            lastServiceId?.let { old -> runCatching { raw("DEL_ONION $old") } }
            Trace.log("Tor: ADD_ONION port=$virtualPort -> 127.0.0.1:$localPort")
            val text = raw("ADD_ONION $keySpec Port=$virtualPort,127.0.0.1:$localPort Flags=Detach")
            val id = Regex("ServiceID=([a-z2-7]{56})").find(text)?.groupValues?.get(1)
                ?: error("Tor nie zwrócił ServiceID po ADD_ONION: ${text.take(160)}")
            lastServiceId = id
            val pk = Regex("PrivateKey=(\\S+)").find(text)?.groupValues?.get(1) ?: existingKey
                ?: error("Tor utworzył usługę onion, ale nie zwrócił klucza prywatnego do zapisania")
            Trace.log("Tor: usługa onion aktywna (${id.take(8)}…)")
            "$id.onion" to pk
        }

    override suspend fun connect(onion: String, port: Int): Socket = withContext(Dispatchers.IO) {
        val socks = socksCache ?: info("net/listeners/socks").trim().trim('"').split(' ').first().also { socksCache = it }
        val sp = socks.substringAfterLast(':').toInt()
        val s = Socket(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", sp)))
        s.connect(InetSocketAddress.createUnresolved(onion, port), 45_000)
        s
    }

    override fun newNetwork(): Boolean = !dead && runCatching { raw("SIGNAL NEWNET"); true }.getOrDefault(false)

    override fun isHealthy(): Boolean = !dead && runCatching {
        info("status/circuit-established", 8_000).trim().trim('"') == "1"
    }.getOrDefault(false)

    override fun stop() {
        stopping = true
        runCatching { conn?.let { ctx.unbindService(it) } }
        conn = null; host = null
        runCatching { ctx.stopService(Intent(ctx, TorHostService::class.java)) }
        runCatching { ctx.stopService(Intent().setClassName(ctx, "org.torproject.jni.TorService")) }
        pending.values.forEach { it.offer(Bundle().apply { putString("error", "zatrzymano") }) }
    }
}
