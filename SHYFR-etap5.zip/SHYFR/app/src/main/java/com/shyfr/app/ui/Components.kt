package com.shyfr.app.ui

import android.text.format.DateUtils
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Brush
import android.graphics.BitmapFactory
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Paleta z ikony: grafit, srebro i lawendowa szarość kropek.
// Kolory zależą od aktualnego motywu (jasny/ciemny), więc są funkcjami kompozycyjnymi.
private val isDarkTheme: Boolean @Composable get() = MaterialTheme.colorScheme.background.luminance() < 0.5f
val ShInk: Color @Composable get() = if (isDarkTheme) Color(0xFF0E0C0A) else Color(0xFFF8F2E9)
val ShSurface: Color @Composable get() = if (isDarkTheme) Color(0xFF1B1713) else Color(0xFFFFFFFF)
val ShSurfaceHi: Color @Composable get() = if (isDarkTheme) Color(0xFF2D261E) else Color(0xFFEFE6D8)
val ShSilver: Color @Composable get() = if (isDarkTheme) Color(0xFFF2E6D0) else Color(0xFF5C4426)
val ShMuted: Color @Composable get() = if (isDarkTheme) Color(0xFFA49A8C) else Color(0xFF7A6D5C)
val ShBubbleOut: Color @Composable get() = if (isDarkTheme) Color(0xFF3D3225) else Color(0xFFF1E0C4)
val ShQuote: Color @Composable get() = if (isDarkTheme) Color(0x22FFFFFF) else Color(0x14000000)

val AvatarColors = listOf(
    Color(0xFF5B5675), Color(0xFF6B5B7B), Color(0xFF4F6B7A), Color(0xFF5C7A66),
    Color(0xFF7A6A4F), Color(0xFF7A4F5C), Color(0xFF4F5C7A), Color(0xFF6E6E78)
)

val ShyfrShapes @Composable get() = Shapes(small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(18.dp), large = RoundedCornerShape(26.dp))

fun shyfrColors(dark: Boolean) = if (dark) darkColorScheme(
    primary = Color(0xFFF6E3C3), onPrimary = Color(0xFF22180A),
    background = Color(0xFF0E0C0A), onBackground = Color(0xFFF4EEE6),
    surface = Color(0xFF1B1713), onSurface = Color(0xFFF4EEE6),
    surfaceVariant = Color(0xFF2D261E), onSurfaceVariant = Color(0xFFA49A8C),
    secondaryContainer = Color(0xFF3D3225), onSecondaryContainer = Color(0xFFF6E3C3),
    outline = Color(0xFF5A5043), error = Color(0xFFE57373)
) else lightColorScheme(
    primary = Color(0xFF7A4E17), onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFFF8F2E9), onBackground = Color(0xFF221B12),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF221B12),
    surfaceVariant = Color(0xFFEFE6D8), onSurfaceVariant = Color(0xFF7A6D5C),
    secondaryContainer = Color(0xFFF1E0C4), onSecondaryContainer = Color(0xFF3A2A12),
    outline = Color(0xFFCFC3B0), error = Color(0xFFBA1A1A)
)

/** Ciepła poświata u góry ekranu (jak w makiecie): gradient od złocistego brązu do tła. */
@Composable
fun Modifier.warmGlow(): Modifier {
    val bg = MaterialTheme.colorScheme.background
    val glow = if (bg.luminance() < 0.5f) Color(0xFF4A3A28) else Color(0xFFEBD9BC)
    return this.background(Brush.verticalGradient(listOf(glow, bg), startY = 0f, endY = 1100f))
}

/** Biały znak na ciemnym motywie, czarny na jasnym. */
@Composable
fun logoRes(): Int = if (isDarkTheme) R.drawable.shyfr_logo else R.drawable.shyfr_logo_ink

@Composable
fun LogoHeader(size: Dp = 96.dp) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(logoRes()), contentDescription = null, modifier = Modifier.size(size))
        Text("SHYFR", fontSize = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 6.sp, color = ShSilver)
    }
}

@Composable
fun Avatar(name: String, color: Int, emoji: String, size: Dp = 44.dp, photo: ByteArray? = null, online: Boolean = false) {
    val bg = AvatarColors[color.coerceIn(0, AvatarColors.lastIndex)]
    val bmp = remember(photo) { photo?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull() } }
    Box(Modifier.size(size)) {
        Box(Modifier.size(size).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
            if (bmp != null) Image(bmp, contentDescription = null, modifier = Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
            else {
                val t = if (emoji.isNotBlank()) emoji else name.trim().take(1).uppercase().ifEmpty { "?" }
                Text(t, fontSize = (size.value * 0.42f).sp, color = Color.White)
            }
        }
        if (online) {
            val ring = MaterialTheme.colorScheme.background
            Box(Modifier.align(Alignment.BottomEnd).size((size.value * 0.30f).dp).clip(CircleShape).background(ring).padding((size.value * 0.05f).dp)
                .clip(CircleShape).background(Color(0xFF3DDC84)))
        }
    }
}

/** Paleta motywu rozmowy. Motyw jest wspólny dla obu rozmówców (synchronizowany ramką KIND_LOOK). */
data class ChatPalette(val name: String, val out: Color, val inBubble: Color, val bg: Color, val accent: Color, val swatch: Color)

private class ThemeDef(val name: String, val dOut: Long, val lOut: Long, val dBg: Long, val lBg: Long, val dAcc: Long, val lAcc: Long)
private val THEMES = listOf(
    ThemeDef("Domyślny", 0xFF4A3B2A, 0xFFF3E2C7, 0xFF0E0C0A, 0xFFF8F2E9, 0xFFF6E3C3, 0xFF7A4E17),
    ThemeDef("Ocean", 0xFF0F5C7A, 0xFFCDEBF7, 0xFF06141B, 0xFFEFF8FC, 0xFF5CC8F0, 0xFF0B6A8F),
    ThemeDef("Fiolet", 0xFF4B3A82, 0xFFE4DCF8, 0xFF0E0A1A, 0xFFF6F3FC, 0xFFB7A2F5, 0xFF5B44A8),
    ThemeDef("Las", 0xFF2D5A3F, 0xFFD6EEDD, 0xFF08130C, 0xFFF1F8F3, 0xFF7ED9A0, 0xFF2E7A4D),
    ThemeDef("Zachód", 0xFF7A4A1F, 0xFFF9E3CC, 0xFF160E07, 0xFFFDF6EE, 0xFFF0A860, 0xFFB5651D),
    ThemeDef("Róż", 0xFF7A2E55, 0xFFF9D8E8, 0xFF16080F, 0xFFFDF1F6, 0xFFF08CBB, 0xFFB03A78),
    ThemeDef("Grafit", 0xFF3A3F47, 0xFFE0E3E8, 0xFF0B0C0E, 0xFFF4F5F7, 0xFFC4C9D1, 0xFF4A5059),
    ThemeDef("Czerń", 0xFF1E3A5F, 0xFFD3E3F7, 0xFF000000, 0xFFFFFFFF, 0xFF6FA8F0, 0xFF1F5FB5)
)
const val CHAT_THEME_COUNT = 8

@Composable
fun chatPalette(theme: Int): ChatPalette {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val t = THEMES[theme.coerceIn(0, THEMES.lastIndex)]
    val bg = Color(if (dark) t.dBg else t.lBg)
    val onBg = MaterialTheme.colorScheme.onBackground
    return ChatPalette(
        t.name, Color(if (dark) t.dOut else t.lOut),
        androidx.compose.ui.graphics.lerp(bg, onBg, if (dark) 0.13f else 0.07f),
        bg, Color(if (dark) t.dAcc else t.lAcc), Color(if (dark) t.dAcc else t.lAcc)
    )
}

fun fmtTime(ts: Long): String {
    if (ts <= 0) return ""
    val f = SimpleDateFormat(if (DateUtils.isToday(ts)) "HH:mm" else "dd.MM", Locale.getDefault())
    return f.format(Date(ts))
}
