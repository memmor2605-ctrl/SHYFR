package com.shyfr.app.net

import android.content.Context
import com.google.crypto.tink.subtle.Hkdf
import com.shyfr.app.crypto.Keys
import com.shyfr.app.session.Prefs
import com.shyfr.app.session.Session
import com.shyfr.app.vault.Contact
import com.shyfr.app.vault.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.security.SecureRandom
import kotlin.math.abs

/**
 * Status aktywności: „aktywny teraz”, „online”, „ostatnio aktywny”.
 *
 * Protokół (osobna ramka PRES, NIE przechodzi przez kolejkę ani ratchet, więc nie zaśmieca historii):
 *   zapytanie:  PRES(1) | sid(16) | ts(8) | nonce(8) | stan(1) | aktywny_ts(8) | mac(32)
 *   odpowiedź:  stan(1) | aktywny_ts(8) | mac(32)
 * Klucz MAC = HKDF(X25519(moja_tożsamość, ich_tożsamość)): zna go tylko ta para, więc nikt trzeci
 * nie podszyje się pod status rozmówcy ani go nie odczyta bez znajomości klucza. Odpowiedź jest związana
 * z nonce zapytania, a zapytanie z czasem (±5 min), co ogranicza powtórki.
 * Wymiana jest symetryczna: obie strony od razu poznają swój stan.
 * Prywatność: wyłączenie „Status aktywności” w Ustawieniach wyłącza ping i ukrywa Twój status (i cudzy u Ciebie).
 */
object Presence {
    const val PRES = 7
    const val STATE_HIDDEN = 0; const val STATE_ACTIVE = 1; const val STATE_BACKGROUND = 2
    private const val SKEW_MS = 5 * 60_000L
    /** Online = ostatnia udana wymiana nie starsza niż to (poll co ~60 s). */
    const val ONLINE_WINDOW_MS = 150_000L

    @Volatile var foreground: Boolean = false
    /** Budzi pętlę odpytywania (np. po wejściu na pierwszy plan). */
    val kick = Channel<Unit>(Channel.CONFLATED)
    private val rnd = SecureRandom()

    fun myState(ctx: Context): Int =
        if (!Prefs.presenceShare(ctx)) STATE_HIDDEN
        else if (foreground && Session.get() != null) STATE_ACTIVE else STATE_BACKGROUND

    private fun macKey(myPriv: ByteArray, myPub: ByteArray, theirPub: ByteArray): ByteArray =
        Hkdf.computeHkdf("HmacSha256", Keys.dh(myPriv, theirPub), Keys.pairAd(myPub, theirPub), "shyfr-presence-v1".toByteArray(), 32)

    private fun long8(v: Long): ByteArray = ByteArray(8) { i -> (v ushr (56 - 8 * i)).toByte() }

    /** Strona odbierająca: bajt PRES został już przeczytany przez router. */
    fun handle(ctx: Context, sock: Socket, inp: DataInputStream) {
        sock.use {
            val store = Store(ctx)
            val sid = ByteArray(16).also { inp.readFully(it) }
            val ts = inp.readLong()
            val nonce = ByteArray(8).also { inp.readFully(it) }
            val theirState = inp.readUnsignedByte()
            val theirActive = inp.readLong()
            val mac = ByteArray(32).also { inp.readFully(it) }
            if (abs(System.currentTimeMillis() - ts) > SKEW_MS || theirState > STATE_BACKGROUND) return
            val c = store.contactBySid(sid) ?: return
            if (c.blocked) return
            val (priv, pub) = store.keys()
            val key = macKey(priv, pub, c.pubkey)
            val expect = Keys.hmac(key, "req".toByteArray(), sid, long8(ts), nonce, byteArrayOf(theirState.toByte()), long8(theirActive))
            if (!Keys.equalsCt(expect, mac)) return

            val myState = myState(ctx)
            // Reciprocity: kto ukrywa swój status, ten nie zapisuje cudzego.
            if (myState != STATE_HIDDEN) {
                store.setPeerPresence(c.id, theirState, theirActive)
                NodeRuntime.contactsVersion.update { it + 1 }
            }
            val myActive = Prefs.lastActive(ctx)
            val out = DataOutputStream(sock.getOutputStream())
            out.writeByte(myState); out.writeLong(myActive)
            out.write(Keys.hmac(key, "rsp".toByteArray(), nonce, byteArrayOf(myState.toByte()), long8(myActive)))
            out.flush()
        }
    }

    /** Pojedyncze odpytanie kontaktu. Błąd sieci = nic nie zmieniamy (offline pokaże się po upływie okna). */
    private suspend fun pollOne(ctx: Context, t: TorTransport, c: Contact, priv: ByteArray, pub: ByteArray) {
        if (c.blocked) return
        val myState = myState(ctx)
        if (myState == STATE_HIDDEN) return
        val sid = Keys.sid(pub)
        val key = macKey(priv, pub, c.pubkey)
        val ts = System.currentTimeMillis()
        val nonce = ByteArray(8).also { rnd.nextBytes(it) }
        val myActive = Prefs.lastActive(ctx)
        val store = Store(ctx)
        try {
            t.connect(c.onion, JoinService.TOR_PORT).use { s ->
                s.soTimeout = 25_000
                val out = DataOutputStream(s.getOutputStream())
                val inp = DataInputStream(s.getInputStream())
                out.writeByte(PRES); out.write(sid); out.writeLong(ts); out.write(nonce)
                out.writeByte(myState); out.writeLong(myActive)
                out.write(Keys.hmac(key, "req".toByteArray(), sid, long8(ts), nonce, byteArrayOf(myState.toByte()), long8(myActive)))
                out.flush()
                val st = inp.readUnsignedByte()
                val active = inp.readLong()
                val mac = ByteArray(32).also { inp.readFully(it) }
                val expect = Keys.hmac(key, "rsp".toByteArray(), nonce, byteArrayOf(st.toByte()), long8(active))
                if (!Keys.equalsCt(expect, mac) || st > STATE_BACKGROUND) return
                withContext(Dispatchers.IO) { store.setPeerPresence(c.id, st, active) }
                NodeRuntime.contactsVersion.update { it + 1 }
            }
        } catch (e: Exception) { /* offline albo błąd Tora: spróbujemy w następnym cyklu */ }
    }

    /** Odpytuje wszystkie kontakty (max 4 równolegle, bo każde połączenie to osobny obwód Tor). */
    suspend fun pollAll(ctx: Context) {
        val t = NodeRuntime.transport ?: return
        if (!Prefs.presenceShare(ctx)) return
        val store = Store(ctx)
        val (priv, pub) = withContext(Dispatchers.IO) { store.keys() }
        val contacts = withContext(Dispatchers.IO) { store.contacts() }
        val gate = Semaphore(4)
        coroutineScope {
            contacts.map { c ->
                async { gate.withPermit { withTimeoutOrNull(60_000) { pollOne(ctx, t, c, priv, pub) } } }
            }.awaitAll()
        }
    }

    /** Tekst statusu do nagłówka rozmowy; null = nic nie pokazuj. */
    fun label(c: Contact, now: Long = System.currentTimeMillis()): String? {
        if (c.peerState == STATE_HIDDEN || c.peerSeen <= 0) return null
        val online = now - c.peerSeen <= ONLINE_WINDOW_MS
        if (online) return if (c.peerState == STATE_ACTIVE) "Aktywny teraz" else "Online"
        val ref = if (c.peerActive > 0) c.peerActive else c.peerSeen
        return "Ostatnio aktywny " + ago(now - ref, ref)
    }
    fun isOnline(c: Contact, now: Long = System.currentTimeMillis()): Boolean =
        c.peerState != STATE_HIDDEN && c.peerSeen > 0 && now - c.peerSeen <= ONLINE_WINDOW_MS

    private fun ago(diff: Long, ts: Long): String {
        val m = diff / 60_000
        return when {
            m < 1 -> "przed chwilą"
            m < 60 -> "$m min temu"
            m < 60 * 24 && android.text.format.DateUtils.isToday(ts) -> "dziś o " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ts))
            m < 60 * 48 -> "wczoraj o " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ts))
            else -> java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault()).format(java.util.Date(ts))
        }
    }
}
