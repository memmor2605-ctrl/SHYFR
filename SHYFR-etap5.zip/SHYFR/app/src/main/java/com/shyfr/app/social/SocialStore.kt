package com.shyfr.app.social

import android.content.Context
import com.shyfr.app.session.Session
import com.shyfr.app.vault.Db
import kotlinx.coroutines.flow.MutableStateFlow
import net.zetetic.database.sqlcipher.SQLiteDatabase

data class SocialIdentity(val id: String, val kind: IdentityKind, val name: String, val idx: Int, val created: Long)

/** Relacje lokalnego grafu społecznego. Zawsze przypisane do jednej tożsamości (nigdy współdzielone). */
enum class Rel(val code: String) { FOLLOW("follow"), BLOCK("block"), MUTE("mute"), CLOSE("close"), FAVORITE("fav"), RESTRICT("restrict") }

object SocialState { val active = MutableStateFlow<String?>(null) }

/**
 * Lokalne dane tożsamości: lista tożsamości, szkice wpisów i graf relacji, wszystko w zaszyfrowanej bazie SHYFR.
 * Klucze prywatne NIE są tu zapisywane (wyprowadza je [IdentityKeys]). Każde zapytanie o szkic lub relację
 * jest ograniczone identyfikatorem tożsamości, więc przełączenie tożsamości nie miesza danych.
 */
class SocialStore(private val ctx: Context) {
    private fun <T> db(block: (SQLiteDatabase) -> T): T {
        val k = Session.get() ?: error("Konto zablokowane")
        val d = Db.open(ctx, k)
        try { return block(d) } finally { d.close() }
    }
    private fun SQLiteDatabase.q(sql: String, vararg args: Any?): android.database.Cursor =
        if (args.isEmpty()) rawQuery(sql) else rawQuery(sql, *args)
    private val prefs get() = ctx.getSharedPreferences("shyfr_social", Context.MODE_PRIVATE)

    fun identities(): List<SocialIdentity> = db { d ->
        d.q("SELECT id,kind,name,idx,created FROM soc_identity WHERE deleted=0 ORDER BY created, id").use { c ->
            buildList { while (c.moveToNext()) add(SocialIdentity(c.getString(0), IdentityKind.from(c.getString(1)), c.getString(2) ?: "", c.getInt(3), c.getLong(4))) }
        }
    }

    /** Pierwsze uruchomienie: jedna tożsamość publiczna. Zwraca aktywną tożsamość. */
    fun ensureDefaults(defaultName: String): SocialIdentity {
        if (identities().isEmpty()) create(IdentityKind.PUBLIC, defaultName.ifBlank { "Ja" })
        val all = identities()
        val a = prefs.getString("active", null)
        val cur = all.firstOrNull { it.id == a } ?: all.first()
        prefs.edit().putString("active", cur.id).apply()
        SocialState.active.value = cur.id
        return cur
    }

    fun active(): String? = prefs.getString("active", null)
    fun setActive(id: String) { prefs.edit().putString("active", id).apply(); SocialState.active.value = id }

    /** Numer klucza nigdy nie jest używany ponownie (usunięte tożsamości zostają jako puste wpisy), więc nowy klucz jest zawsze świeży. */
    fun create(kind: IdentityKind, name: String): SocialIdentity = db { d ->
        val idx = d.q("SELECT COALESCE(MAX(idx),-1)+1 FROM soc_identity WHERE kind=?", kind.code).use { it.moveToFirst(); it.getInt(0) }
        val id = "${kind.code}-$idx"; val now = System.currentTimeMillis()
        d.execSQL("INSERT INTO soc_identity(id,kind,name,idx,created,deleted) VALUES(?,?,?,?,?,0)", arrayOf<Any?>(id, kind.code, name.trim().take(40), idx, now))
        SocialIdentity(id, kind, name.trim().take(40), idx, now)
    }

    fun rename(id: String, name: String) = db { d ->
        d.execSQL("UPDATE soc_identity SET name=? WHERE id=?", arrayOf<Any?>(name.trim().take(40), id))
    }

    /** Usuwa tożsamość i jej szkice oraz relacje. Zawsze zostaje co najmniej jedna. Zwraca false, gdy to ostatnia. */
    fun delete(id: String): Boolean = db { d ->
        val left = d.q("SELECT COUNT(*) FROM soc_identity WHERE deleted=0").use { it.moveToFirst(); it.getInt(0) }
        if (left <= 1) return@db false
        d.execSQL("UPDATE soc_identity SET deleted=1, name='' WHERE id=?", arrayOf<Any?>(id))
        d.execSQL("DELETE FROM soc_draft WHERE identity_id=?", arrayOf<Any?>(id))
        d.execSQL("DELETE FROM soc_graph WHERE identity_id=?", arrayOf<Any?>(id))
        true
    }

    fun saveDraft(identityId: String, audience: String, body: String) = db { d ->
        if (body.isBlank()) d.execSQL("DELETE FROM soc_draft WHERE identity_id=?", arrayOf<Any?>(identityId))
        else d.execSQL("INSERT OR REPLACE INTO soc_draft(identity_id,audience,body,ts) VALUES(?,?,?,?)", arrayOf<Any?>(identityId, audience, body, System.currentTimeMillis()))
    }
    fun draft(identityId: String): Pair<String, String>? = db { d ->
        d.q("SELECT audience, body FROM soc_draft WHERE identity_id=?", identityId).use { if (it.moveToFirst()) it.getString(0) to it.getString(1) else null }
    }

    fun setRel(identityId: String, peer: String, rel: Rel, on: Boolean) = db { d ->
        if (on) d.execSQL("INSERT OR IGNORE INTO soc_graph(identity_id,peer,rel,ts) VALUES(?,?,?,?)", arrayOf<Any?>(identityId, peer, rel.code, System.currentTimeMillis()))
        else d.execSQL("DELETE FROM soc_graph WHERE identity_id=? AND peer=? AND rel=?", arrayOf<Any?>(identityId, peer, rel.code))
    }
    fun has(identityId: String, peer: String, rel: Rel): Boolean = db { d ->
        d.q("SELECT 1 FROM soc_graph WHERE identity_id=? AND peer=? AND rel=?", identityId, peer, rel.code).use { it.moveToFirst() }
    }
    fun peers(identityId: String, rel: Rel): List<String> = db { d ->
        d.q("SELECT peer FROM soc_graph WHERE identity_id=? AND rel=? ORDER BY ts DESC", identityId, rel.code).use { c -> buildList { while (c.moveToNext()) add(c.getString(0)) } }
    }
}
