package com.shyfr.app.net

import android.content.Context
import java.io.File

/**
 * Czyści pamięć podręczną i zapis stanu Tora (skonsolidowana lista węzłów, stan strażników).
 * Nie dotyka kluczy, bazy ani ustawień aplikacji. Tor pobierze listę węzłów od nowa.
 */
object TorData {
    private val NAMES = setOf("state", "lock", "unverified-consensus", "unverified-microdesc-consensus")

    fun purge(ctx: Context): Int {
        var n = 0
        fun walk(d: File, depth: Int) {
            if (depth > 4) return
            d.listFiles()?.forEach { f ->
                if (f.isDirectory) {
                    if (f.name == "diff-cache") { if (f.deleteRecursively()) n++ } else walk(f, depth + 1)
                } else if (f.name in NAMES || f.name.startsWith("cached-")) {
                    if (f.delete()) n++
                }
            }
        }
        // tylko katalogi danych Tora (getDir() daje "app_*") i files/
        ctx.dataDir.listFiles()?.filter { it.isDirectory && (it.name.startsWith("app_") || it.name == "files") }?.forEach { walk(it, 0) }
        return n
    }
}
