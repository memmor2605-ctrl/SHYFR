package com.shyfr.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.feed.CommunityInfo
import com.shyfr.app.feed.DirEntry
import com.shyfr.app.feed.Membership
import com.shyfr.app.feed.PublicProto
import com.shyfr.app.feed.PublicRepo
import kotlinx.coroutines.launch

private fun visLabel(v: String) = when (v) { "private" -> "Prywatna"; "hidden" -> "Ukryta"; else -> "Publiczna" }
private fun roleLabel(r: String?) = when (r) { "owner" -> "Właściciel"; "mod" -> "Moderator"; "banned" -> "Zablokowany"; null -> "Gość"; else -> "Członek" }

/** Katalog i moje społeczności: tworzenie, dołączanie (publiczne od ręki, prywatne/ukryte z zaproszeniem), pseudonim i osobna tożsamość per społeczność. */
@Composable
fun CommunitiesScreen(ctx: Context, onOpenSettings: () -> Unit) {
    val repo = remember { PublicRepo(ctx) }
    val scope = rememberCoroutineScope()
    val configured = repo.relayConfigured()
    var tab by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var dir by remember { mutableStateOf<List<DirEntry>>(emptyList()) }
    var dirNext by remember { mutableStateOf<Long?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var creating by remember { mutableStateOf(false) }
    var joiningCode by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Membership?>(null) }
    var openPost by remember { mutableStateOf<com.shyfr.app.feed.Post?>(null) }
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    val mine by produceState(emptyList<Membership>(), tick, configured) { value = if (configured) runCatching { repo.memberships() }.getOrDefault(emptyList()) else emptyList() }

    fun loadDir(reset: Boolean) {
        scope.launch {
            loading = true; error = null
            try {
                val page = repo.directory(query.trim(), if (reset) 0 else (dirNext ?: 0L).toInt())
                dir = if (reset) page.items else dir + page.items; dirNext = page.next
            } catch (e: Exception) { error = e.message ?: "Błąd sieci" }
            loading = false
        }
    }
    fun join(cid: String, code: String) {
        scope.launch {
            try { val n = repo.join(cid, code); toast("Dołączono: $n"); tick++; tab = 0 } catch (e: Exception) { toast(e.message ?: "Błąd") }
        }
    }
    LaunchedEffect(tab, configured) { if (configured && tab == 1) loadDir(true) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            PillTab("Moje", tab == 0) { tab = 0 }
            PillTab("Katalog", tab == 1) { tab = 1 }
            Spacer(Modifier.weight(1f))
            PillTab("Kod", false) { joiningCode = true }
            PillTab("Nowa", false) { creating = true }
        }
        if (!configured) EmptyState("Społeczności są niedostępne", "Ta wersja aplikacji nie ma jeszcze serwera społeczności. Publiczny feed w zakładce Feed działa bez żadnej konfiguracji.")
        else if (tab == 0) {
            if (mine.isEmpty()) EmptyState("Nie należysz do żadnej społeczności", "Przeglądaj katalog, wpisz kod zaproszenia albo załóż własną.")
            else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(mine, key = { it.cid }) { m ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(ShSurface.copy(alpha = .85f)).clickable { detail = m }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconAvatar(Ic.Group, 46.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(m.name.ifBlank { m.cid.take(8) }, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(visLabel(m.vis) + " · " + roleLabel(m.role) + if (m.nick.isNotBlank()) " · jako ${m.nick}" else " · anonimowo", fontSize = 12.sp, color = ShMuted)
                        }
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                TextField(value = query, onValueChange = { query = it }, singleLine = true, placeholder = { Text("Szukaj społeczności") },
                    leadingIcon = { Icon24(Ic.Search, ShMuted, 20.dp) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
                    colors = TextFieldDefaults.colors(focusedContainerColor = ShSurfaceHi.copy(alpha = .8f), unfocusedContainerColor = ShSurface.copy(alpha = .85f),
                        focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent, unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent))
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = { loadDir(true) }) { Text("Szukaj") }
            }
            when {
                loading && dir.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                error != null && dir.isEmpty() -> EmptyState("Nie udało się wczytać", error ?: "", "Ponów") { loadDir(true) }
                dir.isEmpty() -> EmptyState("Brak wyników", "W katalogu są tylko społeczności publiczne. Ukryte i prywatne wymagają zaproszenia.")
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(dir, key = { it.cid }) { e ->
                        val already = mine.any { it.cid == e.cid }
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(ShSurface.copy(alpha = .85f)).padding(14.dp)) {
                            Text(e.name, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            if (e.descr.isNotBlank()) Text(e.descr, fontSize = 13.sp, color = ShMuted, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            Text("${e.members} członków · ${e.posts} wpisów" + if (e.category.isNotBlank()) " · ${e.category}" else "", fontSize = 11.sp, color = ShMuted)
                            TextButton(enabled = !already, onClick = { join(e.cid, "") }) { Text(if (already) "Należysz" else "Dołącz") }
                        }
                    }
                    if (dirNext != null) item { TextButton(modifier = Modifier.fillMaxWidth(), onClick = { loadDir(false) }) { Text("Wczytaj więcej") } }
                }
            }
        }
    }

    if (creating) CreateCommunityDialog(onDismiss = { creating = false }) { name, descr, vis, cat ->
        creating = false
        scope.launch { try { repo.createCommunity(name, descr, vis, cat); toast("Utworzono społeczność"); tick++; tab = 0 } catch (e: Exception) { toast(e.message ?: "Błąd") } }
    }
    if (joiningCode) {
        var code by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { joiningCode = false }, title = { Text("Dołącz z zaproszeniem") },
            text = { OutlinedTextField(code, { code = it }, label = { Text("shyfr-c:… / shyfr-p:… albo identyfikator") }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = {
                val pl = PublicProto.parsePostLink(code)
                if (pl != null) {
                    joiningCode = false
                    scope.launch { try { openPost = repo.onePost(pl.first, pl.second) } catch (e: Exception) { toast(e.message ?: "Błąd") } }
                    return@TextButton
                }
                val parsed = PublicProto.parseInvite(code)
                if (parsed == null) toast("Nieprawidłowy kod.") else { joiningCode = false; join(parsed.first, parsed.second) }
            }) { Text("Dołącz") } },
            dismissButton = { TextButton(onClick = { joiningCode = false }) { Text("Anuluj") } }
        )
    }
    detail?.let { m -> CommunityDialog(ctx, repo, m, onDismiss = { detail = null; tick++ }) }
    openPost?.let { p -> ThreadDialog(repo, p, "", onDismiss = { openPost = null }, onError = { toast(it) }, onChanged = { }) }
}

@Composable
private fun CreateCommunityDialog(onDismiss: () -> Unit, onCreate: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var descr by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("") }
    var vis by remember { mutableStateOf("public") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Nowa społeczność") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { if (it.length <= 60) name = it }, label = { Text("Nazwa") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(descr, { if (it.length <= 500) descr = it }, label = { Text("Opis") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(cat, { if (it.length <= 32) cat = it }, label = { Text("Kategoria (opcjonalnie)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Widoczność", fontSize = 12.sp, color = ShMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("public" to "Publiczna", "private" to "Prywatna", "hidden" to "Ukryta").forEach { (v, l) -> FilterChip(selected = vis == v, onClick = { vis = v }, label = { Text(l) }) }
                }
                Text(when (vis) { "private" -> "Widoczna w katalogu? Nie. Treści tylko dla osób z zaproszeniem."; "hidden" -> "Nie istnieje w katalogu ani dla osób bez zaproszenia."; else -> "Każdy może ją znaleźć i czytać; pisanie nie wymaga profilu." }, fontSize = 11.sp, color = ShMuted)
                Text("Uwaga: treści społeczności widzi operator przekaźnika (nie są szyfrowane end-to-end).", fontSize = 11.sp, color = ShMuted)
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onCreate(name, descr, vis, cat) }) { Text("Utwórz") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Anuluj") } }
    )
}

@Composable
private fun CommunityDialog(ctx: Context, repo: PublicRepo, m: Membership, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf<CommunityInfo?>(null) }
    var nick by remember { mutableStateOf(m.nick) }
    var reports by remember { mutableStateOf<List<Triple<String, String, Long>>?>(null) }
    var chName by remember { mutableStateOf("") }
    var chKind by remember { mutableStateOf("discussion") }
    var confirmLeave by remember { mutableStateOf(false) }
    var confirmNewId by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var policy by remember { mutableStateOf<String?>(null) }
    var bio by remember { mutableStateOf(m.bio) }
    var descrEdit by remember { mutableStateOf("") }
    var rulesEdit by remember { mutableStateOf("") }
    var catEdit by remember { mutableStateOf("") }
    var isPublic by remember { mutableStateOf(m.isPublic) }
    var confirmPublic by remember { mutableStateOf(false) }
    var previewPub by remember { mutableStateOf<String?>(null) }
    var muted by remember { mutableStateOf(com.shyfr.app.session.Prefs.mutedCommunities(ctx).contains(m.cid)) }
    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()
    LaunchedEffect(Unit) { policy = try { repo.contactPolicy(m.cid) } catch (e: Exception) { null } }
    LaunchedEffect(tick) { try { info = repo.communityInfo(m.cid) } catch (e: Exception) { toast(e.message ?: "Błąd") } }
    LaunchedEffect(info?.descr, info?.rules, info?.category) { info?.let { descrEdit = it.descr; rulesEdit = it.rules; catEdit = it.category } }
    val staff = info?.role == "owner" || info?.role == "mod" || m.isStaff

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(info?.name ?: m.name.ifBlank { "Społeczność" }) },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                info?.let { i ->
                    if (i.descr.isNotBlank()) Text(i.descr, fontSize = 14.sp)
                    Text("${visLabel(i.vis)} · ${i.members} członków · Twoja rola: ${roleLabel(i.role)}", fontSize = 12.sp, color = ShMuted)
                    if (i.rules.isNotBlank()) { Text("Regulamin", fontSize = 12.sp, color = ShMuted); Text(i.rules, fontSize = 13.sp) }
                    if (i.channels.isNotEmpty()) Text("Kanały: " + i.channels.joinToString(", ") { "#" + it.name + if (it.kind == "announce") " (ogłoszenia)" else if (it.kind == "board") " (tablica)" else "" }, fontSize = 12.sp, color = ShMuted)
                } ?: CircularProgressIndicator(Modifier.size(24.dp))
                Text("Twoja tożsamość w tej społeczności", fontSize = 12.sp, color = ShMuted)
                OutlinedTextField(nick, { if (it.length <= 32) nick = it }, label = { Text("Pseudonim (puste = anonimowo)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { scope.launch {
                        try { if (isPublic) repo.setPublicProfile(m.cid, nick, bio) else repo.setNick(m.cid, nick); toast("Zapisano") } catch (e: Exception) { toast(e.message ?: "Błąd") }
                    } }) { Text("Zapisz") }
                    TextButton(onClick = { confirmNewId = true }) { Text("Nowa tożsamość") }
                }
                FilterChip(selected = muted, onClick = { muted = !muted; com.shyfr.app.session.Prefs.setCommunityMuted(ctx, m.cid, muted) },
                    label = { Text(if (muted) "Powiadomienia wyciszone" else "Powiadomienia włączone") })
                Text("Kto może wysłać mi prośbę o kontakt (w tej społeczności)", fontSize = 12.sp, color = ShMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("off" to "Nikt", "members" to "Członkowie", "all" to "Wszyscy").forEach { (v, l) ->
                        FilterChip(selected = policy == v, enabled = policy != null, onClick = {
                            scope.launch { try { repo.setContactPolicy(m.cid, v); policy = v; toast("Zapisano") } catch (e: Exception) { toast(e.message ?: "Błąd") } }
                        }, label = { Text(l) })
                    }
                }
                Text("Domyślnie nikt. Nawet „Wszyscy” nie otwiera czatu: każdą prośbę akceptujesz osobno w zakładce Aktywność.", fontSize = 11.sp, color = ShMuted)
                OutlinedTextField(bio, { if (it.length <= 300) bio = it }, label = { Text("Opis profilu publicznego") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = isPublic, onClick = {
                        if (isPublic) scope.launch { try { repo.clearPublicProfile(m.cid); isPublic = false; toast("Profil publiczny wyłączony") } catch (e: Exception) { toast(e.message ?: "Błąd") } }
                        else confirmPublic = true
                    }, label = { Text(if (isPublic) "Profil publiczny: włączony" else "Profil publiczny: wyłączony") })
                    TextButton(enabled = isPublic, onClick = { scope.launch { previewPub = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { repo.myPub(m.cid) } } }) { Text("Podgląd jako obcy") }
                }
                if (staff) {
                    Text("Administracja", fontSize = 12.sp, color = ShMuted)
                    OutlinedTextField(descrEdit, { if (it.length <= 500) descrEdit = it }, label = { Text("Opis społeczności") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    OutlinedTextField(rulesEdit, { if (it.length <= 1500) rulesEdit = it }, label = { Text("Regulamin") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    OutlinedTextField(catEdit, { if (it.length <= 32) catEdit = it }, label = { Text("Kategoria") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    TextButton(onClick = { scope.launch { try { repo.updateCommunity(m.cid, descrEdit, rulesEdit, catEdit); tick++; toast("Zapisano ustawienia") } catch (e: Exception) { toast(e.message ?: "Błąd") } } }) { Text("Zapisz ustawienia") }
                    TextButton(onClick = {
                        scope.launch {
                            try {
                                val s = repo.createInvite(m.cid, 5, 72)
                                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("SHYFR", s))
                                toast("Skopiowano zaproszenie (5 użyć, 72 h)")
                            } catch (e: Exception) { toast(e.message ?: "Błąd") }
                        }
                    }) { Text("Utwórz zaproszenie i skopiuj") }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(chName, { if (it.length <= 32) chName = it }, label = { Text("Nowy kanał") }, singleLine = true, modifier = Modifier.weight(1f))
                        TextButton(enabled = chName.isNotBlank(), onClick = {
                            scope.launch { try { repo.createChannel(m.cid, chName, chKind); chName = ""; tick++; toast("Utworzono kanał") } catch (e: Exception) { toast(e.message ?: "Błąd") } }
                        }) { Text("Dodaj") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("discussion" to "dyskusja", "announce" to "ogłoszenia", "board" to "tablica").forEach { (v, l) -> FilterChip(selected = chKind == v, onClick = { chKind = v }, label = { Text(l) }) }
                    }
                    TextButton(onClick = { scope.launch { try { reports = repo.reports(m.cid) } catch (e: Exception) { toast(e.message ?: "Błąd") } } }) { Text("Zgłoszenia") }
                    reports?.let { rs ->
                        if (rs.isEmpty()) Text("Brak zgłoszeń.", fontSize = 12.sp, color = ShMuted)
                        rs.forEach { (post, reason, _) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(reason.ifBlank { "(bez powodu)" }, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 2)
                                TextButton(onClick = { scope.launch { try { repo.delete(m.cid, post); toast("Usunięto wpis"); reports = repo.reports(m.cid) } catch (e: Exception) { toast(e.message ?: "Błąd") } } }) { Text("Usuń wpis") }
                            }
                        }
                    }
                }
                TextButton(onClick = { confirmLeave = true }) { Text("Opuść społeczność", color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zamknij") } }
    )
    previewPub?.let { pp -> ProfileDialog(repo, m.cid, pp) { previewPub = null } }
    if (confirmPublic) AlertDialog(
        onDismissRequest = { confirmPublic = false }, title = { Text("Włączyć profil publiczny?") },
        text = { Text("Każdy w tej społeczności zobaczy Twój pseudonim, opis i wpisy pod tym kluczem. Nie daje to nikomu prawa pisania do Ciebie (kontakt nadal wymaga Twojej zgody). Wyłączenie usuwa profil z przekaźnika, ale nie usuwa pseudonimu z już opublikowanych wpisów. Profil dotyczy tylko tej społeczności.") },
        confirmButton = { TextButton(onClick = {
            confirmPublic = false
            scope.launch { try { repo.setPublicProfile(m.cid, nick, bio); isPublic = true; toast("Profil publiczny włączony") } catch (e: Exception) { toast(e.message ?: "Błąd") } }
        }) { Text("Włącz") } },
        dismissButton = { TextButton(onClick = { confirmPublic = false }) { Text("Anuluj") } }
    )
    if (confirmLeave) AlertDialog(
        onDismissRequest = { confirmLeave = false }, title = { Text("Opuścić społeczność?") },
        text = { Text("Twoje wpisy zostaną w społeczności. Usuń je wcześniej, jeśli nie chcesz, by tam pozostały.") },
        confirmButton = { TextButton(onClick = { confirmLeave = false; scope.launch { try { repo.leave(m.cid); onDismiss() } catch (e: Exception) { toast(e.message ?: "Błąd") } } }) { Text("Opuść") } },
        dismissButton = { TextButton(onClick = { confirmLeave = false }) { Text("Anuluj") } }
    )
    if (confirmNewId) AlertDialog(
        onDismissRequest = { confirmNewId = false }, title = { Text("Nowa tożsamość?") },
        text = { Text("Dostaniesz nowy, niepowiązany klucz w tej społeczności. Stare wpisy zostaną pod starym kluczem (nie będziesz mógł ich edytować ani usunąć), a role (np. moderator) przepadną.") },
        confirmButton = { TextButton(onClick = { confirmNewId = false; scope.launch { repo.newIdentity(m.cid); nick = ""; toast("Utworzono nową tożsamość"); tick++ } }) { Text("Utwórz") } },
        dismissButton = { TextButton(onClick = { confirmNewId = false }) { Text("Anuluj") } }
    )
}
