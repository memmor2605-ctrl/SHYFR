package com.shyfr.app.feed

import android.content.Context
import android.net.Uri
import com.google.crypto.tink.subtle.Ed25519Sign
import com.shyfr.app.net.NodeRuntime
import com.shyfr.app.session.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class RelayException(message: String, val code: Int = 0) : Exception(message)

/** Klient HTTP/1.0 przekaźnika publicznego przez Tora (usługa onion, port 80). Nie używa żadnych adresów IP. */
class RelayClient(private val ctx: Context) {
    @Volatile private var powBits = -1

    private fun host(): String = Prefs.relayOnion(ctx) ?: throw RelayException("Nie ustawiono adresu przekaźnika (Ustawienia → Społeczności).")

    private suspend fun http(method: String, pathQs: String, body: ByteArray?, key: Ed25519Sign.KeyPair?): JSONObject {
        val h = host()
        val t = NodeRuntime.transport ?: throw RelayException("Tor jeszcze nie jest gotowy.")
        val raw = withContext(Dispatchers.IO) {
            val s = t.connect(h, 80)
            try {
                s.soTimeout = 60_000
                val sb = StringBuilder()
                sb.append("$method $pathQs HTTP/1.0\r\nHost: $h\r\nAccept: application/json\r\nConnection: close\r\n")
                if (key != null) {
                    val ts = System.currentTimeMillis().toString()
                    val sig = PublicKeys.sign(key, PublicProto.sigMsg("read", pathQs, ts))
                    sb.append("X-Pub: ${PublicProto.hex(key.publicKey)}\r\nX-Ts: $ts\r\nX-Sig: ${PublicProto.hex(sig)}\r\n")
                }
                if (body != null) sb.append("Content-Type: application/json\r\nContent-Length: ${body.size}\r\n")
                sb.append("\r\n")
                val out = s.getOutputStream()
                out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
                if (body != null) out.write(body)
                out.flush()
                s.getInputStream().readBytes()
            } finally { runCatching { s.close() } }
        }
        var idx = -1
        for (i in 0..raw.size - 4) if (raw[i] == 13.toByte() && raw[i + 1] == 10.toByte() && raw[i + 2] == 13.toByte() && raw[i + 3] == 10.toByte()) { idx = i; break }
        if (idx < 0) throw RelayException("Nieprawidłowa odpowiedź przekaźnika.")
        val head = String(raw, 0, idx, Charsets.ISO_8859_1)
        val code = head.substringBefore("\r\n").split(' ').getOrNull(1)?.toIntOrNull() ?: 0
        val text = String(raw, idx + 4, raw.size - idx - 4, Charsets.UTF_8)
        val json = try { JSONObject(text) } catch (e: Exception) { throw RelayException("Nieprawidłowa odpowiedź przekaźnika ($code).", code) }
        if (code != 200) throw RelayException(json.optString("error", "Błąd przekaźnika ($code)."), code)
        return json
    }

    suspend fun get(pathQs: String, key: Ed25519Sign.KeyPair? = null): JSONObject = http("GET", pathQs, null, key)

    /** POST z gotowym JSON-em (np. zbiorcze pobieranie ze skrzynek). */
    suspend fun postJson(pathQs: String, json: String): JSONObject = http("POST", pathQs, json.toByteArray(Charsets.UTF_8), null)

    suspend fun info(): JSONObject = get("/v1/info").also { powBits = it.optInt("pow_bits", 12) }

    /** Podpisuje i wysyła akcję. Pola w kolejności zgodnej z protokołem; czas dodawany na końcu. */
    suspend fun act(type: String, key: Ed25519Sign.KeyPair, vararg fields: Pair<String, String>): JSONObject {
        if (powBits < 0) info()
        val all = fields.toList() + ("ts" to System.currentTimeMillis().toString())
        val msg = PublicProto.sigMsg(type, *all.map { it.second }.toTypedArray())
        val o = JSONObject()
        o.put("type", type)
        all.forEach { o.put(it.first, it.second) }
        o.put("pub", PublicProto.hex(key.publicKey))
        o.put("sig", PublicProto.hex(PublicKeys.sign(key, msg)))
        if (type in PublicProto.POW_TYPES) o.put("pow", withContext(Dispatchers.Default) { PublicProto.solvePow(msg, powBits) })
        return http("POST", "/v1/act", o.toString().toByteArray(Charsets.UTF_8), null)
    }

    companion object { fun q(s: String): String = Uri.encode(s) }
}
