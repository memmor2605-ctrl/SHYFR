package com.shyfr.app.vault

import android.content.Context
import android.os.Build
import android.util.AtomicFile
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import com.shyfr.app.crypto.Kdf
import com.shyfr.app.crypto.KeystoreWrap
import java.io.File
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

sealed interface PinResult {
    data class Ok(val key: ByteArray) : PinResult
    data class Wrong(val left: Int) : PinResult
    data object Disabled : PinResult
}

/**
 * Szybkie odblokowanie (PIN / odcisk palca) zamiast loginu i hasła.
 * Klucz główny jest zapisany w dwóch niezależnych wersjach:
 *  - PIN: owinięty kluczem z Argon2id(PIN) i dodatkowo kluczem sprzętowym Keystore. 5 błędów wyłącza PIN (hasło nadal działa).
 *  - Odcisk palca: klucz Keystore wymagający silnej biometrii przy KAŻDYM użyciu (CryptoObject).
 *    Dodanie nowego odcisku w telefonie unieważnia klucz.
 */
class QuickUnlock(private val ctx: Context) {
    private val pinFile get() = File(ctx.filesDir, "quick_pin.bin")
    private val bioFile get() = File(ctx.filesDir, "quick_bio.bin")
    private val prefs get() = ctx.getSharedPreferences("shyfr_quick", Context.MODE_PRIVATE)
    private val aad = "shyfr-pin-v1".toByteArray()

    private fun atomicRead(file: File): ByteArray = AtomicFile(file).openRead().use { it.readBytes() }
    fun pinEnabled() = pinFile.exists() || File(pinFile.path + ".bak").exists()
    fun bioEnabled() = bioFile.exists() || File(bioFile.path + ".bak").exists()
    fun any() = pinEnabled() || bioEnabled()

    // ---------- PIN ----------
    private fun atomicWrite(file: File, bytes: ByteArray) {
        val atomic = AtomicFile(file)
        val stream = atomic.startWrite()
        try {
            stream.write(bytes)
            atomic.finishWrite(stream)
        } catch (t: Throwable) {
            atomic.failWrite(stream)
            throw t
        }
    }

    fun enablePin(master: ByteArray, pin: CharArray) {
        require(pin.size in 6..12 && pin.all(Char::isDigit)) { "PIN musi mieć 6–12 cyfr" }
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val k = Kdf.derive("pin", pin, salt)
        var inner: ByteArray? = null
        var wrapped: ByteArray? = null
        try {
            inner = KeystoreWrap.seal(k, master, aad)
            wrapped = KeystoreWrap.sealHardware(inner)
            atomicWrite(pinFile, salt + wrapped)
            prefs.edit().putInt("pin_fails", 0).apply()
        } finally {
            k.fill(0); inner?.fill(0); wrapped?.fill(0); salt.fill(0)
        }
    }

    fun unlockWithPin(pin: CharArray): PinResult {
        if (!pinEnabled()) return PinResult.Disabled
        val raw = runCatching { atomicRead(pinFile) }.getOrElse { return PinResult.Disabled }
        if (raw.size < 16 + 28 || pin.size !in 6..12 || !pin.all(Char::isDigit)) {
            val f = prefs.getInt("pin_fails", 0) + 1
            prefs.edit().putInt("pin_fails", f).apply()
            if (f >= MAX_PIN_FAILS) { disablePin(); return PinResult.Disabled }
            return PinResult.Wrong(MAX_PIN_FAILS - f)
        }
        val salt = raw.copyOfRange(0, 16)
        val k = Kdf.derive("pin", pin, salt)
        var inner: ByteArray? = null
        return try {
            inner = KeystoreWrap.openHardware(raw.copyOfRange(16, raw.size))
            val master = KeystoreWrap.open(k, inner, aad)
            prefs.edit().putInt("pin_fails", 0).apply()
            PinResult.Ok(master)
        } catch (e: Exception) {
            val f = prefs.getInt("pin_fails", 0) + 1
            prefs.edit().putInt("pin_fails", f).apply()
            if (f >= MAX_PIN_FAILS) { disablePin(); PinResult.Disabled } else PinResult.Wrong(MAX_PIN_FAILS - f)
        } finally { k.fill(0); salt.fill(0); raw.fill(0); inner?.fill(0) }
    }

    fun disablePin() { pinFile.delete(); prefs.edit().remove("pin_fails").apply() }

    // ---------- Odcisk palca ----------
    private fun ks() = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun bioKey(create: Boolean): SecretKey? {
        (ks().getKey(BIO_ALIAS, null) as? SecretKey)?.let { return it }
        if (!create) return null
        val b = KeyGenParameterSpec.Builder(BIO_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)
        if (Build.VERSION.SDK_INT >= 30) b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
        else @Suppress("DEPRECATION") b.setUserAuthenticationValidityDurationSeconds(-1)
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(b.build())
        return gen.generateKey()
    }

    /** Szyfr do włączenia odcisku: trzeba go przekazać do BiometricPrompt, potem wywołać finishBioEnable. */
    fun bioEnableCipher(): Cipher {
        disableBio()
        val key = bioKey(true) ?: error("Nie udało się utworzyć klucza biometrycznego")
        return Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key) }
    }
    fun finishBioEnable(c: Cipher, master: ByteArray) {
        val encrypted = c.iv + c.doFinal(master)
        try { atomicWrite(bioFile, encrypted) } finally { encrypted.fill(0) }
    }

    /** Szyfr do odblokowania; null, jeśli klucz unieważniono (np. dodano nowy odcisk palca). */
    fun bioUnlockCipher(): Cipher? {
        if (!bioEnabled()) return null
        val key = bioKey(false) ?: run { disableBio(); return null }
        return try {
            val raw = atomicRead(bioFile)
            if (raw.size < 12 + 32 + 16) { raw.fill(0); disableBio(); return null }
            val iv = raw.copyOf(12)
            raw.fill(0)
            Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            }.also { iv.fill(0) }
        } catch (e: KeyPermanentlyInvalidatedException) { disableBio(); null }
        catch (e: Exception) { disableBio(); null }
    }
    fun finishBioUnlock(c: Cipher): ByteArray {
        val raw = atomicRead(bioFile)
        require(raw.size >= 12 + 32 + 16) { "Dane biometrii są uszkodzone" }
        return try { c.doFinal(raw, 12, raw.size - 12) } finally { raw.fill(0) }
    }

    private fun deleteBioKey() { runCatching { ks().deleteEntry(BIO_ALIAS) } }
    fun disableBio() { bioFile.delete(); deleteBioKey() }
    fun disableAll() { disablePin(); disableBio() }

    companion object { const val MAX_PIN_FAILS = 5; private const val BIO_ALIAS = "shyfr_bio_key" }
}
