package com.shyfr.app.ui

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import javax.crypto.Cipher

/** Biometria silna (klasa 3): odcisk palca. Rozpoznawanie twarzy w Samsungu jest klasy słabej i nie może chronić kluczy. */
object Bio {
    fun available(ctx: Context) = BiometricManager.from(ctx)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(activity: FragmentActivity, cipher: Cipher, title: String, onOk: (Cipher) -> Unit, onFail: (String) -> Unit) {
        val bp = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val c = result.cryptoObject?.cipher
                if (c != null) onOk(c) else onFail("Brak obiektu szyfrującego.")
            }
            override fun onAuthenticationError(code: Int, msg: CharSequence) {
                // anulowanie przez użytkownika nie jest błędem: nie pokazujemy komunikatu
                val silent = code == BiometricPrompt.ERROR_USER_CANCELED || code == BiometricPrompt.ERROR_NEGATIVE_BUTTON || code == BiometricPrompt.ERROR_CANCELED
                onFail(if (silent) "" else msg.toString())
            }
        })
        bp.authenticate(
            BiometricPrompt.PromptInfo.Builder().setTitle(title).setNegativeButtonText("Anuluj")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).build(),
            BiometricPrompt.CryptoObject(cipher)
        )
    }
}
