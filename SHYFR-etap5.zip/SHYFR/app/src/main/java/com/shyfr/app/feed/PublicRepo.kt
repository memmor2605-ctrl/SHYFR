package com.shyfr.app.feed

import android.content.Context
import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.X25519
import com.shyfr.app.invite.InviteCodec
import com.shyfr.app.invite.InviteManager
import com.shyfr.app.net.NodeRuntime
import com.shyfr.app.vault.Store
import com.shyfr.app.session.Prefs
import com.shyfr.app.session.Session
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class Post(
    val id: String, val cid: String, val channel: String, val kind: String, val parent: String,
    val text: String, val nick: String, val author: String, val ts: Long, val edited: Long,
    val deleted: Boolean, val pinned: Boolean, val reactions: Map<String, Int>, val comments: Int, val reposts: Int,
    val cursor: Long, val refText: String?, val refNick: String?
) {
    val score get() = reactions.values.sum() + 2 * comments + 2 * reposts
}
data class Channel(val name: String, val kind: String)
data class CommunityInfo(val cid: String, val name: String, val descr: String, val vis: String, val category: String, val role: String?, val members: Int, val channels: List<Channel>)
data class DirEntry(val cid: String, val name: String, val descr: String, val category: String, val members: Int, val posts: Int)
data class Page<T>(val items: List<T>, val next: Long?)

data class Incoming(val cid: String, val community: String, val id: String, val requester: String, val epub: String, val greeting: String, val ts: Long)
data class Outgoing(val cid: String, val community: String, val id: String, val status: String, val invite: String?, val ts: Long)
data class ActivityEvent(val cid: String, val community: String, val type: String, val post: String, val text: String, val nick: String, val emoji: String, val reason: String, val ts: Long)
data class ActivitySnapshot(val incoming: List<Incoming>, val outgoing: List<Outgoing>, val events: List<ActivityEvent>, val failed: Int)

private fun JSONArray.objs(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

fun parsePost(o: JSONObject): Post {
    val rx = o.optJSONObject("reactions") ?: JSONObject()
    val map = rx.keys().asSequence().associateWith { rx.optInt(it) }
    val ref = o.optJSONObject("ref_post")
    return Post(
        o.getString("id"), o.getString("cid"), o.optString("channel"), o.optString("kind"), o.optString("parent"),
        o.optString("text"), o.optString("nick"), o.optString("author"), o.optLong("ts"), o.optLong("edited"),
        o.optBoolean("deleted"), o.optBoolean("pinned"), map, o.optInt("comments"), o.optInt("reposts"),
        o.optLong("cursor"), ref?.optString("text"), ref?.optString("nick")
    )
}

/** Logika warstwy publicznej: klucze per społeczność, wywołania przekaźnika, lokalne członkostwa i zakładki. */
class PublicRepo(private val ctx: Context) {
    private val client = RelayClient(ctx)
    private val store = PublicStore(ctx)
    private val keyCache = HashMap<String, Ed25519Sign.KeyPair>()

    fun relay(): String = Prefs.relayOnion(ctx) ?: throw RelayException("Nie ustawiono adresu przekaźnika (Ustawienia → Społeczności).")
    fun relayConfigured(): Boolean = Prefs.relayOnion(ctx) != null

    private fun key(cid: String, idx: Int? = null): Ed25519Sign.KeyPair {
        val master = Session.get() ?: throw RelayException("Konto zablokowane.")
        val i = idx ?: (store.membership(relay(), cid)?.keyIdx ?: 0)
        return synchronized(keyCache) { keyCache.getOrPut("${relay()}|$cid|$i") { PublicKeys.derive(master, relay(), cid, i) } }
    }
    fun myPub(cid: String): String = PublicProto.hex(key(cid).publicKey)

    /** Klucz do podpisu odczytu tylko dla społeczności niepublicznych (dla publicznych czytamy bez żadnego identyfikatora). */
    private fun readKey(cid: String): Ed25519Sign.KeyPair? {
        val m = store.membership(relay(), cid) ?: return null
        return if (m.vis == "public") null else key(cid)
    }

    suspend fun memberships(): List<Membership> = withContext(Dispatchers.IO) { store.memberships(relay()) }
    suspend fun membership(cid: String): Membership? = withContext(Dispatchers.IO) { store.membership(relay(), cid) }
    suspend fun bookmarks(): List<Bookmark> = withContext(Dispatchers.IO) { store.bookmarks() }
    suspend fun isBookmarked(id: String) = withContext(Dispatchers.IO) { store.isBookmarked(id) }
    suspend fun toggleBookmark(p: Post): Boolean = withContext(Dispatchers.IO) { store.toggleBookmark(Bookmark(p.id, p.cid, p.author, p.nick, p.text, p.ts)) }
    suspend fun likedIds() = withContext(Dispatchers.IO) { store.likedIds() }
    suspend fun savedIds() = withContext(Dispatchers.IO) { store.savedIds() }
    suspend fun myPubs(cids: List<String>): Map<String, String> = withContext(Dispatchers.IO) { cids.associateWith { runCatching { myPub(it) }.getOrDefault("") } }
    suspend fun removeBookmark(id: String) = withContext(Dispatchers.IO) { store.bookmarks().firstOrNull { it.id == id }?.let { store.toggleBookmark(it) } }
    suspend fun reacted(id: String, emoji: String) = withContext(Dispatchers.IO) { store.reacted(id, emoji) }
    suspend fun setNick(cid: String, nick: String) = withContext(Dispatchers.IO) { store.setNick(relay(), cid, nick.trim().take(32)) }

    suspend fun test(): String = client.info().let { "Przekaźnik działa (protokół v${it.optInt("version")}, PoW ${it.optInt("pow_bits")} bitów)." }

    suspend fun directory(q: String, offset: Int): Page<DirEntry> {
        val o = client.get("/v1/communities?q=${RelayClient.q(q)}&before=$offset&limit=20")
        val items = o.getJSONArray("communities").objs().map { DirEntry(it.getString("cid"), it.optString("name"), it.optString("descr"), it.optString("category"), it.optInt("members"), it.optInt("posts")) }
        return Page(items, if (o.isNull("next")) null else o.optLong("next"))
    }

    private fun parseInfo(o: JSONObject): CommunityInfo = CommunityInfo(
        o.getString("cid"), o.optString("name"), o.optString("descr"), o.optString("vis", "public"), o.optString("category"),
        if (o.isNull("role")) null else o.optString("role"), o.optInt("members"),
        (o.optJSONArray("channels") ?: JSONArray()).objs().map { Channel(it.optString("name"), it.optString("kind")) }
    )

    suspend fun communityInfo(cid: String): CommunityInfo {
        val m = membership(cid)
        val info = parseInfo(client.get("/v1/c/$cid", if (m != null && m.vis != "public") withContext(Dispatchers.IO) { key(cid) } else null))
        if (m != null && (info.role != null && info.role != m.role || info.name != m.name)) {
            withContext(Dispatchers.IO) { store.upsert(m.copy(name = info.name, vis = info.vis, role = info.role ?: m.role)) }
        }
        return info
    }

    suspend fun createCommunity(name: String, descr: String, vis: String, category: String): String {
        val cid = PublicProto.newCid()
        val kp = withContext(Dispatchers.IO) { key(cid, 0) }
        client.act("community.create", kp, "cid" to cid, "name" to name.trim(), "descr" to descr.trim(), "vis" to vis, "category" to category.trim())
        withContext(Dispatchers.IO) { store.upsert(Membership(relay(), cid, name.trim(), vis, "", 0, "owner")) }
        return cid
    }

    /** Dołącza do społeczności (publicznej bez kodu, prywatnej/ukrytej z kodem zaproszenia). Zwraca jej nazwę. */
    suspend fun join(cid: String, invite: String): String {
        val kp = withContext(Dispatchers.IO) { key(cid, store.membership(relay(), cid)?.keyIdx ?: 0) }
        val r = client.act("member.join", kp, "cid" to cid, "invite" to invite)
        val info = parseInfo(client.get("/v1/c/$cid", kp))
        withContext(Dispatchers.IO) { store.upsert(Membership(relay(), cid, info.name, info.vis, store.membership(relay(), cid)?.nick ?: "", store.membership(relay(), cid)?.keyIdx ?: 0, r.optString("role", "member"))) }
        return info.name
    }

    suspend fun leave(cid: String) {
        client.act("member.leave", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid)
        withContext(Dispatchers.IO) { store.remove(relay(), cid) }
    }

    /** Nowa tożsamość w społeczności: stary klucz zostaje porzucony, nowy nie jest z nim powiązany. */
    suspend fun newIdentity(cid: String) = withContext(Dispatchers.IO) { store.rotateKey(relay(), cid) }

    suspend fun feed(before: Long): Page<Post> {
        val ms = memberships()
        if (ms.isEmpty()) return Page(emptyList(), null)
        val out = ArrayList<Post>(); var next: Long? = null
        val pubs = ms.filter { it.vis == "public" }.map { it.cid }
        if (pubs.isNotEmpty()) {
            val o = client.get("/v1/feed?cs=${pubs.joinToString(",")}&before=$before&limit=20")
            out += o.getJSONArray("posts").objs().map(::parsePost)
            next = if (o.isNull("next")) null else o.optLong("next")
        }
        if (before == 0L) for (m in ms.filter { it.vis != "public" }) {
            runCatching {
                val kp = withContext(Dispatchers.IO) { key(m.cid) }
                client.get("/v1/c/${m.cid}/posts?limit=20", kp).getJSONArray("posts").objs().map(::parsePost).filter { it.parent.isEmpty() && !it.deleted }
            }.onSuccess { out += it }
        }
        return Page(out.distinctBy { it.id }.sortedByDescending { it.ts }, next)
    }

    suspend fun posts(cid: String, channel: String, sort: String, before: Long, offset: Long, parent: String = ""): Page<Post> {
        val kp = withContext(Dispatchers.IO) { readKey(cid) }
        val o = client.get("/v1/c/$cid/posts?channel=${RelayClient.q(channel)}&parent=$parent&sort=$sort&before=$before&offset=$offset&limit=30", kp)
        return Page(o.getJSONArray("posts").objs().map(::parsePost), if (o.isNull("next")) null else o.optLong("next"))
    }

    suspend fun comments(cid: String, postId: String): List<Post> = posts(cid, "", "new", 0, 0, parent = postId).items

    suspend fun onePost(cid: String, id: String): Post {
        val kp = withContext(Dispatchers.IO) { readKey(cid) }
        return parsePost(client.get("/v1/c/$cid/post/$id", kp))
    }

    suspend fun search(q: String): List<Post> =
        client.get("/v1/search?q=${RelayClient.q(q)}").getJSONArray("posts").objs().map(::parsePost)

    /** [anonymous] = true: brak pseudonimu; w przeciwnym razie używany jest pseudonim ustawiony dla tej społeczności. */
    suspend fun publish(cid: String, channel: String, text: String, anonymous: Boolean, kind: String = "post", parent: String = "", ref: String = ""): String {
        val m = membership(cid)
        val nick = if (anonymous) "" else (m?.nick ?: "")
        if (!anonymous && nick.isBlank()) throw RelayException("Najpierw ustaw pseudonim dla tej społeczności.")
        val kp = withContext(Dispatchers.IO) { key(cid) }
        val r = client.act("post.create", kp, "cid" to cid, "channel" to channel, "kind" to kind, "parent" to parent, "ref" to ref, "text" to text.trim(), "nick" to nick)
        if (m == null) withContext(Dispatchers.IO) { runCatching { store.upsert(Membership(relay(), cid, "", "public", "", 0, "member")) } }
        return r.optString("id")
    }

    suspend fun react(cid: String, postId: String, emoji: String, on: Boolean) {
        client.act("react", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "post" to postId, "emoji" to emoji, "on" to if (on) "1" else "0")
        withContext(Dispatchers.IO) { store.setReacted(postId, emoji, on) }
    }
    suspend fun edit(cid: String, postId: String, text: String) { client.act("post.edit", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "post" to postId, "text" to text.trim()) }
    suspend fun delete(cid: String, postId: String) { client.act("post.delete", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "post" to postId) }
    suspend fun pin(cid: String, postId: String, on: Boolean) { client.act("post.pin", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "post" to postId, "on" to if (on) "1" else "0") }
    suspend fun report(cid: String, postId: String, reason: String) { client.act("report", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "post" to postId, "reason" to reason.take(200)) }
    suspend fun ban(cid: String, authorPub: String) { client.act("mod.set", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "target" to authorPub, "role" to "banned") }
    suspend fun createChannel(cid: String, name: String, kind: String) { client.act("channel.create", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "name" to name.trim(), "ckind" to kind) }

    /** Tworzy zaproszenie (administracja). Zwraca tekst do przekazania: shyfr-c:<cid>:<kod>. */
    suspend fun createInvite(cid: String, uses: Int, hours: Int): String {
        val code = PublicProto.newInviteCode()
        val exp = System.currentTimeMillis() + hours * 3_600_000L
        client.act("invite.create", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "code" to code, "uses" to uses.toString(), "expires" to exp.toString())
        return PublicProto.inviteString(cid, code)
    }

    suspend fun reports(cid: String): List<Triple<String, String, Long>> {
        val kp = withContext(Dispatchers.IO) { key(cid) }
        return client.get("/v1/c/$cid/reports", kp).getJSONArray("reports").objs().map { Triple(it.optString("post"), it.optString("reason"), it.optLong("ts")) }
    }

    // ------------------------------------------------------------ prośby o kontakt
    // Zasada: samo zobaczenie wpisu, reakcja czy członkostwo NIE otwierają kontaktu. Autor musi włączyć przyjmowanie próśb
    // (domyślnie wyłączone), a każdą prośbę zaakceptować. Odpowiedź (zaproszenie do czatu P2P przez Tor) jest zaszyfrowana kluczem proszącego.
    private fun masterKey(): ByteArray = Session.get() ?: throw RelayException("Konto zablokowane.")

    suspend fun contactPolicy(cid: String): String = withContext(Dispatchers.IO) { myPub(cid) }.let { me ->
        val kp = withContext(Dispatchers.IO) { readKey(cid) }
        client.get("/v1/c/$cid/policy?target=$me", kp).optString("mode", "off")
    }

    /** mode: off | members | all. „off” usuwa też klucz skrzynki z przekaźnika. */
    suspend fun setContactPolicy(cid: String, mode: String) {
        val xpub = if (mode == "off") "" else withContext(Dispatchers.IO) {
            val idx = store.membership(relay(), cid)?.keyIdx ?: 0
            PublicProto.hex(X25519.publicFromPrivate(PublicKeys.inboxPriv(masterKey(), relay(), cid, idx)))
        }
        client.act("contact.policy", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "mode" to mode, "xpub" to xpub)
    }

    suspend fun requestContact(cid: String, targetPub: String, greeting: String) {
        val kp = withContext(Dispatchers.IO) { readKey(cid) }
        val pol = client.get("/v1/c/$cid/policy?target=$targetPub", kp)
        val xpub = pol.optString("xpub", "")
        if (pol.optString("mode", "off") == "off" || xpub.length != 64) throw RelayException("Autor nie przyjmuje próśb o kontakt.")
        val (epubHex, box, n) = withContext(Dispatchers.IO) {
            val n = store.nextReqN(relay(), cid, targetPub)
            val epub = X25519.publicFromPrivate(PublicKeys.requestPriv(masterKey(), relay(), cid, targetPub, n))
            Triple(PublicProto.hex(epub), ContactCrypto.seal(PublicProto.fromHex(xpub), greeting.trim().take(140).toByteArray(Charsets.UTF_8)), n)
        }
        val r = client.act("contact.request", withContext(Dispatchers.IO) { key(cid) }, "cid" to cid, "target" to targetPub, "epub" to epubHex, "box" to box)
        withContext(Dispatchers.IO) { store.addRequest(relay(), cid, r.getString("id"), targetPub, n) }
    }

    private suspend fun makeChatInvite(): String = withContext(Dispatchers.IO) {
        val onion = NodeRuntime.onion ?: throw RelayException("Poczekaj, aż SHYFR połączy się z siecią Tor.")
        val (_, pub) = Store(ctx).keys()
        val secret = InviteManager.create(CONTACT_INVITE_IDLE_MS)
        InviteCodec.encode(InviteCodec.Payload(onion, pub, secret))
    }

    suspend fun answerContact(req: Incoming, accept: Boolean) {
        val kp = withContext(Dispatchers.IO) { key(req.cid) }
        if (!accept) { client.act("contact.reply", kp, "cid" to req.cid, "req" to req.id, "status" to "rejected", "box" to ""); return }
        val link = makeChatInvite()
        val box = withContext(Dispatchers.IO) { ContactCrypto.seal(PublicProto.fromHex(req.epub), link.toByteArray(Charsets.UTF_8)) }
        client.act("contact.reply", kp, "cid" to req.cid, "req" to req.id, "status" to "accepted", "box" to box)
    }

    suspend fun blockRequester(req: Incoming) {
        client.act("contact.block", withContext(Dispatchers.IO) { key(req.cid) }, "cid" to req.cid, "target" to req.requester)
    }

    suspend fun markRequestHandled(id: String) = withContext(Dispatchers.IO) { store.markHandled(relay(), id) }

    /** Zbiera prośby, odpowiedzi i zdarzenia ze wszystkich Twoich społeczności. Błąd jednej społeczności nie psuje reszty. */
    suspend fun activitySnapshot(since: Long, skip: Set<String> = emptySet()): ActivitySnapshot {
        val ms = memberships()
        val inc = ArrayList<Incoming>(); val out = ArrayList<Outgoing>(); val ev = ArrayList<ActivityEvent>(); var failed = 0
        for (m in ms) {
            if (m.cid in skip) continue
            try {
                val kp = withContext(Dispatchers.IO) { key(m.cid) }
                val idx = m.keyIdx
                val priv = withContext(Dispatchers.IO) { PublicKeys.inboxPriv(masterKey(), relay(), m.cid, idx) }
                client.get("/v1/c/${m.cid}/inbox", kp).getJSONArray("requests").objs().forEach {
                    val g = ContactCrypto.open(priv, it.optString("box"))?.toString(Charsets.UTF_8) ?: "(nie można odczytać wiadomości)"
                    inc += Incoming(m.cid, m.name, it.getString("id"), it.optString("requester"), it.optString("epub"), g, it.optLong("ts"))
                }
                client.get("/v1/c/${m.cid}/outbox", kp).getJSONArray("requests").objs().forEach {
                    val id = it.getString("id"); val st = it.optString("status")
                    val n = withContext(Dispatchers.IO) { store.requestN(relay(), id) }
                    val handled = withContext(Dispatchers.IO) { store.isHandled(relay(), id) }
                    if (handled) return@forEach
                    var invite: String? = null
                    if (st == "accepted" && n != null) {
                        val rp = withContext(Dispatchers.IO) { PublicKeys.requestPriv(masterKey(), relay(), m.cid, it.optString("target"), n) }
                        invite = ContactCrypto.open(rp, it.optString("reply"))?.toString(Charsets.UTF_8)
                    }
                    out += Outgoing(m.cid, m.name, id, st, invite, it.optLong("ts"))
                }
                client.get("/v1/c/${m.cid}/activity?since=$since", kp).getJSONArray("events").objs().forEach {
                    ev += ActivityEvent(m.cid, m.name, it.optString("type"), it.optString("post"), it.optString("text"), it.optString("nick"), it.optString("emoji"), it.optString("reason"), it.optLong("ts"))
                }
            } catch (e: Exception) { failed++ }
        }
        return ActivitySnapshot(inc.sortedByDescending { it.ts }, out.sortedByDescending { it.ts }, ev.sortedByDescending { it.ts }, failed)
    }

    companion object { const val CONTACT_INVITE_IDLE_MS = 6 * 60 * 60 * 1000L }
}
