package com.shyfr.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.invite.InviteCodec
import com.shyfr.app.invite.InviteManager
import com.shyfr.app.net.JoinService
import com.shyfr.app.net.NodeRuntime
import com.shyfr.app.vault.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Frost: Color @Composable get() = MaterialTheme.colorScheme.primary

@Composable
fun InviteScreen(ctx: Context, onBack: () -> Unit) {
    var link by remember { mutableStateOf<String?>(null) }
    var id by remember { mutableStateOf<ByteArray?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var remaining by remember { mutableLongStateOf(InviteManager.IDLE_MS) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val onion = NodeRuntime.onion
            if (onion == null) { err = "Poczekaj, aż SHYFR połączy się z siecią Tor."; return@withContext }
            val (_, pub) = Store(ctx).keys()
            val secret = InviteManager.create()
            link = InviteCodec.encode(InviteCodec.Payload(onion, pub, secret))
            id = InviteManager.idOf(secret)
        }
    }
    LaunchedEffect(id) {
        val i = id ?: return@LaunchedEffect
        while (true) { remaining = InviteManager.remainingMs(i); if (remaining <= 0) break; delay(1000) }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)
            // każde dotknięcie ekranu = aktywność, przedłuża ważność zaproszenia
            .pointerInput(id) {
                awaitEachGesture { awaitFirstDown(pass = PointerEventPass.Initial); id?.let(InviteManager::touch) }
            },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Zaproszenie", fontSize = 26.sp, color = Frost)
        Spacer(Modifier.height(8.dp))
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        val l = link
        if (l != null) {
            if (remaining > 0) {
                Text("Ważne jeszcze ${remaining / 60000}:${"%02d".format(remaining / 1000 % 60)} bez aktywności. Działa raz.",
                    color = Frost.copy(alpha = .7f))
                Spacer(Modifier.height(16.dp))
                Box(Modifier.background(Color.White).padding(8.dp)) {
                    Image(qrBitmap(l).asImageBitmap(), "Kod QR zaproszenia", Modifier.size(280.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text("Druga osoba skanuje kod w SHYFR (Dołącz). Link wysyłaj tylko zaufanym kanałem.",
                    fontSize = 13.sp, color = Frost.copy(alpha = .7f))
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, l)
                    }, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Udostępnij link") }
            } else {
                Text("Zaproszenie wygasło lub zostało użyte.", color = Frost)
            }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onBack) { Text("Wróć") }
    }
}

@Composable
fun JoinScreen(ctx: Context, initial: String?, onBack: () -> Unit) {
    var text by remember { mutableStateOf(initial ?: "") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var scanning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun doJoin(link: String) {
        if (busy) return
        busy = true; msg = "Łączenie przez Tor… to może potrwać chwilę."
        scope.launch {
            val e = JoinService(ctx).join(link)
            msg = e ?: "Dodano znajomego."
            busy = false
            if (e == null) { delay(800); onBack() }
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) scanning = true else msg = "Bez zgody na aparat wklej link ręcznie."
    }

    if (scanning) {
        Box(Modifier.fillMaxSize()) {
            QrScanner { code -> if (!busy) { scanning = false; text = code; doJoin(code) } }
            OutlinedButton(onClick = { scanning = false }, Modifier.align(Alignment.BottomCenter).padding(24.dp)) { Text("Anuluj") }
        }
        return
    }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Dołącz", fontSize = 26.sp, color = Frost)
        Spacer(Modifier.height(16.dp))
        Button(modifier = Modifier.fillMaxWidth().height(52.dp), onClick = { perm.launch(Manifest.permission.CAMERA) }) { Text("Skanuj kod QR") }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(text, { text = it }, label = { Text("Lub wklej link zaproszenia") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedButton(enabled = !busy && text.isNotBlank(), onClick = { doJoin(text) }) { Text("Dołącz z linku") }
        msg?.let { Spacer(Modifier.height(12.dp)); Text(it, color = Frost) }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onBack) { Text("Wróć") }
    }
}
