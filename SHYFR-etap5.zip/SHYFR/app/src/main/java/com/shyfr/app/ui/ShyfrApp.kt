package com.shyfr.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.view.WindowCompat
import com.shyfr.app.session.Prefs
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.shyfr.app.CrashLog
import com.shyfr.app.Trace
import com.shyfr.app.Deeplink
import com.shyfr.app.R
import com.shyfr.app.net.NodeRuntime
import com.shyfr.app.net.Presence
import com.shyfr.app.vault.Backup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.flow.update
import com.shyfr.app.net.NodeService
import com.shyfr.app.net.NodeState
import com.shyfr.app.session.AppState
import com.shyfr.app.session.Session
import com.shyfr.app.vault.Contact
import com.shyfr.app.vault.Db
import com.shyfr.app.vault.QuickUnlock
import com.shyfr.app.vault.Store
import com.shyfr.app.vault.Vault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Wspólny końcowy krok odblokowania: sprawdza bazę, ustawia klucz w pamięci, uruchamia Tora. */
private fun completeUnlock(ctx: Context, key: ByteArray): Boolean = try {
    Db.open(ctx, key).close(); Session.adopt(key); NodeService.start(ctx); true
} catch (e: Throwable) { Trace.log("completeUnlock BŁĄD: ${e.javaClass.simpleName}: ${e.message}"); key.fill(0); false }

private enum class Screen { Feed, Communities, Home, Activity, Profile, Settings, Invite, Join, Chat, Group }

@Composable
fun ShyfrApp(ctx: Context, activity: FragmentActivity) {
    val vault = remember { Vault(ctx) }
    val quick = remember { QuickUnlock(ctx) }
    var themeMode by remember { mutableIntStateOf(Prefs.theme(ctx)) }
    val dark = when (themeMode) { 1 -> true; 2 -> false; else -> isSystemInDarkTheme() }
    SideEffect {
        val w = activity.window
        WindowCompat.getInsetsController(w, w.decorView).apply { isAppearanceLightStatusBars = !dark; isAppearanceLightNavigationBars = !dark }
    }
    var usePassword by remember { mutableStateOf(false) }
    var quickUnlockError by remember { mutableStateOf<String?>(null) }
    val uiScope = rememberCoroutineScope()
    var crash by remember { mutableStateOf(CrashLog.read(ctx)) }
    var unlocked by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf(Screen.Home) }
    var joinInitial by remember { mutableStateOf<String?>(null) }
    var chat by remember { mutableStateOf<Contact?>(null) }
    var groupId by remember { mutableStateOf<String?>(null) }
    val pending by Deeplink.pending.collectAsState()
    val lockTick by AppState.lockTick.collectAsState()
    LaunchedEffect(lockTick) { if (lockTick > 0) { unlocked = false; screen = Screen.Home; chat = null; groupId = null; usePassword = false } }
    LaunchedEffect(pending, unlocked) {
        val link = pending
        if (unlocked && link != null) { joinInitial = link; screen = Screen.Join; Deeplink.pending.value = null }
    }

    val fontLevel by com.shyfr.app.session.UiState.fontLevel.collectAsState()
    LaunchedEffect(Unit) { com.shyfr.app.session.UiState.fontLevel.value = Prefs.fontLevel(ctx) }
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    val fontFactor = when (fontLevel) { 0 -> 0.9f; 2 -> 1.15f; 3 -> 1.3f; else -> 1f }
    CompositionLocalProvider(androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density, baseDensity.fontScale * fontFactor)) {
    MaterialTheme(colorScheme = shyfrColors(dark), shapes = ShyfrShapes) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Box(Modifier.fillMaxSize().warmGlow().systemBarsPadding()) {
                when {
                    crash != null -> CrashScreen(crash!!) { CrashLog.clear(ctx); crash = null }
                    !unlocked && quick.any() && vault.hasAccount() && !usePassword -> QuickScreen(ctx, activity, quick,
                        onKey = { key ->
                            quickUnlockError = null
                            uiScope.launch(Dispatchers.Default) {
                                val ok = completeUnlock(ctx, key)
                                withContext(Dispatchers.Main) {
                                    if (ok) unlocked = true
                                    else quickUnlockError = "Klucz został odczytany, ale nie udało się otworzyć sejfu SHYFR. Użyj loginu i hasła albo sprawdź raport diagnostyczny."
                                }
                            }
                        },
                        onUsePassword = { usePassword = true; quickUnlockError = null },
                        externalError = quickUnlockError)
                    !unlocked -> AuthScreen(vault, ctx) { unlocked = true }
                    else -> when (screen) {
                        Screen.Feed, Screen.Communities, Screen.Home, Screen.Activity, Screen.Profile, Screen.Settings -> Shell(
                            ctx, activity, vault, screen,
                            onTab = { screen = it },
                            openChat = { chat = it; screen = Screen.Chat },
                            openGroup = { groupId = it; screen = Screen.Group },
                            go = { joinInitial = null; screen = it },
                            onLock = { AppState.lock(ctx) },
                            onWiped = { unlocked = false; screen = Screen.Home; chat = null; groupId = null },
                            themeMode = themeMode,
                            onTheme = { themeMode = it; Prefs.setTheme(ctx, it) }
                        )
                        Screen.Invite -> InviteScreen(ctx) { screen = Screen.Home }
                        Screen.Join -> JoinScreen(ctx, joinInitial) { screen = Screen.Home }
                        Screen.Chat -> chat?.let { ChatScreen(ctx, activity, it) { screen = Screen.Home } }
                        Screen.Group -> groupId?.let { GroupChatScreen(ctx, it) { screen = Screen.Home } }
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun AuthScreen(vault: Vault, ctx: Context, onUnlocked: () -> Unit) {
    val isNew = remember { !vault.hasAccount() }
    var login by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var onboarding by remember { mutableStateOf(isNew && !Prefs.onboarded(ctx)) }
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var bkPass by remember { mutableStateOf("") }
    val pickBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) restoreUri = uri }

    if (onboarding) { Onboarding { Prefs.setOnboarded(ctx); onboarding = false }; return }

    Column(Modifier.fillMaxSize().padding(28.dp).imePadding().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
        LogoHeader(110.dp)
        Spacer(Modifier.height(10.dp))
        Text(if (isNew) "Utwórz anonimowe konto. Dane zostają tylko na tym telefonie." else "Odblokuj konto.",
            color = ShMuted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(login, { login = it }, label = { Text("Login") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(pass, { pass = it }, label = { Text("Hasło") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (isNew) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(pass2, { pass2 = it }, label = { Text("Powtórz hasło") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text("Nie ma resetu hasła. Zapomniane hasło oznacza utratę wszystkich danych.", fontSize = 12.sp, color = ShMuted)
        }
        msg?.let { Spacer(Modifier.height(12.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(20.dp))
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp), onClick = {
            msg = null
            if (login.isBlank() || pass.length < 10) { msg = "Login jest wymagany, hasło min. 10 znaków."; return@Button }
            if (isNew && pass != pass2) { msg = "Hasła się różnią."; return@Button }
            busy = true
            scope.launch(Dispatchers.Default) {
                try {
                    val chars = pass.toCharArray()
                    val key: ByteArray? = if (isNew) vault.create(login, chars)
                    else when (val r = vault.unlock(login, chars)) {
                        is Vault.Result.Ok -> r.masterKey
                        is Vault.Result.Wrong -> { msg = "Błędne dane. Pozostało prób: ${r.attemptsLeft}"; null }
                        Vault.Result.Wiped -> { msg = "Przekroczono limit prób. Dane usunięto."; null }
                        Vault.Result.NoAccount -> { msg = "Brak konta."; null }
                    }
                    chars.fill('\u0000')
                    if (key != null) {
                        Db.open(ctx, key).close()
                        Session.adopt(key)
                        NodeService.start(ctx)
                        withContext(Dispatchers.Main) { onUnlocked() }
                    }
                } catch (e: Throwable) { msg = "Błąd: " + e.javaClass.simpleName + ": " + (e.message ?: "") }
                busy = false
            }
        }) { Text(if (isNew) "Utwórz konto" else "Odblokuj") }
        if (isNew) TextButton(modifier = Modifier.fillMaxWidth(), onClick = { pickBackup.launch(arrayOf("*/*")) }) { Text("Przywróć z kopii zapasowej") }
    }

    restoreUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { restoreUri = null; bkPass = "" },
            title = { Text("Przywróć z kopii") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Wpisz powyżej nowy login i hasło tego konta, a tutaj hasło kopii. Używaj kopii tylko na nowym telefonie: stary telefon przestaw na wyłączony. Po przywróceniu poproś rozmówców o napisanie pierwszej wiadomości, aby szyfrowanie zsynchronizowało się ponownie.", fontSize = 13.sp, color = ShMuted)
                    OutlinedTextField(bkPass, { bkPass = it }, label = { Text("Hasło kopii") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = !busy && bkPass.isNotEmpty(), onClick = {
                    if (login.isBlank() || pass.length < 10 || pass != pass2) { msg = "Uzupełnij login i hasło (min. 10 znaków, dwukrotnie)."; restoreUri = null; return@TextButton }
                    busy = true; restoreUri = null
                    scope.launch(Dispatchers.Default) {
                        val chars = pass.toCharArray(); val bk = bkPass.toCharArray()
                        var key: ByteArray? = null
                        try {
                            val k = vault.create(login, chars)
                            key = k
                            Db.open(ctx, k).close()
                            ctx.contentResolver.openInputStream(uri)?.use { Backup.import(ctx, k, bk, it) } ?: error("Nie można otworzyć pliku.")
                            Session.set(k); NodeService.start(ctx)
                            withContext(Dispatchers.Main) { onUnlocked() }
                        } catch (e: Throwable) {
                            if (key != null) { key?.fill(0); vault.wipe() }
                            msg = if (e is IllegalArgumentException) e.message else "Nie udało się przywrócić kopii."
                        } finally { chars.fill('\u0000'); bk.fill('\u0000'); bkPass = ""; busy = false }
                    }
                }) { Text("Przywróć") }
            },
            dismissButton = { TextButton(onClick = { restoreUri = null; bkPass = "" }) { Text("Anuluj") } }
        )
    }
}

@Composable
private fun Onboarding(onDone: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val pages = listOf(
        Triple("🔒", "Prywatne rozmowy", "Szyfrowanie end-to-end i sieć Tor. Bez numeru telefonu i bez serwera, który widzi Twoje wiadomości."),
        Triple("🔗", "Kontakty przez zaproszenie", "Dodajesz osoby kodem QR lub linkiem. Nikt nie znajdzie Cię po nazwie ani numerze."),
        Triple("💾", "Zadbaj o kopię zapasową", "Nie ma resetu hasła. Bez kopii utrata telefonu oznacza utratę rozmów. Kopię utworzysz w Ustawieniach.")
    )
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(pages[page].first, fontSize = 72.sp)
        Spacer(Modifier.height(24.dp))
        Text(pages[page].second, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(pages[page].third, color = ShMuted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            pages.indices.forEach { i -> Box(Modifier.size(if (i == page) 10.dp else 8.dp).clip(CircleShape).background(if (i == page) MaterialTheme.colorScheme.primary else ShMuted.copy(alpha = .4f))) }
        }
        Spacer(Modifier.height(32.dp))
        Button(modifier = Modifier.fillMaxWidth().height(52.dp), onClick = { if (page < pages.lastIndex) page++ else onDone() }) {
            Text(if (page < pages.lastIndex) "Dalej" else "Zaczynamy")
        }
        if (page < pages.lastIndex) TextButton(onClick = onDone) { Text("Pomiń") }
    }
}

@Composable
private fun Shell(
    ctx: Context, activity: FragmentActivity, vault: Vault, screen: Screen,
    onTab: (Screen) -> Unit, openChat: (Contact) -> Unit, openGroup: (String) -> Unit, go: (Screen) -> Unit,
    onLock: () -> Unit, onWiped: () -> Unit, themeMode: Int, onTheme: (Int) -> Unit
) {
    val st by NodeService.state.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    val reach by NodeRuntime.reachable.collectAsState()
    val online = st is NodeState.Online

    Scaffold(
        containerColor = Color.Transparent,
        topBar = { TopBar(st, reach, { NodeService.restart(ctx) }, { onTab(Screen.Settings) }, onLock) },
        bottomBar = { FloatingNav(screen, onTab) { showAdd = true } }
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when (screen) {
                Screen.Feed -> FeedScreen(ctx, onOpenCommunities = { onTab(Screen.Communities) }, onOpenSettings = { onTab(Screen.Settings) })
                Screen.Communities -> CommunitiesScreen(ctx, onOpenSettings = { onTab(Screen.Settings) })
                Screen.Home -> ChatsList(ctx, openChat, openGroup)
                Screen.Activity -> ActivityScreen(ctx, onOpenSettings = { onTab(Screen.Settings) })
                Screen.Profile -> ProfileScreen(ctx)
                Screen.Settings -> SettingsScreen(ctx, activity, vault, { onTab(Screen.Home) }, onWiped, themeMode, onTheme)
                else -> {}
            }
        }
    }

    if (showAdd) AlertDialog(
        onDismissRequest = { showAdd = false },
        title = { Text("Nowy kontakt") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(enabled = online, modifier = Modifier.fillMaxWidth(), onClick = { showAdd = false; go(Screen.Invite) }) { Text("Pokaż mój kod") }
                OutlinedButton(enabled = online, modifier = Modifier.fillMaxWidth(), onClick = { showAdd = false; go(Screen.Join) }) { Text("Skanuj lub wklej") }
                if (!online) Text("Czekam na połączenie z siecią…", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = { showAdd = false }) { Text("Zamknij") } }
    )
}

@Composable
private fun TopBar(st: NodeState, reach: Boolean, onRestart: () -> Unit, onSettings: () -> Unit, onLock: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.Image(painterResource(logoRes()), contentDescription = null, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(10.dp))
        Text("SHYFR", fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.5.sp, modifier = Modifier.weight(1f))
        StatusPill(st, reach, onRestart)
        Box(Modifier.padding(start = 8.dp).size(40.dp).clip(CircleShape).background(ShSurfaceHi).clickable(onClick = onSettings), contentAlignment = Alignment.Center) { Icon24(Ic.Settings, ShSilver, 20.dp) }
        Box(Modifier.padding(start = 8.dp).size(40.dp).clip(CircleShape).background(ShSurfaceHi).clickable(onClick = onLock), contentAlignment = Alignment.Center) { Icon24(Ic.Lock, ShSilver, 20.dp) }
    }
}

@Composable
private fun StatusPill(st: NodeState, reach: Boolean, onRestart: () -> Unit) {
    val (color, label) = when (st) {
        is NodeState.Online -> if (reach) Color(0xFF6FCF97) to "Tor online" else Color(0xFFE0B35A) to "Rozgłaszam adres…"
        is NodeState.Starting -> Color(0xFFE0B35A) to (Regex("(\\d+)%").find(st.step)?.let { "Tor ${it.groupValues[1]}%" } ?: "Łączenie…")
        is NodeState.Failed -> Color(0xFFE57373) to "Błąd Tor ↻"
        NodeState.Stopped -> ShMuted to "Wyłączony"
    }
    Row(Modifier.clip(RoundedCornerShape(50)).background(ShSurfaceHi).clickable(enabled = st is NodeState.Failed, onClick = onRestart).padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 12.sp)
    }
}

@Composable
private fun ChatsList(ctx: Context, open: (Contact) -> Unit, openGroup: (String) -> Unit) {
    val ver by NodeRuntime.contactsVersion.collectAsState()
    val mver by NodeRuntime.messagesVersion.collectAsState()
    val contacts by produceState(emptyList<Contact>(), ver, mver) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).contacts() }.getOrDefault(emptyList()) }
    }
    val avatars by produceState(emptyMap<Long, ByteArray>(), ver) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).contactAvatars() }.getOrDefault(emptyMap()) }
    }
    val drafts by produceState(emptyMap<Long, String>(), ver) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).drafts() }.getOrDefault(emptyMap()) }
    }
    val scope = rememberCoroutineScope()
    var nowTs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(20_000); nowTs = System.currentTimeMillis() } }
    var query by remember { mutableStateOf("") }
    var showArchived by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<Contact?>(null) }
    val groups by produceState(emptyList<com.shyfr.app.vault.Group>(), ver, mver) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).also { it.ensureNotes() }.groups() }.getOrDefault(emptyList()) }
    }
    var showCreateGroup by remember { mutableStateOf(false) }
    var onlyUnread by remember { mutableStateOf(false) }
    val hits by produceState(emptyList<com.shyfr.app.vault.SearchHit>(), query, mver) {
        value = if (query.trim().length < 2) emptyList()
        else withContext(Dispatchers.IO) { runCatching { Store(ctx).searchAll(query.trim()) }.getOrDefault(emptyList()) }
    }
    val protectedIds = contacts.filter { it.isProtected }.map { it.id }.toSet()
    val shownHits = hits.filter { it.contactId !in protectedIds }
    val shownGroups = (if (showArchived) emptyList() else groups.filter { it.name.contains(query, true) || (it.last ?: "").contains(query, true) })
        .filter { !onlyUnread || it.unread > 0 }
        .sortedByDescending { it.gid == com.shyfr.app.vault.NOTES_GID }
    val archivedCount = contacts.count { it.archived }
    val filtered = contacts
        .filter { it.archived == showArchived }
        .filter { !onlyUnread || it.unread > 0 }
        .filter { it.label.contains(query, true) || it.about.contains(query, true) || (!it.isProtected && (it.last ?: "").contains(query, true)) }
        .sortedWith(compareByDescending<Contact> { it.pinned }.thenByDescending { it.lastTs })
    fun act(block: (Store) -> Unit) = scope.launch(Dispatchers.IO) {
        runCatching { block(Store(ctx)) }
        NodeRuntime.contactsVersion.update { it + 1 }
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
            TextField(value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Szukaj") },
                leadingIcon = { Icon24(Ic.Search, ShMuted, 20.dp) },
                trailingIcon = { if (query.isNotEmpty()) Box(Modifier.clip(CircleShape).clickable { query = "" }.padding(10.dp)) { Icon24(Ic.Close, ShMuted, 16.dp) } },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = ShSurfaceHi.copy(alpha = .8f), unfocusedContainerColor = ShSurface.copy(alpha = .85f),
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                PillTab("Wszystkie", !onlyUnread && !showArchived) { onlyUnread = false; showArchived = false }
                PillTab("Nieprzeczytane", onlyUnread) { onlyUnread = !onlyUnread; showArchived = false }
                if (archivedCount > 0 || showArchived)
                    PillTab("Archiwum ($archivedCount)", showArchived) { showArchived = !showArchived; onlyUnread = false }
                PillTab("＋ Grupa", false) { showCreateGroup = true }
                PillTab("✓ Przeczytane", false) { act { it.markAllRead() } }
            }
        }
        if (contacts.isEmpty() && groups.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                androidx.compose.foundation.Image(painterResource(logoRes()), contentDescription = null, modifier = Modifier.size(104.dp))
                Spacer(Modifier.height(16.dp))
                Text("Brak rozmów", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("Dodaj kontakt przez kod QR lub link zaproszenia.", color = ShMuted, textAlign = TextAlign.Center)
            }
        } else if (filtered.isEmpty() && shownGroups.isEmpty() && shownHits.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (showArchived && query.isBlank()) "Archiwum jest puste" else "Brak wyników wyszukiwania", color = ShMuted) }
        } else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (shownHits.isNotEmpty()) {
                item { Text("Wiadomości (${shownHits.size})", color = ShMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp, top = 4.dp)) }
                items(shownHits.size, key = { "h$it" }) { i ->
                    val h = shownHits[i]
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(ShSurface.copy(alpha = .85f))
                        .clickable { contacts.firstOrNull { it.id == h.contactId }?.let(open) }.padding(12.dp)) {
                        Row { Text(h.label, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1); Text(fmtTime(h.ts), fontSize = 11.sp, color = ShMuted) }
                        Text(h.snippet, fontSize = 13.sp, color = ShMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            items(shownGroups, key = { "g" + it.gid }) { g -> GroupRow(g) { openGroup(g.gid) } }
            items(filtered, key = { it.id }) { c -> ContactRow(c, avatars[c.id], drafts[c.id], Presence.isOnline(c, nowTs), onLong = { menuFor = c }) { open(c) } }
        }
    }
    if (showCreateGroup) CreateGroupDialog(ctx, onDismiss = { showCreateGroup = false }, onCreated = { showCreateGroup = false; openGroup(it) })
    menuFor?.let { c ->
        ContactMenu(c, onDismiss = { menuFor = null },
            onPin = { act { it.setPinned(c.id, !c.pinned) } },
            onMute = { ms -> act { it.setMutedFor(c.id, ms) } },
            onArchive = { act { it.setArchived(c.id, !c.archived) } },
            onUnread = { act { it.markUnread(c.id) } })
    }
}

@Composable
private fun GroupRow(g: com.shyfr.app.vault.Group, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(ShSurface.copy(alpha = .85f)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Avatar(g.name, 0, "👥", 48.dp, null)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(g.name, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text((if (g.muted) "🔕 " else "") + fmtTime(g.lastTs), fontSize = 11.sp, color = ShMuted)
            }
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(g.last ?: "Grupa • ${g.members.size} członków", fontSize = 13.sp, color = ShMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (g.unread > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.primary).padding(horizontal = 7.dp, vertical = 2.dp)) {
                        Text(g.unread.toString(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactMenu(c: Contact, onDismiss: () -> Unit, onPin: () -> Unit, onMute: (Long) -> Unit, onArchive: () -> Unit, onUnread: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(c.label, maxLines = 1) },
        text = {
            Column {
                TextButton(onClick = { onPin(); onDismiss() }) { Text(if (c.pinned) "📌  Odepnij rozmowę" else "📌  Przypnij na górze") }
                if (c.muted) TextButton(onClick = { onMute(-1L); onDismiss() }) { Text("🔔  Włącz powiadomienia") }
                else listOf("1 godzinę" to 3_600_000L, "8 godzin" to 28_800_000L, "7 dni" to 604_800_000L, "Zawsze" to 0L).forEach { (l, ms) ->
                    TextButton(onClick = { onMute(ms); onDismiss() }) { Text("🔕  Wycisz: $l") }
                }
                TextButton(onClick = { onUnread(); onDismiss() }) { Text("🔵  Oznacz jako nieprzeczytane") }
                TextButton(onClick = { onArchive(); onDismiss() }) { Text(if (c.archived) "📤  Przywróć z archiwum" else "🗄  Archiwizuj") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zamknij") } }
    )
}

/** Rozmowa z włączoną blokadą zrzutów: treść wiadomości nie pojawia się na liście ani w wyszukiwarce. */
private val Contact.isProtected: Boolean get() = capMode == 1

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ContactRow(c: Contact, photo: ByteArray?, draft: String?, online: Boolean, onLong: () -> Unit, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(ShSurface.copy(alpha = .85f)).combinedClickable(onClick = onClick, onLongClick = onLong).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Avatar(c.shownName, c.color, c.emoji, 52.dp, photo, online = online)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c.shownName + if (c.verified) "  ✓" else "", fontSize = 16.sp, fontWeight = if (c.unread > 0) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text((if (c.pinned) "📌 " else "") + (if (c.muted) "🔕 " else "") + fmtTime(c.lastTs), fontSize = 11.sp,
                    color = if (c.unread > 0) MaterialTheme.colorScheme.primary else ShMuted)
            }
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (c.blocked) {
                    Text("🚫 Zablokowany", fontSize = 13.sp, color = ShMuted, maxLines = 1, modifier = Modifier.weight(1f))
                } else if (c.isProtected) {
                    Text("🔒 Rozmowa chroniona", fontSize = 13.sp, color = ShMuted, maxLines = 1, modifier = Modifier.weight(1f))
                } else if (!draft.isNullOrBlank()) {
                    Text("Szkic: ", fontSize = 13.sp, color = MaterialTheme.colorScheme.error, maxLines = 1)
                    Text(draft, fontSize = 13.sp, color = ShMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                } else {
                    val st = if (c.last == null) Presence.label(c) else null
                    Text(c.last?.ifBlank { "🚫 Wiadomość usunięta" } ?: st ?: c.about.ifBlank { "Rozpocznij rozmowę" }, fontSize = 13.sp,
                        color = if (c.last == null && online) Color(0xFF3DDC84) else ShMuted,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                }
                if (c.unread > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.primary).padding(horizontal = 7.dp, vertical = 2.dp)) {
                        Text(c.unread.toString(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}


/** Pływający pasek nawigacji w kształcie pigułki z okrągłymi przyciskami (styl z makiety). */
@Composable
private fun FloatingNav(screen: Screen, onTab: (Screen) -> Unit, onAdd: () -> Unit) {
    val unread by NodeRuntime.activityUnread.collectAsState()
    Box(Modifier.fillMaxWidth().padding(bottom = 12.dp), contentAlignment = Alignment.Center) {
        Row(
            Modifier.clip(RoundedCornerShape(36.dp)).background(ShSurface.copy(alpha = .94f)).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            listOf(Screen.Feed to Ic.Feed, Screen.Communities to Ic.Group, Screen.Home to Ic.Chat, Screen.Activity to Ic.Bell, Screen.Profile to Ic.Person).forEach { (s, ic) ->
                val sel = screen == s
                Box {
                    Box(
                        Modifier.size(44.dp).clip(CircleShape)
                            .background(if (sel) MaterialTheme.colorScheme.primary else ShSurfaceHi)
                            .clickable { onTab(s) },
                        contentAlignment = Alignment.Center
                    ) { Icon24(ic, if (sel) MaterialTheme.colorScheme.onPrimary else ShSilver, 22.dp) }
                    if (s == Screen.Activity && unread > 0 && !sel) Box(Modifier.align(Alignment.TopEnd).size(11.dp).clip(CircleShape).background(Color(0xFFE0B35A)))
                }
            }
            Box(
                Modifier.size(44.dp).clip(CircleShape).border(1.dp, ShMuted.copy(alpha = .55f), CircleShape).clickable(onClick = onAdd),
                contentAlignment = Alignment.Center
            ) { Icon24(Ic.Add, ShSilver, 22.dp) }
        }
    }
}

/** Zakładka-pigułka: wybrana jest kremowa, pozostałe przyciemnione. */
@Composable
internal fun PillTab(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) MaterialTheme.colorScheme.primary else ShSurfaceHi.copy(alpha = .75f))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else ShSilver)
    }
}
