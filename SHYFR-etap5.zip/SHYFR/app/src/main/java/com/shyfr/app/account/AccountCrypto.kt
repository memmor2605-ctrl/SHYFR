package com.shyfr.app.account

import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Hkdf
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Koperta odzyskiwania konta: klucz główny konta zaszyfrowany kluczem z hasła (Argon2id liczy wywołujący, tu tylko kryptografia).
 * Z jednego wyniku Argon2id wyprowadzamy trzy NIEZALEŻNE wartości: identyfikator koperty (lookup), klucz szyfrujący AES-256-GCM
 * i klucz podpisu Ed25519 (prawo zapisu i odczytu na przekaźniku). Przekaźnik nie widzi loginu, hasła ani klucza głównego.
 */
object AccountCrypto {
    class Keys(val lookup: String, val wrapKey: ByteArray, val signing: Ed25519Sign.KeyPair) {
        fun wipe() = wrapKey.fill(0)
    }

    fun normLogin(login: String) = login.trim().lowercase()

    /** Sól zależy tylko od loginu, więc nowy telefon odtworzy ją bez żadnych danych. Bezpieczeństwo zapewnia hasło i koszt Argon2id. */
    fun saltFor(login: String): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(("shyfr-account-salt-v1|" + normLogin(login)).toByteArray(Charsets.UTF_8)).copyOf(16)

    private fun hkdf(root: ByteArray, label: String) = Hkdf.computeHkdf("HmacSha256", root, ByteArray(0), label.toByteArray(Charsets.UTF_8), 32)

    fun keysFromRoot(root: ByteArray): Keys {
        val lookup = hkdf(root, "shyfr-acct-lookup-v1").joinToString("") { "%02x".format(it) }
        return Keys(lookup, hkdf(root, "shyfr-acct-wrap-v1"), Ed25519Sign.KeyPair.newKeyPairFromSeed(hkdf(root, "shyfr-acct-sign-v1")))
    }

    private fun aad(k: Keys, ver: Long) = k.lookup.toByteArray(Charsets.US_ASCII) + ByteBuffer.allocate(8).putLong(ver).array()
    private const val FORMAT: Byte = 1

    /** Zwraca kopertę jako base64url bez dopełnienia: nonce(12) | AES-GCM( format | klucz główny ). */
    fun seal(master: ByteArray, k: Keys, ver: Long, rng: SecureRandom = SecureRandom()): String {
        require(master.size == 32) { "Klucz główny ma 32 bajty" }
        val nonce = ByteArray(12).also(rng::nextBytes)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(k.wrapKey, "AES"), GCMParameterSpec(128, nonce))
        c.updateAAD(aad(k, ver))
        val ct = c.doFinal(byteArrayOf(FORMAT) + master)
        return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(nonce + ct)
    }

    /** Null, gdy koperta jest uszkodzona, ma inną wersję albo klucz jest błędny (czyli hasło jest błędne). */
    fun open(blob: String, k: Keys, ver: Long): ByteArray? = try {
        val raw = java.util.Base64.getUrlDecoder().decode(blob)
        if (raw.size < 12 + 16 + 33) null else {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(k.wrapKey, "AES"), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            c.updateAAD(aad(k, ver))
            val pt = c.doFinal(raw, 12, raw.size - 12)
            if (pt.size == 33 && pt[0] == FORMAT) pt.copyOfRange(1, 33) else null
        }
    } catch (e: Exception) { null }

    private val COMMON = setOf("passwordpassword", "123456789012", "qwertyuiopas", "haslohaslohaslo", "administrator", "letmeinletmein", "iloveyouiloveyou", "shyfrshyfrshyfr")

    /**
     * Hasło chroni kopertę przed zgadywaniem offline przez operatora przekaźnika, więc musi być naprawdę silne.
     * Zwraca opis problemu albo null, gdy hasło jest akceptowalne. To ocena heurystyczna, nie gwarancja.
     */
    fun strengthProblem(password: CharArray, login: String): String? {
        val p = String(password)
        if (p.length < 12) return "Hasło musi mieć co najmniej 12 znaków."
        if (p.lowercase() == normLogin(login) || p.lowercase().contains(normLogin(login)) && normLogin(login).length >= 4) return "Hasło nie może zawierać loginu."
        if (p.toSet().size < 6) return "Hasło jest zbyt przewidywalne: użyj więcej różnych znaków."
        if (p.lowercase() in COMMON) return "To hasło jest zbyt popularne."
        val classes = listOf(p.any { it.isLowerCase() }, p.any { it.isUpperCase() }, p.any { it.isDigit() }, p.any { !it.isLetterOrDigit() }).count { it }
        if (classes < 3 && p.length < 16) return "Użyj co najmniej 16 znaków albo połącz małe i wielkie litery, cyfry i znaki specjalne."
        return null
    }
}
