package com.shyfr.app.net

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.system.Os
import android.system.OsConstants
import java.io.File
import java.io.FileOutputStream
import android.os.Messenger
import com.shyfr.app.Trace
import net.freehaven.tor.control.TorControlConnection
import org.torproject.jni.TorService

/**
 * Działa w OSOBNYM procesie (:tor), razem z biblioteką TorService. Jeśli natywny Tor się wywróci
 * lub wywoła exit(), ginie tylko ten proces, a główna aplikacja to zauważa i uruchamia Tora od nowa
 * na czystym stanie. Aplikacja rozmawia z hostem przez Messenger (polecenia kontrolne Tora).
 */
class TorHostService : Service() {
    @Volatile private var tor: TorService? = null
    @Volatile private var control: TorControlConnection? = null
    private var conn: ServiceConnection? = null
    private lateinit var thread: HandlerThread
    private lateinit var messenger: Messenger

    override fun onCreate() {
        super.onCreate()
        Trace.init(this)
        Trace.log("TorHost: start w procesie :tor pid=${android.os.Process.myPid()}")
        redirectStdio()
        thread = HandlerThread("shyfr-torhost").also { it.start() }
        messenger = Messenger(object : Handler(thread.looper) {
            override fun handleMessage(m: Message) { handle(m) }
        })
        val c = object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
                Trace.log("TorHost: TorService połączony")
                tor = (b as TorService.LocalBinder).service
            }
            override fun onServiceDisconnected(n: ComponentName?) { Trace.log("TorHost: TorService rozłączony"); tor = null; control = null }
        }
        conn = c
        val i = Intent(this, TorService::class.java)
        runCatching { startService(i) }.onFailure { Trace.log("TorHost: startService błąd $it") }
        bindService(i, c, Context.BIND_AUTO_CREATE)
    }

    /** Tor loguje na stdout/stderr. Kierujemy je do pliku, żeby zobaczyć jego komunikaty także przy nagłym wyjściu. */
    private fun redirectStdio() {
        runCatching {
            val f = File(cacheDir, "tor-stdout.log")
            if (f.exists() && f.length() > 60_000) f.delete()
            val fos = FileOutputStream(f, true)
            Os.dup2(fos.fd, OsConstants.STDOUT_FILENO)
            Os.dup2(fos.fd, OsConstants.STDERR_FILENO)
            Trace.log("TorHost: stdout/stderr Tora -> tor-stdout.log")
        }.onFailure { Trace.log("TorHost: przekierowanie stdout nieudane: $it") }
    }

    override fun onBind(i: Intent?): IBinder = messenger.binder

    override fun onDestroy() {
        Trace.log("TorHost: onDestroy")
        runCatching { conn?.let { unbindService(it) } }
        runCatching { stopService(Intent(this, TorService::class.java)) }
        thread.quitSafely()
        super.onDestroy()
        // Czysty stan natywnego Tora: proces :tor ma żyć tylko tak długo, jak ta usługa.
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    private fun currentControl(): TorControlConnection? =
        control ?: tor?.torControlConnection?.also { control = it }

    private fun handle(m: Message) {
        val reply = m.replyTo ?: return
        val data = m.data
        val b = Bundle()
        try {
            when (m.what) {
                OP_READY -> b.putBoolean("ok", currentControl() != null)
                OP_RAW -> b.putString("text", raw(currentControl() ?: error("Tor niegotowy"), data.getString("v") ?: ""))
                OP_INFO -> b.putString("text", (currentControl() ?: error("Tor niegotowy")).getInfo(data.getString("v") ?: ""))
            }
        } catch (e: Throwable) {
            b.putString("error", e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
        runCatching { reply.send(Message.obtain(null, m.what, m.arg1, 0).also { it.data = b }) }
    }

    /**
     * jtorctl nie udostępnia publicznie surowych poleceń (metoda jest protected, pole z treścią
     * odpowiedzi package-private), więc wywołujemy ją refleksją.
     */
    private fun raw(c: TorControlConnection, cmd: String): String {
        val m = TorControlConnection::class.java.getDeclaredMethod(
            "sendAndWaitForResponse", String::class.java, String::class.java)
        m.isAccessible = true
        val reply = (m.invoke(c, cmd + "\r\n", null) as List<*>).filterNotNull()
        return reply.joinToString("\n") { l ->
            val f = l.javaClass.getDeclaredField("msg"); f.isAccessible = true; f.get(l) as String
        }
    }

    companion object { const val OP_READY = 1; const val OP_RAW = 2; const val OP_INFO = 3 }
}
