package com.shyfr.app.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle

/**
 * Lekkie formatowanie wiadomości (lokalne — nie zmienia treści wysyłanej przez sieć):
 * *pogrubienie*, _kursywa_, ~przekreślenie~, `kod` oraz podkreślone linki http(s).
 * Znaczniki muszą stać na granicy słowa, więc snake_case_nazwa się nie psuje.
 */
private val TOKEN = Regex(
    "(?<![\\p{L}\\p{N}])(?:\\*([^*\\n]+)\\*|_([^_\\n]+)_|~([^~\\n]+)~|`([^`\\n]+)`)(?![\\p{L}\\p{N}])|(https?://[^\\s]+)"
)
private val URL_RE = Regex("https?://[^\\s]+")

fun richText(src: String, linkColor: Color, codeBg: Color): AnnotatedString = buildAnnotatedString {
    var pos = 0
    for (m in TOKEN.findAll(src)) {
        if (m.range.first > pos) append(src.substring(pos, m.range.first))
        val g = m.groups
        when {
            g[1] != null -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(g[1]!!.value) }
            g[2] != null -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(g[2]!!.value) }
            g[3] != null -> withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { append(g[3]!!.value) }
            g[4] != null -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(g[4]!!.value) }
            else -> withStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)) { append(m.value) }
        }
        pos = m.range.last + 1
    }
    if (pos < src.length) append(src.substring(pos))
}

/** Pierwszy link http(s) w tekście (lub null) — do akcji „Otwórz link” w menu wiadomości. */
fun firstLink(src: String): String? = URL_RE.find(src)?.value?.trimEnd('.', ',', ')', ';', '!', '?')
