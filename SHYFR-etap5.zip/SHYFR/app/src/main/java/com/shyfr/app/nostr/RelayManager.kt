package com.shyfr.app.nostr

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap

interface RelayLink {
    val url: String
    /** Wiadomości od przekaźnika. Kanał zamyka się, gdy połączenie się kończy. */
    val incoming: ReceiveChannel<String>
    suspend fun send(text: String)
    fun close()
}
fun interface RelayConnector { suspend fun connect(url: String): RelayLink }
interface RelayMemory { fun load(): List<String>; fun save(urls: List<String>) }

data class RelayConfig(
    val target: Int = 4, val maxParallel: Int = 6,
    val connectTimeoutMs: Long = 25_000, val probeTimeoutMs: Long = 15_000,
    val publishTimeoutMs: Long = 10_000, val queryTimeoutMs: Long = 12_000,
    val backoffBaseMs: Long = 5_000, val backoffMaxMs: Long = 600_000,
    val healthIntervalMs: Long = 60_000, val banMs: Long = 6 * 3_600_000L,
    val verifySignatures: Boolean = true
)

data class PublishResult(val accepted: Int, val rejected: Int, val noAnswer: Int, val attempted: Int) {
    /** Sukces tylko wtedy, gdy co najmniej jeden przekaźnik potwierdził przyjęcie zdarzenia. */
    val success get() = accepted > 0
    val noConnection get() = attempted == 0
}
data class QueryResult(val events: List<NostrEvent>, val asked: Int, val answered: Int)
enum class NetState { CONNECTING, ONLINE, OFFLINE }
data class NetStatus(val state: NetState, val connected: Int)

/** Stan jednego przekaźnika do podglądu diagnostycznego (tylko tryb programisty). */
data class RelayDiag(val url: String, val connected: Boolean, val banned: Boolean, val failures: Int, val lastError: String, val retryInMs: Long)

/**
 * Jedyny zarządca połączeń z publicznymi przekaźnikami Nostr. Użytkownik nie podaje żadnych adresów:
 * lista startowa i zapamiętane udane przekaźniki wystarczą. Każdy kandydat jest sprawdzany w praktyce
 * (połączenie, odpowiedź EOSE na zapytanie NIP-01); przekaźniki wymagające logowania (NIP-42), płatne albo
 * niedziałające są pomijane, a awarie ponawiane z rosnącym opóźnieniem. Nie zakładamy, że każdy przekaźnik
 * jest osiągalny przez Tora ani że przechowuje dane na stałe.
 */
class RelayManager(
    bootstrap: List<String>, private val connector: RelayConnector, private val memory: RelayMemory,
    private val cfg: RelayConfig = RelayConfig(), private val now: () -> Long = System::currentTimeMillis,
    private val rnd: java.util.Random = java.util.Random()
) {
    private class Relay(val url: String) {
        @Volatile var link: RelayLink? = null
        @Volatile var failures = 0
        @Volatile var nextTryAt = 0L
        @Volatile var bannedUntil = 0L
        @Volatile var lastError = ""
    }
    private class Sub(val onEvent: (String, NostrEvent) -> Unit, val onEose: (String) -> Unit, val onClosed: (String) -> Unit)
    private enum class Probe { OK, BAD, UNSUITABLE }

    private val relays = ConcurrentHashMap<String, Relay>()
    private val subs = ConcurrentHashMap<String, Sub>()
    private val pendingOk = ConcurrentHashMap<String, CompletableDeferred<RelayMsg.Ok>>()
    private val verified = object : LinkedHashMap<String, Boolean>(512, 0.75f, true) { override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Boolean>) = size > 2000 }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val ensureLock = Mutex()
    private val kick = Channel<Unit>(Channel.CONFLATED)
    @Volatile private var started = false
    @Volatile private var connecting = false
    private val _status = MutableStateFlow(NetStatus(NetState.OFFLINE, 0))
    val status: StateFlow<NetStatus> get() = _status

    init {
        (memory.load() + bootstrap).map { it.trim().trimEnd('/') }.filter { it.isNotEmpty() }.distinct().forEach { relays[it] = Relay(it) }
    }

    /** Opóźnienie przed kolejną próbą: rośnie wykładniczo do limitu, z losowym rozrzutem do 20%. */
    fun backoffMs(failures: Int): Long {
        if (failures <= 0) return 0
        val base = minOf(cfg.backoffMaxMs, cfg.backoffBaseMs shl minOf(failures - 1, 20))
        return base + (base * 0.2 * rnd.nextDouble()).toLong()
    }

    private fun live() = relays.values.filter { it.link != null }

    fun diagnostics(): List<RelayDiag> = relays.values.map {
        RelayDiag(it.url, it.link != null, it.bannedUntil > now(), it.failures, it.lastError, maxOf(0L, it.nextTryAt - now()))
    }.sortedWith(compareBy({ !it.connected }, { it.banned }, { it.failures }, { it.url }))

    fun connectedUrls(): List<String> = live().map { it.url }
    private fun refreshStatus() {
        val n = live().size
        _status.value = NetStatus(if (n > 0) NetState.ONLINE else if (connecting) NetState.CONNECTING else NetState.OFFLINE, n)
    }

    private fun fail(r: Relay, unsuitable: Boolean = false, reason: String = "") {
        if (reason.isNotEmpty()) r.lastError = reason
        r.failures++
        r.nextTryAt = now() + backoffMs(r.failures)
        if (unsuitable) r.bannedUntil = now() + cfg.banMs
    }

    private fun isUnsuitable(msg: String): Boolean {
        val m = msg.lowercase()
        return listOf("auth-required", "restricted", "payment", "paid", "blocked", "not allowed", "whitelist", "pow:").any { m.contains(it) }
    }

    private fun candidates(): List<Relay> {
        val remembered = memory.load().map { it.trimEnd('/') }
        return relays.values.filter { it.link == null && it.bannedUntil <= now() && it.nextTryAt <= now() }
            .shuffled(rnd).sortedWith(compareBy({ if (it.url in remembered) 0 else 1 }, { it.failures }))
    }

    /**
     * Dobija połączenia do liczby docelowej, falami po tyle kandydatów, ile brakuje (zapamiętane przekaźniki idą pierwsze),
     * żeby nie otwierać zbędnych połączeń przez Tora. Bezpieczne do wielokrotnego wywołania.
     */
    suspend fun ensure() = ensureLock.withLock {
        if (live().size >= cfg.target) return@withLock
        connecting = true; refreshStatus()
        try {
            val cands = candidates(); var i = 0
            while (live().size < cfg.target && i < cands.size) {
                val need = minOf(cfg.target - live().size, cfg.maxParallel)
                val wave = cands.subList(i, minOf(cands.size, i + need)); i += wave.size
                coroutineScope { wave.forEach { r -> launch { tryConnect(r) } } }
            }
        } finally { connecting = false; refreshStatus() }
    }

    private suspend fun tryConnect(r: Relay) {
        val link = try { withTimeout(cfg.connectTimeoutMs) { connector.connect(r.url) } }
        catch (e: TimeoutCancellationException) { fail(r, reason = "przekroczono czas łączenia"); return }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { fail(r, reason = (e.message ?: e.javaClass.simpleName).take(80)); return }
        when (probe(link)) {
            Probe.OK -> attach(r, link)
            Probe.UNSUITABLE -> { link.close(); fail(r, unsuitable = true, reason = "wymaga logowania albo jest płatny") }
            Probe.BAD -> { link.close(); fail(r, reason = "brak poprawnej odpowiedzi na zapytanie") }
        }
    }

    private suspend fun probe(link: RelayLink): Probe {
        val sub = "p" + rnd.nextInt(1_000_000)
        try { link.send(NostrWire.reqMsg(sub, listOf(Filter(kinds = listOf(1), limit = 1)))) } catch (e: CancellationException) { throw e } catch (e: Exception) { return Probe.BAD }
        val res = withTimeoutOrNull(cfg.probeTimeoutMs) {
            var out = Probe.BAD
            loop@ for (t in link.incoming) {
                when (val m = NostrWire.parse(t)) {
                    is RelayMsg.Eose -> if (m.sub == sub) { out = Probe.OK; break@loop }
                    is RelayMsg.Closed -> { out = if (isUnsuitable(m.message)) Probe.UNSUITABLE else Probe.BAD; break@loop }
                    is RelayMsg.Notice -> if (isUnsuitable(m.message)) { out = Probe.UNSUITABLE; break@loop }
                    is RelayMsg.Auth -> { out = Probe.UNSUITABLE; break@loop }
                    else -> {}
                }
            }
            out
        }
        if (res == Probe.OK) runCatching { link.send(NostrWire.closeMsg(sub)) }
        return res ?: Probe.BAD
    }

    private fun attach(r: Relay, link: RelayLink) {
        r.link = link; r.failures = 0; r.nextTryAt = 0
        memory.save((connectedUrls() + memory.load()).distinct().take(8))
        refreshStatus()
        scope.launch {
            try { for (t in link.incoming) dispatch(r.url, t) }
            catch (e: CancellationException) { throw e } catch (_: Exception) { }
            finally {
                if (r.link === link) { r.link = null; fail(r, reason = "połączenie zerwane"); refreshStatus(); kick.trySend(Unit) }
                link.close()
            }
        }
    }

    private fun dispatch(url: String, text: String) {
        when (val m = NostrWire.parse(text)) {
            is RelayMsg.Event -> subs[m.sub]?.onEvent?.invoke(url, m.ev)
            is RelayMsg.Eose -> subs[m.sub]?.onEose?.invoke(url)
            is RelayMsg.Closed -> { relays[url]?.let { if (isUnsuitable(m.message)) it.bannedUntil = now() + cfg.banMs }; subs[m.sub]?.onClosed?.invoke(url) }
            is RelayMsg.Ok -> pendingOk[url + "|" + m.id]?.complete(m)
            else -> {}
        }
    }

    /** Uruchamia nadzór w tle: uzupełnia połączenia i sprawdza je okresowo. Wielokrotne wywołanie nic nie psuje. */
    fun start() {
        if (started) return
        started = true
        scope.launch { while (isActive) { runCatching { ensure() }; withTimeoutOrNull(cfg.healthIntervalMs) { kick.receive() } } }
    }

    /** Zmiana sieci (Wi-Fi ↔ dane): stare obwody są martwe, więc rozłączamy i łączymy od nowa bez czekania na opóźnienia. */
    fun networkChanged() {
        relays.values.forEach { r -> r.nextTryAt = 0; r.failures = 0; r.link?.let { l -> r.link = null; l.close() } }
        refreshStatus(); kick.trySend(Unit)
    }

    fun shutdown() { started = false; scope.cancel(); relays.values.forEach { it.link?.close(); it.link = null }; refreshStatus() }

    suspend fun publish(ev: NostrEvent): PublishResult {
        if (live().size < 2) ensure()
        val targets = live()
        if (targets.isEmpty()) return PublishResult(0, 0, 0, 0)
        val text = NostrWire.eventMsg(ev)
        val answers = coroutineScope {
            targets.map { r ->
                async {
                    val key = r.url + "|" + ev.id
                    val d = CompletableDeferred<RelayMsg.Ok>(); pendingOk[key] = d
                    val ok: RelayMsg.Ok? = try { r.link?.send(text); withTimeoutOrNull(cfg.publishTimeoutMs) { d.await() } }
                    catch (e: CancellationException) { throw e } catch (e: Exception) { null }
                    finally { pendingOk.remove(key) }
                    if (ok != null && !ok.accepted && isUnsuitable(ok.message)) r.bannedUntil = now() + cfg.banMs
                    ok
                }
            }.awaitAll()
        }
        return PublishResult(answers.count { it?.accepted == true }, answers.count { it != null && !it.accepted }, answers.count { it == null }, targets.size)
    }

    private fun isVerified(e: NostrEvent): Boolean {
        synchronized(verified) { if (verified[e.id] == true) return true }
        val ok = e.isValid()
        if (ok) synchronized(verified) { verified[e.id] = true }
        return ok
    }

    /** Zapytanie do wszystkich połączonych przekaźników naraz. Wyniki bez duplikatów, sprawdzone (id i podpis), od najnowszych. */
    suspend fun query(filters: List<Filter>, timeoutMs: Long = cfg.queryTimeoutMs): QueryResult {
        if (live().isEmpty()) ensure()
        val targets = live()
        if (targets.isEmpty()) return QueryResult(emptyList(), 0, 0)
        val subId = "q" + rnd.nextInt(Int.MAX_VALUE)
        val seen = ConcurrentHashMap<String, NostrEvent>()
        val done = ConcurrentHashMap.newKeySet<String>()
        val all = CompletableDeferred<Unit>()
        subs[subId] = Sub(
            onEvent = { _, e -> if (seen.size < 2000) seen.putIfAbsent(e.id, e) },
            onEose = { u -> done.add(u); if (done.size >= targets.size) all.complete(Unit) },
            onClosed = { u -> done.add(u); if (done.size >= targets.size) all.complete(Unit) }
        )
        try {
            val req = NostrWire.reqMsg(subId, filters)
            targets.forEach { r -> try { r.link?.send(req) } catch (e: CancellationException) { throw e } catch (e: Exception) { done.add(r.url) } }
            withTimeoutOrNull(timeoutMs) { all.await() }
        } finally {
            subs.remove(subId)
            val close = NostrWire.closeMsg(subId)
            targets.forEach { r -> runCatching { r.link?.send(close) } }
        }
        val events = seen.values.toList()
        val good = if (!cfg.verifySignatures) events else coroutineScope { events.map { e -> async(Dispatchers.Default) { if (isVerified(e)) e else null } }.awaitAll().filterNotNull() }
        return QueryResult(good.sortedByDescending { it.createdAt }, targets.size, done.size)
    }
}
