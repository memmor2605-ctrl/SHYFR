package com.shyfr.app.session

/** Klucz główny żyje tylko w RAM, tylko gdy konto jest odblokowane. */
object Session {
    @Volatile private var key: ByteArray? = null
    fun set(k: ByteArray) { clear(); key = k }
    fun get(): ByteArray? = key
    /** Jeśli ten sam klucz już jest w RAM (węzeł działa w tle po blokadzie ekranu), niczego nie zeruje. */
    fun adopt(k: ByteArray) { val cur = key; if (cur != null && cur.contentEquals(k)) k.fill(0) else set(k) }
    fun clear() { key?.fill(0); key = null }
}
