package com.shyfr.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.shyfr.app.net.NodeState
import com.shyfr.app.vault.Backup
import com.shyfr.app.net.NodeRuntime
import com.shyfr.app.net.NodeService
import com.shyfr.app.net.Presence
import com.shyfr.app.session.Prefs
import com.shyfr.app.session.Session
import com.shyfr.app.session.UiState
import com.shyfr.app.vault.QuickUnlock
import com.shyfr.app.vault.Store
import com.shyfr.app.vault.Vault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp,
        color = ShMuted, modifier = Modifier.padding(start = 8.dp, top = 24.dp, bottom = 8.dp))
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(ShSurface)) { content() }
}

@Composable
private fun StatusRow(ok: Boolean, title: String, detail: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.padding(end = 14.dp).size(9.dp).clip(CircleShape).background(if (ok) androidx.compose.ui.graphics.Color(0xFF4CAF7A) else androidx.compose.ui.graphics.Color(0xFFD1A64A)))
        Column(Modifier.weight(1f)) { Text(title, fontSize = 15.sp); Text(detail, fontSize = 12.sp, color = ShMuted) }
    }
}

private val ONION_RE = Regex("[a-z2-7]{16,56}\\.onion")
private val HEX_RE = Regex("\\b[0-9a-fA-F]{24,}\\b")
/** Maskuje adresy onion i długie identyfikatory heksadecymalne, zanim raport zostanie pokazany lub skopiowany. */
private fun redact(s: String) = s.replace(ONION_RE, "[onion]").replace(HEX_RE, "[id]")

@Composable
private fun SwitchRow(title: String, subtitle: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = ShMuted)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun LinkRow(title: String, subtitle: String? = null, danger: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = ShMuted)
        }
        Icon24(Ic.Forward, ShMuted, 16.dp)
    }
}

@Composable
private fun ChipRow(title: String, options: List<Pair<Int, String>>, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (v, l) -> FilterChip(selected = selected == v, onClick = { onSelect(v) }, label = { Text(l, fontSize = 13.sp) }) }
        }
    }
}

@Composable
fun SettingsScreen(ctx: Context, activity: androidx.fragment.app.FragmentActivity, vault: Vault, onBack: () -> Unit, onWiped: () -> Unit, themeMode: Int, onTheme: (Int) -> Unit) {
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val quick = remember { QuickUnlock(ctx) }
    val pw = PasswordVisualTransformation()
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    var lockS by remember { mutableIntStateOf(Prefs.lockSeconds(ctx)) }
    var dndOn by remember { mutableIntStateOf(if (Prefs.dndEnabled(ctx)) 1 else 0) }
    var dndStart by remember { mutableIntStateOf(Prefs.dndStart(ctx)) }
    var dndEnd by remember { mutableIntStateOf(Prefs.dndEnd(ctx)) }
    var bgNode by remember { mutableIntStateOf(if (Prefs.bgNode(ctx)) 1 else 0) }
    var defTtl by remember { mutableIntStateOf(Prefs.defaultTtl(ctx)) }
    var fontLvl by remember { mutableIntStateOf(Prefs.fontLevel(ctx)) }
    var screenSec by remember { mutableStateOf(Prefs.screenSecurity(ctx)) }
    var receipts by remember { mutableStateOf(Prefs.readReceipts(ctx)) }
    var presence by remember { mutableStateOf(Prefs.presenceShare(ctx)) }
    var notifyCap by remember { mutableStateOf(Prefs.notifyCapture(ctx)) }
    var quickTick by remember { mutableIntStateOf(0) }
    var backupPw by remember { mutableStateOf("") }
    var backupPw2 by remember { mutableStateOf("") }
    var pendingPw by remember { mutableStateOf<CharArray?>(null) }
    var backupTick by remember { mutableIntStateOf(0) }
    val torState by NodeService.state.collectAsState()
    val contactList by produceState(emptyList<com.shyfr.app.vault.Contact>(), NodeRuntime.contactsVersion.collectAsState().value) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).contacts() }.getOrDefault(emptyList()) }
    }
    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val pw = pendingPw; pendingPw = null
        if (uri != null && pw != null) scope.launch(Dispatchers.IO) {
            val r = runCatching {
                val key = Session.get() ?: error("locked")
                ctx.contentResolver.openOutputStream(uri)?.use { Backup.export(ctx, key, pw, it) } ?: error("stream")
            }
            pw.fill('\u0000')
            withContext(Dispatchers.Main) {
                if (r.isSuccess) { Prefs.setLastBackup(ctx, System.currentTimeMillis()); backupTick++; toast("Kopia zapisana") } else toast("Nie udało się utworzyć kopii")
            }
        } else pw?.fill('\u0000')
    }

    var extraText by remember { mutableStateOf(Prefs.extraRelays(ctx).joinToString("\n")) }
    var relayText by remember { mutableStateOf(Prefs.relayOnion(ctx) ?: "") }
    var advanced by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) } // quick | duress | bridges | wipeMsgs | wipeAll | purge | trace
    var trace by remember { mutableStateOf<String?>(null) }
    var bridges by remember { mutableStateOf(Prefs.bridgesText(ctx)) }
    var pinNew by remember { mutableStateOf("") }
    var login by remember { mutableStateOf("") }
    var main by remember { mutableStateOf("") }
    var duress by remember { mutableStateOf("") }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0" }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 16.dp)) {
        
        Section("Stan ochrony") {
            val verifiedN = contactList.count { it.verified }
            StatusRow(true, "Szyfrowanie end-to-end", "Włączone dla wszystkich rozmów")
            StatusRow(torState is NodeState.Online, "Połączenie zabezpieczone", if (torState is NodeState.Online) "Aktywne" else "Łączenie…")
            StatusRow(contactList.isEmpty() || verifiedN == contactList.size, "Zweryfikowane kontakty", "$verifiedN z ${contactList.size}")
            StatusRow(quick.pinEnabled() || quick.bioEnabled(), "Szybkie odblokowanie", if (quick.pinEnabled() || quick.bioEnabled()) "Włączone" else "Wyłączone")
            StatusRow(screenSec, "Ochrona ekranu", if (screenSec) "Włączona" else "Wyłączona")
            val lb = remember(backupTick) { Prefs.lastBackup(ctx) }
            StatusRow(lb > 0, "Kopia zapasowa", if (lb > 0) java.text.SimpleDateFormat("d MMM yyyy, HH:mm", java.util.Locale("pl")).format(java.util.Date(lb)) else "Brak. Utrata telefonu = utrata danych")
        }

        Section("Prywatność") {
            SwitchRow("Ochrona ekranu", "Blokuje zrzuty i podgląd aplikacji", screenSec) { v ->
                screenSec = v; Prefs.setScreenSecurity(ctx, v)
                if (v) activity.window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                else activity.window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
            }
            SwitchRow("Potwierdzenia przeczytania", null, receipts) { receipts = it; Prefs.setReadReceipts(ctx, it) }
            SwitchRow("Status aktywności", null, presence) { presence = it; Prefs.setPresenceShare(ctx, it); Presence.kick.trySend(Unit) }
            SwitchRow("Powiadamiaj o zrzutach i eksporcie", null, notifyCap) { notifyCap = it; Prefs.setNotifyCapture(ctx, it) }
            ChipRow("Znikanie wiadomości (nowe kontakty)", listOf(0 to "Wył.", 3600 to "1 godz.", 86400 to "24 godz.", 604800 to "7 dni"), defTtl) { defTtl = it; Prefs.setDefaultTtl(ctx, it) }
        }

        Section("Bezpieczeństwo") {
            ChipRow("Blokada po wyjściu z aplikacji", listOf(0 to "Od razu", 30 to "30 s", 120 to "2 min", 600 to "10 min"), lockS) { lockS = it; Prefs.setLockSeconds(ctx, it) }
            ChipRow("Odbieraj wiadomości w tle po blokadzie", listOf(1 to "Włączone", 0 to "Wyłączone"), bgNode) { bgNode = it; Prefs.setBgNode(ctx, it == 1) }
            LinkRow("Oszczędzanie baterii", "Wyłącz optymalizację dla SHYFR, aby system nie usypiał połączenia") {
                runCatching { ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            LinkRow("Zablokuj całkowicie", "Klucz znika z pamięci, rozmówcy zobaczą Cię jako offline") { com.shyfr.app.session.AppState.lock(ctx, full = true) }
            LinkRow("Szybkie odblokowanie", quickTick.let { listOfNotNull(if (quick.pinEnabled()) "PIN" else null, if (quick.bioEnabled()) "Odcisk palca" else null).joinToString(" • ").ifEmpty { "Wyłączone" } }) { dialog = "quick" }
            LinkRow("Hasło paniki") { dialog = "duress" }
        }

        Section("Powiadomienia") {
            ChipRow("Nie przeszkadzać", listOf(1 to "Włączone", 0 to "Wyłączone"), dndOn) { dndOn = it; Prefs.setDnd(ctx, it == 1, dndStart, dndEnd) }
            ChipRow("Cisza od godziny", listOf(20 to "20:00", 21 to "21:00", 22 to "22:00", 23 to "23:00", 0 to "00:00"), dndStart) { dndStart = it; Prefs.setDnd(ctx, dndOn == 1, dndStart, dndEnd) }
            ChipRow("Cisza do godziny", listOf(5 to "5:00", 6 to "6:00", 7 to "7:00", 8 to "8:00", 9 to "9:00"), dndEnd) { dndEnd = it; Prefs.setDnd(ctx, dndOn == 1, dndStart, dndEnd) }
            Text("W czasie ciszy SHYFR nie pokazuje powiadomień o wiadomościach ani aktywności. Wiadomości nadal dochodzą. Powiadomienia pokazują tylko ogólną informację, bez nadawcy i treści.", fontSize = 12.sp, color = ShMuted, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }

        Section("Wygląd") {
            ChipRow("Motyw", listOf(0 to "Systemowy", 1 to "Ciemny", 2 to "Jasny"), themeMode) { onTheme(it) }
            ChipRow("Rozmiar tekstu", listOf(0 to "Mały", 1 to "Normalny", 2 to "Duży", 3 to "Największy"), fontLvl) { fontLvl = it; Prefs.setFontLevel(ctx, it); UiState.fontLevel.value = it }
        }

        Section("Dane") {
            LinkRow("Utwórz kopię zapasową", Prefs.lastBackup(ctx).let { if (it > 0 && backupTick >= 0) "Ostatnia: " + java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale("pl")).format(java.util.Date(it)) else "Zaszyfrowany plik .shybk" }) { dialog = "backup" }
            LinkRow("Pamięć i załączniki") { dialog = "storage" }
            LinkRow("Usuń wszystkie wiadomości") { dialog = "wipeMsgs" }
            LinkRow("Usuń konto i wszystkie dane", danger = true) { dialog = "wipeAll" }
        }

        Section("Zaawansowane") {
            LinkRow(if (advanced) "Ukryj ustawienia zaawansowane" else "Pokaż ustawienia zaawansowane", "Połączenie, serwery, diagnostyka") { advanced = !advanced }
            if (advanced) {
                LinkRow("Sprawdź połączenie", "Sieć, obwody, osiągalność Twojego adresu") { dialog = "net" }
                LinkRow("Mosty (gdy sieć blokuje połączenie)", if (Prefs.bridges(ctx).isEmpty()) "Wyłączone" else "${Prefs.bridges(ctx).size} skonfigurowane") { dialog = "bridges" }
                LinkRow("Połącz ponownie") { toast("Łączę ponownie…"); NodeService.restart(ctx) }
                LinkRow("Zresetuj dane połączenia") { dialog = "purge" }
                LinkRow("Dodatkowe serwery skrzynki", "Awaria jednego nie zatrzyma wiadomości (obecnie: ${Prefs.extraRelays(ctx).size})") { dialog = "relays2" }
                LinkRow("Serwer społeczności", if (Prefs.usingDefaultRelay(ctx)) "Domyślny serwer SHYFR" else Prefs.relayOnion(ctx)?.let { it.take(12) + "….onion" } ?: "Nie ustawiono") { dialog = "relay" }
            }
        }

        Section("O aplikacji") {
            LinkRow("SHYFR $version") { }
            LinkRow("Raport diagnostyczny") { scope.launch(Dispatchers.IO) { trace = com.shyfr.app.CrashLog.fullReport(ctx) }; dialog = "trace" }
        }
        Spacer(Modifier.height(24.dp))
    }

    when (dialog) {
        "net" -> {
            var info by remember { mutableStateOf("Sprawdzam…") }
            var refresh by remember { mutableIntStateOf(0) }
            LaunchedEffect(refresh) {
                info = kotlinx.coroutines.withContext(Dispatchers.IO) {
                    val t = com.shyfr.app.net.NodeRuntime.transport
                    val st = NodeService.state.value
                    buildString {
                        appendLine("Sieć: " + com.shyfr.app.net.NetMonitor.current(ctx))
                        appendLine("Węzeł: " + when (st) {
                            is com.shyfr.app.net.NodeState.Online -> "online"
                            is com.shyfr.app.net.NodeState.Starting -> st.step
                            is com.shyfr.app.net.NodeState.Failed -> "błąd: " + st.reason
                            else -> "zatrzymany"
                        })
                        appendLine("Obwody Tora: " + if (t == null) "brak transportu" else if (t.isHealthy()) "działają" else "brak")
                        appendLine("Adres onion osiągalny: " + if (com.shyfr.app.net.NodeRuntime.reachable.value) "tak" else "jeszcze nie")
                        appendLine("Skrzynka na przekaźniku: " + if (com.shyfr.app.net.Mailbox.enabled(ctx)) "włączona, przekaźników: ${Prefs.mailboxRelays(ctx).size} (rozmówca musi mieć co najmniej jeden wspólny)" else "wyłączona (wpisz przekaźnik w Społecznościach)")
                        if (com.shyfr.app.net.NetMonitor.changedAt > 0) appendLine("Ostatnia zmiana sieci: " + fmtTime(com.shyfr.app.net.NetMonitor.changedAt))
                    }.trim()
                }
            }
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Diagnoza sieci") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(info, fontSize = 14.sp)
                        Text("Rozmowa działa między różnymi sieciami (Wi-Fi, komórkowa) przez Tora, bez wspólnego Wi-Fi. Gdy wiadomości nie dochodzą, zrób „Odśwież obwody”, a potem „Sprawdź mój adres”. Jeśli sieć blokuje Tora, dodaj mosty (Mosty Tor).", fontSize = 12.sp, color = ShMuted)
                    }
                },
                confirmButton = {
                    Row {
                        TextButton(onClick = {
                            scope.launch {
                                val ok = kotlinx.coroutines.withContext(Dispatchers.IO) { com.shyfr.app.net.NodeRuntime.transport?.newNetwork() == true }
                                toast(if (ok) "Odświeżono obwody Tora" else "Nie udało się odświeżyć")
                                refresh++
                            }
                        }) { Text("Odśwież obwody") }
                        TextButton(onClick = {
                            scope.launch {
                                val t = com.shyfr.app.net.NodeRuntime.transport; val o = com.shyfr.app.net.NodeRuntime.onion
                                if (t == null || o == null) { toast("Węzeł nie jest gotowy"); return@launch }
                                val t0 = System.currentTimeMillis()
                                val err = kotlinx.coroutines.withContext(Dispatchers.IO) { try { t.connect(o, NodeService.VIRTUAL_PORT).use { }; null } catch (e: Exception) { e.javaClass.simpleName } }
                                toast(if (err == null) "Adres osiągalny (${(System.currentTimeMillis() - t0) / 1000} s)" else "Adres nieosiągalny ($err)")
                                refresh++
                            }
                        }) { Text("Sprawdź mój adres") }
                    }
                },
                dismissButton = { TextButton(onClick = { dialog = null }) { Text("Zamknij") } }
            )
        }
        "relays2" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Dodatkowe przekaźniki skrzynki") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Do 2 dodatkowych adresów onion (po jednym w linii). Zaszyfrowane wiadomości są zapisywane we wszystkich przekaźnikach i odbierane ze wszystkich, więc awaria jednego ich nie blokuje. Rozmówca musi mieć co najmniej jeden wspólny przekaźnik z Tobą.", fontSize = 12.sp, color = ShMuted)
                    OutlinedTextField(extraText, { extraText = it }, label = { Text("xxxxxxxx….onion") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val parsed = extraText.split("\n", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                    val valid = parsed.mapNotNull { com.shyfr.app.feed.PublicProto.normalizeOnion(it) }.distinct()
                    if (valid.size != parsed.size) toast("Część adresów jest nieprawidłowa (wymagany onion v3).")
                    else if (valid.size > 2) toast("Maksymalnie 2 dodatkowe adresy.")
                    else { Prefs.setExtraRelays(ctx, valid); extraText = valid.joinToString("\n"); dialog = null; toast("Zapisano") }
                }) { Text("Zapisz") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Anuluj") } }
        )
        "relay" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Przekaźnik publiczny") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Adres onion v3 przekaźnika (relay/shyfr_relay.py na Termux lub serwerze). Treści społeczności widzi operator przekaźnika. Przekaźnik służy też jako skrzynka na zaszyfrowane wiadomości prywatne, gdy druga osoba jest offline lub w złej sieci: widzi wtedy tylko szyfrogramy, rozmiar i czas. Oba telefony muszą mieć ten sam adres.", fontSize = 12.sp, color = ShMuted)
                    OutlinedTextField(relayText, { relayText = it }, label = { Text("xxxxxxxx….onion") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (Prefs.defaultRelay() != null && !Prefs.usingDefaultRelay(ctx)) TextButton(onClick = { Prefs.resetRelayToDefault(ctx); relayText = Prefs.relayOnion(ctx) ?: ""; dialog = null; toast("Przywrócono domyślny przekaźnik") }) { Text("Użyj domyślnego przekaźnika SHYFR") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = relayText.trim()
                    if (t.isEmpty()) { Prefs.setRelayOnion(ctx, null); dialog = null; toast("Wyłączono przekaźnik") }
                    else {
                        val n = com.shyfr.app.feed.PublicProto.normalizeOnion(t)
                        if (n == null) toast("To nie jest adres onion v3 (56 znaków + .onion).")
                        else { Prefs.setRelayOnion(ctx, n); relayText = n; toast("Zapisano. Sprawdzam połączenie…")
                            scope.launch { try { toast(com.shyfr.app.feed.PublicRepo(ctx).test()) } catch (e: Exception) { toast("Brak połączenia: " + (e.message ?: "")) } } }
                    }
                }) { Text("Zapisz i testuj") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Anuluj") } }
        )
        "quick" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Szybkie odblokowanie") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(pinNew, { if (it.length <= 12 && it.all(Char::isDigit)) pinNew = it },
                        label = { Text("Nowy PIN (6–12 cyfr)") }, singleLine = true, visualTransformation = pw,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
                    Button(enabled = Session.get() != null && pinNew.length in 6..12, modifier = Modifier.fillMaxWidth(), onClick = {
                        scope.launch(Dispatchers.Default) {
                            val master = Session.get()?.copyOf() ?: return@launch
                            val chars = pinNew.toCharArray()
                            try {
                                quick.enablePin(master, chars)
                                withContext(Dispatchers.Main) { pinNew = ""; quickTick++; toast("PIN włączony") }
                            } catch (e: Throwable) {
                                withContext(Dispatchers.Main) { toast("Nie udało się włączyć PIN-u") }
                            } finally { master.fill(0); chars.fill('\u0000') }
                        }
                    }) { Text("Włącz PIN") }
                    OutlinedButton(enabled = Session.get() != null, modifier = Modifier.fillMaxWidth(), onClick = {
                        scope.launch(Dispatchers.Default) {
                            if (!Bio.available(ctx)) { withContext(Dispatchers.Main) { toast("Biometria niedostępna") }; return@launch }
                            val master = Session.get()?.copyOf() ?: return@launch
                            val cipher = try { quick.bioEnableCipher() } catch (e: Throwable) {
                                master.fill(0); withContext(Dispatchers.Main) { toast("Nie udało się przygotować biometrii") }; return@launch
                            }
                            withContext(Dispatchers.Main) {
                                Bio.prompt(activity, cipher, "Włącz odblokowanie odciskiem palca",
                                    onOk = { c ->
                                        try { quick.finishBioEnable(c, master); toast("Odcisk palca włączony"); quickTick++ }
                                        catch (e: Throwable) { toast("Błąd biometrii"); quick.disableBio() }
                                        finally { master.fill(0) }
                                    },
                                    onFail = { m -> if (m.isNotBlank()) toast(m); master.fill(0); quick.disableBio() })
                            }
                        }
                    }) { Text("Włącz odcisk palca") }
                    TextButton(onClick = { quick.disableAll(); quickTick++; toast("Wyłączone") }) { Text("Wyłącz szybkie odblokowanie") }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Gotowe") } }
        )
        "duress" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Hasło paniki") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Wpisane zamiast hasła głównego po cichu usuwa wszystkie dane.", fontSize = 13.sp, color = ShMuted)
                    OutlinedTextField(login, { login = it }, label = { Text("Login") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(main, { main = it }, label = { Text("Hasło główne") }, singleLine = true, visualTransformation = pw, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(duress, { duress = it }, label = { Text("Hasło paniki") }, singleLine = true, visualTransformation = pw, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = login.isNotBlank() && main.isNotBlank() && duress.isNotBlank(), onClick = {
                    scope.launch(Dispatchers.Default) {
                        val r = vault.setDuress(login, main.toCharArray(), duress.toCharArray())
                        withContext(Dispatchers.Main) {
                            toast(r ?: "Zapisano")
                            if (r == null) { main = ""; duress = ""; dialog = null }
                        }
                    }
                }) { Text("Zapisz") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Anuluj") } }
        )
        "bridges" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Mosty Tor") },
            text = {
                Column {
                    Text("Jeden w linii: IP:port [odcisk]", fontSize = 13.sp, color = ShMuted)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(bridges, { bridges = it }, minLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val (lines, error) = Prefs.parseBridges(bridges)
                    if (error != null) toast(error)
                    else { Prefs.setBridges(ctx, lines); dialog = null; toast("Zapisano, restartuję…"); NodeService.restart(ctx) }
                }) { Text("Zapisz i zrestartuj") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Anuluj") } }
        )
        "purge" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Wyczyścić dane Tora?") },
            text = { Text("Tor pobierze listę węzłów od nowa i zostanie zrestartowany.") },
            confirmButton = { TextButton(onClick = { dialog = null; toast("Czyszczę…"); NodeService.restart(ctx, purge = true) }) { Text("Wyczyść") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Anuluj") } }
        )
        "wipeMsgs" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Usunąć wszystkie wiadomości?") },
            text = { Text("Kontakty zostają. Tej operacji nie można cofnąć.") },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    scope.launch(Dispatchers.IO) {
                        runCatching { Store(ctx).deleteAllMessages() }
                        NodeRuntime.messagesVersion.update { it + 1 }
                        withContext(Dispatchers.Main) { toast("Usunięto") }
                    }
                }) { Text("Usuń", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Anuluj") } }
        )
        "wipeAll" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Usunąć konto?") },
            text = { Text("Konto, kontakty i wiadomości zostaną bezpowrotnie usunięte z tego telefonu.") },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    scope.launch(Dispatchers.IO) {
                        Session.clear(); NodeService.stop(ctx); vault.wipe()
                        withContext(Dispatchers.Main) { onWiped() }
                    }
                }) { Text("Usuń", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Anuluj") } }
        )
        "backup" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Kopia zapasowa") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Zapisuje kontakty, rozmowy i klucze w pliku zaszyfrowanym osobnym hasłem. Bez tego hasła pliku nie da się otworzyć, a hasła nie da się odzyskać.", fontSize = 13.sp, color = ShMuted)
                    OutlinedTextField(backupPw, { backupPw = it }, label = { Text("Hasło kopii (min. 10 znaków)") }, singleLine = true, visualTransformation = pw, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(backupPw2, { backupPw2 = it }, label = { Text("Powtórz hasło") }, singleLine = true, visualTransformation = pw, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = backupPw.length >= 10 && backupPw == backupPw2, onClick = {
                    pendingPw = backupPw.toCharArray(); backupPw = ""; backupPw2 = ""; dialog = null
                    createBackup.launch("shyfr-" + java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date()) + ".shybk")
                }) { Text("Zapisz plik") }
            },
            dismissButton = { TextButton(onClick = { dialog = null; backupPw = ""; backupPw2 = "" }) { Text("Anuluj") } }
        )
        "storage" -> {
            val st by produceState(0 to 0L) { value = withContext(Dispatchers.IO) { runCatching { Store(ctx).attachmentStats() }.getOrDefault(0 to 0L) } }
            val dbSize = remember { ctx.getDatabasePath("shyfr.db").length() }
            fun mb(b: Long) = String.format(java.util.Locale.getDefault(), "%.1f MB", b / 1048576.0)
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Pamięć") },
                text = { Text("Baza danych: ${mb(dbSize)}\nZałączniki: ${st.first} (${mb(st.second)})") },
                confirmButton = {
                    TextButton(enabled = st.first > 0, onClick = {
                        dialog = null
                        scope.launch(Dispatchers.IO) { runCatching { Store(ctx).purgeAttachments() }; NodeRuntime.messagesVersion.update { it + 1 }; withContext(Dispatchers.Main) { toast("Załączniki usunięte") } }
                    }) { Text("Usuń załączniki", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { dialog = null }) { Text("Zamknij") } }
            )
        }
        "trace" -> AlertDialog(
            onDismissRequest = { dialog = null; trace = null },
            title = { Text("Raport diagnostyczny") },
            text = {
                Column {
                    Text("Adresy i identyfikatory są zamaskowane. Raport zostaje na telefonie, dopóki sam go nie skopiujesz.", fontSize = 12.sp, color = ShMuted)
                    Spacer(Modifier.height(8.dp))
                    SelectionContainer(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) { Text(trace?.let { redact(it) } ?: "Wczytywanie…", fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { trace?.let { clip.setText(AnnotatedString(redact(it))) } }) { Text("Kopiuj") } },
            dismissButton = { TextButton(onClick = { dialog = null; trace = null }) { Text("Zamknij") } }
        )
    }
}
