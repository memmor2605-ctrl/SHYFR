package com.shyfr.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.crypto.Keys
import com.shyfr.app.net.Messenger
import com.shyfr.app.net.NodeRuntime
import com.shyfr.app.vault.Contact
import com.shyfr.app.vault.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.SecureRandom

private const val MAX_MEMBERS = 16 // razem z Tobą
private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

/** Tworzenie grupy: wybierasz kontakty; grupa pojawi się u nich po pierwszej wysłanej wiadomości. */
@Composable
fun CreateGroupDialog(ctx: Context, onDismiss: () -> Unit, onCreated: (String) -> Unit) {
    val contacts by produceState(emptyList<Contact>()) {
        value = withContext(Dispatchers.IO) { runCatching { Store(ctx).contacts() }.getOrDefault(emptyList()) }
    }
    var name by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf(setOf<Long>()) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nowa grupa") },
        text = {
            Column {
                OutlinedTextField(name, { name = it.take(40) }, label = { Text("Nazwa grupy") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Text("Członkowie (max ${MAX_MEMBERS - 1}). Każdy dostaje wiadomości osobnym, szyfrowanym kanałem — ale odpowie tylko tym członkom, których sam ma w kontaktach.",
                    fontSize = 12.sp, color = ShMuted)
                Spacer(Modifier.height(6.dp))
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    if (contacts.isEmpty()) Text("Najpierw dodaj znajomych.", color = ShMuted)
                    contacts.forEach { c ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = c.id in picked, onCheckedChange = { on ->
                                picked = if (on && picked.size < MAX_MEMBERS - 1) picked + c.id else picked - c.id
                            })
                            Text(c.label, maxLines = 1)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && picked.isNotEmpty(), onClick = {
                scope.launch(Dispatchers.IO) {
                    runCatching {
                        val st = Store(ctx)
                        val (_, myPub) = st.keys()
                        val sids = st.contacts().filter { it.id in picked }.map { hex(Keys.sid(it.pubkey)) } + hex(Keys.sid(myPub))
                        val gid = hex(ByteArray(8).also { SecureRandom().nextBytes(it) })
                        st.createGroup(gid, name.trim(), sids.distinct())
                        NodeRuntime.contactsVersion.update { it + 1 }
                        withContext(Dispatchers.Main) { onCreated(gid) }
                    }
                }
            }) { Text("Utwórz") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Anuluj") } }
    )
}

@Composable
fun GroupChatScreen(ctx: Context, gid: String, onBack: () -> Unit) {
    val ver by NodeRuntime.messagesVersion.collectAsState()
    val cver by NodeRuntime.contactsVersion.collectAsState()
    val data by produceState<Triple<com.shyfr.app.vault.Group?, List<com.shyfr.app.vault.GMsg>, Map<String, String>>>(
        Triple(null, emptyList(), emptyMap()), ver, cver) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val st = Store(ctx)
                st.markGroupRead(gid)
                val names = st.contacts().associate { hex(Keys.sid(it.pubkey)) to it.label }
                Triple(st.group(gid), st.groupMessages(gid), names)
            }.getOrDefault(Triple(null, emptyList(), emptyMap()))
        }
    }
    val (group, msgs, names) = data
    var text by remember { mutableStateOf("") }
    var info by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val isNotes = gid == com.shyfr.app.vault.NOTES_GID
    fun who(sid: String) = names[sid] ?: "Nieznany (${sid.take(4)})"

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().background(ShSurface).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
            IconAvatar(Ic.Group, 40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(group?.name ?: "Grupa", fontSize = 17.sp, maxLines = 1)
                Text(if (isNotes) "Tylko Ty — nic nie wychodzi z telefonu" else "${group?.members?.size ?: 0} członków", fontSize = 12.sp, color = ShMuted)
            }
            TextButton(onClick = { info = !info }) { Text(if (info) "Zamknij" else "Info") }
        }
        if (info && group != null) Column(Modifier.fillMaxWidth().background(ShSurfaceHi).padding(14.dp)) {
            if (!isNotes) Text("Członkowie", fontSize = 12.sp, color = ShMuted)
            if (!isNotes) group.members.forEach { sid ->
                val reachable = names.containsKey(sid)
                Text("• " + if (reachable) who(sid) else "Nieznany (${sid.take(4)}) — nie jest Twoim kontaktem", fontSize = 14.sp,
                    color = if (reachable) MaterialTheme.colorScheme.onBackground else ShMuted)
            }
            if (!isNotes) Spacer(Modifier.height(6.dp))
            if (!isNotes) Text("Nie jest to czat z jednym wspólnym kluczem: wiadomość trafia osobnym kanałem do każdego członka z Twoich kontaktów.",
                fontSize = 12.sp, color = ShMuted)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = group.muted, onCheckedChange = { v ->
                    scope.launch(Dispatchers.IO) { Store(ctx).setGroupMuted(gid, v); NodeRuntime.contactsVersion.update { it + 1 } }
                })
                Spacer(Modifier.width(8.dp)); Text("Wycisz powiadomienia")
            }
            TextButton(onClick = { confirmDelete = true }) { Text("Usuń grupę z tego telefonu", color = MaterialTheme.colorScheme.error) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), reverseLayout = true) {
            items(msgs.reversed(), key = { it.id }) { m ->
                val mine = m.sender.isEmpty()
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Column(Modifier.widthIn(max = 290.dp).background(if (mine) ShBubbleOut else ShSurfaceHi,
                        RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                        if (!mine) Text(who(m.sender), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        Text(richText(m.body, MaterialTheme.colorScheme.primary, ShSurface), color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp)
                        Text(fmtTime(m.ts), fontSize = 10.sp, color = ShMuted)
                    }
                }
            }
        }
        note?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f), placeholder = { Text(if (isNotes) "Zapisz notatkę" else "Wiadomość do grupy") },
                shape = RoundedCornerShape(24.dp), maxLines = 4)
            Spacer(Modifier.width(8.dp))
            Button(enabled = text.isNotBlank(), shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(54.dp), onClick = {
                val t = text
                if (isNotes) {
                    scope.launch(Dispatchers.IO) {
                        runCatching { Store(ctx).addOutgoingGroupMsg(gid, hex(ByteArray(8).also { SecureRandom().nextBytes(it) }), t) }
                        NodeRuntime.messagesVersion.update { it + 1 }
                        text = ""
                    }
                    return@Button
                }
                scope.launch(Dispatchers.IO) {
                    val r = runCatching { Messenger(ctx).sendGroupText(gid, t) }.getOrNull()
                    note = when {
                        r == null -> "Nie udało się wysłać wiadomości do grupy."
                        r.second == 0 -> "Żaden członek grupy nie jest Twoim kontaktem."
                        r.first == 0 -> "Szyfrowanie z członkami jeszcze się ustala. Spróbuj, gdy będą online."
                        r.first < r.second -> "Wysłano do ${r.first} z ${r.second} członków — z pozostałymi szyfrowanie jeszcze się ustala."
                        else -> null
                    }
                    if (r != null && r.first > 0) text = ""
                }
            }) { Icon24(Ic.Send, androidx.compose.material3.LocalContentColor.current, 20.dp) }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Usunąć grupę?") },
        text = { Text("Grupa i jej wiadomości znikną z tego telefonu. Inni członkowie zachowają swoje kopie. Nowa wiadomość od członka utworzy grupę ponownie.") },
        confirmButton = { TextButton(onClick = {
            confirmDelete = false
            scope.launch(Dispatchers.IO) { runCatching { Store(ctx).deleteGroup(gid) }; NodeRuntime.contactsVersion.update { it + 1 }; withContext(Dispatchers.Main) { onBack() } }
        }) { Text("Usuń", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Anuluj") } }
    )
}
