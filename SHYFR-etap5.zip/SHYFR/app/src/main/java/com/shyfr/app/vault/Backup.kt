package com.shyfr.app.vault

import android.content.Context
import com.shyfr.app.crypto.Kdf
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Zaszyfrowana kopia zapasowa (.shybk), niezależna od sprzętowego klucza telefonu.
 *
 * Plik: "SHYBK1" | sól(16) | prefiks IV(4) | fragmenty [długość(4, bit31 = ostatni) | szyfrogram AES-256-GCM].
 * Klucz = Argon2id(hasło kopii, sól). Każdy fragment (64 KB) jest uwierzytelniany osobno i z numerem,
 * więc manipulacja, obcięcie lub zamiana kolejności są wykrywane, a restore nie wymaga ładowania całości do pamięci.
 * Zawartość: wszystkie tabele bazy (tożsamość i klucz onion, kontakty, sesje, wiadomości, załączniki, grupy, profil, członkostwa i zakładki społeczności). Klucze społeczności nie są w kopii: odtwarzają się z klucza konta, więc przywracaj kopię na to samo konto (ten sam login i hasło).
 */
object Backup {
    private val MAGIC = "SHYBK1".toByteArray()
    private const val CHUNK = 64 * 1024
    private val TABLES = listOf("identity", "profile", "contacts", "sessions", "messages", "reactions",
        "attachments", "att_chunks", "chat_groups", "group_msgs", "seen",
        "pub_membership", "pub_bookmarks", "pub_requests", "pub_reacted")

    private fun key(password: CharArray, salt: ByteArray) = SecretKeySpec(Kdf.derive("shyfr-backup", password, salt), "AES")
    private fun iv(prefix: ByteArray, counter: Long) = prefix + ByteArray(8) { i -> (counter ushr (56 - 8 * i)).toByte() }
    private fun cipher(mode: Int, k: SecretKeySpec, prefix: ByteArray, counter: Long, last: Boolean): Cipher =
        Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(mode, k, GCMParameterSpec(128, iv(prefix, counter)))
            updateAAD(MAGIC); updateAAD(byteArrayOf(if (last) 1 else 0))
        }

    private class EncOut(val out: OutputStream, val k: SecretKeySpec, val prefix: ByteArray) : OutputStream() {
        private val buf = ByteArrayOutputStream(CHUNK)
        private var n = 0L
        override fun write(b: Int) { buf.write(b); if (buf.size() >= CHUNK) flushChunk(false) }
        override fun write(b: ByteArray, off: Int, len: Int) {
            var o = off; var l = len
            while (l > 0) { val take = minOf(l, CHUNK - buf.size()); buf.write(b, o, take); o += take; l -= take; if (buf.size() >= CHUNK) flushChunk(false) }
        }
        private fun flushChunk(last: Boolean) {
            val ct = cipher(Cipher.ENCRYPT_MODE, k, prefix, n++, last).doFinal(buf.toByteArray()); buf.reset()
            DataOutputStream(out).apply { writeInt(ct.size or (if (last) Int.MIN_VALUE else 0)); write(ct); flush() }
        }
        override fun close() { flushChunk(true); out.flush() }
    }

    private class DecIn(val inp: DataInputStream, val k: SecretKeySpec, val prefix: ByteArray) : InputStream() {
        private var cur = ByteArray(0); private var pos = 0; private var n = 0L; private var done = false
        private fun fill(): Boolean {
            while (pos >= cur.size) {
                if (done) return false
                val h = try { inp.readInt() } catch (e: EOFException) { throw IllegalArgumentException("Plik kopii jest uszkodzony lub niepełny.") }
                val last = h < 0; val len = h and Int.MAX_VALUE
                if (len < 16 || len > CHUNK + 64) throw IllegalArgumentException("Plik kopii jest uszkodzony.")
                val ct = ByteArray(len).also { inp.readFully(it) }
                cur = try { cipher(Cipher.DECRYPT_MODE, k, prefix, n++, last).doFinal(ct) }
                catch (e: Exception) { throw IllegalArgumentException("Błędne hasło kopii lub uszkodzony plik.") }
                pos = 0; done = last
            }
            return true
        }
        override fun read(): Int = if (fill()) cur[pos++].toInt() and 0xff else -1
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            if (!fill()) return -1
            val t = minOf(len, cur.size - pos); System.arraycopy(cur, pos, b, off, t); pos += t; return t
        }
    }

    /** Zapisuje kopię do [out]. Wymaga otwartej bazy (odblokowane konto). */
    fun export(ctx: Context, master: ByteArray, password: CharArray, out: OutputStream) {
        val rng = SecureRandom()
        val salt = ByteArray(16).also(rng::nextBytes); val prefix = ByteArray(4).also(rng::nextBytes)
        val k = key(password, salt)
        out.write(MAGIC); out.write(salt); out.write(prefix)
        val db = Db.open(ctx, master)
        try {
            DataOutputStream(EncOut(out, k, prefix)).use { o ->
                o.writeUTF("SHYBK-DATA"); o.writeInt(1); o.writeLong(System.currentTimeMillis())
                for (t in TABLES) {
                    db.rawQuery("SELECT * FROM $t").use { c ->
                        val cols = c.columnNames
                        o.writeUTF(t); o.writeInt(cols.size); cols.forEach { o.writeUTF(it) }
                        while (c.moveToNext()) {
                            o.writeByte(1)
                            for (i in cols.indices) when (c.getType(i)) {
                                1 -> { o.writeByte(1); o.writeLong(c.getLong(i)) }
                                2 -> { o.writeByte(4); o.writeDouble(c.getDouble(i)) }
                                3 -> { o.writeByte(2); o.writeUTF(c.getString(i)) }
                                4 -> { val b = c.getBlob(i); o.writeByte(3); o.writeInt(b.size); o.write(b) }
                                else -> o.writeByte(0)
                            }
                        }
                        o.writeByte(0)
                    }
                }
                o.writeUTF("END")
            }
        } finally { db.close() }
    }

    /**
     * Wczytuje kopię do świeżo utworzonej bazy. Cały import jest jedną transakcją: błąd = brak zmian.
     * Kolejka wysyłki jest pomijana (ramki były zaszyfrowane stanem sesji ze starego telefonu).
     */
    fun import(ctx: Context, master: ByteArray, password: CharArray, input: InputStream) {
        val head = DataInputStream(input)
        val magic = ByteArray(MAGIC.size).also { head.readFully(it) }
        require(magic.contentEquals(MAGIC)) { "To nie jest plik kopii SHYFR." }
        val salt = ByteArray(16).also { head.readFully(it) }; val prefix = ByteArray(4).also { head.readFully(it) }
        val i = DataInputStream(DecIn(head, key(password, salt), prefix))
        require(i.readUTF() == "SHYBK-DATA") { "Plik kopii jest uszkodzony." }
        require(i.readInt() == 1) { "Nieobsługiwana wersja kopii." }
        i.readLong()
        val db = Db.open(ctx, master)
        try {
            db.beginTransaction()
            try {
                while (true) {
                    val name = i.readUTF()
                    if (name == "END") break
                    require(name in TABLES) { "Plik kopii jest uszkodzony." }
                    val cols = List(i.readInt()) { i.readUTF() }
                    val have = HashSet<String>()
                    db.rawQuery("PRAGMA table_info($name)").use { c -> val ni = c.getColumnIndex("name"); while (c.moveToNext()) have.add(c.getString(ni)) }
                    db.execSQL("DELETE FROM $name")
                    val use = cols.map { it in have }
                    val sql = "INSERT OR REPLACE INTO $name(" + cols.filterIndexed { x, _ -> use[x] }.joinToString(",") +
                        ") VALUES(" + cols.filterIndexed { x, _ -> use[x] }.joinToString(",") { "?" } + ")"
                    while (i.readUnsignedByte() == 1) {
                        val vals = ArrayList<Any?>()
                        for (x in cols.indices) {
                            val v: Any? = when (i.readUnsignedByte()) {
                                1 -> i.readLong(); 2 -> i.readUTF(); 3 -> ByteArray(i.readInt()).also { i.readFully(it) }; 4 -> i.readDouble(); else -> null
                            }
                            if (use[x]) vals.add(v)
                        }
                        db.execSQL(sql, vals.toTypedArray())
                    }
                }
                db.execSQL("DELETE FROM outbox")
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        } finally { db.close() }
    }
}
