package com.shyfr.app.vault

import android.content.Context
import com.shyfr.app.crypto.Kdf
import com.shyfr.app.crypto.Keys
import com.shyfr.app.crypto.KeystoreWrap
import java.io.File
import java.security.SecureRandom

/**
 * Konto lokalne SHYFR. Nic nie opuszcza telefonu.
 *
 * masterKey (losowe 256 b) -> otwiera bazę SQLCipher.
 * masterKey jest owinięty dwiema warstwami:
 *   1) kluczem z Argon2id(login+hasło)   -> trzeba znać hasło
 *   2) kluczem sprzętowym (Keystore)     -> trzeba mieć to urządzenie
 * Prawdziwe "wyczyszczenie" to zniszczenie klucza sprzętowego: bez niego baza jest tylko szumem.
 */
class Vault(private val ctx: Context) {
    private val file get() = File(ctx.filesDir, "vault.bin")
    private val duressFile get() = File(ctx.filesDir, "duress.bin")
    private val dbFile get() = ctx.getDatabasePath("shyfr.db")
    private val prefs get() = ctx.getSharedPreferences("shyfr_guard", Context.MODE_PRIVATE)

    sealed interface Result {
        data class Ok(val masterKey: ByteArray) : Result
        data class Wrong(val attemptsLeft: Int) : Result
        data object Wiped : Result
        data object NoAccount : Result
    }

    fun hasAccount() = file.exists()

    /** Zapis atomowy: przerwanie procesu w trakcie nie zostawia uszkodzonego pliku sejfu. */
    private fun writeAtomic(f: File, bytes: ByteArray) {
        val af = android.util.AtomicFile(f)
        val os = af.startWrite()
        try { os.write(bytes); af.finishWrite(os) } catch (e: Throwable) { af.failWrite(os); throw e }
    }

    fun create(login: String, password: CharArray): ByteArray = createWithMaster(login, password, ByteArray(32).also(SecureRandom()::nextBytes))

    /** Zakłada sejf z podanym kluczem głównym (odzyskanie konta na nowym telefonie). Zwraca ten sam klucz. */
    fun createWithMaster(login: String, password: CharArray, master: ByteArray): ByteArray {
        require(!hasAccount()) { "Konto już istnieje" }
        require(master.size == 32) { "Zły klucz główny" }
        val rng = SecureRandom()
        val salt = ByteArray(16).also(rng::nextBytes)
        val pwKey = Kdf.derive(login, password, salt)
        try {
            val inner = KeystoreWrap.seal(pwKey, master, aad = "shyfr-v1".toByteArray())
            val outer = KeystoreWrap.sealHardware(inner)
            writeAtomic(file, byteArrayOf(1) + salt + outer)
            prefs.edit().putInt("fails", 0).apply()
        } finally { pwKey.fill(0) }
        return master
    }

    fun unlock(login: String, password: CharArray): Result {
        if (!hasAccount()) return Result.NoAccount
        // Hasło paniki: wygląda jak zwykła pomyłka, ale po cichu niszczy dane.
        if (matchesDuress(password)) { wipe(); return Result.Wrong(MAX_FAILS - 1) }
        val raw = file.readBytes()
        val salt = raw.copyOfRange(1, 17)
        val outer = raw.copyOfRange(17, raw.size)
        val pwKey = Kdf.derive(login, password, salt)
        return try {
            val inner = KeystoreWrap.openHardware(outer)
            val master = KeystoreWrap.open(pwKey, inner, "shyfr-v1".toByteArray())
            prefs.edit().putInt("fails", 0).apply()
            Result.Ok(master)
        } catch (e: Exception) {
            val fails = prefs.getInt("fails", 0) + 1
            prefs.edit().putInt("fails", fails).apply()
            if (fails >= MAX_FAILS) { wipe(); Result.Wiped }
            else Result.Wrong(MAX_FAILS - fails)
        } finally { pwKey.fill(0) }
    }

    /** Ustawia hasło paniki. Wymaga potwierdzenia loginem i hasłem głównym. Zwraca błąd lub null. */
    fun setDuress(login: String, main: CharArray, duress: CharArray): String? {
        if (duress.size < 10) return "Hasło paniki: min. 10 znaków."
        if (String(duress) == String(main)) return "Hasło paniki musi różnić się od głównego."
        when (val r = unlock(login, main)) {
            is Result.Ok -> r.masterKey.fill(0)
            else -> return "Błędny login lub hasło główne."
        }
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val h = Kdf.derive("duress", duress, salt)
        writeAtomic(duressFile, salt + h)
        h.fill(0)
        return null
    }

    private fun matchesDuress(pw: CharArray): Boolean {
        if (!duressFile.exists()) return false
        val raw = duressFile.readBytes()
        val h = Kdf.derive("duress", pw, raw.copyOfRange(0, 16))
        return Keys.equalsCt(h, raw.copyOfRange(16, 48)).also { h.fill(0) }
    }

    /** Tryb paniki / limit prób: niszczy klucze, bazę, dane Tora i ustawienia. */
    fun wipe() {
        KeystoreWrap.deleteHardwareKey()
        runCatching { QuickUnlock(ctx).disableAll() }
        file.delete(); duressFile.delete()
        dbFile.delete()
        File(dbFile.path + "-wal").delete(); File(dbFile.path + "-shm").delete(); File(dbFile.path + "-journal").delete()
        runCatching {
            ctx.dataDir.listFiles()?.filter { it.isDirectory && it.name.startsWith("app_") }?.forEach { it.deleteRecursively() }
            ctx.filesDir.listFiles()?.forEach { it.deleteRecursively() }
            ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        }
        prefs.edit().clear().apply()
        ctx.getSharedPreferences("shyfr_settings", Context.MODE_PRIVATE).edit().clear().apply()
    }

    companion object { const val MAX_FAILS = 10 }
}
