package com.shyfr.app.social

import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Hkdf
import java.security.SecureRandom

enum class IdentityKind(val code: String, val label: String) {
    PUBLIC("pub", "Publiczna"), PRIVATE("prv", "Prywatna"), ANON("anon", "Anonimowa");
    companion object { fun from(code: String?) = entries.firstOrNull { it.code == code } ?: PUBLIC }
}

/**
 * Klucze tożsamości społecznościowych. Każda tożsamość (rodzaj + numer) ma OSOBNĄ parę kluczy:
 * podpisu Ed25519 oraz zgody X25519 (do treści z ograniczonym dostępem). Klucze wyprowadza HKDF-SHA256
 * z klucza głównego sejfu z oddzielną etykietą domeny, więc: (1) nie są zapisywane w jawnej postaci,
 * (2) odtwarzają się po przywróceniu konta, (3) bez klucza głównego nie da się powiązać dwóch tożsamości.
 * Uwaga: kto zna klucz główny (czyli Ty, na swoim telefonie), potrafi wyprowadzić wszystkie. To nie jest
 * anonimowość wobec właściciela konta, tylko brak publicznego powiązania między tożsamościami.
 */
object IdentityKeys {
    private fun hkdf(master: ByteArray, domain: String, kind: IdentityKind, idx: Int): ByteArray =
        Hkdf.computeHkdf("HmacSha256", master, ByteArray(0), "$domain|${kind.code}|$idx".toByteArray(Charsets.UTF_8), 32)

    fun signing(master: ByteArray, kind: IdentityKind, idx: Int): Ed25519Sign.KeyPair =
        Ed25519Sign.KeyPair.newKeyPairFromSeed(hkdf(master, "shyfr-social-sign-v1", kind, idx))

    /** Prywatny klucz X25519 tożsamości (szyfrowanie treści dla zatwierdzonych obserwujących, etap 3). */
    fun agreementPriv(master: ByteArray, kind: IdentityKind, idx: Int): ByteArray =
        hkdf(master, "shyfr-social-agree-v1", kind, idx)

    fun publicHex(master: ByteArray, kind: IdentityKind, idx: Int): String =
        signing(master, kind, idx).publicKey.joinToString("") { "%02x".format(it) }
}

object Pseudonym {
    private val words = listOf("Cień", "Szyfr", "Mgła", "Wilk", "Sokół", "Kruk", "Lis", "Jeż", "Echo", "Głaz", "Wiatr", "Zimorodek")
    private val rnd = SecureRandom()
    fun random(): String = words[rnd.nextInt(words.size)] + "-" + (1000 + rnd.nextInt(9000))
}
