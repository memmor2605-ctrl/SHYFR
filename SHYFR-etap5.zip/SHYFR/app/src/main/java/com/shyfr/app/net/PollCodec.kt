package com.shyfr.app.net

/**
 * Ankieta w rozmowie prywatnej to zwykła wiadomość tekstowa (więc działa przez istniejące szyfrowanie i skrzynkę):
 * znacznik „📊” + znak zerowej szerokości, pytanie, a w kolejnych liniach opcje. Starsze wersje aplikacji pokażą ją jako zwykły tekst.
 * Głosy to osobne, szyfrowane ramki (KIND_VOTE): mid ankiety + numer opcji.
 */
object PollCodec {
    const val MARK = "📊\u200B"
    const val MAX_OPTIONS = 6

    fun encode(question: String, options: List<String>): String? {
        val q = question.trim().replace("\n", " ")
        val opts = options.map { it.trim().replace("\n", " ") }.filter { it.isNotEmpty() }
        if (q.isEmpty() || q.length > 200 || opts.size < 2 || opts.size > MAX_OPTIONS || opts.any { it.length > 60 } || opts.toSet().size != opts.size) return null
        return MARK + q + "\n" + opts.joinToString("\n")
    }

    fun decode(body: String): Pair<String, List<String>>? {
        if (!body.startsWith(MARK)) return null
        val lines = body.removePrefix(MARK).split("\n")
        if (lines.size < 3 || lines.size - 1 > MAX_OPTIONS) return null
        return lines[0] to lines.drop(1)
    }
}
