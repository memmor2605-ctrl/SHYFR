package com.shyfr.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import com.shyfr.app.vault.MAX_ATT_BYTES
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream

/** Przygotowanie zdjęć i plików do wysyłki. Zdjęcia są obracane wg EXIF, przeskalowane i ponownie zakodowane (to usuwa EXIF/GPS). */
object Attachments {
    class Prepared(val name: String, val mime: String, val bytes: ByteArray, val image: Boolean)

    fun prepare(ctx: Context, uri: Uri, asImage: Boolean): Prepared {
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: "application/octet-stream"
        val name = cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "plik"
        val raw = cr.openInputStream(uri)?.use { readLimited(it, MAX_ATT_BYTES + 1) }
            ?: throw IllegalArgumentException("Nie udało się otworzyć pliku.")
        if (raw.size > MAX_ATT_BYTES) throw IllegalArgumentException("Plik jest za duży (max 8 MB).")
        if (!asImage) return Prepared(name, mime, raw, false)
        val bmp = loadOriented(raw, 1600) ?: throw IllegalArgumentException("Nie udało się odczytać zdjęcia.")
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return Prepared("zdjecie.jpg", "image/jpeg", out.toByteArray(), true)
    }

    /** Awatar: kwadrat 128x128, JPEG (kilka KB). */
    fun avatarJpeg(ctx: Context, uri: Uri): ByteArray {
        val raw = ctx.contentResolver.openInputStream(uri)?.use { readLimited(it, MAX_ATT_BYTES + 1) }
            ?: throw IllegalArgumentException("Nie udało się otworzyć zdjęcia.")
        val bmp = loadOriented(raw, 512) ?: throw IllegalArgumentException("Nie udało się odczytać zdjęcia.")
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val small = Bitmap.createScaledBitmap(sq, 128, 128, true)
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return out.toByteArray()
    }

    /** Dekoduje z próbkowaniem (oszczędza pamięć); najdłuższy bok najwyżej ok. [maxPx]. */
    fun decodeSampled(bytes: ByteArray, maxPx: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= maxPx || o.outHeight / (s * 2) >= maxPx) s *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun loadOriented(raw: ByteArray, maxPx: Int): Bitmap? {
        var bmp = decodeSampled(raw, maxPx) ?: return null
        val orient = runCatching {
            ExifInterface(ByteArrayInputStream(raw)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val deg = when (orient) { ExifInterface.ORIENTATION_ROTATE_90 -> 90f; ExifInterface.ORIENTATION_ROTATE_180 -> 180f; ExifInterface.ORIENTATION_ROTATE_270 -> 270f; else -> 0f }
        if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        val longest = maxOf(bmp.width, bmp.height)
        if (longest > maxPx) {
            val k = maxPx.toFloat() / longest
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
        }
        if (bmp.hasAlpha()) { // JPEG nie ma przezroczystości
            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            Canvas(flat).apply { drawColor(Color.WHITE); drawBitmap(bmp, 0f, 0f, null) }
            bmp = flat
        }
        return bmp
    }

    private fun readLimited(input: InputStream, limit: Int): ByteArray {
        val bo = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        while (bo.size() < limit) {
            val n = input.read(buf, 0, minOf(buf.size, limit - bo.size()))
            if (n < 0) break
            bo.write(buf, 0, n)
        }
        return bo.toByteArray()
    }

    fun humanSize(b: Int): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> "${b / 1024} KB"
        else -> "%.1f MB".format(b / 1048576.0)
    }
}
