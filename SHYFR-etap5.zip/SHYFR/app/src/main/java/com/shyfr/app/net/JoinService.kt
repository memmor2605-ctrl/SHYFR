package com.shyfr.app.net

import android.content.Context
import com.shyfr.app.Trace
import com.shyfr.app.crypto.Keys
import com.shyfr.app.crypto.Ratchet
import com.shyfr.app.invite.InviteCodec
import com.shyfr.app.invite.InviteManager
import com.shyfr.app.vault.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.ConnectException
import java.io.IOException

/**
 * Handshake dodawania znajomego przez zaproszenie (przez Tora):
 *   B -> A : HELLO  id(16) | tagB(32) | pubB(32) | onionB(56)
 *   A -> B : ACCEPT tagA(32)   albo REJECT (bez podania powodu)
 * Po sukcesie obie strony tworzą sesję Double Ratchet z ziarna = HKDF(sekret zaproszenia, DH tożsamości).
 * Sekret jest jednorazowy i natychmiast zerowany.
 */
class JoinService(private val ctx: Context) {
    private val store = Store(ctx)
    private val onionRe = Regex("^[a-z2-7]{56}$")

    private fun tag(secret: ByteArray, label: String, vararg p: ByteArray) =
        Keys.hmac(secret, label.toByteArray(), *p)

    /** Strona zapraszająca (A). Bajt HELLO został już przeczytany przez router. */
    fun handleHello(sock: Socket, inp: DataInputStream) {
        sock.use {
            val out = DataOutputStream(sock.getOutputStream())
            val id = ByteArray(16).also { inp.readFully(it) }
            val tagB = ByteArray(32).also { inp.readFully(it) }
            val pubB = ByteArray(32).also { inp.readFully(it) }
            val onB = ByteArray(56).also { inp.readFully(it) }
            val onionHost = String(onB, Charsets.US_ASCII)
            val (privA, pubA) = store.keys()

            val secret = if (!onionRe.matches(onionHost)) null else
                InviteManager.tryJoin(id) { s -> Keys.equalsCt(tagB, tag(s, "shyfr-join-v1", pubA, pubB, onB)) }
            if (secret == null) { out.writeByte(REJECT); out.flush(); return }

            val root = Keys.rootSeed(secret, Keys.dh(privA, pubB), pubA, pubB)
            val session = Ratchet.initResponder(root, privA, pubA).serialize()
            store.addContact("$onionHost.onion", pubB, session)
            NodeRuntime.contactsVersion.update { it + 1 }
            out.writeByte(ACCEPT)
            out.write(tag(secret, "shyfr-accept-v1", pubA, pubB))
            out.flush()
            secret.fill(0); root.fill(0)
        }
    }

    /** Strona dołączająca (B). Zwraca komunikat błędu albo null przy sukcesie. */
    suspend fun join(link: String): String? = withContext(Dispatchers.IO) {
        val p = InviteCodec.decode(link) ?: return@withContext "Nieprawidłowe zaproszenie."
        val t = NodeRuntime.transport
        val myOnion = NodeRuntime.onion
        if (t == null || myOnion == null) return@withContext "Poczekaj, aż SHYFR połączy się z siecią Tor."
        var phase = "łączenia z usługą onion przez Tor"
        try {
            val (privB, pubB) = store.keys()
            val onB = myOnion.removeSuffix(".onion").toByteArray(Charsets.US_ASCII)
            var error: String? = null
            var cid = -1L
            t.connectRetry(p.onion).use { s ->
                // Po udanym SOCKS CONNECT wiemy, że endpoint przyjął połączenie TCP.
                phase = "negocjacji bezpiecznego handshake"
                s.soTimeout = 30_000
                val out = DataOutputStream(s.getOutputStream())
                val inp = DataInputStream(s.getInputStream())
                out.writeByte(HELLO)
                out.write(InviteManager.idOf(p.secret))
                out.write(tag(p.secret, "shyfr-join-v1", p.pub, pubB, onB))
                out.write(pubB)
                out.write(onB)
                out.flush()
                if (inp.readUnsignedByte() != ACCEPT) {
                    error = "Zaproszenie wygasło, zostało użyte lub jest błędne."
                } else {
                    val tagA = ByteArray(32).also { inp.readFully(it) }
                    if (!Keys.equalsCt(tagA, tag(p.secret, "shyfr-accept-v1", p.pub, pubB))) {
                        error = "Nie udało się potwierdzić tożsamości drugiej osoby."
                    } else {
                        val root = Keys.rootSeed(p.secret, Keys.dh(privB, p.pub), p.pub, pubB)
                        val session = Ratchet.initInitiator(root, p.pub).serialize()
                        root.fill(0)
                        cid = store.addContact(p.onion, p.pub, session)
                    }
                }
            }
            if (error == null) {
                NodeRuntime.contactsVersion.update { it + 1 }
                // Pierwsza wiadomość techniczna: pozwala zapraszającemu zacząć odpowiadać.
                if (cid > 0) { store.setPsent(cid); Messenger(ctx).sendOwnProfile(cid) }
            }
            error
        } catch (e: SocketTimeoutException) {
            Trace.log("join TIMEOUT podczas $phase: ${e.message}")
            if (phase.startsWith("negocjacji"))
                "Usługa onion przyjęła połączenie, ale nie zakończyła handshake w wyznaczonym czasie. Sprawdź, czy druga aplikacja nadal działa i czy jej węzeł nie jest blokowany przez system."
            else
                "Nie udało się osiągnąć usługi onion przez Tor (timeout). To nie potwierdza, że znajomy jest offline. Sprawdź oba połączenia z internetem i spróbuj ponownie."
        } catch (e: ConnectException) {
            Trace.log("join CONNECT podczas $phase: ${e.message}")
            "Tor nie zestawił połączenia z usługą onion (${e.message ?: "odmowa połączenia"}). Status znajomego jest nieznany — nie można na tej podstawie stwierdzić, że jest offline."
        } catch (e: IOException) {
            Trace.log("join IO podczas $phase: ${e.javaClass.simpleName}: ${e.message}")
            "Problem transportu Tor podczas $phase: ${e.message ?: e.javaClass.simpleName}. Status znajomego jest nieznany."
        } catch (e: Exception) {
            Trace.log("join BŁĄD podczas $phase: ${e.javaClass.simpleName}: ${e.message}")
            "Nie udało się dokończyć $phase (${e.javaClass.simpleName}: ${e.message ?: "brak opisu"}). Status znajomego jest nieznany."
        } finally { p.secret.fill(0) }
    }

    /** Ponawiamy błędy zestawiania SOCKS; wyjątek z ostatniej próby zachowuje właściwy typ. */
    private suspend fun TorTransport.connectRetry(onion: String): Socket {
        var last: Exception? = null
        for (i in 1..8) {
            try {
                Trace.log("join: próba $i połączenia z onion")
                return connect(onion, TOR_PORT)
            } catch (e: Exception) {
                last = e
                Trace.log("join: próba $i nieudana: ${e.javaClass.simpleName}: ${e.message}")
                if (i < 8) kotlinx.coroutines.delay(15_000)
            }
        }
        throw last!!
    }

    companion object {
        const val HELLO = 1; const val ACCEPT = 2; const val REJECT = 3
        const val TOR_PORT = NodeService.VIRTUAL_PORT
    }
}
