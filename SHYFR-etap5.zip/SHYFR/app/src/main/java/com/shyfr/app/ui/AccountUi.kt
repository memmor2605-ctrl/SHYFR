package com.shyfr.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.account.AccountSync
import com.shyfr.app.net.NodeService
import com.shyfr.app.session.Session
import com.shyfr.app.vault.Db
import com.shyfr.app.vault.Vault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Pierwszy ekran nowej instalacji: dwie wyraźne drogi, bez żargonu. */
@Composable
fun WelcomeScreen(onCreate: () -> Unit, onLogin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        LogoHeader(120.dp)
        Spacer(Modifier.height(12.dp))
        Text("Prywatne rozmowy i społeczność. Połączenie zabezpieczamy za Ciebie.", color = ShMuted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(40.dp))
        Button(modifier = Modifier.fillMaxWidth().height(52.dp), onClick = onCreate) { Text("Utwórz konto") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(modifier = Modifier.fillMaxWidth().height(52.dp), onClick = onLogin) { Text("Zaloguj się") }
    }
}

/** Logowanie na nowym telefonie: login i hasło wystarczą, żeby odzyskać klucze konta. */
@Composable
fun RestoreOnlineScreen(vault: Vault, ctx: Context, onBack: () -> Unit, onUnlocked: () -> Unit) {
    var login by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(28.dp).imePadding().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
        LogoHeader(90.dp)
        Spacer(Modifier.height(10.dp))
        Text("Zaloguj się na istniejące konto", fontSize = 18.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text("Wpisz login i hasło ze starego telefonu.", color = ShMuted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(login, { login = it }, label = { Text("Login") }, singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(pass, { pass = it }, label = { Text("Hasło") }, singleLine = true, enabled = !busy,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        status?.let { Spacer(Modifier.height(12.dp)); Text(it, color = ShMuted, fontSize = 13.sp) }
        err?.let { Spacer(Modifier.height(12.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(20.dp))
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp), onClick = {
            err = null
            if (login.isBlank() || pass.length < 10) { err = "Podaj login i hasło."; return@Button }
            busy = true
            scope.launch(Dispatchers.Default) {
                val chars = pass.toCharArray()
                try {
                    when (val r = AccountSync.restore(ctx, login, chars) { s -> status = s }) {
                        is AccountSync.Restore.Ok -> {
                            val key = vault.createWithMaster(login, chars, r.master.copyOf())
                            r.master.fill(0)
                            Db.open(ctx, key).close(); Session.adopt(key); NodeService.start(ctx)
                            AccountSync.markRestored(ctx, r.lookup)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(ctx, "Konto odzyskane. Kontakty i rozmowy ze starego telefonu nie są zsynchronizowane, dodaj rozmówców ponownie.", Toast.LENGTH_LONG).show()
                                onUnlocked()
                            }
                        }
                        AccountSync.Restore.NotFound -> err = "Nie znaleziono konta albo hasło jest błędne. Jeśli konto nie miało włączonego odzyskiwania, użyj kopii zapasowej z pliku."
                        is AccountSync.Restore.Failed -> err = r.message
                    }
                } catch (e: Throwable) { err = "Nie udało się zalogować: " + (e.message ?: e.javaClass.simpleName) }
                finally { chars.fill('\u0000'); status = null; busy = false }
            }
        }) { Text(if (busy) "Logowanie…" else "Zaloguj się") }
        TextButton(modifier = Modifier.fillMaxWidth(), enabled = !busy, onClick = onBack) { Text("Wróć") }
    }
}

/** Okna odzyskiwania w Ustawieniach: włączenie, wyłączenie i uczciwy opis zakresu. */
@Composable
fun RecoveryDialogs(ctx: Context, vault: Vault, which: String, onClose: () -> Unit, onChanged: () -> Unit) {
    if (which == "recoveryInfo") {
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text("Odzyskiwanie konta") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Co wraca po zalogowaniu na nowym telefonie: klucz główny konta, a z niego Twoje tożsamości społecznościowe i klucze społeczności.", fontSize = 14.sp)
                    Text("Co nie wraca: kontakty, rozmowy, wiadomości i załączniki zapisane tylko na starym telefonie. Rozmówców trzeba dodać ponownie. Do pełnej kopii służy plik kopii zapasowej (Dane).", fontSize = 14.sp)
                    Text("Bezpieczeństwo: klucz na serwerze jest zaszyfrowany hasłem. Operator serwera mógłby próbować zgadywać hasło, dlatego musi być długie i niepowtarzalne. Zapomniane hasło oznacza brak odzyskania.", fontSize = 14.sp)
                    Text("Nie używaj konta na dwóch telefonach jednocześnie: szyfrowanie rozmów rozjedzie się. Po odzyskaniu wyłącz stary telefon.", fontSize = 14.sp, color = ShMuted)
                }
            },
            confirmButton = { TextButton(onClick = onClose) { Text("Zamknij") } }
        )
        return
    }
    val off = which == "recoveryOff"
    var login by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text(if (off) "Wyłączyć odzyskiwanie?" else "Włącz odzyskiwanie konta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (off) "Zaszyfrowany klucz zostanie usunięty z serwera. Potwierdź loginem i hasłem."
                else "Zaszyfrowany klucz konta trafi na serwer SHYFR, żeby wystarczył login i hasło na nowym telefonie. Potwierdź loginem i hasłem. Błędne hasło liczy się do limitu prób odblokowania.", fontSize = 13.sp, color = ShMuted)
                OutlinedTextField(login, { login = it }, label = { Text("Login") }, singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pass, { pass = it }, label = { Text("Hasło") }, singleLine = true, enabled = !busy,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                msg?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && login.isNotBlank() && pass.isNotEmpty(), onClick = {
                busy = true; msg = null
                scope.launch(Dispatchers.Default) {
                    val chars = pass.toCharArray()
                    try {
                        when (val r = vault.unlock(login, chars)) {
                            is Vault.Result.Ok -> {
                                val err = if (off) AccountSync.disable(ctx, login, chars) else AccountSync.enableNow(ctx, login, chars, r.masterKey)
                                r.masterKey.fill(0)
                                if (err == null) withContext(Dispatchers.Main) { onChanged(); onClose() } else msg = err
                            }
                            is Vault.Result.Wrong -> msg = "Błędny login lub hasło. Pozostało prób: ${r.attemptsLeft}"
                            else -> msg = "Nie można potwierdzić konta."
                        }
                    } catch (e: Throwable) { msg = e.message ?: "Błąd." }
                    finally { chars.fill('\u0000'); busy = false }
                }
            }) { Text(if (off) "Wyłącz" else "Włącz") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onClose) { Text("Anuluj") } }
    )
}
