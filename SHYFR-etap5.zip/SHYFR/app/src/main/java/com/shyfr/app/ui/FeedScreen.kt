package com.shyfr.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.feed.Bookmark
import com.shyfr.app.feed.Membership
import com.shyfr.app.feed.Post
import com.shyfr.app.feed.PublicRepo
import kotlinx.coroutines.launch

/** Feed: wpisy ze społeczności, do których należysz. Bez publicznego profilu; autor to „Anonimowy uczestnik” albo pseudonim społeczności. */
@Composable
private fun CommunityFeed(ctx: Context, onOpenCommunities: () -> Unit, onOpenSettings: () -> Unit) {
    val repo = remember { PublicRepo(ctx) }
    val scope = rememberCoroutineScope()
    val configured = repo.relayConfigured()
    var tab by remember { mutableIntStateOf(0) } // 0 najnowsze, 1 popularne (z załadowanych), 2 zapisane
    var tick by remember { mutableIntStateOf(0) }
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var next by remember { mutableStateOf<Long?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var thread by remember { mutableStateOf<Post?>(null) }
    var composing by remember { mutableStateOf(false) }
    var quoteOf by remember { mutableStateOf<Post?>(null) }
    var editing by remember { mutableStateOf<Post?>(null) }
    var editText by remember { mutableStateOf("") }
    var reporting by remember { mutableStateOf<Post?>(null) }
    var reportText by remember { mutableStateOf("") }
    var contacting by remember { mutableStateOf<Post?>(null) }
    var profileOf by remember { mutableStateOf<Post?>(null) }
    var greeting by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Post>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    var searched by remember { mutableStateOf(false) }
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    val joined by produceState(emptyList<Membership>(), tick, configured) {
        value = if (configured) runCatching { repo.memberships() }.getOrDefault(emptyList()) else emptyList()
    }
    val myPubs by produceState(emptyMap<String, String>(), joined) { value = repo.myPubs(joined.map { it.cid }) }
    val liked by produceState(emptySet<String>(), tick, posts) { value = runCatching { repo.likedIds() }.getOrDefault(emptySet()) }
    val votes by produceState(emptyMap<String, Int>(), tick, posts) { value = runCatching { repo.votes() }.getOrDefault(emptyMap()) }
    val savedIds by produceState(emptySet<String>(), tick, posts) { value = runCatching { repo.savedIds() }.getOrDefault(emptySet()) }
    val saved by produceState(emptyList<Bookmark>(), tick, tab) { value = if (tab == 2) runCatching { repo.bookmarks() }.getOrDefault(emptyList()) else emptyList() }
    val names = joined.associate { it.cid to it.name }

    fun load(reset: Boolean) {
        scope.launch {
            loading = true; error = null
            try {
                val page = repo.feed(if (reset) 0L else (next ?: 0L))
                posts = if (reset) page.items else (posts + page.items).distinctBy { it.id }
                next = page.next
            } catch (e: Exception) { error = e.message ?: "Błąd sieci" }
            loading = false
        }
    }
    fun act(ok: String? = null, block: suspend () -> Unit) {
        scope.launch {
            try { block(); ok?.let { toast(it) }; tick++; load(true) } catch (e: Exception) { toast(e.message ?: "Błąd") }
        }
    }
    fun runSearch() {
        if (q.trim().length < 2) { toast("Wpisz co najmniej 2 znaki"); return }
        scope.launch {
            searching = true; searchError = null; searched = true
            try { results = repo.search(q.trim()) } catch (e: Exception) { searchError = e.message ?: "Błąd" }
            searching = false
        }
    }
    LaunchedEffect(configured, tick) { if (configured) load(true) }

    val postItem: @Composable (Post) -> Unit = { p ->
        val m = joined.firstOrNull { it.cid == p.cid }
                        PostCard(
                            p, names[p.cid] ?: "", mine = p.author.isNotEmpty() && p.author == myPubs[p.cid], staff = m?.isStaff == true,
                            saved = p.id in savedIds, liked = p.id in liked,
                            onLike = { act { repo.react(p.cid, p.id, "❤", p.id !in liked) } },
                            onOpen = { thread = p },
                            onRepost = { quote -> if (quote) quoteOf = p else act("Udostępniono dalej") { repo.publish(p.cid, p.channel, "", true, "repost", "", p.id) } },
                            onSave = { scope.launch { repo.toggleBookmark(p); tick++ } },
                            myVote = votes[p.id], onVote = { i -> act { repo.vote(p.cid, p.id, i) } },
                            onReact = { e -> act { repo.react(p.cid, p.id, e, !repo.reacted(p.id, e)) } },
                            onMenu = { key ->
                                when (key) {
                                    "copy" -> { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("SHYFR", p.text)); toast("Skopiowano") }
                                    "link" -> { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("SHYFR", com.shyfr.app.feed.PublicProto.postLink(p.cid, p.id))); toast("Skopiowano link") }
                                    "edit" -> { editing = p; editText = p.text }
                                    "delete" -> act("Usunięto") { repo.delete(p.cid, p.id) }
                                    "report" -> { reporting = p; reportText = "" }
                                    "contact" -> { contacting = p; greeting = "" }
                                    "profile" -> profileOf = p
                                    "pin" -> act { repo.pin(p.cid, p.id, !p.pinned) }
                                    "ban" -> act("Zablokowano autora") { repo.ban(p.cid, p.author) }
                                }
                            }
                        )
    }


    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            PillTab("Najnowsze", tab == 0) { tab = 0 }
            PillTab("Popularne", tab == 1) { tab = 1 }
            PillTab("Zapisane", tab == 2) { tab = 2 }
            PillTab("Szukaj", tab == 3) { tab = 3 }
            Spacer(Modifier.weight(1f))
            PillTab("Nowy wpis", false) { if (joined.isEmpty()) toast("Najpierw dołącz do społeczności.") else composing = true }
        }
        when {
            !configured -> EmptyState("Społeczności są niedostępne", "Ta wersja aplikacji nie ma jeszcze serwera społeczności. Zakładka „Publiczny” działa bez konfiguracji.")
            tab == 2 -> if (saved.isEmpty()) EmptyState("Brak zapisanych", "Zapisuj wpisy przyciskiem Zapisz. Kopie są tylko na tym telefonie.") else LazyColumn(
                Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(saved, key = { it.id }) { b ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(ShSurface.copy(alpha = .85f)).padding(14.dp)) {
                        Text((if (b.nick.isNotBlank()) b.nick else "Anonimowy uczestnik") + " · " + fmtTime(b.ts), fontSize = 12.sp, color = ShMuted)
                        Text(b.text, fontSize = 15.sp)
                        TextButton(onClick = { scope.launch { repo.removeBookmark(b.id); tick++ } }) { Text("Usuń zakładkę") }
                    }
                }
            }
            tab == 3 -> Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextField(value = q, onValueChange = { q = it }, singleLine = true, placeholder = { Text("Tekst lub #hashtag") },
                        leadingIcon = { Icon24(Ic.Search, ShMuted, 20.dp) },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                        keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { runSearch() }),
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(28.dp),
                        colors = TextFieldDefaults.colors(focusedContainerColor = ShSurfaceHi.copy(alpha = .8f), unfocusedContainerColor = ShSurface.copy(alpha = .85f),
                            focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent, unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent))
                    TextButton(onClick = { runSearch() }) { Text("Szukaj") }
                }
                when {
                    searching -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    searchError != null -> EmptyState("Nie udało się wyszukać", searchError ?: "", "Ponów") { runSearch() }
                    !searched -> EmptyState("Szukaj we wpisach", "Wyszukiwanie obejmuje publiczne społeczności na przekaźniku. Hashtagi zaczynają się od #.")
                    results.isEmpty() -> EmptyState("Brak wyników", "Nic nie pasuje do „$q”.")
                    else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp, top = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(results, key = { it.id }) { p -> postItem(p) }
                    }
                }
            }
            joined.isEmpty() && !loading -> EmptyState("Brak społeczności", "Dołącz do publicznej społeczności albo użyj zaproszenia, aby zobaczyć tu wpisy.", "Znajdź społeczność", onOpenCommunities)
            loading && posts.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            error != null && posts.isEmpty() -> EmptyState("Nie udało się wczytać", error ?: "", "Ponów") { load(true) }
            else -> {
                val shown = if (tab == 1) posts.sortedByDescending { it.score } else posts
                if (shown.isEmpty()) EmptyState("Pusto", "W Twoich społecznościach nie ma jeszcze wpisów. Napisz pierwszy!")
                else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown, key = { it.id }) { p ->
                        postItem(p)
                    }
                    if (next != null) item { TextButton(modifier = Modifier.fillMaxWidth(), onClick = { load(false) }) { Text(if (loading) "Wczytywanie…" else "Wczytaj więcej") } }
                }
            }
        }
    }

    thread?.let { p ->
        ThreadDialog(repo, p, myPubs[p.cid] ?: "", onDismiss = { thread = null; tick++ }, onError = { toast(it) }, onChanged = { })
    }
    if (composing || quoteOf != null) ComposeDialog(repo, joined, quoteOf, null,
        onDismiss = { composing = false; quoteOf = null },
        onDone = { composing = false; quoteOf = null; toast("Opublikowano"); tick++ },
        onError = { toast(it) })
    editing?.let { p ->
        AlertDialog(
            onDismissRequest = { editing = null }, title = { Text("Edytuj wpis") },
            text = { OutlinedTextField(editText, { if (it.length <= 2000) editText = it }, modifier = Modifier.fillMaxWidth(), minLines = 3) },
            confirmButton = { TextButton(enabled = editText.isNotBlank(), onClick = { val t = editText; editing = null; act("Zapisano") { repo.edit(p.cid, p.id, t) } }) { Text("Zapisz") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Anuluj") } }
        )
    }
    profileOf?.let { p -> ProfileDialog(repo, p.cid, p.author) { profileOf = null } }
    contacting?.let { p ->
        AlertDialog(
            onDismissRequest = { contacting = null }, title = { Text("Prośba o kontakt") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Autor dostanie anonimową prośbę i sam zdecyduje, czy ją przyjąć. Działa tylko, jeśli autor włączył prośby o kontakt w tej społeczności. Powitanie jest zaszyfrowane kluczem autora (przekaźnik go nie odczyta).", fontSize = 12.sp, color = ShMuted)
                    OutlinedTextField(greeting, { if (it.length <= 140) greeting = it }, label = { Text("Powitanie (do 140 znaków)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                }
            },
            confirmButton = { TextButton(enabled = greeting.isNotBlank(), onClick = { val g = greeting; contacting = null; act("Wysłano prośbę o kontakt") { repo.requestContact(p.cid, p.author, g) } }) { Text("Wyślij prośbę") } },
            dismissButton = { TextButton(onClick = { contacting = null }) { Text("Anuluj") } }
        )
    }
    reporting?.let { p ->
        AlertDialog(
            onDismissRequest = { reporting = null }, title = { Text("Zgłoś wpis") },
            text = { OutlinedTextField(reportText, { if (it.length <= 200) reportText = it }, label = { Text("Powód (opcjonalnie)") }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { val t = reportText; reporting = null; act("Zgłoszono moderatorom") { repo.report(p.cid, p.id, t) } }) { Text("Wyślij") } },
            dismissButton = { TextButton(onClick = { reporting = null }) { Text("Anuluj") } }
        )
    }
}


/** Feed: publiczny (sieć Nostr, połączenie automatyczne) albo wpisy z Twoich społeczności. */
@Composable
fun FeedScreen(ctx: Context, onOpenCommunities: () -> Unit, onOpenSettings: () -> Unit) {
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillTab("Publiczny", mode == 0) { mode = 0 }
            PillTab("Z moich społeczności", mode == 1) { mode = 1 }
        }
        HorizontalDivider(color = ShLine, thickness = 0.5.dp)
        Box(Modifier.weight(1f).fillMaxWidth()) { if (mode == 0) PublicFeed(ctx) else CommunityFeed(ctx, onOpenCommunities, onOpenSettings) }
    }
}
