package com.shyfr.app.nostr

import org.json.JSONArray
import org.json.JSONObject

sealed interface RelayMsg {
    data class Event(val sub: String, val ev: NostrEvent) : RelayMsg
    data class Eose(val sub: String) : RelayMsg
    data class Ok(val id: String, val accepted: Boolean, val message: String) : RelayMsg
    data class Notice(val message: String) : RelayMsg
    data class Closed(val sub: String, val message: String) : RelayMsg
    data class Auth(val challenge: String) : RelayMsg
}

/** Filtr zapytania (NIP-01). */
data class Filter(
    val ids: List<String>? = null, val authors: List<String>? = null, val kinds: List<Int>? = null,
    val since: Long? = null, val until: Long? = null, val limit: Int? = null, val tags: Map<String, List<String>> = emptyMap()
) {
    fun toJson(): String {
        val p = ArrayList<String>()
        ids?.let { p += "\"ids\":" + strs(it) }; authors?.let { p += "\"authors\":" + strs(it) }
        kinds?.let { p += "\"kinds\":" + it.joinToString(",", "[", "]") }
        since?.let { p += "\"since\":$it" }; until?.let { p += "\"until\":$it" }; limit?.let { p += "\"limit\":$it" }
        tags.forEach { (k, v) -> p += NostrEvent.jsonString("#$k") + ":" + strs(v) }
        return p.joinToString(",", "{", "}")
    }
    private fun strs(l: List<String>) = l.joinToString(",", "[", "]") { NostrEvent.jsonString(it) }
}

object NostrWire {
    private const val MAX_CONTENT = 100_000
    private const val MAX_TAGS = 2_000

    fun eventFrom(o: JSONObject): NostrEvent? = try {
        val tagsJ = o.getJSONArray("tags")
        if (tagsJ.length() > MAX_TAGS) null else {
            val tags = (0 until tagsJ.length()).map { i -> val t = tagsJ.getJSONArray(i); (0 until t.length()).map { j -> t.getString(j) } }
            val content = o.getString("content")
            if (content.length > MAX_CONTENT) null
            else NostrEvent(o.getString("id"), o.getString("pubkey"), o.getLong("created_at"), o.getInt("kind"), tags, content, o.getString("sig"))
        }
    } catch (e: Exception) { null }

    fun parse(text: String): RelayMsg? = try {
        val a = JSONArray(text)
        when (a.getString(0)) {
            "EVENT" -> eventFrom(a.getJSONObject(2))?.let { RelayMsg.Event(a.getString(1), it) }
            "EOSE" -> RelayMsg.Eose(a.getString(1))
            "OK" -> RelayMsg.Ok(a.getString(1), a.getBoolean(2), a.optString(3, ""))
            "NOTICE" -> RelayMsg.Notice(a.optString(1, ""))
            "CLOSED" -> RelayMsg.Closed(a.getString(1), a.optString(2, ""))
            "AUTH" -> RelayMsg.Auth(a.optString(1, ""))
            else -> null
        }
    } catch (e: Exception) { null }

    fun reqMsg(sub: String, filters: List<Filter>) = "[\"REQ\"," + NostrEvent.jsonString(sub) + filters.joinToString("") { "," + it.toJson() } + "]"
    fun closeMsg(sub: String) = "[\"CLOSE\"," + NostrEvent.jsonString(sub) + "]"
    fun eventMsg(ev: NostrEvent) = "[\"EVENT\"," + ev.toWireJson() + "]"
}
