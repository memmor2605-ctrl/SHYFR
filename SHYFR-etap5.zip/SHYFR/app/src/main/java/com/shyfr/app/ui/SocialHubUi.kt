package com.shyfr.app.ui

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.social.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private fun slug(s: String): String {
    val t = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9_]+"), "_").trim('_').take(24)
    return if (t.length >= 3) t else (t + "_user").take(24)
}

private fun visLabel(v: String) = when (v) { "private" -> "prywatne"; "anon" -> "anonimowe"; "public" -> "publiczne"; else -> "" }

/** Obserwowanie dla AKTYWNEJ tożsamości: profil na przekaźniku, liczniki, prośby, listy, wyszukiwanie, powiadomienia. */
@Composable
fun SocialHub(ctx: Context) {
    val repo = remember { SocialRepo(ctx) }
    val active by SocialState.active.collectAsState()
    var view by remember(active) { mutableStateOf("home") }
    var tick by remember { mutableIntStateOf(0) }
    var identity by remember { mutableStateOf<SocialIdentity?>(null) }
    var profile by remember { mutableStateOf<SocialProfileInfo?>(null) }
    var pending by remember { mutableIntStateOf(0) }
    var loaded by remember(active) { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(active, tick) {
        loaded = false; error = null
        try {
            val id = repo.activeIdentity(); identity = id
            profile = repo.myProfile(id)
            pending = if (profile != null && id.kind == IdentityKind.PRIVATE) repo.requests(id).size else 0
        } catch (e: CancellationException) { throw e } catch (e: Exception) { error = e.message ?: "Błąd sieci" }
        loaded = true
    }
    val id = identity
    Column(Modifier.fillMaxWidth()) {
        when {
            !loaded -> Text("Wczytywanie…", color = ShMuted)
            error != null -> {
                Text(error ?: "", color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
                TextButton(onClick = { tick++ }) { Text("Ponów") }
            }
            id == null -> {}
            profile == null || view == "edit" -> ProfileForm(repo, id, profile) { view = "home"; tick++ }
            view == "followers" -> UserList("Obserwujący", { repo.list(id, "followers") }, onBack = { view = "home" }, searchable = false) { u, reload ->
                RowAction("Usuń") { repo.decide(id, u.pub, false); reload() }
                RowAction("Blokuj") { repo.block(id, u.pub, true); reload() }
            }
            view == "following" -> UserList("Obserwowani", { repo.list(id, "following") }, onBack = { view = "home" }, searchable = false) { u, reload ->
                if (u.state == "pending") Text("Oczekuje", fontSize = 12.sp, color = ShMuted)
                RowAction(if (u.state == "pending") "Wycofaj" else "Przestań") { repo.follow(id, u.pub, false); reload() }
            }
            view == "requests" -> UserList("Prośby o obserwowanie", { repo.requests(id) }, onBack = { view = "home"; tick++ }, searchable = false) { u, reload ->
                RowAction("Akceptuj") { repo.decide(id, u.pub, true); reload() }
                RowAction("Odrzuć") { repo.decide(id, u.pub, false); reload() }
                RowAction("Blokuj") { repo.block(id, u.pub, true); reload() }
            }
            view == "search" -> SearchView(repo, id) { view = "home" }
            view == "notifs" -> NotifView(repo, id) { view = "home" }
            else -> SocialHome(profile!!, pending, onOpen = { view = it })
        }
    }
}

@Composable
private fun RowAction(label: String, onClick: suspend () -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    TextButton(enabled = !busy, onClick = { busy = true; scope.launch { try { onClick() } catch (e: CancellationException) { throw e } catch (_: Exception) { } ; busy = false } }) { Text(label, fontSize = 13.sp) }
}

@Composable
private fun SocialHome(p: SocialProfileInfo, pending: Int, onOpen: (String) -> Unit) {
    Text("@${p.handle}", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    Text(p.name + " · konto ${visLabel(p.vis)}", fontSize = 13.sp, color = ShMuted)
    if (p.bio.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(p.bio, fontSize = 14.sp) }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
        Text("${p.followers ?: "–"} obserwujących", fontSize = 14.sp)
        Text("${p.following ?: "–"} obserwowanych", fontSize = 14.sp)
    }
    HorizontalDivider(Modifier.padding(vertical = 12.dp), color = ShLine, thickness = 0.5.dp)
    if (p.vis == "private") HubRow(Ic.Bell, if (pending > 0) "Prośby o obserwowanie ($pending)" else "Prośby o obserwowanie") { onOpen("requests") }
    HubRow(Ic.Group, "Obserwujący") { onOpen("followers") }
    HubRow(Ic.Person, "Obserwowani") { onOpen("following") }
    HubRow(Ic.Search, "Szukaj kont") { onOpen("search") }
    HubRow(Ic.Bell, "Powiadomienia tej tożsamości") { onOpen("notifs") }
    HubRow(Ic.Edit, "Edytuj profil i prywatność") { onOpen("edit") }
    Spacer(Modifier.height(12.dp))
    Text("Operator przekaźnika widzi, kto kogo obserwuje (pod kluczami tożsamości, nie pod Twoim imieniem). Ukrycie list i liczników działa tylko w odpowiedziach przekaźnika, to nie jest szyfrowanie.", fontSize = 11.sp, color = ShMuted)
}

@Composable
private fun HubRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickableNoRipple(onClick).padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon24(icon, ShSilver, 20.dp); Spacer(Modifier.width(16.dp)); Text(text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Icon24(Ic.Forward, ShMuted, 16.dp)
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.then(Modifier.clickable(onClick = onClick))

@Composable
private fun ProfileForm(repo: SocialRepo, id: SocialIdentity, cur: SocialProfileInfo?, onDone: () -> Unit) {
    var handle by remember(id.id) { mutableStateOf(cur?.handle ?: slug(id.name)) }
    var name by remember(id.id) { mutableStateOf(cur?.name ?: id.name) }
    var bio by remember(id.id) { mutableStateOf(cur?.bio ?: "") }
    var discover by remember(id.id) { mutableStateOf(cur?.discover ?: (id.kind != IdentityKind.ANON)) }
    var hideFol by remember(id.id) { mutableStateOf(cur?.hideFollowers ?: false) }
    var hideFing by remember(id.id) { mutableStateOf(cur?.hideFollowing ?: false) }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Text(if (cur == null) "Utwórz profil: ${id.kind.label.lowercase()}" else "Edytuj profil", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(handle, { handle = it.lowercase().filter { c -> c in 'a'..'z' || c in '0'..'9' || c == '_' }.take(24) }, label = { Text("Nazwa użytkownika (unikalna)") }, prefix = { Text("@") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(name, { name = it.take(40) }, label = { Text(if (id.kind == IdentityKind.ANON) "Pseudonim" else "Wyświetlana nazwa") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(bio, { bio = it.take(300) }, label = { Text("Opis") }, modifier = Modifier.fillMaxWidth())
    SwitchRow("Pokazuj w wyszukiwaniu kont", discover) { discover = it }
    SwitchRow("Ukryj licznik i listę obserwujących", hideFol) { hideFol = it }
    SwitchRow("Ukryj licznik i listę obserwowanych", hideFing) { hideFing = it }
    Text(if (id.kind == IdentityKind.PRIVATE) "Konto prywatne: obserwować mogą tylko osoby, które zatwierdzisz." else "Konto bez zatwierdzania: każdy może Cię obserwować.", fontSize = 12.sp, color = ShMuted)
    err?.let { Spacer(Modifier.height(6.dp)); Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
    Spacer(Modifier.height(12.dp))
    Button(enabled = !busy && handle.length >= 3 && name.isNotBlank(), modifier = Modifier.fillMaxWidth().height(48.dp), onClick = {
        busy = true; err = null
        scope.launch {
            try { repo.setProfile(id, handle, name, bio, discover, hideFol, hideFing); onDone() }
            catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "Nie udało się zapisać." }
            busy = false
        }
    }) { Text("Zapisz") }
    if (cur != null) TextButton(modifier = Modifier.fillMaxWidth(), onClick = onDone) { Text("Anuluj") }
}

@Composable
private fun SwitchRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f)); Switch(on, onChange)
    }
}

@Composable
private fun UserList(
    title: String, load: suspend () -> List<SocialUser>, onBack: () -> Unit, searchable: Boolean,
    actions: @Composable RowScope.(SocialUser, () -> Unit) -> Unit
) {
    var users by remember { mutableStateOf<List<SocialUser>?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        try { users = load() } catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "Błąd sieci"; users = emptyList() }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconTap(Ic.Back, "Wróć", onClick = onBack)
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
    err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
    val l = users
    if (l == null) Text("Wczytywanie…", color = ShMuted)
    else if (l.isEmpty() && err == null) Text("Pusto.", color = ShMuted, modifier = Modifier.padding(vertical = 12.dp))
    else l.forEach { u -> UserRow(u) { actions(u) { tick++ } } }
}

@Composable
private fun UserRow(u: SocialUser, actions: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconAvatar(if (u.vis == "anon") Ic.Shield else if (u.vis == "private") Ic.Lock else Ic.Person, 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(u.name.ifBlank { "Bez profilu" }, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (u.handle.isNotBlank()) "@${u.handle}" else u.pub.take(8) + "…", fontSize = 12.sp, color = ShMuted, maxLines = 1)
        }
        actions()
    }
}

@Composable
private fun SearchView(repo: SocialRepo, id: SocialIdentity, onBack: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<SocialUser>?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    val states = remember { mutableStateMapOf<String, String>() }
    val scope = rememberCoroutineScope()
    Row(verticalAlignment = Alignment.CenterVertically) { IconTap(Ic.Back, "Wróć", onClick = onBack); Text("Szukaj kont", fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
    OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Nazwa lub @użytkownik") }, modifier = Modifier.fillMaxWidth())
    Button(enabled = q.trim().length >= 2, onClick = {
        scope.launch { err = null; try { results = repo.search(id, q) } catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "Błąd sieci" } }
    }) { Text("Szukaj") }
    err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
    val me = remember(id.id) { mutableStateOf("") }
    LaunchedEffect(id.id) { me.value = repo.pubOf(id) }
    results?.filter { it.pub != me.value }?.forEach { u ->
        UserRow(u) {
            val st = states[u.pub] ?: ""
            if (st == "active") Text("Obserwujesz", fontSize = 12.sp, color = ShMuted)
            else if (st == "pending") Text("Prośba wysłana", fontSize = 12.sp, color = ShMuted)
            else RowAction("Obserwuj") { states[u.pub] = repo.follow(id, u.pub, true) }
        }
    }
    if (results?.isEmpty() == true) Text("Brak wyników. Konta z wyłączonym wyszukiwaniem nie są pokazywane.", color = ShMuted, fontSize = 13.sp)
}

@Composable
private fun NotifView(repo: SocialRepo, id: SocialIdentity, onBack: () -> Unit) {
    var ev by remember { mutableStateOf<List<SocialEvent>?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(id.id) { try { ev = repo.notifs(id) } catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "Błąd sieci"; ev = emptyList() } }
    Row(verticalAlignment = Alignment.CenterVertically) { IconTap(Ic.Back, "Wróć", onClick = onBack); Text("Powiadomienia", fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
    err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
    val l = ev
    if (l == null) Text("Wczytywanie…", color = ShMuted)
    else if (l.isEmpty() && err == null) Text("Brak nowych powiadomień.", color = ShMuted, modifier = Modifier.padding(vertical = 12.dp))
    else l.forEach { e ->
        val who = if (e.handle.isNotBlank()) "@${e.handle}" else "Ktoś"
        val text = when (e.type) { "follow" -> "$who zaczął Cię obserwować"; "request" -> "$who prosi o zgodę na obserwowanie"; "accepted" -> "$who zaakceptował Twoją prośbę"; else -> who }
        Text(text, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp))
        HorizontalDivider(color = ShLine, thickness = 0.5.dp)
    }
}
