package com.shyfr.app.vault

import android.content.Context
import com.shyfr.app.crypto.Keys
import com.shyfr.app.session.Session
import net.zetetic.database.sqlcipher.SQLiteDatabase
import java.io.ByteArrayOutputStream
import java.security.SecureRandom

data class Contact(
    val id: Long, val label: String, val onion: String, val pubkey: ByteArray, val ttl: Int, val verified: Boolean,
    val color: Int, val emoji: String, val about: String, val psent: Boolean, val unread: Int,
    val last: String?, val lastTs: Long, val muted: Boolean,
    val pinned: Boolean = false, val archived: Boolean = false,
    val theme: Int = 0, val capMode: Int = 0, val qEmoji: String = "", val chatNick: String = "", val myNick: String = "",
    val peerState: Int = 0, val peerActive: Long = 0L, val peerSeen: Long = 0L, val blocked: Boolean = false
) {
    /** Nazwa widoczna w rozmowie: pseudonim nadany w tej rozmowie, a jeśli go brak, nazwa kontaktu. */
    val shownName: String get() = chatNick.ifBlank { label }
}
data class Group(val gid: String, val name: String, val members: List<String>, val unread: Int, val muted: Boolean, val last: String?, val lastTs: Long)
data class GMsg(val id: Long, val sender: String, val body: String, val ts: Long)
/** Rozpakowana ramka wiadomości grupowej. sender "" = ja. */
data class GroupFrame(val gid: String, val mid: String, val name: String, val members: List<String>, val text: String)

data class SearchHit(val contactId: Long, val label: String, val snippet: String, val ts: Long)
const val NOTES_GID = "0000000000000000"

data class Profile(val nick: String, val color: Int, val emoji: String, val about: String)
const val ATT_CHUNK = 48_000
const val MAX_ATT_BYTES = 8_000_000

data class AttInfo(val id: String, val name: String, val mime: String, val size: Int, val image: Boolean, val done: Boolean)
data class AttMeta(val id: String, val name: String, val mime: String, val size: Int, val total: Int, val image: Boolean)
data class Msg(
    val id: Long, val outgoing: Boolean, val body: String, val ts: Long, val delivered: Boolean, val failed: Boolean, val att: AttInfo?,
    val mid: String?, val replyMid: String?, val replyBody: String?, val replyOut: Boolean,
    val edited: Boolean, val deleted: Boolean, val reactions: Map<String, Int>, val myReaction: String?,
    val read: Boolean = false, val sys: Boolean = false, val pinned: Boolean = false
)
data class OutFrame(val rowId: Long, val msgId: Long, val frame: ByteArray)

/** Dostęp do zaszyfrowanej bazy. Działa tylko przy odblokowanym koncie (klucz w Session). */
class Store(private val ctx: Context) {
    private fun <T> db(block: (SQLiteDatabase) -> T): T {
        val k = Session.get() ?: error("Konto zablokowane")
        val d = Db.open(ctx, k)
        try { return block(d) } finally { d.close() }
    }
    private fun <T> tx(d: SQLiteDatabase, block: () -> T): T {
        d.beginTransaction()
        try { val r = block(); d.setTransactionSuccessful(); return r } finally { d.endTransaction() }
    }
    private val none: Array<Any?>? get() = null
    /** SQLCipher: rawQuery(String, Object...) to varargs; tablica musi być rozwinięta (*), pusta = brak argumentów. */
    private fun SQLiteDatabase.q(sql: String, args: Array<Any?>?): android.database.Cursor =
        if (args == null || args.isEmpty()) rawQuery(sql) else rawQuery(sql, *args)

    /** Para kluczy X25519 tożsamości (prywatny, publiczny). */
    fun keys(): Pair<ByteArray, ByteArray> = db { d ->
        d.execSQL("INSERT OR IGNORE INTO identity(id) VALUES(1)")
        var priv = d.q("SELECT x_priv FROM identity WHERE id=1", none).use { if (it.moveToFirst()) it.getBlob(0) else null }
        if (priv == null) {
            priv = Keys.newPriv()
            d.execSQL("UPDATE identity SET x_priv=? WHERE id=1", arrayOf<Any?>(priv))
        }
        priv to Keys.pub(priv)
    }

    /** Dodaje kontakt razem z sesją szyfrowania. Zwraca id kontaktu lub -1, jeśli już istnieje. */
    fun addContact(onion: String, pub: ByteArray, session: ByteArray): Long = db { d ->
        val exists = d.q("SELECT 1 FROM contacts WHERE onion=?", arrayOf<Any?>(onion)).use { it.moveToFirst() }
        if (exists) -1L else tx(d) {
            val n = d.q("SELECT COUNT(*) FROM contacts", none).use { it.moveToFirst(); it.getInt(0) } + 1
            d.execSQL("INSERT INTO contacts(label, onion, pubkey, ttl) VALUES(?,?,?,?)", arrayOf<Any?>("Znajomy $n", onion, pub, com.shyfr.app.session.Prefs.defaultTtl(ctx)))
            val id = d.q("SELECT last_insert_rowid()", none).use { it.moveToFirst(); it.getLong(0) }
            d.execSQL("INSERT OR REPLACE INTO sessions(contact_id, state) VALUES(?,?)", arrayOf<Any?>(id, session))
            id
        }
    }

    private fun readContact(c: android.database.Cursor) =
        Contact(c.getLong(0), c.getString(1), c.getString(2), c.getBlob(3), c.getInt(4), c.getInt(5) == 1,
            c.getInt(6), c.getString(7) ?: "", c.getString(8) ?: "", c.getInt(9) == 1, c.getInt(10),
            c.getString(11), c.getLong(12), c.getInt(13) == 1, c.getInt(14) == 1, c.getInt(15) == 1,
            c.getInt(16), c.getInt(17), c.getString(18) ?: "", c.getString(19) ?: "", c.getString(20) ?: "",
            c.getInt(21), c.getLong(22), c.getLong(23), c.getInt(24) == 1)
    private fun contactCols(): String {
        val now = System.currentTimeMillis()
        val live = "m.contact_id=contacts.id AND (m.expires=0 OR m.expires>$now)"
        return "id,label,onion,pubkey,COALESCE(ttl,0),COALESCE(verified,0),COALESCE(color,0),COALESCE(emoji,''),COALESCE(about,'')," +
            "COALESCE(psent,0),COALESCE(unread,0)," +
            "(SELECT body FROM messages m WHERE $live ORDER BY m.id DESC LIMIT 1)," +
            "COALESCE((SELECT ts FROM messages m WHERE $live ORDER BY m.id DESC LIMIT 1),0)," +
            "(CASE WHEN COALESCE(muted,0)=1 AND (COALESCE(mute_until,0)=0 OR mute_until>$now) THEN 1 ELSE 0 END)," +
            "COALESCE(pinned,0),COALESCE(archived,0),COALESCE(theme,0),COALESCE(capmode,0),COALESCE(qemoji,''),COALESCE(cnick,''),COALESCE(mynick,'')," +
            "COALESCE(peer_state,0),COALESCE(peer_active,0),COALESCE(peer_seen,0),COALESCE(blocked,0)"
    }

    fun contacts(): List<Contact> = db { d ->
        d.q("SELECT ${contactCols()} FROM contacts ORDER BY id", none).use { c -> buildList { while (c.moveToNext()) add(readContact(c)) } }
    }
    fun contact(id: Long): Contact? = db { d ->
        d.q("SELECT ${contactCols()} FROM contacts WHERE id=?", arrayOf<Any?>(id)).use { if (it.moveToFirst()) readContact(it) else null }
    }
    fun contactBySid(sid: ByteArray): Contact? = contacts().firstOrNull { Keys.equalsCt(Keys.sid(it.pubkey), sid) }

    fun setTtl(contactId: Long, seconds: Int) = db { d ->
        d.execSQL("UPDATE contacts SET ttl=? WHERE id=?", arrayOf<Any?>(seconds, contactId))
    }

    fun loadSession(contactId: Long): ByteArray? = db { d ->
        d.q("SELECT state FROM sessions WHERE contact_id=?", arrayOf<Any?>(contactId)).use { if (it.moveToFirst()) it.getBlob(0) else null }
    }
    fun seen(contactId: Long, h: ByteArray): Boolean = db { d ->
        d.q("SELECT 1 FROM seen WHERE contact_id=? AND h=?", arrayOf<Any?>(contactId, h)).use { it.moveToFirst() }
    }

    private fun expiry(ttl: Int) = if (ttl > 0) System.currentTimeMillis() + ttl * 1000L else 0L

    fun commitIncoming(contactId: Long, state: ByteArray, h: ByteArray, body: String?, ttl: Int, mid: String? = null, replyMid: String? = null) = db { d ->
        tx(d) {
            d.execSQL("UPDATE sessions SET state=? WHERE contact_id=?", arrayOf<Any?>(state, contactId))
            d.execSQL("INSERT OR IGNORE INTO seen(contact_id, h) VALUES(?,?)", arrayOf<Any?>(contactId, h))
            d.execSQL("DELETE FROM seen WHERE contact_id=? AND rowid NOT IN (SELECT rowid FROM seen WHERE contact_id=? ORDER BY rowid DESC LIMIT 500)",
                arrayOf<Any?>(contactId, contactId))
            if (body != null) {
                d.execSQL("INSERT OR IGNORE INTO messages(contact_id, outgoing, body, ts, expires, status, mid, reply_mid) VALUES(?,0,?,?,?,1,?,?)",
                    arrayOf<Any?>(contactId, body, System.currentTimeMillis(), expiry(ttl), mid, replyMid))
                d.execSQL("UPDATE contacts SET unread=COALESCE(unread,0)+1 WHERE id=?", arrayOf<Any?>(contactId))
            }
        }
    }

    fun commitOutgoing(contactId: Long, state: ByteArray, frame: ByteArray, text: String?, ttl: Int, ackMsgId: Long = 0L, mid: String? = null, replyMid: String? = null) = db { d ->
        tx(d) {
            d.execSQL("UPDATE sessions SET state=? WHERE contact_id=?", arrayOf<Any?>(state, contactId))
            var msgId = ackMsgId
            if (text != null) {
                d.execSQL("INSERT INTO messages(contact_id, outgoing, body, ts, expires, status, mid, reply_mid) VALUES(?,1,?,?,?,0,?,?)",
                    arrayOf<Any?>(contactId, text, System.currentTimeMillis(), expiry(ttl), mid, replyMid))
                msgId = d.q("SELECT last_insert_rowid()", none).use { it.moveToFirst(); it.getLong(0) }
            }
            d.execSQL("INSERT INTO outbox(contact_id, frame, msg_id) VALUES(?,?,?)", arrayOf<Any?>(contactId, frame, msgId))
        }
    }

    fun outboxContacts(): List<Long> = db { d ->
        d.q("SELECT DISTINCT contact_id FROM outbox", none).use { c -> buildList { while (c.moveToNext()) add(c.getLong(0)) } }
    }
    fun outboxFrames(contactId: Long): List<OutFrame> = db { d ->
        d.q("SELECT id,msg_id,frame FROM outbox WHERE contact_id=? ORDER BY id", arrayOf<Any?>(contactId)).use { c ->
            buildList { while (c.moveToNext()) add(OutFrame(c.getLong(0), c.getLong(1), c.getBlob(2))) }
        }
    }
    fun ackOutbox(f: OutFrame) = db { d ->
        tx(d) {
            d.execSQL("DELETE FROM outbox WHERE id=?", arrayOf<Any?>(f.rowId))
            if (f.msgId > 0) d.execSQL("UPDATE messages SET status=1 WHERE id=? AND status<>3", arrayOf<Any?>(f.msgId))
        }
    }

    /** Odbiorca odrzucił ramkę (NACK). Po 5 próbach porzucamy ją, żeby nie blokowała kolejki. */
    fun nackOutbox(f: OutFrame) = db { d ->
        tx(d) {
            d.execSQL("UPDATE outbox SET attempts=COALESCE(attempts,0)+1 WHERE id=?", arrayOf<Any?>(f.rowId))
            val n = d.q("SELECT attempts FROM outbox WHERE id=?", arrayOf<Any?>(f.rowId)).use { if (it.moveToFirst()) it.getInt(0) else 0 }
            if (n >= 5) {
                d.execSQL("DELETE FROM outbox WHERE id=?", arrayOf<Any?>(f.rowId))
                if (f.msgId > 0) d.execSQL("UPDATE messages SET status=2 WHERE id=?", arrayOf<Any?>(f.msgId))
            }
        }
    }

    fun messages(contactId: Long): List<Msg> = db { d ->
        // reakcje: mid -> (emoji -> liczba), moja reakcja
        val counts = HashMap<String, MutableMap<String, Int>>()
        val mine = HashMap<String, String>()
        d.q("SELECT msg_mid, by_me, emoji FROM reactions WHERE contact_id=?", arrayOf<Any?>(contactId)).use { c ->
            while (c.moveToNext()) {
                val mid = c.getString(0) ?: continue
                val e = c.getString(2) ?: continue
                counts.getOrPut(mid) { LinkedHashMap() }.merge(e, 1, Int::plus)
                if (c.getInt(1) == 1) mine[mid] = e
            }
        }
        d.q("SELECT m.id,m.outgoing,m.body,m.ts,m.status,a.id,a.name,a.mime,a.size,COALESCE(a.image,0),COALESCE(a.done,0)," +
            "m.mid,m.reply_mid,COALESCE(m.edited,0),COALESCE(m.deleted,0)," +
            "(SELECT q.body FROM messages q WHERE q.contact_id=m.contact_id AND q.mid=m.reply_mid LIMIT 1)," +
            "(SELECT q.outgoing FROM messages q WHERE q.contact_id=m.contact_id AND q.mid=m.reply_mid LIMIT 1),COALESCE(m.sys,0),COALESCE(m.pinned,0) " +
            "FROM messages m LEFT JOIN attachments a ON a.id=m.att_id " +
            "WHERE m.contact_id=? AND (m.expires=0 OR m.expires>?) ORDER BY m.id",
            arrayOf<Any?>(contactId, System.currentTimeMillis())).use { c ->
            buildList {
                while (c.moveToNext()) {
                    val att = if (c.getString(5) != null) AttInfo(c.getString(5), c.getString(6) ?: "plik", c.getString(7) ?: "", c.getInt(8), c.getInt(9) == 1, c.getInt(10) == 1) else null
                    val mid = c.getString(11)
                    add(Msg(c.getLong(0), c.getInt(1) == 1, c.getString(2) ?: "", c.getLong(3), c.getInt(4) == 1 || c.getInt(4) == 3, c.getInt(4) == 2, att,
                        mid, c.getString(12), c.getString(15), c.getInt(16) == 1, c.getInt(13) == 1, c.getInt(14) == 1,
                        if (mid != null) counts[mid] ?: emptyMap() else emptyMap(), if (mid != null) mine[mid] else null, read = c.getInt(4) == 3, sys = c.getInt(17) == 1, pinned = c.getInt(18) == 1))
                }
            }
        }
    }

    // ---------- Załączniki ----------
    /** Odczyt po kawałkach (okno kursora ma limit rozmiaru wiersza, więc nie trzymamy całości w jednym BLOB-ie). */
    fun attBytes(attId: String): ByteArray = db { d ->
        val total = d.q("SELECT COUNT(*) FROM att_chunks WHERE att_id=?", arrayOf<Any?>(attId)).use { it.moveToFirst(); it.getInt(0) }
        val bo = ByteArrayOutputStream()
        for (i in 0 until total) d.q("SELECT data FROM att_chunks WHERE att_id=? AND idx=?", arrayOf<Any?>(attId, i)).use { if (it.moveToFirst()) bo.write(it.getBlob(0)) }
        bo.toByteArray()
    }

    /** Tworzy załącznik wychodzący i wiadomość (status "oczekuje"). Zwraca id wiadomości. */
    fun addOutgoingAttachment(contactId: Long, m: AttMeta, data: ByteArray, label: String, ttl: Int): Long = db { d ->
        tx(d) {
            d.execSQL("INSERT INTO attachments(id,contact_id,name,mime,size,total,got,image,done) VALUES(?,?,?,?,?,?,?,?,1)",
                arrayOf<Any?>(m.id, contactId, m.name, m.mime, m.size, m.total, m.total, if (m.image) 1 else 0))
            for (i in 0 until m.total) {
                val from = i * ATT_CHUNK
                val to = minOf(data.size, from + ATT_CHUNK)
                d.execSQL("INSERT INTO att_chunks(att_id,idx,data) VALUES(?,?,?)", arrayOf<Any?>(m.id, i, data.copyOfRange(from, to)))
            }
            d.execSQL("INSERT INTO messages(contact_id,outgoing,body,ts,expires,status,att_id,mid) VALUES(?,1,?,?,?,0,?,?)",
                arrayOf<Any?>(contactId, label, System.currentTimeMillis(), expiry(ttl), m.id, m.id))
            d.q("SELECT last_insert_rowid()", none).use { it.moveToFirst(); it.getLong(0) }
        }
    }

    fun discardOutgoingAttachment(msgId: Long, attId: String) = db { d ->
        tx(d) {
            d.execSQL("DELETE FROM messages WHERE id=?", arrayOf<Any?>(msgId))
            d.execSQL("DELETE FROM att_chunks WHERE att_id=?", arrayOf<Any?>(attId))
            d.execSQL("DELETE FROM attachments WHERE id=?", arrayOf<Any?>(attId))
        }
    }

    private fun commitCommon(d: SQLiteDatabase, contactId: Long, state: ByteArray, h: ByteArray) {
        d.execSQL("UPDATE sessions SET state=? WHERE contact_id=?", arrayOf<Any?>(state, contactId))
        d.execSQL("INSERT OR IGNORE INTO seen(contact_id, h) VALUES(?,?)", arrayOf<Any?>(contactId, h))
        d.execSQL("DELETE FROM seen WHERE contact_id=? AND rowid NOT IN (SELECT rowid FROM seen WHERE contact_id=? ORDER BY rowid DESC LIMIT 500)",
            arrayOf<Any?>(contactId, contactId))
    }

    fun commitIncomingMeta(contactId: Long, state: ByteArray, h: ByteArray, m: AttMeta) = db { d ->
        tx(d) {
            commitCommon(d, contactId, state, h)
            d.execSQL("INSERT OR IGNORE INTO attachments(id,contact_id,name,mime,size,total,got,image,done) VALUES(?,?,?,?,?,?,0,?,0)",
                arrayOf<Any?>(m.id, contactId, m.name, m.mime, m.size, m.total, if (m.image) 1 else 0))
        }
    }

    /** Zwraca true, gdy to był ostatni brakujący kawałek (powstała wiadomość z załącznikiem). */
    fun commitIncomingChunk(contactId: Long, state: ByteArray, h: ByteArray, attId: String, idx: Int, data: ByteArray, ttl: Int): Boolean = db { d ->
        tx(d) {
            commitCommon(d, contactId, state, h)
            var complete = false
            val row = d.q("SELECT total,image,name FROM attachments WHERE id=? AND contact_id=? AND done=0", arrayOf<Any?>(attId, contactId)).use {
                if (it.moveToFirst()) Triple(it.getInt(0), it.getInt(1) == 1, it.getString(2) ?: "plik") else null
            }
            if (row != null && idx >= 0 && idx < row.first) {
                d.execSQL("INSERT OR IGNORE INTO att_chunks(att_id,idx,data) VALUES(?,?,?)", arrayOf<Any?>(attId, idx, data))
                val got = d.q("SELECT COUNT(*) FROM att_chunks WHERE att_id=?", arrayOf<Any?>(attId)).use { it.moveToFirst(); it.getInt(0) }
                d.execSQL("UPDATE attachments SET got=? WHERE id=?", arrayOf<Any?>(got, attId))
                if (got >= row.first) {
                    d.execSQL("UPDATE attachments SET done=1 WHERE id=?", arrayOf<Any?>(attId))
                    val label = if (row.second) "🖼 Zdjęcie" else "📎 " + row.third
                    d.execSQL("INSERT INTO messages(contact_id,outgoing,body,ts,expires,status,att_id,mid) VALUES(?,0,?,?,?,1,?,?)",
                        arrayOf<Any?>(contactId, label, System.currentTimeMillis(), expiry(ttl), attId, attId))
                    d.execSQL("UPDATE contacts SET unread=COALESCE(unread,0)+1 WHERE id=?", arrayOf<Any?>(contactId))
                    complete = true
                }
            }
            complete
        }
    }

    // ---------- Reakcje, edycja, usuwanie ----------
    private fun setReactionSql(d: SQLiteDatabase, contactId: Long, mid: String, byMe: Boolean, emoji: String?) {
        if (emoji == null) d.execSQL("DELETE FROM reactions WHERE contact_id=? AND msg_mid=? AND by_me=?", arrayOf<Any?>(contactId, mid, if (byMe) 1 else 0))
        else d.execSQL("INSERT OR REPLACE INTO reactions(contact_id,msg_mid,by_me,emoji) VALUES(?,?,?,?)", arrayOf<Any?>(contactId, mid, if (byMe) 1 else 0, emoji))
    }
    private fun editSql(d: SQLiteDatabase, contactId: Long, mid: String, text: String, outgoing: Boolean) {
        d.execSQL("UPDATE messages SET body=?, edited=1 WHERE contact_id=? AND mid=? AND outgoing=? AND att_id IS NULL AND COALESCE(deleted,0)=0",
            arrayOf<Any?>(text, contactId, mid, if (outgoing) 1 else 0))
    }
    /** Zostawia ślad "wiadomość usunięta" i kasuje treść oraz załącznik. */
    private fun tombstoneSql(d: SQLiteDatabase, contactId: Long, mid: String, outgoing: Boolean) {
        val att = d.q("SELECT att_id FROM messages WHERE contact_id=? AND mid=? AND outgoing=?",
            arrayOf<Any?>(contactId, mid, if (outgoing) 1 else 0)).use { if (it.moveToFirst()) it.getString(0) else null }
        d.execSQL("UPDATE messages SET body='', deleted=1, att_id=NULL, pinned=0 WHERE contact_id=? AND mid=? AND outgoing=?",
            arrayOf<Any?>(contactId, mid, if (outgoing) 1 else 0))
        if (att != null) {
            d.execSQL("DELETE FROM att_chunks WHERE att_id=?", arrayOf<Any?>(att))
            d.execSQL("DELETE FROM attachments WHERE id=?", arrayOf<Any?>(att))
        }
        d.execSQL("DELETE FROM reactions WHERE contact_id=? AND msg_mid=?", arrayOf<Any?>(contactId, mid))
    }

    /** Przypięcie jest wspólne dla obu rozmówców (kto chce, może przypiąć lub odpiąć dowolną wiadomość z rozmowy). */
    fun setPinned(contactId: Long, mid: String, on: Boolean) = db { d ->
        d.execSQL("UPDATE messages SET pinned=? WHERE contact_id=? AND mid=? AND COALESCE(deleted,0)=0", arrayOf<Any?>(if (on) 1 else 0, contactId, mid))
    }
    fun commitIncomingPin(contactId: Long, state: ByteArray, h: ByteArray, mid: String, on: Boolean) = db { d ->
        tx(d) {
            commitCommon(d, contactId, state, h)
            d.execSQL("UPDATE messages SET pinned=? WHERE contact_id=? AND mid=? AND COALESCE(deleted,0)=0", arrayOf<Any?>(if (on) 1 else 0, contactId, mid))
        }
    }

    // ---- ankiety w rozmowach prywatnych: po jednym głosie na uczestnika (zmiana głosu zastępuje poprzedni)
    fun setPollVote(contactId: Long, mid: String, byMe: Boolean, opt: Int) = db { d -> pollVoteSql(d, contactId, mid, byMe, opt) }
    private fun pollVoteSql(d: SQLiteDatabase, contactId: Long, mid: String, byMe: Boolean, opt: Int) {
        d.execSQL("INSERT OR REPLACE INTO poll_votes(contact_id, mid, by_me, opt) VALUES(?,?,?,?)", arrayOf<Any?>(contactId, mid, if (byMe) 1 else 0, opt))
    }
    fun commitIncomingVote(contactId: Long, state: ByteArray, h: ByteArray, mid: String, opt: Int) = db { d ->
        tx(d) { commitCommon(d, contactId, state, h); pollVoteSql(d, contactId, mid, false, opt) }
    }
    /** mid ankiety -> (mój głos, głos rozmówcy). */
    fun pollVotes(contactId: Long): Map<String, Pair<Int?, Int?>> = db { d ->
        val mine = HashMap<String, Int>(); val theirs = HashMap<String, Int>()
        d.q("SELECT mid, by_me, opt FROM poll_votes WHERE contact_id=?", arrayOf<Any?>(contactId)).use { c ->
            while (c.moveToNext()) { if (c.getInt(1) == 1) mine[c.getString(0)] = c.getInt(2) else theirs[c.getString(0)] = c.getInt(2) }
        }
        (mine.keys + theirs.keys).associateWith { mine[it] to theirs[it] }
    }

    fun setReaction(contactId: Long, mid: String, byMe: Boolean, emoji: String?) = db { d -> setReactionSql(d, contactId, mid, byMe, emoji) }
    fun applyEdit(contactId: Long, mid: String, text: String, outgoing: Boolean) = db { d -> editSql(d, contactId, mid, text, outgoing) }
    fun tombstone(contactId: Long, mid: String, outgoing: Boolean) = db { d -> tx(d) { tombstoneSql(d, contactId, mid, outgoing) } }
    /** Usuwa wiadomość tylko u mnie (bez śladu). Osierocone załączniki sprząta sweepExpired. */
    fun deleteLocal(msgRowId: Long) = db { d -> d.execSQL("DELETE FROM messages WHERE id=?", arrayOf<Any?>(msgRowId)) }

    fun commitIncomingReaction(contactId: Long, state: ByteArray, h: ByteArray, mid: String, emoji: String?) = db { d ->
        tx(d) { commitCommon(d, contactId, state, h); setReactionSql(d, contactId, mid, false, emoji) }
    }
    /** Edytować i usuwać można tylko wiadomości, które ten kontakt sam wysłał (outgoing=0). */
    fun commitIncomingEdit(contactId: Long, state: ByteArray, h: ByteArray, mid: String, text: String) = db { d ->
        tx(d) { commitCommon(d, contactId, state, h); editSql(d, contactId, mid, text, false) }
    }
    fun commitIncomingDelete(contactId: Long, state: ByteArray, h: ByteArray, mid: String) = db { d ->
        tx(d) { commitCommon(d, contactId, state, h); tombstoneSql(d, contactId, mid, false) }
    }

    // ---------- Awatary ----------
    fun commitIncomingAvatar(contactId: Long, state: ByteArray, h: ByteArray, bytes: ByteArray?) = db { d ->
        tx(d) {
            commitCommon(d, contactId, state, h)
            d.execSQL("UPDATE contacts SET avatar=? WHERE id=?", arrayOf<Any?>(bytes, contactId))
        }
    }
    fun ownAvatar(): ByteArray? = db { d -> d.q("SELECT avatar FROM profile WHERE id=1", none).use { if (it.moveToFirst()) it.getBlob(0) else null } }
    /** Wymaga istniejącego profilu (profile() tworzy go przy pierwszym użyciu). */
    fun setOwnAvatar(b: ByteArray?) = db { d -> d.execSQL("UPDATE profile SET avatar=? WHERE id=1", arrayOf<Any?>(b)) }
    fun contactAvatar(id: Long): ByteArray? = db { d ->
        d.q("SELECT avatar FROM contacts WHERE id=?", arrayOf<Any?>(id)).use { if (it.moveToFirst()) it.getBlob(0) else null }
    }
    fun contactAvatars(): Map<Long, ByteArray> = db { d ->
        d.q("SELECT id, avatar FROM contacts WHERE avatar IS NOT NULL", none).use { c ->
            buildMap { while (c.moveToNext()) c.getBlob(1)?.let { put(c.getLong(0), it) } }
        }
    }

    // ---------- Kontakty ----------
    fun setPinned(id: Long, v: Boolean) = db { d ->
        d.execSQL("UPDATE contacts SET pinned=? WHERE id=?", arrayOf<Any?>(if (v) 1 else 0, id))
    }
    fun setArchived(id: Long, v: Boolean) = db { d ->
        d.execSQL("UPDATE contacts SET archived=? WHERE id=?", arrayOf<Any?>(if (v) 1 else 0, id))
    }
    /** Szkic nieodesłanej wiadomości — trzymany w zaszyfrowanej bazie, nie w SharedPreferences. */
    fun draft(id: Long): String = db { d ->
        d.q("SELECT draft FROM contacts WHERE id=?", arrayOf<Any?>(id)).use { if (it.moveToFirst()) it.getString(0) ?: "" else "" }
    }
    fun setDraft(id: Long, text: String) = db { d ->
        d.execSQL("UPDATE contacts SET draft=? WHERE id=?", arrayOf<Any?>(text.ifBlank { null }, id))
    }
    fun drafts(): Map<Long, String> = db { d ->
        d.q("SELECT id, draft FROM contacts WHERE draft IS NOT NULL AND draft<>''", none).use { c ->
            buildMap { while (c.moveToNext()) put(c.getLong(0), c.getString(1)) }
        }
    }

    fun setMuted(id: Long, v: Boolean) = db { d ->
        d.execSQL("UPDATE contacts SET muted=?, mute_until=0 WHERE id=?", arrayOf<Any?>(if (v) 1 else 0, id))
    }
    /** Wyciszenie na czas: durationMs = 0 → bezterminowo, -1 → włącz powiadomienia. */
    fun setMutedFor(id: Long, durationMs: Long) = db { d ->
        if (durationMs < 0) d.execSQL("UPDATE contacts SET muted=0, mute_until=0 WHERE id=?", arrayOf<Any?>(id))
        else d.execSQL("UPDATE contacts SET muted=1, mute_until=? WHERE id=?", arrayOf<Any?>(if (durationMs == 0L) 0L else System.currentTimeMillis() + durationMs, id))
    }
    /** Anuluje niewysłaną (lub nieudaną) wiadomość tekstową: usuwa ją z kolejki i z rozmowy. */
    fun cancelOutgoing(msgRowId: Long) = db { d ->
        tx(d) {
            d.execSQL("DELETE FROM outbox WHERE msg_id=?", arrayOf<Any?>(msgRowId))
            d.execSQL("DELETE FROM messages WHERE id=? AND outgoing=1 AND status IN (0,2) AND att_id IS NULL", arrayOf<Any?>(msgRowId))
        }
    }
    fun setVerified(id: Long, v: Boolean) = db { d ->
        d.execSQL("UPDATE contacts SET verified=? WHERE id=?", arrayOf<Any?>(if (v) 1 else 0, id))
    }
    fun rename(id: Long, label: String) = db { d ->
        d.execSQL("UPDATE contacts SET label=? WHERE id=?", arrayOf<Any?>(label.trim().take(40), id))
    }
    /** Usuwa kontakt razem z sesją szyfrowania, kolejką, wiadomościami, reakcjami i załącznikami. */
    fun deleteContact(id: Long) = db { d ->
        tx(d) {
            for (t in listOf("messages", "outbox", "seen", "reactions")) d.execSQL("DELETE FROM $t WHERE contact_id=?", arrayOf<Any?>(id))
            d.execSQL("DELETE FROM att_chunks WHERE att_id IN (SELECT id FROM attachments WHERE contact_id=?)", arrayOf<Any?>(id))
            d.execSQL("DELETE FROM attachments WHERE contact_id=?", arrayOf<Any?>(id))
            d.execSQL("DELETE FROM sessions WHERE contact_id=?", arrayOf<Any?>(id))
            d.execSQL("DELETE FROM contacts WHERE id=?", arrayOf<Any?>(id))
        }
    }
    fun deleteAllMessages() = db { d ->
        tx(d) {
            d.execSQL("DELETE FROM messages")
            d.execSQL("DELETE FROM att_chunks")
            d.execSQL("DELETE FROM attachments")
            d.execSQL("DELETE FROM reactions")
        }
    }
    /** Czyści historię jednej rozmowy, zostawiając kontakt, sesję szyfrowania i dedup (seen). */
    fun clearChat(id: Long) = db { d ->
        tx(d) {
            d.execSQL("DELETE FROM att_chunks WHERE att_id IN (SELECT id FROM attachments WHERE contact_id=?)", arrayOf<Any?>(id))
            d.execSQL("DELETE FROM attachments WHERE contact_id=?", arrayOf<Any?>(id))
            d.execSQL("DELETE FROM reactions WHERE contact_id=?", arrayOf<Any?>(id))
            d.execSQL("DELETE FROM messages WHERE contact_id=?", arrayOf<Any?>(id))
            d.execSQL("UPDATE contacts SET unread=0, draft=NULL WHERE id=?", arrayOf<Any?>(id))
        }
    }
    fun markUnread(id: Long) = db { d -> d.execSQL("UPDATE contacts SET unread=MAX(unread,1) WHERE id=?", arrayOf<Any?>(id)) }
    fun setStarred(msgRowId: Long, v: Boolean) = db { d ->
        d.execSQL("UPDATE messages SET starred=? WHERE id=?", arrayOf<Any?>(if (v) 1 else 0, msgRowId))
    }
    fun starredIds(contactId: Long): Set<Long> = db { d ->
        d.q("SELECT id FROM messages WHERE contact_id=? AND starred=1", arrayOf<Any?>(contactId)).use { c ->
            buildSet { while (c.moveToNext()) add(c.getLong(0)) }
        }
    }
    fun commitIncomingTtl(contactId: Long, state: ByteArray, h: ByteArray, seconds: Int) = db { d ->
        tx(d) {
            commitCommon(d, contactId, state, h)
            d.execSQL("UPDATE contacts SET ttl=? WHERE id=?", arrayOf<Any?>(seconds, contactId))
        }
    }
    /** Odbiorca przeczytał moją wiadomość [mid] — oznacz ją i wszystkie wcześniejsze moje jako przeczytane. */
    fun commitIncomingRead(contactId: Long, state: ByteArray, h: ByteArray, mid: String) = db { d ->
        tx(d) {
            commitCommon(d, contactId, state, h)
            d.execSQL("UPDATE messages SET status=3 WHERE contact_id=? AND outgoing=1 AND status<2 AND id<=" +
                "COALESCE((SELECT id FROM messages WHERE contact_id=? AND outgoing=1 AND mid=?),0)", arrayOf<Any?>(contactId, contactId, mid))
        }
    }
    fun lastReceipt(id: Long): String? = db { d ->
        d.q("SELECT rcpt FROM contacts WHERE id=?", arrayOf<Any?>(id)).use { if (it.moveToFirst()) it.getString(0) else null }
    }
    fun setLastReceipt(id: Long, mid: String) = db { d -> d.execSQL("UPDATE contacts SET rcpt=? WHERE id=?", arrayOf<Any?>(mid, id)) }
    fun setPsent(id: Long) = db { d -> d.execSQL("UPDATE contacts SET psent=1 WHERE id=?", arrayOf<Any?>(id)) }
    fun markRead(id: Long) = db { d -> d.execSQL("UPDATE contacts SET unread=0 WHERE id=?", arrayOf<Any?>(id)) }

    // ---------- Profil ----------
    fun profile(): Profile = db { d ->
        d.q("SELECT nick,color,emoji,about FROM profile WHERE id=1", none).use {
            if (it.moveToFirst()) Profile(it.getString(0) ?: "", it.getInt(1), it.getString(2) ?: "", it.getString(3) ?: "") else null
        } ?: run {
            val rnd = SecureRandom()
            val p = Profile("Anon-" + "%04X".format(rnd.nextInt(0x10000)), rnd.nextInt(8), "", "")
            d.execSQL("INSERT OR REPLACE INTO profile(id,nick,color,emoji,about) VALUES(1,?,?,?,?)", arrayOf<Any?>(p.nick, p.color, p.emoji, p.about))
            p
        }
    }
    fun saveProfile(p: Profile) = db { d ->
        d.execSQL("INSERT OR IGNORE INTO profile(id,nick,color,emoji,about) VALUES(1,'',0,'','')")
        d.execSQL("UPDATE profile SET nick=?, color=?, emoji=?, about=? WHERE id=1", arrayOf<Any?>(p.nick, p.color, p.emoji, p.about))
    }
    /** Profil odebrany od kontaktu. Nazwa kontaktu zmienia się tylko, jeśli użytkownik nie nadał własnej. */
    fun applyProfile(id: Long, p: Profile) = db { d ->
        val row = d.q("SELECT label, COALESCE(nick,'') FROM contacts WHERE id=?", arrayOf<Any?>(id)).use {
            if (it.moveToFirst()) it.getString(0) to it.getString(1) else null
        } ?: return@db
        val label = if (row.first.startsWith("Znajomy ") || row.first == row.second) p.nick.ifBlank { row.first } else row.first
        d.execSQL("UPDATE contacts SET nick=?, color=?, emoji=?, about=?, label=? WHERE id=?",
            arrayOf<Any?>(p.nick, p.color, p.emoji, p.about, label, id))
    }

    /** Znikające wiadomości: usuwa wygasłe (secure_delete zeruje je w pliku). */
    fun sweepExpired() = db { d ->
        d.execSQL("DELETE FROM messages WHERE expires>0 AND expires<?", arrayOf<Any?>(System.currentTimeMillis()))
        // załączniki, do których nie ma już wiadomości (ukończone), znikają razem z nimi
        d.execSQL("DELETE FROM att_chunks WHERE att_id IN (SELECT id FROM attachments WHERE done=1 AND id NOT IN (SELECT att_id FROM messages WHERE att_id IS NOT NULL))")
        d.execSQL("DELETE FROM attachments WHERE done=1 AND id NOT IN (SELECT att_id FROM messages WHERE att_id IS NOT NULL)")
    }

    // ---------- Grupy (model: każdy członek dostaje osobną, uwierzytelnioną ramkę przez swoją sesję 1:1) ----------
    private fun groupFromCursor(c: android.database.Cursor) = Group(
        c.getString(0), c.getString(1) ?: "", (c.getString(2) ?: "").split(',').filter { it.isNotEmpty() },
        c.getInt(3), c.getInt(4) == 1, c.getString(5), c.getLong(6))
    private val groupCols = "gid,name,members,COALESCE(unread,0),COALESCE(muted,0)," +
        "(SELECT body FROM group_msgs m WHERE m.gid=chat_groups.gid ORDER BY m.id DESC LIMIT 1)," +
        "COALESCE((SELECT ts FROM group_msgs m WHERE m.gid=chat_groups.gid ORDER BY m.id DESC LIMIT 1),ts)"

    fun groups(): List<Group> = db { d ->
        d.q("SELECT $groupCols FROM chat_groups ORDER BY 7 DESC", none).use { c -> buildList { while (c.moveToNext()) add(groupFromCursor(c)) } }
    }
    fun group(gid: String): Group? = db { d ->
        d.q("SELECT $groupCols FROM chat_groups WHERE gid=?", arrayOf<Any?>(gid)).use { if (it.moveToFirst()) groupFromCursor(it) else null }
    }
    fun createGroup(gid: String, name: String, members: List<String>) = db { d ->
        d.execSQL("INSERT OR IGNORE INTO chat_groups(gid,name,members,ts) VALUES(?,?,?,?)",
            arrayOf<Any?>(gid, name, members.joinToString(","), System.currentTimeMillis()))
    }
    fun groupMessages(gid: String): List<GMsg> = db { d ->
        d.q("SELECT id,sender,body,ts FROM group_msgs WHERE gid=? ORDER BY id", arrayOf<Any?>(gid)).use { c ->
            buildList { while (c.moveToNext()) add(GMsg(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3))) }
        }
    }
    fun addOutgoingGroupMsg(gid: String, mid: String, body: String) = db { d ->
        d.execSQL("INSERT OR IGNORE INTO group_msgs(gid,sender,body,ts,mid) VALUES(?,'',?,?,?)", arrayOf<Any?>(gid, body, System.currentTimeMillis(), mid))
    }
    fun markGroupRead(gid: String) = db { d -> d.execSQL("UPDATE chat_groups SET unread=0 WHERE gid=?", arrayOf<Any?>(gid)) }
    fun setGroupMuted(gid: String, v: Boolean) = db { d -> d.execSQL("UPDATE chat_groups SET muted=? WHERE gid=?", arrayOf<Any?>(if (v) 1 else 0, gid)) }
    fun deleteGroup(gid: String) = db { d ->
        tx(d) {
            d.execSQL("DELETE FROM group_msgs WHERE gid=?", arrayOf<Any?>(gid))
            d.execSQL("DELETE FROM chat_groups WHERE gid=?", arrayOf<Any?>(gid))
        }
    }

    /**
     * Zapis przychodzącej wiadomości grupowej. Zasady bezpieczeństwa:
     *  - ramka musi wymieniać mnie wśród członków,
     *  - nadawca musi być na liście członków; dla znanej już grupy — także na JEJ zapisanej liście,
     *    inaczej nikt spoza grupy nie podmieni nazwy ani składu,
     *  - stan sesji 1:1 i tak się przesuwa (commitCommon), a ramka jest potwierdzana.
     * Zwraca true, gdy zapisano nową wiadomość i grupa nie jest wyciszona (można powiadomić).
     */
    fun commitIncomingGroup(contactId: Long, state: ByteArray, h: ByteArray, g: GroupFrame, senderSid: String, mySid: String): Boolean = db { d ->
        var notify = false
        tx(d) {
            commitCommon(d, contactId, state, h)
            if (mySid !in g.members || senderSid !in g.members) return@tx
            val existing = d.q("SELECT members, COALESCE(muted,0) FROM chat_groups WHERE gid=?", arrayOf<Any?>(g.gid)).use {
                if (it.moveToFirst()) (it.getString(0) ?: "").split(',') to (it.getInt(1) == 1) else null
            }
            if (existing == null) {
                d.execSQL("INSERT INTO chat_groups(gid,name,members,ts) VALUES(?,?,?,?)",
                    arrayOf<Any?>(g.gid, g.name, g.members.joinToString(","), System.currentTimeMillis()))
            } else {
                if (senderSid !in existing.first) return@tx
                d.execSQL("UPDATE chat_groups SET name=?, members=? WHERE gid=?", arrayOf<Any?>(g.name, g.members.joinToString(","), g.gid))
            }
            d.execSQL("INSERT OR IGNORE INTO group_msgs(gid,sender,body,ts,mid) VALUES(?,?,?,?,?)",
                arrayOf<Any?>(g.gid, senderSid, g.text, System.currentTimeMillis(), g.mid))
            val added = d.q("SELECT changes()", none).use { it.moveToFirst(); it.getInt(0) } > 0
            if (added) {
                d.execSQL("UPDATE chat_groups SET unread=COALESCE(unread,0)+1, ts=? WHERE gid=?", arrayOf<Any?>(System.currentTimeMillis(), g.gid))
                notify = existing?.second != true
            }
        }
        notify
    }

    // ---------- Notatki do siebie, wyszukiwanie globalne, oznaczanie ----------
    /** „Notatki” to lokalna grupa tylko dla mnie (nic nie wychodzi do sieci). */
    fun ensureNotes() = db { d ->
        d.execSQL("INSERT OR IGNORE INTO chat_groups(gid,name,members,ts) VALUES(?,?,?,?)", arrayOf<Any?>(NOTES_GID, "📝 Notatki do siebie", "", 0L))
    }
    fun markAllRead() = db { d ->
        tx(d) { d.execSQL("UPDATE contacts SET unread=0"); d.execSQL("UPDATE chat_groups SET unread=0") }
    }
    /** Wyszukiwanie po treści wszystkich rozmów 1:1 (bez usuniętych i wygasłych). */
    fun searchAll(query: String, limit: Int = 30): List<SearchHit> = db { d ->
        val q = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        d.q("SELECT m.contact_id, c.label, m.body, m.ts FROM messages m JOIN contacts c ON c.id=m.contact_id " +
            "WHERE m.body LIKE ? ESCAPE '\\' AND COALESCE(m.deleted,0)=0 AND COALESCE(m.sys,0)=0 AND (m.expires=0 OR m.expires>?) ORDER BY m.id DESC LIMIT ?",
            arrayOf<Any?>("%$q%", System.currentTimeMillis(), limit)).use { c ->
            buildList { while (c.moveToNext()) add(SearchHit(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3))) }
        }
    }

    // ---------- Etap 6: wygląd rozmowy, ochrona zrzutów, obecność, komunikaty systemowe ----------
    /** Zapisuje wspólną personalizację rozmowy (motyw, emoji, pseudonimy). */
    fun setChatLook(id: Long, theme: Int, emoji: String, chatNick: String, myNick: String) = db { d ->
        d.execSQL("UPDATE contacts SET theme=?, qemoji=?, cnick=?, mynick=? WHERE id=?",
            arrayOf<Any?>(theme.coerceIn(0, 7), emoji, chatNick, myNick, id))
    }
    /** Tryb zrzutów ekranu w tej rozmowie: 0 = jak w Ustawieniach, 1 = blokuj, 2 = zezwalaj i powiadamiaj. */
    fun setCapMode(id: Long, mode: Int) = db { d ->
        d.execSQL("UPDATE contacts SET capmode=? WHERE id=?", arrayOf<Any?>(mode.coerceIn(0, 2), id))
    }
    fun commitIncomingLook(contactId: Long, state: ByteArray, h: ByteArray, theme: Int, emoji: String, forMe: String, forThem: String) = db { d ->
        tx(d) {
            commitCommon(d, contactId, state, h)
            // "forMe" = jak rozmówca nazywa MNIE, "forThem" = jak nazywa siebie
            d.execSQL("UPDATE contacts SET theme=?, qemoji=?, mynick=?, cnick=? WHERE id=?",
                arrayOf<Any?>(theme.coerceIn(0, 7), emoji, forMe, forThem, contactId))
        }
    }
    /** Wiersz systemowy w rozmowie (np. „zrobił zrzut ekranu”). Nie liczy się jako nieprzeczytana wiadomość. */
    fun addSystemMessage(contactId: Long, text: String, outgoing: Boolean) = db { d ->
        d.execSQL("INSERT INTO messages(contact_id,outgoing,body,ts,expires,status,sys) VALUES(?,?,?,?,0,1,1)",
            arrayOf<Any?>(contactId, if (outgoing) 1 else 0, text, System.currentTimeMillis()))
    }
    fun commitIncomingNotice(contactId: Long, state: ByteArray, h: ByteArray, text: String) = db { d ->
        tx(d) {
            commitCommon(d, contactId, state, h)
            d.execSQL("INSERT INTO messages(contact_id,outgoing,body,ts,expires,status,sys) VALUES(?,0,?,?,0,1,1)",
                arrayOf<Any?>(contactId, text, System.currentTimeMillis()))
            d.execSQL("UPDATE contacts SET unread=COALESCE(unread,0)+1 WHERE id=?", arrayOf<Any?>(contactId))
        }
    }
    /** Stan obecności rozmówcy: 0 = ukryty/nieznany, 1 = aktywny (aplikacja na pierwszym planie), 2 = online w tle. */
    fun setPeerPresence(id: Long, state: Int, activeTs: Long) = db { d ->
        val now = System.currentTimeMillis()
        if (state == 1) d.execSQL("UPDATE contacts SET peer_state=1, peer_seen=?, peer_active=? WHERE id=?", arrayOf<Any?>(now, now, id))
        else if (state == 2) d.execSQL("UPDATE contacts SET peer_state=2, peer_seen=?, peer_active=MAX(COALESCE(peer_active,0),?) WHERE id=?", arrayOf<Any?>(now, activeTs, id))
        else d.execSQL("UPDATE contacts SET peer_state=0, peer_seen=0, peer_active=0 WHERE id=?", arrayOf<Any?>(id))
    }
    /** Każda udana, uwierzytelniona wymiana (ACK wiadomości) dowodzi, że rozmówca jest osiągalny. */
    fun touchSeen(id: Long) = db { d ->
        d.execSQL("UPDATE contacts SET peer_seen=? WHERE id=? AND peer_state<>0", arrayOf<Any?>(System.currentTimeMillis(), id))
    }

    // ---------- Blokowanie, pamięć ----------
    fun setBlocked(id: Long, v: Boolean) = db { d -> d.execSQL("UPDATE contacts SET blocked=? WHERE id=?", arrayOf<Any?>(if (v) 1 else 0, id)) }

    /** (liczba plików, łączny rozmiar w bajtach) ukończonych załączników. */
    fun attachmentStats(): Pair<Int, Long> = db { d ->
        d.q("SELECT COUNT(*), COALESCE(SUM(size),0) FROM attachments WHERE done=1", none).use { if (it.moveToFirst()) it.getInt(0) to it.getLong(1) else 0 to 0L }
    }
    /** Usuwa wszystkie załączniki z telefonu; wiadomości zostają z adnotacją. */
    fun purgeAttachments() = db { d ->
        tx(d) {
            d.execSQL("UPDATE messages SET body='📎 Załącznik usunięty z telefonu', att_id=NULL WHERE att_id IS NOT NULL")
            d.execSQL("DELETE FROM att_chunks WHERE att_id IN (SELECT id FROM attachments WHERE done=1)")
            d.execSQL("DELETE FROM attachments WHERE done=1")
        }
    }
}
