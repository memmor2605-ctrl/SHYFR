package com.shyfr.app.account

import android.content.Context
import com.shyfr.app.crypto.Kdf
import com.shyfr.app.feed.RelayClient
import com.shyfr.app.feed.RelayException
import com.shyfr.app.net.NodeRuntime
import com.shyfr.app.net.NodeService
import com.shyfr.app.net.NodeState
import com.shyfr.app.net.TorAndroidTransport
import com.shyfr.app.session.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Odzyskiwanie konta przez login i hasło. Do przekaźnika trafia wyłącznie zaszyfrowana koperta z kluczem głównym konta
 * (patrz [AccountCrypto] i relay/README.md). Zakres: klucz główny, a z niego tożsamości społecznościowe i klucze społeczności.
 * NIE obejmuje kontaktów, rozmów ani załączników: te zostają tylko na telefonie. Koperta idzie na przekaźnik domyślny wbudowany
 * w wersję, bo nowy telefon nie zna żadnego innego adresu.
 */
object AccountSync {
    sealed interface Restore {
        class Ok(val master: ByteArray, val lookup: String) : Restore
        data object NotFound : Restore
        class Failed(val message: String) : Restore
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private fun sp(c: Context) = c.getSharedPreferences("shyfr_account", Context.MODE_PRIVATE)

    fun enabledAt(c: Context): Long = sp(c).getLong("at", 0)
    private fun markActive(c: Context, lookup: String) = sp(c).edit().putLong("at", System.currentTimeMillis()).putString("lookup", lookup).apply()
    private fun markOff(c: Context) = sp(c).edit().clear().apply()

    private fun host(c: Context): String? = Prefs.defaultRelay() ?: Prefs.relayOnion(c)
    private fun client(c: Context) = RelayClient(c, host(c))

    /** Argon2id (ok. 1 s). Uruchamiać poza wątkiem interfejsu. */
    fun keys(login: String, password: CharArray): AccountCrypto.Keys {
        val root = Kdf.derive("account:" + login, password, AccountCrypto.saltFor(login))
        try { return AccountCrypto.keysFromRoot(root) } finally { root.fill(0) }
    }

    private suspend fun upload(c: Context, k: AccountCrypto.Keys, master: ByteArray) {
        try {
            client(c).act("account.put", k.signing, "lookup" to k.lookup, "ver" to "1", "blob" to AccountCrypto.seal(master, k, 1))
        } catch (e: RelayException) {
            if (e.code != 409) throw e   // 409: ta sama koperta już leży na przekaźniku
        }
        markActive(c, k.lookup)
    }

    /** Po założeniu konta: wysyła kopertę, gdy tylko Tor będzie gotowy (ponawia przez ok. 15 minut). Zeruje klucze po wszystkim. */
    fun protectInBackground(c: Context, k: AccountCrypto.Keys, master: ByteArray) {
        val app = c.applicationContext
        scope.launch {
            try {
                repeat(60) {
                    if (NodeService.state.value is NodeState.Online && NodeRuntime.transport != null) {
                        try { upload(app, k, master); return@launch } catch (e: CancellationException) { throw e } catch (_: Exception) { }
                    }
                    delay(15_000)
                }
            } finally { k.wipe(); master.fill(0) }
        }
    }

    /** Włączenie lub odświeżenie z Ustawień. Zwraca opis błędu albo null. Wymaga działającego połączenia. */
    suspend fun enableNow(c: Context, login: String, password: CharArray, master: ByteArray): String? {
        AccountCrypto.strengthProblem(password, login)?.let { return it + " Zmień hasło konta, aby chronić kopertę online." }
        if (host(c) == null) return "Ta wersja SHYFR nie ma wbudowanego serwera odzyskiwania kont."
        if (NodeService.state.value !is NodeState.Online) return "Poczekaj, aż połączenie będzie aktywne, i spróbuj ponownie."
        val k = withContext(Dispatchers.Default) { keys(login, password) }
        return try { upload(c, k, master); null }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { e.message ?: "Nie udało się wysłać koperty." }
        finally { k.wipe() }
    }

    suspend fun disable(c: Context, login: String, password: CharArray): String? {
        val k = withContext(Dispatchers.Default) { keys(login, password) }
        return try { client(c).act("account.delete", k.signing, "lookup" to k.lookup); markOff(c); null }
        catch (e: CancellationException) { throw e }
        catch (e: RelayException) { if (e.code == 404) { markOff(c); null } else e.message }
        catch (e: Exception) { e.message ?: "Nie udało się usunąć koperty." }
        finally { k.wipe() }
    }

    /**
     * Nowy telefon: przed założeniem konta nie ma jeszcze klucza węzła, więc na czas pobrania koperty uruchamiamy sam klient Tora
     * i zatrzymujemy go przed normalnym startem węzła.
     */
    suspend fun restore(c: Context, login: String, password: CharArray, onStatus: (String) -> Unit): Restore {
        if (host(c) == null) return Restore.Failed("Ta wersja SHYFR nie ma wbudowanego serwera odzyskiwania kont.")
        val k = withContext(Dispatchers.Default) { keys(login, password) }
        val t = TorAndroidTransport(c.applicationContext)
        NodeRuntime.transport = t
        try {
            onStatus("Łączenie z siecią…")
            t.start { p -> onStatus("Łączenie z siecią $p%") }
            onStatus("Szukam konta…")
            val o = client(c).act("account.get", k.signing, "lookup" to k.lookup)
            val master = AccountCrypto.open(o.getString("blob"), k, o.getLong("ver")) ?: return Restore.NotFound
            return Restore.Ok(master, k.lookup)
        } catch (e: CancellationException) { throw e
        } catch (e: RelayException) { return if (e.code == 404) Restore.NotFound else Restore.Failed(e.message ?: "Błąd połączenia.")
        } catch (e: Exception) { return Restore.Failed("Nie udało się połączyć. Sprawdź internet i spróbuj ponownie.")
        } finally {
            k.wipe()
            runCatching { t.stop() }
            NodeRuntime.transport = null
        }
    }

    fun markRestored(c: Context, lookup: String) = markActive(c, lookup)
}
