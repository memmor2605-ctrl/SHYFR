package com.shyfr.app.ui

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.social.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun IdentityKind.icon(): ImageVector = when (this) { IdentityKind.PUBLIC -> Ic.Person; IdentityKind.PRIVATE -> Ic.Lock; IdentityKind.ANON -> Ic.Shield }
private fun IdentityKind.hint(): String = when (this) {
    IdentityKind.PUBLIC -> "Widoczna w wyszukiwaniu, każdy może ją obserwować."
    IdentityKind.PRIVATE -> "Obserwujący tylko za Twoją zgodą."
    IdentityKind.ANON -> "Osobny klucz i pseudonim. Bez publicznego powiązania z Twoimi innymi tożsamościami."
}

/** Przełącznik tożsamości: zawsze widoczny nad profilem; dotknięcie otwiera listę. Przełączanie nie wymaga wylogowania. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdentityChip(ctx: Context, modifier: Modifier = Modifier) {
    var version by remember { mutableIntStateOf(0) }
    val active by SocialState.active.collectAsState()
    val list by produceState(emptyList<SocialIdentity>(), version) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val st = SocialStore(ctx)
                val nick = runCatching { com.shyfr.app.vault.Store(ctx).profile().nick }.getOrDefault("")
                st.ensureDefaults(nick); st.identities()
            }.getOrDefault(emptyList())
        }
    }
    val cur = list.firstOrNull { it.id == active } ?: list.firstOrNull()
    var open by remember { mutableStateOf(false) }
    var creating by remember { mutableStateOf<IdentityKind?>(null) }
    var renaming by remember { mutableStateOf<SocialIdentity?>(null) }
    var deleting by remember { mutableStateOf<SocialIdentity?>(null) }
    val scope = rememberCoroutineScope()
    fun io(block: () -> Unit) = scope.launch(Dispatchers.IO) { runCatching(block); version++ }

    if (cur != null) Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, ShLine, RoundedCornerShape(12.dp))
            .clickable { open = true }.a11y("Przełącz tożsamość").padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconAvatar(cur.kind.icon(), 36.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(cur.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Tożsamość ${cur.kind.label.lowercase()}", fontSize = 12.sp, color = ShMuted)
        }
        Icon24(Ic.Down, ShMuted, 20.dp)
    }

    if (open) ModalBottomSheet(onDismissRequest = { open = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = ShSurface) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Text("Tożsamości", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Każda ma własny klucz, obserwujących i szkice. Wpisy i obserwowanie przez tożsamości dojdą w kolejnym etapie.", fontSize = 12.sp, color = ShMuted)
            Spacer(Modifier.height(8.dp))
            list.forEach { i ->
                val sel = i.id == cur?.id
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { io { SocialStore(ctx).setActive(i.id) }; open = false }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconAvatar(i.kind.icon(), 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(i.name, fontSize = 15.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(i.kind.label, fontSize = 12.sp, color = ShMuted)
                    }
                    if (sel) Icon24(Ic.Check, MaterialTheme.colorScheme.primary, 20.dp)
                    IconTap(Ic.Edit, "Zmień nazwę", ShMuted, 40.dp, 18.dp) { renaming = i }
                    if (list.size > 1) IconTap(Ic.Delete, "Usuń tożsamość", ShMuted, 40.dp, 18.dp) { deleting = i }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = ShLine, thickness = 0.5.dp)
            Text("Dodaj tożsamość", fontSize = 13.sp, color = ShMuted, fontWeight = FontWeight.Medium)
            IdentityKind.entries.forEach { k ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { creating = k; open = false }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon24(Ic.Add, ShSilver, 20.dp, Modifier.padding(horizontal = 10.dp))
                    Column {
                        Text(k.label, fontSize = 15.sp)
                        Text(k.hint(), fontSize = 12.sp, color = ShMuted)
                    }
                }
            }
        }
    }

    creating?.let { kind ->
        var name by remember(kind) { mutableStateOf(if (kind == IdentityKind.ANON) Pseudonym.random() else "") }
        AlertDialog(
            onDismissRequest = { creating = null },
            title = { Text("Nowa tożsamość: ${kind.label.lowercase()}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it.take(40) }, label = { Text(if (kind == IdentityKind.ANON) "Pseudonim" else "Nazwa") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (kind == IdentityKind.ANON) TextButton(onClick = { name = Pseudonym.random() }) { Text("Losuj pseudonim") }
                    Text(kind.hint(), fontSize = 12.sp, color = ShMuted)
                }
            },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    val n = name; creating = null
                    io { val c = SocialStore(ctx).create(kind, n); SocialStore(ctx).setActive(c.id) }
                }) { Text("Utwórz") }
            },
            dismissButton = { TextButton(onClick = { creating = null }) { Text("Anuluj") } }
        )
    }
    renaming?.let { i ->
        var name by remember(i.id) { mutableStateOf(i.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Zmień nazwę") },
            text = { OutlinedTextField(name, { name = it.take(40) }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { val n = name; renaming = null; io { SocialStore(ctx).rename(i.id, n) } }) { Text("Zapisz") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Anuluj") } }
        )
    }
    deleting?.let { i ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Usunąć tożsamość?") },
            text = { Text("„${i.name}” zniknie z listy razem z jej szkicami i relacjami zapisanymi na tym telefonie. Wpisy już opublikowane przez tę tożsamość zostają w sieci. Klucz nie zostanie użyty ponownie.", fontSize = 14.sp) },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    io {
                        val st = SocialStore(ctx)
                        if (st.delete(i.id) && st.active() == i.id) st.identities().firstOrNull()?.let { st.setActive(it.id) }
                    }
                }) { Text("Usuń", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Anuluj") } }
        )
    }
}
