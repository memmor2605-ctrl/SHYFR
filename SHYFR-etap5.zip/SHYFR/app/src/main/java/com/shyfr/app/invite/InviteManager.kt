package com.shyfr.app.invite

import com.shyfr.app.crypto.Keys

/**
 * Aktywne zaproszenia. Tylko w pamięci RAM: po zablokowaniu konta lub zamknięciu aplikacji znikają.
 * Zaproszenie wygasa: (1) po 15 min braku aktywności, (2) po użyciu, (3) po 5 błędnych próbach.
 */
object InviteManager {
    const val IDLE_MS = 15 * 60 * 1000L
    private const val MAX_FAILS = 5

    private class Inv(val secret: ByteArray, var last: Long, val idle: Long, var fails: Int = 0)
    private val invites = HashMap<String, Inv>()

    fun idOf(secret: ByteArray): ByteArray = Keys.sha256(secret).copyOf(16)
    private fun key(id: ByteArray) = id.joinToString("") { "%02x".format(it) }

    /** [idleMs]: po jakim czasie bez aktywności zaproszenie wygasa (domyślnie 15 min; zaproszenia z próśb o kontakt są dłuższe). */
    @Synchronized fun create(idleMs: Long = IDLE_MS): ByteArray {
        purge()
        val secret = ByteArray(32).also { java.security.SecureRandom().nextBytes(it) }
        invites[key(idOf(secret))] = Inv(secret, System.currentTimeMillis(), idleMs)
        return secret
    }

    /** Aktywność użytkownika przedłuża ważność. */
    @Synchronized fun touch(id: ByteArray) { invites[key(id)]?.last = System.currentTimeMillis() }

    /** Ile ms zostało; 0 gdy wygasło, zostało użyte lub usunięte. */
    @Synchronized fun remainingMs(id: ByteArray): Long {
        purge()
        val inv = invites[key(id)] ?: return 0
        return (inv.idle - (System.currentTimeMillis() - inv.last)).coerceAtLeast(0)
    }

    /** Atomowo: sprawdza dowód znajomości sekretu i unieważnia zaproszenie. Zwraca sekret lub null. */
    @Synchronized fun tryJoin(id: ByteArray, verify: (ByteArray) -> Boolean): ByteArray? {
        purge()
        val k = key(id)
        val inv = invites[k] ?: return null
        if (!verify(inv.secret)) {
            if (++inv.fails >= MAX_FAILS) invites.remove(k)?.secret?.fill(0)
            return null
        }
        invites.remove(k)
        return inv.secret
    }

    @Synchronized fun clear() { invites.values.forEach { it.secret.fill(0) }; invites.clear() }

    private fun purge() {
        val now = System.currentTimeMillis()
        invites.entries.removeIf { (_, v) -> (now - v.last > v.idle).also { if (it) v.secret.fill(0) } }
    }
}
