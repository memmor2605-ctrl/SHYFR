package com.shyfr.app.ui

import android.content.Context
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.nostr.*
import com.shyfr.app.social.IdentityKind
import com.shyfr.app.social.SocialIdentity
import com.shyfr.app.social.SocialState
import com.shyfr.app.social.SocialStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val WARN_ALL = "„Wszystko” to niefiltrowany strumień z całej publicznej sieci. Mogą pojawić się treści nieodpowiednie i spam. SHYFR nie moderuje cudzych serwerów."

/** Publiczny feed. Połączenia z serwerami sieci dobiera i podtrzymuje aplikacja, użytkownik niczego nie konfiguruje. */
@Composable
fun PublicFeed(ctx: Context) {
    val mgr = remember { NostrHub.acquire(ctx) }
    DisposableEffect(Unit) { onDispose { NostrHub.release(ctx) } }
    val repo = remember { NostrFeedRepo(ctx, mgr) }
    val status by mgr.status.collectAsState()
    val activeId by SocialState.active.collectAsState()
    val scope = rememberCoroutineScope()

    var identity by remember { mutableStateOf<SocialIdentity?>(null) }
    var me by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(FeedKind.SHYFR) }
    var notes by remember { mutableStateOf<List<NostrEvent>>(emptyList()) }
    var names by remember { mutableStateOf<Map<String, NostrProfile>>(emptyMap()) }
    var reacts by remember { mutableStateOf<Map<String, Reactions>>(emptyMap()) }
    var follows by remember { mutableStateOf<Set<String>>(emptySet()) }
    var loading by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var canMore by remember { mutableStateOf(false) }
    var loadedOnce by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var posting by remember { mutableStateOf(false) }
    var replyTarget by remember { mutableStateOf<NostrEvent?>(null) }
    var askAll by remember { mutableStateOf(false) }

    suspend fun enrich(list: List<NostrEvent>, id: SocialIdentity) {
        names = names + repo.profiles(list.map { it.pubkey })
        reacts = reacts + repo.reactions(list.map { it.id }, me)
        follows = withContext(Dispatchers.IO) { list.map { it.pubkey }.filter { repo.isFollowing(id, it) }.toSet() }
    }

    LaunchedEffect(tab, activeId, tick) {
        loading = true
        try {
            val id = withContext(Dispatchers.IO) { SocialStore(ctx).ensureDefaults("") }
            identity = id; me = repo.pubOf(id)
            val page = repo.feed(tab, id)
            notes = page.notes; canMore = page.notes.size >= 10
            info = when {
                tab == FeedKind.FOLLOWING && page.asked == 0 && page.notes.isEmpty() -> null
                page.asked == 0 -> "Sieć publiczna jest chwilowo niedostępna. Łączę ponownie…"
                else -> null
            }
            enrich(page.notes, id)
        } catch (e: CancellationException) { throw e } catch (e: Exception) { info = "Nie udało się wczytać wpisów. Spróbuję ponownie." }
        loadedOnce = true
        loading = false
    }
    // Automatyczne ponawianie, gdy nic się nie wczytało (np. sieć dopiero się łączy).
    LaunchedEffect(Unit) { while (true) { delay(20_000); if (notes.isEmpty() && !loading && tab != FeedKind.FOLLOWING) tick++ } }
    LaunchedEffect(status.state) { if (status.state == NetState.ONLINE && notes.isEmpty() && !loading && loadedOnce && tab != FeedKind.FOLLOWING) tick++ }

    val canPost = identity?.kind != IdentityKind.PRIVATE
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(16.dp)) {
                OutlinedTextField(text, { text = it.take(2000) }, enabled = canPost && !posting, placeholder = { Text("Co nowego?") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 6)
                Spacer(Modifier.height(6.dp))
                identity?.let { id ->
                    Text(if (canPost) "Publikujesz jako: ${id.name} (${id.kind.label.lowercase()})" else "Tożsamość prywatna nie publikuje w sieci publicznej. Wpisy tylko dla obserwujących wymagają szyfrowania, którego jeszcze nie ma. Przełącz na publiczną lub anonimową w Profilu.",
                        fontSize = 12.sp, color = ShMuted)
                }
                Text("Wpis jest publiczny: serwery sieci mogą go odczytać. Tor ukrywa tylko Twój adres IP.", fontSize = 11.sp, color = ShMuted)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(info ?: if (status.state == NetState.CONNECTING) "Łączenie…" else "", fontSize = 12.sp, color = ShMuted, modifier = Modifier.weight(1f))
                    Button(enabled = canPost && !posting && text.isNotBlank() && identity != null, onClick = {
                        val id = identity ?: return@Button
                        posting = true
                        scope.launch {
                            try {
                                val p = repo.publishNote(id, text)
                                if (p.result.success) { text = ""; info = "Opublikowano."; notes = listOf(p.event) + notes; me = p.event.pubkey }
                                else info = if (p.result.noConnection) "Sieć publiczna jest chwilowo niedostępna. Spróbuj za chwilę." else "Nie udało się opublikować. Spróbuj ponownie."
                            } catch (e: CancellationException) { throw e }
                            catch (e: IllegalArgumentException) { info = e.message }
                            catch (e: Exception) { info = "Nie udało się opublikować. Spróbuj ponownie." }
                            posting = false
                        }
                    }) { Text(if (posting) "Wysyłanie…" else "Opublikuj") }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillTab("SHYFR", tab == FeedKind.SHYFR) { tab = FeedKind.SHYFR }
                    PillTab("Obserwowani", tab == FeedKind.FOLLOWING) { tab = FeedKind.FOLLOWING }
                    PillTab("Wszystko", tab == FeedKind.ALL) { if (tab != FeedKind.ALL) askAll = true }
                    PillTab("Odśwież", false) { tick++ }
                }
            }
            HorizontalDivider(color = ShLine, thickness = 0.5.dp)
        }
        if (notes.isEmpty() && !loading) item {
            Text(if (tab == FeedKind.FOLLOWING) "Nikogo jeszcze nie obserwujesz. Wybierz „Obserwuj” przy wpisie w zakładce SHYFR." else "Brak wpisów do pokazania.", color = ShMuted, modifier = Modifier.padding(24.dp))
        }
        if (loading && notes.isEmpty()) item { Text("Wczytywanie…", color = ShMuted, modifier = Modifier.padding(24.dp)) }
        items(notes, key = { it.id }) { e ->
            NoteRow(e, names[e.pubkey]?.name?.ifBlank { null } ?: (e.pubkey.take(8) + "…"), reacts[e.id], e.pubkey == me, e.pubkey in follows,
                onLike = { scope.launch { try { val id = identity ?: return@launch; if (repo.react(id, e).success) reacts = reacts + (e.id to Reactions((reacts[e.id]?.count ?: 0) + 1, true)) } catch (x: CancellationException) { throw x } catch (_: Exception) { } } },
                onReply = { replyTarget = e },
                onFollow = { scope.launch { try { val id = identity ?: return@launch; val on = e.pubkey !in follows; repo.setFollow(id, e.pubkey, on); follows = if (on) follows + e.pubkey else follows - e.pubkey } catch (x: CancellationException) { throw x } catch (_: Exception) { } } })
        }
        if (canMore && notes.isNotEmpty()) item {
            TextButton(modifier = Modifier.fillMaxWidth(), enabled = !loading, onClick = {
                val id = identity ?: return@TextButton
                loading = true
                scope.launch {
                    try {
                        val page = repo.feed(tab, id, until = notes.last().createdAt - 1)
                        val known = notes.map { it.id }.toSet()
                        val fresh = page.notes.filter { it.id !in known }
                        notes = notes + fresh; canMore = fresh.size >= 5; enrich(fresh, id)
                    } catch (e: CancellationException) { throw e } catch (_: Exception) { info = "Nie udało się wczytać starszych wpisów." }
                    loading = false
                }
            }) { Text("Starsze wpisy") }
        }
    }

    if (askAll) AlertDialog(
        onDismissRequest = { askAll = false }, title = { Text("Strumień niefiltrowany") }, text = { Text(WARN_ALL, fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = { askAll = false; tab = FeedKind.ALL }) { Text("Pokaż") } },
        dismissButton = { TextButton(onClick = { askAll = false }) { Text("Anuluj") } }
    )
    replyTarget?.let { t -> identity?.let { id -> ReplyDialog(repo, id, t, names[t.pubkey]?.name ?: (t.pubkey.take(8) + "…"), canPost) { replyTarget = null } } }
}

@Composable
private fun NoteRow(e: NostrEvent, author: String, r: Reactions?, mine: Boolean, following: Boolean, onLike: () -> Unit, onReply: () -> Unit, onFollow: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(author, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Text(fmtTime(e.createdAt * 1000), fontSize = 12.sp, color = ShMuted)
        }
        Spacer(Modifier.height(4.dp))
        Text(e.content, fontSize = 15.sp, maxLines = 14)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onLike, enabled = r?.mine != true) { Text("Lubię" + (r?.count?.takeIf { it > 0 }?.let { " $it" } ?: ""), fontSize = 13.sp, color = if (r?.mine == true) MaterialTheme.colorScheme.primary else ShMuted) }
            TextButton(onClick = onReply) { Text("Odpowiedz", fontSize = 13.sp, color = ShMuted) }
            if (!mine) TextButton(onClick = onFollow) { Text(if (following) "Obserwujesz" else "Obserwuj", fontSize = 13.sp, color = ShMuted) }
        }
    }
    HorizontalDivider(color = ShLine, thickness = 0.5.dp)
}

@Composable
private fun ReplyDialog(repo: NostrFeedRepo, id: SocialIdentity, note: NostrEvent, author: String, canPost: Boolean, onClose: () -> Unit) {
    var replies by remember { mutableStateOf<List<NostrEvent>?>(null) }
    var names by remember { mutableStateOf<Map<String, NostrProfile>>(emptyMap()) }
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(note.id) {
        try { val r = repo.replies(note); replies = r; names = repo.profiles(r.map { it.pubkey }) }
        catch (e: CancellationException) { throw e } catch (_: Exception) { replies = emptyList() }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Odpowiedzi do: $author", maxLines = 1) },
        text = {
            Column(Modifier.verticalScrollCompat(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(note.content, fontSize = 14.sp, color = ShMuted, maxLines = 4)
                HorizontalDivider(color = ShLine, thickness = 0.5.dp)
                val l = replies
                if (l == null) Text("Wczytywanie…", color = ShMuted)
                else if (l.isEmpty()) Text("Brak odpowiedzi.", color = ShMuted)
                else l.forEach { r -> Column { Text(names[r.pubkey]?.name?.ifBlank { null } ?: (r.pubkey.take(8) + "…"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text(r.content, fontSize = 14.sp) } }
                if (canPost) OutlinedTextField(text, { text = it.take(2000) }, placeholder = { Text("Twoja odpowiedź") }, enabled = !busy, modifier = Modifier.fillMaxWidth())
                msg?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            if (canPost) TextButton(enabled = !busy && text.isNotBlank(), onClick = {
                busy = true; msg = null
                scope.launch {
                    try {
                        val p = repo.publishNote(id, text, note)
                        if (p.result.success) { replies = (replies ?: emptyList()) + p.event; text = "" } else msg = "Nie udało się wysłać odpowiedzi. Spróbuj ponownie."
                    } catch (e: CancellationException) { throw e } catch (_: Exception) { msg = "Nie udało się wysłać odpowiedzi." }
                    busy = false
                }
            }) { Text("Odpowiedz") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Zamknij") } }
    )
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier = this.then(Modifier.verticalScroll(rememberScrollState()))


/** Podgląd stanu sieci publicznej dla programisty: który serwer jest połączony i z jakiego powodu pozostałe nie. */
@Composable
fun NostrDiagDialog(ctx: Context, onClose: () -> Unit) {
    val mgr = remember { NostrHub.acquire(ctx) }
    DisposableEffect(Unit) { onDispose { NostrHub.release(ctx) } }
    val status by mgr.status.collectAsState()
    var rows by remember { mutableStateOf(mgr.diagnostics()) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { while (true) { rows = mgr.diagnostics(); delay(2_000) } }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Sieć publiczna: ${status.connected} połączonych") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(when (status.state) { NetState.ONLINE -> "Stan: połączono"; NetState.CONNECTING -> "Stan: łączenie…"; NetState.OFFLINE -> "Stan: brak połączenia" }, fontSize = 13.sp)
                rows.forEach { r ->
                    Column {
                        Text(r.url.removePrefix("wss://"), fontSize = 13.sp, fontWeight = if (r.connected) FontWeight.SemiBold else FontWeight.Normal)
                        Text(when {
                            r.connected -> "połączony"
                            r.banned -> "pominięty: ${r.lastError}"
                            r.failures > 0 -> "błąd (${r.failures}): ${r.lastError}, kolejna próba za ${r.retryInMs / 1000} s"
                            else -> "jeszcze nie próbowano"
                        }, fontSize = 11.sp, color = ShMuted)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { scope.launch { mgr.networkChanged(); runCatching { mgr.ensure() } } }) { Text("Połącz od nowa") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Zamknij") } }
    )
}
