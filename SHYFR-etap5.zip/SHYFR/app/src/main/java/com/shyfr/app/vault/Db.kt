package com.shyfr.app.vault

import android.content.Context
import net.zetetic.database.sqlcipher.SQLiteDatabase

/** Zaszyfrowana baza SQLCipher otwierana kluczem głównym. */
object Db {
    init { System.loadLibrary("sqlcipher") }

    /** Losowy 256-bitowy klucz podajemy jako surowy (x'hex'). */
    private fun rawKey(k: ByteArray) = ("x'" + k.joinToString("") { "%02x".format(it) } + "'").toByteArray()

    private fun hasColumn(db: SQLiteDatabase, table: String, column: String): Boolean =
        db.rawQuery("PRAGMA table_info($table)").use { c ->
            val name = c.getColumnIndex("name")
            while (c.moveToNext()) if (c.getString(name).equals(column, ignoreCase = true)) return@use true
            false
        }

    /** Idempotentna migracja: nie wykonuje ALTER TABLE, jeśli kolumna już istnieje. */
    private fun ensureColumn(db: SQLiteDatabase, table: String, definition: String) {
        val column = definition.substringBefore(' ').trim()
        if (!hasColumn(db, table, column)) {
            db.execSQL("ALTER TABLE $table ADD COLUMN $definition")
        }
    }

    fun open(ctx: Context, masterKey: ByteArray): SQLiteDatabase {
        val f = ctx.getDatabasePath("shyfr.db").also { it.parentFile?.mkdirs() }
        val db = SQLiteDatabase.openOrCreateDatabase(f, rawKey(masterKey), null, null)
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS contacts(id INTEGER PRIMARY KEY, label TEXT, onion TEXT, pubkey BLOB)")
            db.execSQL("CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, contact_id INTEGER, outgoing INTEGER, body TEXT, ts INTEGER, expires INTEGER)")
            db.execSQL("CREATE TABLE IF NOT EXISTS identity(id INTEGER PRIMARY KEY CHECK(id=1), onion_key TEXT)")
            db.execSQL("CREATE TABLE IF NOT EXISTS sessions(contact_id INTEGER PRIMARY KEY, state BLOB)")
            db.execSQL("CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY AUTOINCREMENT, contact_id INTEGER, frame BLOB, msg_id INTEGER)")
            db.execSQL("CREATE TABLE IF NOT EXISTS seen(contact_id INTEGER, h BLOB, PRIMARY KEY(contact_id, h))")
            db.execSQL("CREATE TABLE IF NOT EXISTS profile(id INTEGER PRIMARY KEY CHECK(id=1), nick TEXT, color INTEGER, emoji TEXT, about TEXT)")
            db.execSQL("CREATE TABLE IF NOT EXISTS attachments(id TEXT PRIMARY KEY, contact_id INTEGER, name TEXT, mime TEXT, size INTEGER, total INTEGER, got INTEGER DEFAULT 0, image INTEGER DEFAULT 0, done INTEGER DEFAULT 0)")
            db.execSQL("CREATE TABLE IF NOT EXISTS att_chunks(att_id TEXT, idx INTEGER, data BLOB, PRIMARY KEY(att_id, idx))")
            db.execSQL("CREATE TABLE IF NOT EXISTS reactions(contact_id INTEGER, msg_mid TEXT, by_me INTEGER, emoji TEXT, PRIMARY KEY(contact_id, msg_mid, by_me))")

            // Warstwa publiczna (przekaźnik): członkostwa, zakładki, własne reakcje. Bez kluczy prywatnych (wyprowadzane z klucza sejfu).
            db.execSQL("CREATE TABLE IF NOT EXISTS pub_membership(relay TEXT, cid TEXT, name TEXT, vis TEXT, nick TEXT DEFAULT '', key_idx INTEGER DEFAULT 0, role TEXT DEFAULT 'member', joined INTEGER DEFAULT 0, bio TEXT DEFAULT '', is_public INTEGER DEFAULT 0, PRIMARY KEY(relay, cid))")
            db.execSQL("CREATE TABLE IF NOT EXISTS pub_bookmarks(post_id TEXT PRIMARY KEY, cid TEXT, author TEXT, nick TEXT, text TEXT, ts INTEGER, added INTEGER DEFAULT 0)")
            db.execSQL("CREATE TABLE IF NOT EXISTS pub_requests(relay TEXT, cid TEXT, req_id TEXT, target TEXT, n INTEGER DEFAULT 0, ts INTEGER DEFAULT 0, handled INTEGER DEFAULT 0, PRIMARY KEY(relay, req_id))")
            db.execSQL("CREATE TABLE IF NOT EXISTS pub_reacted(post_id TEXT, emoji TEXT, PRIMARY KEY(post_id, emoji))")
            db.execSQL("CREATE TABLE IF NOT EXISTS chat_groups(gid TEXT PRIMARY KEY, name TEXT, members TEXT, unread INTEGER DEFAULT 0, muted INTEGER DEFAULT 0, ts INTEGER DEFAULT 0)")
            db.execSQL("CREATE TABLE IF NOT EXISTS group_msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, gid TEXT, sender TEXT, body TEXT, ts INTEGER, mid TEXT, UNIQUE(gid, sender, mid))")

            db.beginTransaction()
            try {
                ensureColumn(db, "identity", "x_priv BLOB")
                ensureColumn(db, "contacts", "ttl INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "status INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "verified INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "nick TEXT")
                ensureColumn(db, "contacts", "color INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "emoji TEXT")
                ensureColumn(db, "contacts", "about TEXT")
                ensureColumn(db, "contacts", "psent INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "unread INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "muted INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "avatar BLOB")
                ensureColumn(db, "contacts", "pinned INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "archived INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "draft TEXT")
                ensureColumn(db, "contacts", "rcpt TEXT")
                // Etap 6: personalizacja rozmowy, ochrona zrzutów ekranu, obecność
                ensureColumn(db, "contacts", "theme INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "capmode INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "qemoji TEXT")
                ensureColumn(db, "contacts", "cnick TEXT")
                ensureColumn(db, "contacts", "mynick TEXT")
                ensureColumn(db, "contacts", "peer_state INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "peer_active INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "peer_seen INTEGER DEFAULT 0")
                ensureColumn(db, "messages", "sys INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "blocked INTEGER DEFAULT 0")
                ensureColumn(db, "contacts", "mute_until INTEGER DEFAULT 0")
                ensureColumn(db, "messages", "status INTEGER DEFAULT 0")
                ensureColumn(db, "messages", "att_id TEXT")
                ensureColumn(db, "messages", "mid TEXT")
                ensureColumn(db, "messages", "reply_mid TEXT")
                ensureColumn(db, "messages", "edited INTEGER DEFAULT 0")
                ensureColumn(db, "messages", "deleted INTEGER DEFAULT 0")
                ensureColumn(db, "messages", "starred INTEGER DEFAULT 0")
                ensureColumn(db, "outbox", "attempts INTEGER DEFAULT 0")
                ensureColumn(db, "profile", "avatar BLOB")
                ensureColumn(db, "pub_membership", "bio TEXT DEFAULT ''")
                ensureColumn(db, "pub_membership", "is_public INTEGER DEFAULT 0")
                // Indeks jest optymalizacją/deduplicacją. Nie blokujemy otwarcia starej bazy,
                // jeśli historyczny plik zawiera już powielone identyfikatory wiadomości.
                runCatching { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_msg_mid ON messages(contact_id, outgoing, mid)") }
                db.rawQuery("PRAGMA user_version = 12").use { cursor -> while (cursor.moveToNext()) { /* consume pragma result */ } }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            db.rawQuery("PRAGMA secure_delete = ON").use { cursor -> while (cursor.moveToNext()) { /* consume pragma result */ } }
            return db
        } catch (t: Throwable) {
            db.close()
            throw IllegalStateException("Nie udało się otworzyć lub zaktualizować zaszyfrowanej bazy SHYFR: ${t.message}", t)
        }
    }
}
