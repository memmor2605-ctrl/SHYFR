package com.shyfr.app.feed

import com.google.crypto.tink.subtle.Hkdf
import com.google.crypto.tink.subtle.X25519
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * „Zapieczętowana skrzynka” dla próśb o kontakt: X25519 (klucz efemeryczny) + HKDF-SHA256 + AES-256-GCM.
 * Przekaźnik widzi tylko zaszyfrowany blob; odczytać go może wyłącznie właściciel klucza odbiorcy.
 * Format (base64url bez paddingu): epub(32) | nonce(12) | szyfrogram+tag.
 * To prosty schemat jednokierunkowy (bez forward secrecy względem klucza odbiorcy); służy tylko do przekazania
 * krótkiego powitania i jednorazowego zaproszenia, po czym rozmowa przechodzi na protokół P2P z Double Ratchet.
 */
object ContactCrypto {
    private val rnd = SecureRandom()
    private val enc = java.util.Base64.getUrlEncoder().withoutPadding()
    private val dec = java.util.Base64.getUrlDecoder()
    private val INFO = "shyfr-contact-seal-v1".toByteArray(Charsets.UTF_8)

    private fun aesKey(shared: ByteArray, epub: ByteArray, rpub: ByteArray): ByteArray =
        Hkdf.computeHkdf("HmacSha256", shared, epub + rpub, INFO, 32)

    fun seal(recipientPub: ByteArray, plaintext: ByteArray): String {
        val epriv = X25519.generatePrivateKey()
        val epub = X25519.publicFromPrivate(epriv)
        val key = aesKey(X25519.computeSharedSecret(epriv, recipientPub), epub, recipientPub)
        val nonce = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        c.updateAAD(epub + recipientPub)
        val ct = c.doFinal(plaintext)
        key.fill(0); epriv.fill(0)
        return enc.encodeToString(epub + nonce + ct)
    }

    /** Zwraca null, jeśli blob jest uszkodzony albo nie jest przeznaczony dla tego klucza. */
    fun open(recipientPriv: ByteArray, sealed: String): ByteArray? {
        return try {
            val raw = dec.decode(sealed)
            if (raw.size < 32 + 12 + 16) return null
            val epub = raw.copyOfRange(0, 32)
            val nonce = raw.copyOfRange(32, 44)
            val ct = raw.copyOfRange(44, raw.size)
            val rpub = X25519.publicFromPrivate(recipientPriv)
            val key = aesKey(X25519.computeSharedSecret(recipientPriv, epub), epub, rpub)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            c.updateAAD(epub + rpub)
            val out = c.doFinal(ct)
            key.fill(0)
            out
        } catch (e: Exception) { null }
    }
}
