package com.shyfr.app.feed

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Protokół przekaźnika publicznego. MUSI być zgodny z relay/shyfr_relay.py
 * (wektory testowe: PublicProtoTest oraz relay/test_relay.py).
 */
object PublicProto {
    /** Akcje wymagające dowodu pracy (ochrona przed spamem bez kont i adresów IP). */
    val POW_TYPES = setOf("post.create", "community.create", "member.join", "report")

    /** Bajty podpisywane kluczem społeczności: SHYFR1|typ|b64url(część)|... (części jako UTF-8). */
    fun sigMsg(type: String, vararg parts: String): ByteArray {
        val enc = java.util.Base64.getUrlEncoder().withoutPadding()
        val sb = StringBuilder("SHYFR1|").append(type)
        for (p in parts) sb.append('|').append(enc.encodeToString(p.toByteArray(Charsets.UTF_8)))
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    fun leadingZeroBits(h: ByteArray): Int {
        var n = 0
        for (b in h) {
            val v = b.toInt() and 0xff
            if (v == 0) { n += 8; continue }
            n += Integer.numberOfLeadingZeros(v) - 24
            break
        }
        return n
    }

    private fun powHash(msg: ByteArray, nonce: Long): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(msg); md.update(("|" + nonce).toByteArray(Charsets.UTF_8))
        return md.digest()
    }

    fun powOk(msg: ByteArray, nonce: Long, bits: Int): Boolean = bits <= 0 || leadingZeroBits(powHash(msg, nonce)) >= bits

    fun solvePow(msg: ByteArray, bits: Int): Long {
        var n = 0L
        while (!powOk(msg, n, bits)) n++
        return n
    }

    fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
    fun fromHex(s: String): ByteArray = ByteArray(s.length / 2) { i -> s.substring(2 * i, 2 * i + 2).toInt(16).toByte() }

    private val rnd = SecureRandom()
    fun newCid(): String = hex(ByteArray(8).also { rnd.nextBytes(it) })
    fun newInviteCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
        return (1..12).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
    }

    /** Adres przekaźnika: tylko onion v3 (56 znaków base32). Zwraca postać znormalizowaną albo null. */
    fun normalizeOnion(s: String): String? {
        val t = s.trim().lowercase().removePrefix("http://").removePrefix("https://").trimEnd('/')
        return if (Regex("^[a-z2-7]{56}\\.onion$").matches(t)) t else null
    }

    /** Zaproszenie do społeczności: shyfr-c:<cid>:<kod> (kod pusty dla społeczności publicznej). */
    fun inviteString(cid: String, code: String) = "shyfr-c:$cid:$code"
    fun parseInvite(s: String): Pair<String, String>? {
        val t = s.trim()
        val m = Regex("^shyfr-c:([0-9a-f]{16}):([A-Za-z0-9]{0,32})$").find(t)
        if (m != null) return m.groupValues[1] to m.groupValues[2]
        return if (Regex("^[0-9a-f]{16}$").matches(t)) t to "" else null
    }
}
