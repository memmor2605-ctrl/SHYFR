package com.shyfr.app.net

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.shyfr.app.Trace
import com.shyfr.app.invite.InviteManager
import com.shyfr.app.session.Session
import com.shyfr.app.vault.Db
import com.shyfr.app.vault.Store
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.DataInputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket

sealed interface NodeState {
    data object Stopped : NodeState
    data class Starting(val step: String) : NodeState
    data class Online(val onion: String) : NodeState
    data class Failed(val reason: String) : NodeState
}

/**
 * Usługa pierwszoplanowa SHYFR: Tor + własna usługa onion + nasłuch połączeń od znajomych.
 * Samoleczenie: po błędzie lub gdy Tor przestaje mieć obwody, węzeł startuje od nowa (rosnące opóźnienie do 2 min).
 */
class NodeService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var transport: TorTransport? = null
    private var server: ServerSocket? = null
    private var job: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Trace.log("NodeService.onStartCommand")
        startForeground(1, notification(if (_state.value is NodeState.Online) "Online w sieci Tor" else "Łączenie z siecią Tor…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (job == null) job = scope.launch { runNode() }
        return START_NOT_STICKY // po zablokowaniu konta nie wstajemy sami (klucz jest tylko w RAM)
    }

    private suspend fun runNode() {
        var attempt = 0
        while (scope.isActive) {
            val key = Session.get()
            if (key == null) { _state.value = NodeState.Failed("Konto zablokowane"); stopSelf(); return }
            var failure: String? = null
            try {
                nodeOnce(key)
            } catch (e: CancellationException) { throw e
            } catch (e: Throwable) {
                Trace.log("runNode BŁĄD: $e")
                failure = (e.javaClass.simpleName + ": " + (e.message ?: "")).trim()
            }
            cleanupTransport()
            attempt = if (failure == null) 0 else attempt + 1
            if (failure?.contains("Tora zakończył") == true) {
                // proces Tora padł: uszkodzony stan na dysku mógł być przyczyną, więc czyścimy pamięć podręczną Tora
                Trace.log("czyszczenie danych Tora: ${TorData.purge(applicationContext)} plików")
            }
            val wait = if (failure == null) 3 else minOf(120, 10 * attempt)
            _state.value = if (failure != null) NodeState.Failed("$failure (ponawiam za $wait s)")
            else NodeState.Starting("Ponowne łączenie z siecią Tor")
            Trace.log("runNode: ponawiam za $wait s")
            delay(wait * 1000L)
        }
    }

    /** Jeden pełny cykl życia węzła. Wraca, gdy gniazdo nasłuchu zostanie zamknięte (np. przez watchdog). */
    private suspend fun nodeOnce(key: ByteArray) = coroutineScope {
        Trace.log("runNode: start Tora")
        _state.value = NodeState.Starting("Uruchamianie Tora")
        val t = TorAndroidTransport(applicationContext).also { transport = it }
        t.onDeath = { Trace.log("Tor padł, restart węzła"); runCatching { server?.close() } }
        NodeRuntime.transport = t
        t.start { p -> _state.value = NodeState.Starting("Łączenie z siecią Tor $p%") }
        Trace.log("runNode: Tor gotowy")

        // ADD_ONION kieruje ruch jawnie na 127.0.0.1. Nie używamy getLoopbackAddress(),
        // bo na części urządzeń zwraca ::1, przez co Tor nie może dotrzeć do listenera.
        val ss = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1")).also { server = it }
        Trace.log("listener lokalny: ${ss.inetAddress.hostAddress}:${ss.localPort}")
        val db = Db.open(applicationContext, key)
        val saved = db.rawQuery("SELECT onion_key FROM identity WHERE id=1").use { if (it.moveToFirst()) it.getString(0) else null }

        Trace.log("runNode: publikuję usługę onion")
        _state.value = NodeState.Starting("Publikowanie adresu onion")
        val (onion, pk) = t.publishService(VIRTUAL_PORT, ss.localPort, saved)
        if (saved == null) {
            db.execSQL("INSERT OR IGNORE INTO identity(id) VALUES(1)")
            db.execSQL("UPDATE identity SET onion_key=? WHERE id=1", arrayOf(pk))
        }
        db.close()

        NodeRuntime.onion = onion
        Trace.log("runNode: usługa onion opublikowana i listener aktywny")
        Trace.log("runNode: online")
        NodeRuntime.onIncoming = { notifyIncoming() }
        _state.value = NodeState.Online(onion)
        updateNotification("Online w sieci Tor")

        val outbox = launch { outboxLoop() }
        val dog = launch { watchdog(t, ss) }
        val presence = launch { presenceLoop() }
        val mbox = launch { mailboxLoop() }
        val act = launch { activityLoop() }
        var chk: Job = launch { selfCheck(t, onion, restartOnFail = false) }
        // Zmiana sieci (Wi-Fi ↔ komórkowa ↔ inne Wi-Fi): świeże obwody Tora, ponowne sprawdzenie adresu, natychmiastowa próba wysyłki.
        val netEvents = kotlinx.coroutines.channels.Channel<String>(kotlinx.coroutines.channels.Channel.CONFLATED)
        NetMonitor.start(applicationContext) { d -> netEvents.trySend(d) }
        val net = launch {
            for (d in netEvents) {
                delay(3_000) // sieć często „mruga” przy przełączaniu
                Trace.log("zmiana sieci ($d): odświeżam obwody Tora")
                Trace.log("SIGNAL NEWNET: " + if (t.newNetwork()) "ok" else "błąd")
                chk.cancel(); chk = launch { selfCheck(t, onion, restartOnFail = true) }
                NodeRuntime.kick.trySend(Unit); NodeRuntime.mailboxKick.trySend(Unit)
            }
        }
        acceptLoop(ss)
        outbox.cancel(); dog.cancel(); presence.cancel(); mbox.cancel(); act.cancel(); net.cancel(); chk.cancel(); NetMonitor.stop(applicationContext)
    }

    private fun cleanupTransport() {
        runCatching { server?.close() }; server = null
        transport?.stop(); transport = null
        NodeRuntime.transport = null; NodeRuntime.onion = null; NodeRuntime.reachable.value = false
    }

    /**
     * Świeży adres onion jest osiągalny dopiero, gdy jego deskryptor trafi do węzłów HSDir (zwykle 30-120 s).
     * Sprawdzamy to połączeniem do samego siebie przez Tor; po 6 min przestajemy czekać (wynik w raporcie diagnostycznym).
     */
    private suspend fun selfCheck(t: TorTransport, onion: String, restartOnFail: Boolean) {
        NodeRuntime.reachable.value = false
        val start = System.currentTimeMillis()
        delay(20_000)
        while (scope.isActive && System.currentTimeMillis() - start < 6 * 60_000L) {
            val ok = runCatching { t.connect(onion, VIRTUAL_PORT).use { true } }.getOrDefault(false)
            if (ok) {
                Trace.log("selfCheck: adres onion osiągalny po ${(System.currentTimeMillis() - start) / 1000} s")
                NodeRuntime.selfTestEverOk = true
                NodeRuntime.reachable.value = true; return
            }
            Trace.log("selfCheck: adres jeszcze nieosiągalny (${(System.currentTimeMillis() - start) / 1000} s)")
            delay(15_000)
        }
        if (restartOnFail && NodeRuntime.selfTestEverOk) {
            // test własnego adresu działał wcześniej, a po zmianie sieci nie wraca: Tor utknął, więc restartujemy węzeł
            Trace.log("selfCheck: adres nieosiągalny po zmianie sieci, restart węzła")
            runCatching { server?.close() }
            return
        }
        Trace.log("selfCheck: brak potwierdzenia po 6 min (test własnego adresu może nie działać w tej wersji Tora)")
        NodeRuntime.reachable.value = true
    }

    /** Co 30 s sprawdza obwody Tor. Po 3 porażkach z rzędu zamyka gniazdo, co restartuje węzeł. */
    private suspend fun watchdog(t: TorTransport, ss: ServerSocket) {
        delay(60_000)
        var bad = 0
        while (scope.isActive) {
            if (t.isHealthy()) bad = 0
            else if (++bad >= 3) {
                Trace.log("watchdog: Tor bez obwodów, restart węzła")
                runCatching { ss.close() }
                return
            }
            delay(30_000)
        }
    }

    /** Router połączeń przychodzących: zaproszenie (HELLO) albo wiadomości (MSG). */
    private suspend fun acceptLoop(ss: ServerSocket) {
        while (scope.isActive && !ss.isClosed) {
            val s = runCatching { ss.accept() }.getOrNull() ?: break
            scope.launch {
                runCatching { route(s) }.onFailure {
                    Trace.log("router: błąd obsługi połączenia: ${it.javaClass.simpleName}: ${it.message}")
                    runCatching { s.close() }
                }
            }
        }
    }

    private fun route(s: Socket) {
        s.soTimeout = 30_000
        val inp = DataInputStream(s.getInputStream())
        when (val type = inp.readUnsignedByte()) {
            JoinService.HELLO -> { Trace.log("router: przychodzący handshake zaproszenia"); JoinService(applicationContext).handleHello(s, inp) }
            Messenger.MSG -> Messenger(applicationContext).handleMessages(s, inp)
            Presence.PRES -> Presence.handle(applicationContext, s, inp)
            else -> { Trace.log("router: nieznany typ ramki $type"); s.close() }
        }
    }

    /** Co 30 s (lub od razu po nowej wiadomości): wysyła kolejkę i usuwa wygasłe wiadomości. */
    private suspend fun outboxLoop() {
        val m = Messenger(applicationContext)
        while (scope.isActive) {
            runCatching { m.flushOutbox() }
            runCatching { Store(applicationContext).sweepExpired() }
            withTimeoutOrNull(30_000) { NodeRuntime.kick.receive() }
        }
    }

    /**
     * Status aktywności: odpytujemy kontakty tylko, gdy aplikacja jest na pierwszym planie (nikt nie patrzy = brak ruchu
     * i zużycia baterii). Odpowiadamy na cudze zapytania zawsze, o ile status nie jest wyłączony.
     */
    private suspend fun presenceLoop() {
        delay(5_000)
        while (scope.isActive) {
            if (Presence.foreground && Session.get() != null) runCatching { Presence.pollAll(applicationContext) }
            withTimeoutOrNull(60_000) { Presence.kick.receive() }
        }
    }

    /** Co 60 s (i po zmianie sieci) pobiera ramki ze skrzynki na przekaźniku, jeśli jest skonfigurowany. */
    private suspend fun mailboxLoop() {
        val m = Messenger(applicationContext)
        val mb = Mailbox(applicationContext)
        var lastLog = 0L
        delay(15_000)
        while (scope.isActive) {
            if (Mailbox.enabled(applicationContext) && Session.get() != null) {
                try {
                    val n = mb.pollAll(m)
                    if (n > 0) Trace.log("skrzynka: odebrano $n ramek")
                } catch (e: CancellationException) { throw e
                } catch (e: Exception) {
                    if (System.currentTimeMillis() - lastLog > 300_000L) { lastLog = System.currentTimeMillis(); Trace.log("skrzynka: pobieranie nieudane (${e.javaClass.simpleName}: ${(e.message ?: "").take(60)})") }
                }
            }
            withTimeoutOrNull(60_000) { NodeRuntime.mailboxKick.receive() }
        }
    }

    /** Co 10 min sprawdza nowe prośby o kontakt i zdarzenia przy Twoich wpisach (poza wyciszonymi społecznościami). */
    private suspend fun activityLoop() {
        val repo = com.shyfr.app.feed.PublicRepo(applicationContext)
        var lastNotified = 0
        delay(45_000)
        while (scope.isActive) {
            if (repo.relayConfigured() && Session.get() != null) {
                try {
                    val s = repo.activitySnapshot(com.shyfr.app.session.Prefs.activitySeen(applicationContext), com.shyfr.app.session.Prefs.mutedCommunities(applicationContext))
                    val unread = s.incoming.size + s.outgoing.count { it.status != "pending" } + s.events.size
                    NodeRuntime.activityUnread.value = unread
                    if (unread > lastNotified) notifyActivity()
                    lastNotified = unread
                } catch (e: CancellationException) { throw e
                } catch (e: Exception) { /* przekaźnik niedostępny: spróbujemy za 10 min */ }
            }
            delay(10 * 60_000L)
        }
    }

    private fun notifyActivity() {
        if (com.shyfr.app.session.Prefs.quietNow(this)) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_ACT, "Aktywność", NotificationManager.IMPORTANCE_LOW))
        nm.notify(3, NotificationCompat.Builder(this, CH_ACT)
            .setContentTitle("SHYFR").setContentText("Nowa aktywność") // bez szczegółów na ekranie blokady
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET).setAutoCancel(true).build())
    }

    private fun notifyIncoming() {
        if (com.shyfr.app.session.Prefs.quietNow(this)) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MSG, "Wiadomości", NotificationManager.IMPORTANCE_DEFAULT))
        nm.notify(2, NotificationCompat.Builder(this, CH_MSG)
            .setContentTitle("SHYFR").setContentText("Nowa wiadomość") // bez nadawcy i treści
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET).setAutoCancel(true).build())
    }

    override fun onDestroy() {
        scope.cancel()
        cleanupTransport()
        NodeRuntime.onIncoming = null
        InviteManager.clear()
        _state.value = NodeState.Stopped
        super.onDestroy()
    }

    private fun channel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "SHYFR", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(text: String): Notification {
        channel()
        return NotificationCompat.Builder(this, CH)
            .setContentTitle("SHYFR").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock).setOngoing(true).build()
    }
    private fun updateNotification(text: String) =
        getSystemService(NotificationManager::class.java).notify(1, notification(text))

    companion object {
        const val VIRTUAL_PORT = 9735
        private const val CH = "shyfr_node"
        private const val CH_MSG = "shyfr_msg"
        private const val CH_ACT = "shyfr_activity"
        private val _state = MutableStateFlow<NodeState>(NodeState.Stopped)
        val state: StateFlow<NodeState> = _state

        fun start(c: Context) = c.startForegroundService(Intent(c, NodeService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, NodeService::class.java)) }

        /** Pełny restart węzła (np. po zmianie mostów). Wymaga odblokowanego konta. */
        fun restart(c: Context, purge: Boolean = false) {
            val app = c.applicationContext
            stop(app)
            Handler(Looper.getMainLooper()).postDelayed({
                if (purge) Trace.log("ręczne czyszczenie danych Tora: ${TorData.purge(app)} plików")
                if (Session.get() != null) start(app)
            }, 1500)
        }
    }
}
