package com.shyfr.app.nostr

import com.google.crypto.tink.subtle.Hkdf
import java.security.MessageDigest

/** Zdarzenie Nostr (NIP-01). */
data class NostrEvent(
    val id: String, val pubkey: String, val createdAt: Long, val kind: Int,
    val tags: List<List<String>>, val content: String, val sig: String
) {
    /** Poprawne tylko wtedy, gdy identyfikator odpowiada treści ORAZ podpis pasuje do klucza autora. */
    fun isValid(): Boolean = try {
        id == computeId(pubkey, createdAt, kind, tags, content) &&
            Schnorr.verify(unhex(id), unhex(pubkey), unhex(sig))
    } catch (e: Exception) { false }

    fun tagValues(name: String): List<String> = tags.filter { it.size >= 2 && it[0] == name }.map { it[1] }

    /** JSON do wysłania do przekaźnika (standardowe znakowanie ucieczką, poprawne dla każdego parsera). */
    fun toWireJson(): String = buildString {
        append("{\"id\":\"").append(id).append("\",\"pubkey\":\"").append(pubkey).append("\",\"created_at\":").append(createdAt)
        append(",\"kind\":").append(kind).append(",\"tags\":[")
        tags.forEachIndexed { i, t -> if (i > 0) append(','); append('['); t.forEachIndexed { j, s -> if (j > 0) append(','); append(jsonString(s)) }; append(']') }
        append("],\"content\":").append(jsonString(content)).append(",\"sig\":\"").append(sig).append("\"}")
    }

    companion object {
        fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
        fun unhex(s: String): ByteArray {
            require(s.length % 2 == 0) { "Zły hex" }
            return ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        }

        /** Znakowanie ucieczką do liczenia identyfikatora: dokładnie jak w NIP-01 (tylko \n \" \\ \r \t \b \f, reszta bez zmian). */
        internal fun canonicalString(s: String): String = buildString {
            append('"')
            for (ch in s) when (ch) {
                '"' -> append("\\\""); '\\' -> append("\\\\"); '\n' -> append("\\n"); '\r' -> append("\\r")
                '\t' -> append("\\t"); '\b' -> append("\\b"); '\u000C' -> append("\\f"); else -> append(ch)
            }
            append('"')
        }

        /** Na przewodzie wolno użyć pełnej ucieczki (\u00XX dla znaków sterujących), bo przekaźnik i tak parsuje JSON. */
        internal fun jsonString(s: String): String = buildString {
            append('"')
            for (ch in s) when {
                ch == '"' -> append("\\\""); ch == '\\' -> append("\\\\"); ch == '\n' -> append("\\n"); ch == '\r' -> append("\\r")
                ch == '\t' -> append("\\t"); ch == '\b' -> append("\\b"); ch == '\u000C' -> append("\\f")
                ch.code < 0x20 -> append("\\u%04x".format(ch.code)); else -> append(ch)
            }
            append('"')
        }

        fun serializeForId(pubkey: String, createdAt: Long, kind: Int, tags: List<List<String>>, content: String): String =
            "[0,\"$pubkey\",$createdAt,$kind,[" + tags.joinToString(",") { t -> "[" + t.joinToString(",") { canonicalString(it) } + "]" } + "]," + canonicalString(content) + "]"

        fun computeId(pubkey: String, createdAt: Long, kind: Int, tags: List<List<String>>, content: String): String =
            hex(MessageDigest.getInstance("SHA-256").digest(serializeForId(pubkey, createdAt, kind, tags, content).toByteArray(Charsets.UTF_8)))

        fun create(sk: ByteArray, kind: Int, tags: List<List<String>>, content: String, createdAt: Long = System.currentTimeMillis() / 1000, aux: ByteArray? = null): NostrEvent {
            val pub = hex(Schnorr.publicKey(sk))
            val id = computeId(pub, createdAt, kind, tags, content)
            val sig = if (aux == null) Schnorr.sign(unhex(id), sk) else Schnorr.sign(unhex(id), sk, aux)
            return NostrEvent(id, pub, createdAt, kind, tags, content, hex(sig))
        }
    }
}

/** Klucze Nostr tożsamości: osobny klucz na tożsamość, wyprowadzany z klucza głównego (nie zapisujemy ich nigdzie). */
object NostrKeys {
    fun secretFor(master: ByteArray, kindCode: String, idx: Int): ByteArray {
        var counter = 0
        while (true) {
            val sk = Hkdf.computeHkdf("HmacSha256", master, ByteArray(0), "shyfr-nostr-v1|$kindCode|$idx|$counter".toByteArray(Charsets.UTF_8), 32)
            if (Schnorr.isValidSecret(sk)) return sk
            counter++
        }
    }
    fun publicHex(sk: ByteArray) = NostrEvent.hex(Schnorr.publicKey(sk))
}
