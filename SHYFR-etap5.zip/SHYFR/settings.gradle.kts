pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        // część wydań Tora bywa tylko tutaj; wpuszczamy wyłącznie grupę info.guardianproject
        maven {
            url = uri("https://raw.githubusercontent.com/guardianproject/gpmaven/master")
            content { includeGroup("info.guardianproject") }
        }
    }
}
rootProject.name = "SHYFR"
include(":app")
