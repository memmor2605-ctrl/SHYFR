#!/data/data/com.termux/files/usr/bin/bash
# Uruchamia przekaźnik SHYFR na telefonie z Androidem (Termux) jako usługę onion. Darmowe: potrzebny tylko stary telefon na ładowarce z Wi-Fi.
# Użycie (w katalogu relay/): bash setup-termux.sh
set -e
DIR="$HOME/shyfr-relay"; HS="$HOME/.shyfr-relay/hs"
pkg update -y && pkg install -y python tor termux-api
mkdir -p "$DIR" "$HS" "$HOME/.termux/boot" && chmod 700 "$HS"
cp "$(dirname "$0")/shyfr_relay.py" "$DIR/"
TORRC="$PREFIX/etc/tor/torrc"; mkdir -p "$(dirname "$TORRC")"; touch "$TORRC"
if ! grep -q "shyfr-relay/hs" "$TORRC"; then
  printf '\n# SHYFR przekaźnik\nHiddenServiceDir %s\nHiddenServicePort 80 127.0.0.1:8787\n' "$HS" >> "$TORRC"
fi
cat > "$DIR/start.sh" <<'EOS'
#!/data/data/com.termux/files/usr/bin/bash
# Start po restarcie telefonu i ręcznie. Nie wyłączaj optymalizacji baterii tylko dla Termux: ustaw „Bez ograniczeń” dla Termux i Termux:Boot.
termux-wake-lock
cd "$HOME/shyfr-relay"
pgrep -x tor >/dev/null || (tor >"$HOME/shyfr-relay/tor.log" 2>&1 &)
mkdir -p "$HOME/shyfr-relay/backup"
( while true; do sleep 86400; cp relay.db "backup/relay-$(date +%F).db" 2>/dev/null; ls -1t backup/relay-*.db 2>/dev/null | tail -n +8 | xargs -r rm -f; done ) &
while true; do SHYFR_RELAY_DB="$HOME/shyfr-relay/relay.db" python3 shyfr_relay.py; sleep 5; done
EOS
chmod +x "$DIR/start.sh"; cp "$DIR/start.sh" "$HOME/.termux/boot/shyfr-relay.sh"
pgrep -x tor >/dev/null && pkill -HUP tor || true
nohup "$DIR/start.sh" >"$DIR/relay.log" 2>&1 &
echo "Czekam na adres onion (do 2 minut)..."
for i in $(seq 1 60); do [ -s "$HS/hostname" ] && break; sleep 2; done
if [ -s "$HS/hostname" ]; then echo "Adres przekaźnika: $(cat "$HS/hostname")"; else echo "Adres jeszcze się nie pojawił. Sprawdź: cat $HS/hostname oraz $DIR/tor.log"; fi
echo "Zainstaluj aplikację Termux:Boot, aby przekaźnik startował po restarcie telefonu."
