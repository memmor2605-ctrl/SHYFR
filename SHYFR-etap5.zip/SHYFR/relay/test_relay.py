import hashlib, json, os, threading, time, unittest, urllib.request, urllib.error
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
import shyfr_relay as R

BITS = 8

class Client:
    """Klucz per społeczność, jak w aplikacji (tu losowy)."""
    def __init__(self, base):
        self.base = base; self.k = Ed25519PrivateKey.generate()
        self.pub = self.k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()

    def act(self, typ, **f):
        f.setdefault("ts", int(time.time() * 1000))
        parts = [f[n] for n in R.FIELDS[typ]]
        msg = R.sigmsg(typ, *parts)
        obj = dict(f, type=typ, pub=self.pub, sig=self.k.sign(msg).hex())
        if typ in R.POW_TYPES:
            n = 0
            while not R.pow_ok(msg, n, BITS): n += 1
            obj["pow"] = n
        return self.post(obj)

    def post(self, obj):
        req = urllib.request.Request(self.base + "/v1/act", json.dumps(obj).encode(), {"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e: return e.code, json.loads(e.read())

    def post_raw(self, path, obj):
        req = urllib.request.Request(self.base + path, json.dumps(obj).encode(), {"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e: return e.code, json.loads(e.read())

    def get(self, path, auth=True):
        h = {}
        if auth:
            ts = str(int(time.time() * 1000))
            h = {"X-Pub": self.pub, "X-Ts": ts, "X-Sig": self.k.sign(R.sigmsg("read", path, ts)).hex()}
        try:
            with urllib.request.urlopen(urllib.request.Request(self.base + path, headers=h)) as r: return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e: return e.code, json.loads(e.read())

def now(): return int(time.time() * 1000)

class RelayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.relay = R.Relay(":memory:", pow_bits=BITS, rate_per_min=1000)
        cls.srv = R.serve(cls.relay, "127.0.0.1", 0)
        cls.base = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
    @classmethod
    def tearDownClass(cls): cls.srv.shutdown()

    def new_comm(self, vis="public", name="Test"):
        o = Client(self.base); cid = os.urandom(8).hex()
        st, r = o.act("community.create", cid=cid, name=name, descr="opis", vis=vis, category="tech")
        self.assertEqual(st, 200, r); return o, cid

    def post(self, c, cid, text="Cześć #SHYFR", channel="ogólny", kind="post", parent="", ref="", nick=""):
        return c.act("post.create", cid=cid, channel=channel, kind=kind, parent=parent, ref=ref, text=text, nick=nick)

    # --- podpisy i anty-replay
    def test_bad_signature_and_tamper(self):
        o, cid = self.new_comm(); u = Client(self.base)
        msg = dict(type="post.create", cid=cid, channel="ogólny", kind="post", parent="", ref="", text="a", nick="", ts=now(), pub=u.pub, sig="00" * 64, pow=0)
        self.assertEqual(u.post(msg)[0], 401)
        st, r = self.post(u, cid, "oryginal"); self.assertEqual(st, 200)

    def test_old_timestamp_rejected(self):
        o, cid = self.new_comm(); u = Client(self.base)
        st, r = u.act("post.create", cid=cid, channel="ogólny", kind="post", parent="", ref="", text="x", nick="", ts=now() - 3600_000)
        self.assertEqual(st, 400)

    def test_pow_required(self):
        o, cid = self.new_comm(); u = Client(self.base)
        f = dict(cid=cid, channel="ogólny", kind="post", parent="", ref="", text="x", nick="", ts=now())
        msg = R.sigmsg("post.create", *[f[n] for n in R.FIELDS["post.create"]])
        obj = dict(f, type="post.create", pub=u.pub, sig=u.k.sign(msg).hex())
        self.assertEqual(u.post(obj)[0], 400)

    def test_duplicate_rejected(self):
        o, cid = self.new_comm(); u = Client(self.base)
        ts = now()
        a = u.act("post.create", cid=cid, channel="ogólny", kind="post", parent="", ref="", text="dup", nick="", ts=ts)
        b = u.act("post.create", cid=cid, channel="ogólny", kind="post", parent="", ref="", text="dup", nick="", ts=ts)
        self.assertEqual(a[0], 200); self.assertEqual(b[0], 409)

    # --- anonimowość: brak globalnych identyfikatorów w rekordach publicznych
    def test_no_global_identifiers_leak(self):
        o, cid = self.new_comm(); u = Client(self.base)
        st, r = self.post(u, cid, "anonim", nick=""); self.assertEqual(st, 200)
        st, data = o.get("/v1/c/%s/posts" % cid, auth=False)
        raw = json.dumps(data)
        for banned in ("sid", "onion", "device", "ip"):
            self.assertNotIn('"%s"' % banned, raw)
        self.assertEqual(data["posts"][0]["nick"], "")
        self.assertEqual(data["posts"][0]["author"], u.pub)  # tylko klucz tej społeczności

    def test_keys_differ_between_communities(self):
        a, b = Client(self.base), Client(self.base)
        self.assertNotEqual(a.pub, b.pub)  # klient wyprowadza osobny klucz na społeczność (test w aplikacji: PublicKeysTest)

    # --- posty, komentarze, reakcje, reposty
    def test_post_comment_react_repost_flow(self):
        o, cid = self.new_comm(); u = Client(self.base); v = Client(self.base)
        pid = self.post(u, cid, "pierwszy #news")[1]["id"]
        self.assertEqual(self.post(v, cid, "komentarz", kind="comment", parent=pid)[0], 200)
        self.assertEqual(v.act("react", cid=cid, post=pid, emoji="❤", on="1")[0], 200)
        self.assertEqual(v.act("react", cid=cid, post=pid, emoji="❤", on="1")[0], 200)  # idempotentne
        self.assertEqual(self.post(v, cid, "", kind="repost", ref=pid)[0], 200)
        self.assertEqual(self.post(v, cid, "cytuję", kind="quote", ref=pid)[0], 200)
        st, d = u.get("/v1/c/%s/posts?channel=og%%C3%%B3lny" % cid, auth=False)
        orig = [p for p in d["posts"] if p["id"] == pid][0]
        self.assertEqual(orig["comments"], 1); self.assertEqual(orig["reactions"], {"❤": 1}); self.assertEqual(orig["reposts"], 2)
        st, c = u.get("/v1/c/%s/posts?parent=%s" % (cid, pid), auth=False); self.assertEqual(len(c["posts"]), 1)
        v.act("react", cid=cid, post=pid, emoji="❤", on="0")
        st, d = u.get("/v1/c/%s/posts" % cid, auth=False)
        self.assertEqual([p for p in d["posts"] if p["id"] == pid][0]["reactions"], {})

    def test_hashtag_search(self):
        o, cid = self.new_comm(); u = Client(self.base)
        self.post(u, cid, "o #Tor i #ssl")
        st, d = u.get("/v1/search?q=%23tor", auth=False); self.assertEqual(len(d["posts"]), 1)
        st, d = u.get("/v1/search?q=nieistnieje", auth=False); self.assertEqual(d["posts"], [])

    def test_pagination_and_sort(self):
        o, cid = self.new_comm(); u = Client(self.base)
        ids = [self.post(u, cid, "wpis %d" % i)[1]["id"] for i in range(5)]
        st, p1 = u.get("/v1/c/%s/posts?limit=2" % cid, auth=False)
        self.assertEqual(len(p1["posts"]), 2); self.assertIsNotNone(p1["next"])
        st, p2 = u.get("/v1/c/%s/posts?limit=2&before=%d" % (cid, p1["next"]), auth=False)
        self.assertEqual(len(p2["posts"]), 2)
        self.assertFalse({p["id"] for p in p1["posts"]} & {p["id"] for p in p2["posts"]})
        u.act("react", cid=cid, post=ids[0], emoji="🔥", on="1")
        st, top = u.get("/v1/c/%s/posts?sort=top" % cid, auth=False); self.assertEqual(top["posts"][0]["id"], ids[0])

    # --- edycja, usuwanie, przypinanie, uprawnienia
    def test_edit_delete_pin_permissions(self):
        o, cid = self.new_comm(); u = Client(self.base); v = Client(self.base)
        pid = self.post(u, cid, "stare")[1]["id"]
        self.assertEqual(v.act("post.edit", cid=cid, post=pid, text="hak")[0], 403)
        self.assertEqual(u.act("post.edit", cid=cid, post=pid, text="nowe")[0], 200)
        self.assertEqual(v.act("post.delete", cid=cid, post=pid)[0], 403)
        self.assertEqual(u.act("post.pin", cid=cid, post=pid, on="1")[0], 403)
        self.assertEqual(o.act("post.pin", cid=cid, post=pid, on="1")[0], 200)
        self.assertEqual(o.act("post.delete", cid=cid, post=pid)[0], 200)  # właściciel moderuje
        st, d = u.get("/v1/c/%s/posts" % cid, auth=False)
        gone = [p for p in d["posts"] if p["id"] == pid][0]; self.assertTrue(gone["deleted"]); self.assertEqual(gone["text"], "")

    def test_announce_channel_only_staff_can_post(self):
        o, cid = self.new_comm(); u = Client(self.base)
        self.assertEqual(self.post(u, cid, "x", channel="ogłoszenia")[0], 403)
        pid = self.post(o, cid, "ogłoszenie", channel="ogłoszenia")[1]["id"]
        self.assertEqual(self.post(u, cid, "komentarz", channel="ogłoszenia", kind="comment", parent=pid)[0], 200)

    def test_channels_and_roles(self):
        o, cid = self.new_comm(); u = Client(self.base)
        self.assertEqual(u.act("channel.create", cid=cid, name="tech", ckind="discussion")[0], 403)
        self.assertEqual(o.act("channel.create", cid=cid, name="tech", ckind="board")[0], 200)
        self.assertEqual(o.act("mod.set", cid=cid, target=u.pub, role="mod")[0], 200)
        self.assertEqual(u.act("channel.create", cid=cid, name="pytania", ckind="discussion")[0], 200)
        w = Client(self.base)
        self.assertEqual(u.act("mod.set", cid=cid, target=w.pub, role="mod")[0], 403)  # mod nie robi modów
        self.assertEqual(u.act("mod.set", cid=cid, target=o.pub, role="banned")[0], 403)  # właściciela nie ruszy

    def test_ban_blocks_posting_and_joining(self):
        o, cid = self.new_comm(); u = Client(self.base)
        self.assertEqual(self.post(u, cid, "ok")[0], 200)
        self.assertEqual(o.act("mod.set", cid=cid, target=u.pub, role="banned")[0], 200)
        self.assertEqual(self.post(u, cid, "znowu")[0], 403)
        self.assertEqual(u.act("react", cid=cid, post="x" * 32, emoji="👍", on="1")[0], 403)
        self.assertEqual(u.act("member.leave", cid=cid)[0], 200)
        self.assertEqual(self.post(u, cid, "po wyjściu")[0], 403)  # blokada przetrwała próbę „wyjścia”

    # --- prywatne i ukryte
    def test_private_requires_invite_and_membership(self):
        o, cid = self.new_comm("private"); u = Client(self.base)
        self.post(o, cid, "sekret")
        self.assertEqual(u.get("/v1/c/%s/posts" % cid, auth=False)[0], 403)
        self.assertEqual(self.post(u, cid, "wbijam")[0], 403)
        self.assertEqual(u.act("member.join", cid=cid, invite="")[0], 403)
        self.assertEqual(o.act("invite.create", cid=cid, code="ABCD1234efgh", uses=1, expires=now() + 60000)[0], 200)
        self.assertEqual(u.act("member.join", cid=cid, invite="ABCD1234efgh")[0], 200)
        self.assertEqual(Client(self.base).act("member.join", cid=cid, invite="ABCD1234efgh")[0], 403)  # użyty
        st, d = u.get("/v1/c/%s/posts" % cid); self.assertEqual(st, 200); self.assertEqual(len(d["posts"]), 1)
        self.assertEqual(u.get("/v1/c/%s/posts" % cid, auth=False)[0], 403)  # bez podpisu odczytu nadal nie

    def test_expired_invite(self):
        o, cid = self.new_comm("private"); u = Client(self.base)
        o.act("invite.create", cid=cid, code="EXPIRED12345", uses=5, expires=now() - 1000)
        self.assertEqual(u.act("member.join", cid=cid, invite="EXPIRED12345")[0], 403)

    def test_hidden_not_listed_and_404(self):
        o, cid = self.new_comm("hidden", "Ukryta-xyz"); u = Client(self.base)
        st, d = u.get("/v1/communities?q=Ukryta-xyz", auth=False)
        self.assertEqual(d["communities"], [])
        self.assertEqual(u.get("/v1/c/%s" % cid, auth=False)[0], 404)
        self.assertEqual(o.get("/v1/c/%s" % cid)[0], 200)

    def test_public_directory_lists_public_only(self):
        self.new_comm("public", "Widoczna-qq"); self.new_comm("private", "Prywatna-qq")
        st, d = Client(self.base).get("/v1/communities?q=-qq", auth=False)
        self.assertEqual([c["name"] for c in d["communities"]], ["Widoczna-qq"])

    def test_feed_respects_visibility(self):
        o1, c1 = self.new_comm("public"); o2, c2 = self.new_comm("private")
        self.post(o1, c1, "publiczny wpis"); self.post(o2, c2, "prywatny wpis")
        u = Client(self.base)
        st, d = u.get("/v1/feed?cs=%s,%s" % (c1, c2), auth=False)
        self.assertEqual([p["text"] for p in d["posts"]], ["publiczny wpis"])
        st, d = o2.get("/v1/feed?cs=%s,%s" % (c1, c2))
        self.assertEqual({p["text"] for p in d["posts"]}, {"publiczny wpis", "prywatny wpis"})

    def test_reports_visible_only_to_staff(self):
        o, cid = self.new_comm(); u = Client(self.base)
        pid = self.post(u, cid, "złe")[1]["id"]
        self.assertEqual(u.act("report", cid=cid, post=pid, reason="spam")[0], 200)
        self.assertEqual(u.get("/v1/c/%s/reports" % cid)[0], 403)
        st, d = o.get("/v1/c/%s/reports" % cid); self.assertEqual(d["reports"][0]["reason"], "spam")

    def test_rate_limit(self):
        r = R.Relay(":memory:", pow_bits=0, rate_per_min=3)
        c = Client("http://x"); cid = os.urandom(8).hex()
        def do(typ, **f):
            f.setdefault("ts", now()); msg = R.sigmsg(typ, *[f[n] for n in R.FIELDS[typ]])
            return r.act(dict(f, type=typ, pub=c.pub, sig=c.k.sign(msg).hex()))
        do("community.create", cid=cid, name="n", descr="", vis="public", category="")
        do("post.create", cid=cid, channel="ogólny", kind="post", parent="", ref="", text="1", nick="")
        do("post.create", cid=cid, channel="ogólny", kind="post", parent="", ref="", text="2", nick="")
        with self.assertRaises(R.Err) as e: do("post.create", cid=cid, channel="ogólny", kind="post", parent="", ref="", text="3", nick="")
        self.assertEqual(e.exception.code, 429)

    def test_single_post_endpoint(self):
        o, cid = self.new_comm("private"); u = Client(self.base)
        pid = self.post(o, cid, "jeden")[1]["id"]
        self.assertEqual(u.get("/v1/c/%s/post/%s" % (cid, pid), auth=False)[0], 403)
        st, d = o.get("/v1/c/%s/post/%s" % (cid, pid)); self.assertEqual((st, d["text"]), (200, "jeden"))

    # --- prośby o kontakt
    def _xpub(self): return os.urandom(32).hex()

    def test_contact_default_off_and_no_access_from_interaction(self):
        o, cid = self.new_comm(); a = Client(self.base); b = Client(self.base)
        pid = self.post(a, cid, "post A")[1]["id"]
        b.act("react", cid=cid, post=pid, emoji="❤", on="1"); self.post(b, cid, "komentarz", kind="comment", parent=pid)  # reakcja, komentarz i członkostwo
        st, r = b.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="zaszyfrowane")
        self.assertEqual(st, 403)  # niczego to nie otwiera: domyślnie „off”
        self.assertEqual(b.get("/v1/c/%s/outbox" % cid)[1]["requests"], [])

    def test_contact_full_flow_accept_and_privacy(self):
        o, cid = self.new_comm(); a = Client(self.base); b = Client(self.base); c = Client(self.base)
        self.post(a, cid, "post"); self.post(b, cid, "post b")
        self.assertEqual(a.act("contact.policy", cid=cid, mode="members", xpub=self._xpub())[0], 200)
        self.assertEqual(b.get("/v1/c/%s/policy?target=%s" % (cid, a.pub), auth=False)[1]["mode"], "members")
        st, r = b.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="blob1"); self.assertEqual(st, 200)
        rid = r["id"]
        # inbox: tylko adresat; ktoś trzeci nie widzi cudzej skrzynki
        self.assertEqual(self.new_get(c, "/v1/c/%s/inbox" % cid)["requests"], [])
        self.assertEqual(a.get("/v1/c/%s/inbox" % cid, auth=False)[0], 401)
        inbox = a.get("/v1/c/%s/inbox" % cid)[1]["requests"]; self.assertEqual([x["id"] for x in inbox], [rid])
        # nie-adresat nie może odpowiedzieć
        self.assertEqual(c.act("contact.reply", cid=cid, req=rid, status="accepted", box="x")[0], 404)
        self.assertEqual(a.act("contact.reply", cid=cid, req=rid, status="accepted", box="zaproszenie-zaszyfrowane")[0], 200)
        self.assertEqual(a.act("contact.reply", cid=cid, req=rid, status="rejected", box="")[0], 409)
        out = b.get("/v1/c/%s/outbox" % cid)[1]["requests"][0]
        self.assertEqual((out["status"], out["reply"]), ("accepted", "zaproszenie-zaszyfrowane"))
        self.assertEqual(a.get("/v1/c/%s/inbox" % cid)[1]["requests"], [])

    def new_get(self, c, path): return c.get(path)[1]

    def test_contact_members_only_mode_and_all_mode(self):
        o, cid = self.new_comm(); a = Client(self.base); outsider = Client(self.base)
        self.post(a, cid, "x")
        a.act("contact.policy", cid=cid, mode="members", xpub=self._xpub())
        self.assertEqual(outsider.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="b")[0], 403)
        a.act("contact.policy", cid=cid, mode="all", xpub=self._xpub())
        self.assertEqual(outsider.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="b")[0], 200)
        a.act("contact.policy", cid=cid, mode="off", xpub="")
        self.assertEqual(Client(self.base).act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="b")[0], 403)

    def test_contact_block_hides_and_limits(self):
        o, cid = self.new_comm(); a = Client(self.base); b = Client(self.base)
        self.post(a, cid, "x"); self.post(b, cid, "y")
        a.act("contact.policy", cid=cid, mode="all", xpub=self._xpub())
        self.assertEqual(b.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="1")[0], 200)
        self.assertEqual(b.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="2")[0], 200)
        self.assertEqual(b.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="3")[0], 429)  # limit oczekujących
        self.assertEqual(a.act("contact.block", cid=cid, target=b.pub)[0], 200)
        st, r = b.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="4")
        self.assertEqual((st, r["error"]), (403, "Autor nie przyjmuje próśb o kontakt."))  # ten sam komunikat co „off”
        self.assertEqual({x["status"] for x in b.get("/v1/c/%s/outbox" % cid)[1]["requests"]}, {"rejected"})

    def test_contact_banned_cannot_request_and_no_self_request(self):
        o, cid = self.new_comm(); a = Client(self.base); b = Client(self.base)
        self.post(a, cid, "x"); self.post(b, cid, "y")
        a.act("contact.policy", cid=cid, mode="all", xpub=self._xpub())
        self.assertEqual(a.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="s")[0], 400)
        o.act("mod.set", cid=cid, target=b.pub, role="banned")
        self.assertEqual(b.act("contact.request", cid=cid, target=a.pub, epub=self._xpub(), box="1")[0], 403)

    def test_activity_events_without_reactor_identity(self):
        o, cid = self.new_comm(); a = Client(self.base); b = Client(self.base)
        pid = self.post(a, cid, "mój wpis")[1]["id"]
        b.act("react", cid=cid, post=pid, emoji="🔥", on="1")
        self.post(b, cid, "odpowiedź", kind="comment", parent=pid, nick="Bob")
        self.post(b, cid, "", kind="repost", ref=pid)
        b.act("report", cid=cid, post=pid, reason="spam")
        ev = a.get("/v1/c/%s/activity?since=0" % cid)[1]["events"]
        self.assertEqual({e["type"] for e in ev}, {"reaction", "comment", "repost"})
        self.assertNotIn(b.pub, json.dumps(ev))  # nie ujawniamy, kto zareagował/odpisał
        self.assertEqual(b.get("/v1/c/%s/activity?since=0" % cid)[1]["events"], [])  # b nie ma własnych wpisów z aktywnością
        self.assertIn("report", {e["type"] for e in o.get("/v1/c/%s/activity?since=0" % cid)[1]["events"]})

    # --- skrzynki (store-and-forward)
    def _pull(self, *clients_boxes):
        ts = str(int(time.time() * 1000)); items = []
        for c in clients_boxes:
            items.append({"box": c.pub, "after": "0", "ts": ts, "sig": c.k.sign(R.sigmsg("pull", c.pub, "0", ts)).hex()})
        st, r = Client(self.base).post_raw("/v1/mbox/pull", {"items": items}); return st, r

    def test_mailbox_put_pull_ack(self):
        box = Client(self.base)  # klucz skrzynki wspólny dla pary
        self.assertEqual(box.act("mbox.put", box=box.pub, data="QUJD")[0], 200)
        self.assertEqual(box.act("mbox.put", box=box.pub, data="REVG")[0], 200)
        st, r = self._pull(box); items = r["results"][box.pub]
        self.assertEqual([i["data"] for i in items], ["QUJD", "REVG"])
        self.assertEqual(box.act("mbox.ack", box=box.pub, upto=str(items[0]["seq"]))[0], 200)
        st, r = self._pull(box); self.assertEqual([i["data"] for i in r["results"][box.pub]], ["REVG"])
        box.act("mbox.ack", box=box.pub, upto=str(items[1]["seq"]))
        st, r = self._pull(box); self.assertEqual(r["results"], {})

    def test_mailbox_only_key_holder_can_write_or_read(self):
        a, mallory = Client(self.base), Client(self.base)
        self.assertEqual(mallory.act("mbox.put", box=a.pub, data="QUJD")[0], 403)  # nie zna klucza skrzynki
        a.act("mbox.put", box=a.pub, data="QUJD")
        ts = str(int(time.time() * 1000))
        forged = {"box": a.pub, "after": "0", "ts": ts, "sig": mallory.k.sign(R.sigmsg("pull", a.pub, "0", ts)).hex()}
        st, r = mallory.post_raw("/v1/mbox/pull", {"items": [forged]})
        self.assertEqual(r["results"], {})  # podpis cudzym kluczem nie otwiera skrzynki
        self.assertEqual(mallory.act("mbox.ack", box=a.pub, upto="999")[0], 403)

    def test_mailbox_limits_and_validation(self):
        b = Client(self.base)
        self.assertEqual(b.act("mbox.put", box=b.pub, data="x" * 90001)[0], 400)
        self.assertEqual(b.act("mbox.put", box=b.pub, data="nie base64 !!")[0], 400)
        self.assertEqual(b.act("mbox.put", box=b.pub, data="")[0], 400)

    def test_mailbox_isolated_between_boxes_and_batch_pull(self):
        a, b = Client(self.base), Client(self.base)
        a.act("mbox.put", box=a.pub, data="QQ"); b.act("mbox.put", box=b.pub, data="Qg")
        st, r = self._pull(a, b)
        self.assertEqual(r["results"][a.pub][0]["data"], "QQ"); self.assertEqual(r["results"][b.pub][0]["data"], "Qg")
        st, r = self._pull(a); self.assertNotIn(b.pub, r["results"])

    def test_mailbox_full_and_ttl(self):
        c = Client(self.base)
        old = R.MBOX_MAX_ITEMS; R.MBOX_MAX_ITEMS = 3
        try:
            for i in range(3): self.assertEqual(c.act("mbox.put", box=c.pub, data="QQ")[0], 200)
            self.assertEqual(c.act("mbox.put", box=c.pub, data="QQ")[0], 429)
        finally: R.MBOX_MAX_ITEMS = old
        # TTL: stare wpisy są usuwane przy kolejnym zapisie
        self.relay.db.execute("UPDATE mbox SET ts=? WHERE box=?", (1, c.pub)); self.relay.db.commit()
        self.assertEqual(c.act("mbox.put", box=c.pub, data="Qg")[0], 200)
        st, r = self._pull(c); self.assertEqual([i["data"] for i in r["results"][c.pub]], ["Qg"])

    def test_text_limits(self):
        o, cid = self.new_comm(); u = Client(self.base)
        self.assertEqual(self.post(u, cid, "x" * 2001)[0], 400)
        self.assertEqual(self.post(u, cid, "   ")[0], 400)

    def test_pure_python_ed25519_matches(self):
        """Implementacja zapasowa (Termux bez `cryptography`) musi zgadzać się z biblioteką."""
        import importlib, sys, types
        src = open(R.__file__, encoding="utf-8").read()
        src = src.replace("from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey", "raise ImportError")
        mod = types.ModuleType("relay_pure"); exec(compile(src, "relay_pure", "exec"), mod.__dict__)
        k = Ed25519PrivateKey.generate(); pub = k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        m = b"SHYFR1|test"; s = k.sign(m)
        self.assertTrue(mod.ed_verify(pub, s, m)); self.assertFalse(mod.ed_verify(pub, s, m + b"x"))
        bad = bytearray(s); bad[5] ^= 1; self.assertFalse(mod.ed_verify(pub, bytes(bad), m))

if __name__ == "__main__":
    unittest.main(verbosity=2)
