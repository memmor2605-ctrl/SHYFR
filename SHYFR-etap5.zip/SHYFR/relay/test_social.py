import threading, time, unittest
import shyfr_relay as R
from test_relay import Client, BITS


class SocialTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.relay = R.Relay(":memory:", pow_bits=BITS, rate_per_min=100000)
        cls.srv = R.serve(cls.relay, "127.0.0.1", 0)
        cls.base = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.n = 0
    @classmethod
    def tearDownClass(cls): cls.srv.shutdown()

    def ident(self, vis="public", discover=1, hide_followers=0, hide_following=0, handle=None):
        SocialTests.n += 1
        c = Client(self.base); c.handle = handle or "user_%d" % SocialTests.n
        st, r = c.act("social.profile", handle=c.handle, name="Nazwa " + c.handle, bio="bio", vis=vis,
                      discover=str(discover), hide_followers=str(hide_followers), hide_following=str(hide_following))
        self.assertEqual(st, 200, r)
        return c

    def follow(self, a, b, on=1): return a.act("social.follow", target=b.pub, on=str(on))
    def decide(self, owner, fol, accept): return owner.act("social.decide", follower=fol.pub, accept=str(accept))
    def users(self, st_r): return [u["pub"] for u in st_r[1]["users"]]

    # 1. publiczne konto obserwuje publiczne
    def test_public_follows_public(self):
        a, b = self.ident(), self.ident()
        st, r = self.follow(a, b); self.assertEqual((st, r["state"]), (200, "active"))
        _, p = b.get("/v1/social/profile?pub=" + b.pub); self.assertEqual((p["followers"], p["following"]), (1, 0))
        _, pa = a.get("/v1/social/profile?pub=" + b.pub); self.assertEqual(pa["you_follow"], "active"); self.assertFalse(pa["follows_you"])
        self.assertIn(a.pub, self.users(b.get("/v1/social/followers?pub=" + b.pub)))
        self.assertIn(b.pub, self.users(a.get("/v1/social/following?pub=" + a.pub)))
        self.follow(b, a); _, pa = a.get("/v1/social/profile?pub=" + b.pub); self.assertTrue(pa["mutual"])

    # 2. konto prywatne dostaje prośbę i ją zatwierdza
    def test_private_request_and_approval(self):
        a, b = self.ident(), self.ident("private")
        st, r = self.follow(a, b); self.assertEqual(r["state"], "pending")
        _, p = b.get("/v1/social/profile?pub=" + b.pub); self.assertEqual(p["followers"], 0)  # prośba to jeszcze nie obserwujący
        reqs = b.get("/v1/social/requests")[1]["requests"]; self.assertEqual([x["pub"] for x in reqs], [a.pub])
        self.assertEqual(self.decide(b, a, 1)[0], 200)
        self.assertEqual(b.get("/v1/social/requests")[1]["requests"], [])
        _, p = b.get("/v1/social/profile?pub=" + b.pub); self.assertEqual(p["followers"], 1)
        ev = a.get("/v1/social/notifs?since=0")[1]["events"]; self.assertIn("accepted", [e["type"] for e in ev])
        evb = b.get("/v1/social/notifs?since=0")[1]["events"]; self.assertEqual(evb[0]["type"], "follow")

    def test_pending_request_is_a_notification_for_target(self):
        a, b = self.ident(), self.ident("private"); self.follow(a, b)
        self.assertEqual([e["type"] for e in b.get("/v1/social/notifs?since=0")[1]["events"]], ["request"])

    def test_reject_and_cancel(self):
        a, b = self.ident(), self.ident("private"); self.follow(a, b)
        self.assertEqual(self.decide(b, a, 0)[0], 200)
        self.assertEqual(b.get("/v1/social/requests")[1]["requests"], [])
        self.assertEqual(self.follow(a, b)[1]["state"], "pending")   # może poprosić ponownie
        self.assertEqual(self.follow(a, b, 0)[0], 200)               # i wycofać prośbę
        self.assertEqual(b.get("/v1/social/requests")[1]["requests"], [])
        self.assertEqual(self.decide(b, a, 1)[0], 404)               # nie ma już czego zatwierdzać

    # 3. niezatwierdzeni nie widzą list konta prywatnego (a prośby ani ich nie ujawniają)
    def test_private_lists_hidden_from_strangers(self):
        a, b, c, stranger = self.ident(), self.ident("private"), self.ident(), self.ident()
        self.follow(a, b); self.decide(b, a, 1); self.follow(b, c)
        for kind in ("followers", "following"):
            self.assertEqual(stranger.get("/v1/social/%s?pub=%s" % (kind, b.pub))[0], 403)
            self.assertEqual(c.get("/v1/social/%s?pub=%s" % (kind, b.pub), auth=False)[0], 403)
            self.assertEqual(a.get("/v1/social/%s?pub=%s" % (kind, b.pub))[0], 200)   # zatwierdzony widzi
            self.assertEqual(b.get("/v1/social/%s?pub=%s" % (kind, b.pub))[0], 200)   # właściciel widzi
        self.assertEqual(stranger.get("/v1/social/requests")[1]["requests"], [])      # cudzych próśb nie da się odczytać

    # 4. usunięcie obserwującego odcina go od przyszłych treści; ponowna prośba wymaga zgody
    def test_remove_follower(self):
        a, b = self.ident(), self.ident("private"); self.follow(a, b); self.decide(b, a, 1)
        self.assertEqual(self.decide(b, a, 0)[0], 200)
        self.assertEqual(self.users(b.get("/v1/social/followers?pub=" + b.pub)), [])
        self.assertEqual(a.get("/v1/social/followers?pub=" + b.pub)[0], 403)          # utracił dostęp do listy
        self.assertEqual(self.follow(a, b)[1]["state"], "pending")

    def test_block_removes_edges_and_prevents_follow(self):
        a, b = self.ident(), self.ident(); self.follow(a, b); self.follow(b, a)
        self.assertEqual(b.act("social.block", target=a.pub, on="1")[0], 200)
        self.assertEqual(self.users(b.get("/v1/social/followers?pub=" + b.pub)), [])
        self.assertEqual(self.users(a.get("/v1/social/followers?pub=" + a.pub)), [])
        st, r = self.follow(a, b); self.assertEqual(st, 403)
        self.assertEqual(a.get("/v1/social/profile?pub=" + b.pub)[0], 404)            # zablokowany nie widzi profilu
        self.assertEqual(b.act("social.block", target=a.pub, on="0")[0], 200)
        self.assertEqual(self.follow(a, b)[0], 200)

    # 5. konto anonimowe: osobny klucz, brak łączności z innymi tożsamościami, nieodkrywalne
    def test_anonymous_identity(self):
        main = self.ident("public", handle="glowny_klucz")
        anon = self.ident("anon", discover=0, handle="cien_9999")
        self.assertNotEqual(main.pub, anon.pub)
        self.assertEqual(self.users(main.get("/v1/social/search?q=cien_9999")), [])   # nieodkrywalny
        fan = self.ident(); self.assertEqual(self.follow(fan, anon)[1]["state"], "active")
        _, p = fan.get("/v1/social/profile?pub=" + anon.pub)
        self.assertNotIn(main.pub, str(p)); self.assertEqual(p["vis"], "anon")
        self.assertNotIn(main.pub, str(anon.get("/v1/social/notifs?since=0")[1]))

    # 6. ukrywanie list i liczników
    def test_hide_counts_and_lists(self):
        a, b = self.ident(), self.ident(hide_followers=1, hide_following=1); self.follow(a, b); self.follow(b, a)
        _, p = a.get("/v1/social/profile?pub=" + b.pub); self.assertEqual((p["followers"], p["following"]), (None, None))
        self.assertEqual(a.get("/v1/social/followers?pub=" + b.pub)[0], 403)
        self.assertEqual(a.get("/v1/social/following?pub=" + b.pub)[0], 403)
        _, own = b.get("/v1/social/profile?pub=" + b.pub); self.assertEqual(own["followers"], 1); self.assertEqual(own["hide_followers"], 1)

    # 7. wyszukiwanie i filtrowanie list
    def test_search_and_list_filter(self):
        t = self.ident(handle="szukany_abc", discover=1)
        hidden = self.ident(handle="szukany_xyz", discover=0)
        found = self.users(t.get("/v1/social/search?q=szukany_"))
        self.assertIn(t.pub, found); self.assertNotIn(hidden.pub, found)
        self.assertEqual(self.users(t.get("/v1/social/search?q=%25")), [])          # znak % nie działa jak wildcard
        a, b = self.ident(handle="kasia_k"), self.ident(handle="tomek_t")
        self.follow(a, t); self.follow(b, t)
        self.assertEqual(self.users(t.get("/v1/social/followers?pub=%s&q=kasia" % t.pub)), [a.pub])

    def test_unique_handle_and_change(self):
        a = self.ident(handle="unikalny_1")
        st, r = Client(self.base).act("social.profile", handle="unikalny_1", name="x", bio="", vis="public", discover="1", hide_followers="0", hide_following="0")
        self.assertEqual(st, 409)
        self.assertEqual(a.act("social.profile", handle="unikalny_2", name="x", bio="", vis="public", discover="1", hide_followers="0", hide_following="0")[0], 200)
        self.assertEqual(Client(self.base).act("social.profile", handle="unikalny_1", name="x", bio="", vis="public", discover="1", hide_followers="0", hide_following="0")[0], 200)
        self.assertEqual(Client(self.base).act("social.profile", handle="Z!", name="x", bio="", vis="public", discover="1", hide_followers="0", hide_following="0")[0], 400)

    # walidacje i ochrona przed nadużyciami
    def test_validation(self):
        a, b = self.ident(), self.ident()
        self.assertEqual(self.follow(a, a)[0], 400)
        nobody = Client(self.base); self.assertEqual(nobody.act("social.follow", target=nobody.pub[::-1], on="1")[0], 403)  # brak profilu celu
        self.assertEqual(self.decide(a, b, 1)[0], 404)
        self.assertEqual(a.act("social.follow", target=b.pub, on="2")[0], 400)

    def test_follow_requires_pow(self):
        a, b = self.ident(), self.ident()
        obj = {"type": "social.follow", "target": b.pub, "on": "1", "ts": str(int(time.time() * 1000)), "pub": a.pub}
        ts = obj["ts"]; msg = R.sigmsg("social.follow", b.pub, "1", ts); obj["sig"] = a.k.sign(msg).hex()
        st, r = a.post(obj); self.assertEqual(st, 400)

    def test_pending_cap(self):
        old = R.SOC_MAX_PENDING; R.SOC_MAX_PENDING = 2
        try:
            b = self.ident("private")
            for _ in range(2): self.assertEqual(self.follow(self.ident(), b)[0], 200)
            self.assertEqual(self.follow(self.ident(), b)[0], 429)
        finally: R.SOC_MAX_PENDING = old

    # 7 z listy kryteriów: widoczność przez wiele przekaźników = ten sam rekord podpisany kluczem, więc każdy przekaźnik go przyjmie
    def test_same_signed_record_is_accepted_by_a_second_relay(self):
        other = R.Relay(":memory:", pow_bits=BITS, rate_per_min=100000)
        a = Client(self.base)
        obj = {"type": "social.profile", "handle": "dwa_przekazniki", "name": "N", "bio": "", "vis": "public", "discover": "1", "hide_followers": "0",
               "hide_following": "0", "ts": str(int(time.time() * 1000)), "pub": a.pub}
        obj["sig"] = a.k.sign(R.sigmsg("social.profile", *[obj[k] for k in R.FIELDS["social.profile"]])).hex()
        self.assertTrue(self.relay.act(dict(obj))["ok"])
        self.assertTrue(other.act(dict(obj))["ok"])
        self.assertEqual(other.social_profile(a.pub, None)["handle"], "dwa_przekazniki")


if __name__ == "__main__":
    unittest.main()
