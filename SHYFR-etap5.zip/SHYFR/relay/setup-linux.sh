#!/usr/bin/env bash
# Instaluje przekaźnik SHYFR jako usługę systemową na Debian/Ubuntu/Raspberry Pi OS (stary komputer, Raspberry Pi, VPS).
# Użycie (w katalogu relay/, jako root): sudo bash setup-linux.sh
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Uruchom jako root: sudo bash $0"; exit 1; }
apt-get update -y && apt-get install -y tor python3 python3-cryptography
id shyfr >/dev/null 2>&1 || useradd --system --home /var/lib/shyfr-relay --create-home --shell /usr/sbin/nologin shyfr
install -d -o shyfr -g shyfr /opt/shyfr-relay /var/lib/shyfr-relay /var/lib/shyfr-relay/backup
install -m 644 "$(dirname "$0")/shyfr_relay.py" /opt/shyfr-relay/shyfr_relay.py
cat > /etc/systemd/system/shyfr-relay.service <<'EOS'
[Unit]
Description=SHYFR przekaźnik publiczny
After=network-online.target tor.service
Wants=network-online.target
[Service]
User=shyfr
Environment=SHYFR_RELAY_DB=/var/lib/shyfr-relay/relay.db
ExecStart=/usr/bin/python3 /opt/shyfr-relay/shyfr_relay.py
Restart=always
RestartSec=5
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/var/lib/shyfr-relay
PrivateTmp=true
[Install]
WantedBy=multi-user.target
EOS
cat > /etc/systemd/system/shyfr-relay-backup.service <<'EOS'
[Service]
Type=oneshot
User=shyfr
ExecStart=/usr/bin/python3 -c "import sqlite3,datetime,glob,os; d='/var/lib/shyfr-relay/'; s=sqlite3.connect(d+'relay.db'); t=sqlite3.connect(d+'backup/relay-'+datetime.date.today().isoformat()+'.db'); s.backup(t); t.close(); s.close(); [os.remove(f) for f in sorted(glob.glob(d+'backup/relay-*.db'))[:-7]]"
EOS
cat > /etc/systemd/system/shyfr-relay-backup.timer <<'EOS'
[Timer]
OnCalendar=daily
Persistent=true
[Install]
WantedBy=timers.target
EOS
if ! grep -q "shyfr_relay" /etc/tor/torrc; then
  printf '\n# SHYFR przekaźnik\nHiddenServiceDir /var/lib/tor/shyfr_relay/\nHiddenServicePort 80 127.0.0.1:8787\n' >> /etc/tor/torrc
fi
systemctl daemon-reload
systemctl enable --now tor shyfr-relay shyfr-relay-backup.timer
systemctl restart tor
echo "Czekam na adres onion (do 2 minut)..."
for i in $(seq 1 60); do [ -s /var/lib/tor/shyfr_relay/hostname ] && break; sleep 2; done
if [ -s /var/lib/tor/shyfr_relay/hostname ]; then echo "Adres przekaźnika: $(cat /var/lib/tor/shyfr_relay/hostname)"; else echo "Adres jeszcze się nie pojawił: sprawdź 'journalctl -u tor' i /var/lib/tor/shyfr_relay/hostname"; fi
