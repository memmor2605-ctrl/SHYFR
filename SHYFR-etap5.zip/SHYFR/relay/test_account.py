import hashlib, os, threading, time, unittest
import shyfr_relay as R
from test_relay import Client, BITS


def acct_keys(login, password):
    """Odpowiednik klienta: lookup i klucz podpisu zależą wyłącznie od loginu i hasła (tu SHA-256 zamiast Argon2id)."""
    root = hashlib.sha256(("account|" + login + "|" + password).encode()).digest()
    c = Client.__new__(Client)
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    c.k = Ed25519PrivateKey.from_private_bytes(hashlib.sha256(b"sign" + root).digest())
    c.pub = c.k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()
    return hashlib.sha256(b"lookup" + root).hexdigest(), c


class AccountTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.relay = R.Relay(":memory:", pow_bits=BITS, rate_per_min=100000)
        cls.srv = R.serve(cls.relay, "127.0.0.1", 0)
        cls.base = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
    @classmethod
    def tearDownClass(cls): cls.srv.shutdown()

    def acct(self, login, pw):
        lk, c = acct_keys(login, pw); c.base = self.base; return lk, c

    def test_new_device_gets_the_envelope_with_login_and_password_only(self):
        lk, old = self.acct("ala", "haslo-bardzo-dlugie-1")
        st, r = old.act("account.put", lookup=lk, ver=1, blob="QUJD" * 20); self.assertEqual(st, 200, r)
        lk2, newdev = self.acct("ala", "haslo-bardzo-dlugie-1")      # drugi telefon: te same dane, żadnego pliku
        self.assertEqual(lk, lk2)
        st, r = newdev.act("account.get", lookup=lk2); self.assertEqual((st, r["blob"], r["ver"]), (200, "QUJD" * 20, 1))

    def test_wrong_password_and_unknown_account_look_the_same(self):
        lk, c = self.acct("bob", "haslo-bardzo-dlugie-2"); c.act("account.put", lookup=lk, ver=1, blob="QUJD")
        lk_bad, bad = self.acct("bob", "inne-haslo-bardzo-dlugie")
        st1, r1 = bad.act("account.get", lookup=lk_bad)                     # zły lookup
        st2, r2 = bad.act("account.get", lookup=lk)                         # prawdziwy lookup, zły klucz
        _, nobody = self.acct("nikt", "x"); st3, r3 = nobody.act("account.get", lookup="0" * 64)
        self.assertEqual({st1, st2, st3}, {404}); self.assertEqual(r1["error"], r2["error"]); self.assertEqual(r2["error"], r3["error"])

    def test_only_the_owner_can_update_delete_and_versions_only_grow(self):
        lk, c = self.acct("cez", "haslo-bardzo-dlugie-3"); c.act("account.put", lookup=lk, ver=1, blob="QUJD")
        _, thief = self.acct("zlodziej", "inne-haslo-123456")
        self.assertEqual(thief.act("account.put", lookup=lk, ver=2, blob="WlpaWg")[0], 403)
        self.assertEqual(thief.act("account.delete", lookup=lk)[0], 404)
        self.assertEqual(c.act("account.put", lookup=lk, ver=1, blob="QUJD")[0], 409)   # brak cofania wersji
        self.assertEqual(c.act("account.put", lookup=lk, ver=2, blob="RERERA")[0], 200)
        self.assertEqual(c.act("account.get", lookup=lk)[1]["blob"], "RERERA")
        self.assertEqual(c.act("account.delete", lookup=lk)[0], 200)
        self.assertEqual(c.act("account.get", lookup=lk)[0], 404)

    def test_validation_and_pow(self):
        lk, c = self.acct("dan", "haslo-bardzo-dlugie-4")
        self.assertEqual(c.act("account.put", lookup="zly", ver=1, blob="QUJD")[0], 400)
        self.assertEqual(c.act("account.put", lookup=lk, ver=1, blob="a" * (R.ACCOUNT_MAX_BLOB + 1))[0], 400)
        self.assertEqual(c.act("account.put", lookup=lk, ver=1, blob="nie base64!")[0], 400)
        self.assertEqual(c.act("account.put", lookup=lk, ver=0, blob="QUJD")[0], 400)
        ts = str(int(time.time() * 1000)); msg = R.sigmsg("account.get", lk, ts)
        st, r = c.post({"type": "account.get", "lookup": lk, "ts": ts, "pub": c.pub, "sig": c.k.sign(msg).hex()})
        self.assertEqual(st, 400)                                                         # bez dowodu pracy

    def test_blob_is_not_readable_by_other_endpoints(self):
        lk, c = self.acct("ewa", "haslo-bardzo-dlugie-5"); c.act("account.put", lookup=lk, ver=1, blob="U0VLUkVU")
        for path in ("/v1/info", "/v1/communities", "/v1/social/search?q=ewa"):
            self.assertNotIn("U0VLUkVU", str(c.get(path)[1]))


if __name__ == "__main__":
    unittest.main()
