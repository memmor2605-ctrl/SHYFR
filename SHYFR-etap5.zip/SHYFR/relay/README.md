# SHYFR przekaźnik publiczny (relay)

Serwer treści publicznych: społeczności, kanały, wpisy, komentarze, reakcje, zgłoszenia. Prywatne rozmowy NIE przechodzą przez niego (idą P2P przez Tor).
Tylko biblioteka standardowa Pythona (`cryptography` przyspiesza weryfikację podpisów, jeśli jest).

## Uruchomienie w Termux (jak dotychczasowy przekaźnik)
```
pkg install python tor
mkdir -p ~/shyfr-relay && cp shyfr_relay.py ~/shyfr-relay/ && cd ~/shyfr-relay
termux-wake-lock
python3 shyfr_relay.py &
```
Do `torrc` Tora (Termux: `$PREFIX/etc/tor/torrc`) dopisz i zrestartuj Tora:
```
HiddenServiceDir /data/data/com.termux/files/home/.shyfr-relay/hs
HiddenServicePort 80 127.0.0.1:8787
```
Adres usługi: `cat ~/.shyfr-relay/hs/hostname`. Wpisz go w aplikacji: Ustawienia → Społeczności → Przekaźnik publiczny.
Zmienne: `SHYFR_RELAY_DB` (plik bazy, domyślnie `relay.db`), `SHYFR_RELAY_PORT` (8787), `SHYFR_POW_BITS` (12; wyższa wartość = trudniej spamować, wolniej publikować).

## Skrzynki dla wiadomości prywatnych
Przekaźnik przechowuje zaszyfrowane ramki między parą kontaktów (store-and-forward), gdy bezpośrednie połączenie P2P przez Tor się nie uda. Widzi szyfrogram, rozmiar i czas; identyfikator skrzynki zna tylko para. Limity: 64 kB na ramkę, 500 wiadomości / 8 MB na skrzynkę, 14 dni.

## Testy
`python3 -m unittest test_relay test_social -v` (56 testów: 41 w test_relay.py i 15 w test_social.py. Pokrywają: podpisy, PoW, uprawnienia, prywatne/ukryte społeczności, zaproszenia, bany, paginacja, wyszukiwanie, brak wycieku identyfikatorów).

## Model prywatności i jego granice (bez złudzeń)
- Każdy rekord podpisuje klucz Ed25519 wyprowadzony OSOBNO dla każdej społeczności z klucza sejfu. Przekaźnik nie dostaje SID, adresu onion ani innego stałego identyfikatora; nie loguje adresów połączeń.
- Operator przekaźnika WIDZI całą treść (publiczne treści nie są szyfrowane end-to-end), czasy publikacji i potrafi powiązać wpisy tego samego pseudonimu w obrębie jednej społeczności. Wpisy z różnych społeczności nie są powiązane kluczami, ale analiza stylu pisania i czasu aktywności może je powiązać.
- Tor ukrywa adres IP, ale nie chroni przed analizą korelacji czasowej przez operatora, który sam obserwuje ruch.
- Operator może cenzurować, usuwać i zmieniać kolejność treści. Społeczności „prywatne” i „ukryte” są chronione tylko zaufaniem do operatora, nie kryptografią.
- Brak multimediów (obrazy/wideo) w tej wersji protokołu; tylko tekst do 2000 znaków.
- Ochrona przed spamem: dowód pracy (PoW) + limit akcji na klucz. Nowy klucz omija limit na klucz, ale nie PoW.

## Domyślny przekaźnik wbudowany w aplikację (feed i społeczności bez konfiguracji)
Żeby użytkownicy nie musieli nic wpisywać, ustaw adres onion swojego przekaźnika w zmiennej repozytorium GitHub `SHYFR_DEFAULT_RELAY`
(Settings → Secrets and variables → Actions → Variables). Workflow przekaże go do budowania (`-PshyfrDefaultRelay=...`), a aplikacja użyje go,
dopóki użytkownik sam nie wpisze innego. Lokalnie: `gradle assembleDebug -PshyfrDefaultRelay=xxxxxxxx.onion`.
Przekaźnik musi działać stale: najlepiej mały serwer VPS albo Raspberry Pi w domu (usługa onion nie wymaga otwierania portów). Telefon z Termux nadaje się do testów, nie do stałej pracy.
Operator przekaźnika odpowiada za moderację i widzi treści publiczne: opisz go w polityce prywatności przed publikacją.

## Darmowe hostowanie (bez wynajmowania serwera)
Prywatne rozmowy działają zupełnie bez serwera (P2P przez Tor). Przekaźnik jest potrzebny tylko do feedu, społeczności i skrzynki. Najtańsze opcje:
1. **Sprzęt, który już masz (0 zł):** stary telefon z Androidem na ładowarce i Wi-Fi (`bash setup-termux.sh`, w Termux), albo Raspberry Pi / stary komputer z Debianem lub Ubuntu (`sudo bash setup-linux.sh`). Usługa onion nie wymaga otwierania portów ani stałego IP. Skrypty robią też codzienną kopię bazy (7 ostatnich).
2. **Darmowy VPS w chmurze:** np. Oracle Always Free. Uwaga: Oracle zastrzega odzyskiwanie bezczynnych instancji (CPU poniżej progu przez 7 dni), konta bywają blokowane, a zasoby bywają niedostępne. Rób kopie zapasowe i nie traktuj tego jako gwarancji.
3. **Telefon, na którym testujesz:** wystarczy do testów, nie do stałej pracy (usypia, wyczerpuje baterię, restartuje się).
Skrypty zostały sprawdzone tylko pod względem składni, nie na prawdziwym telefonie ani serwerze: przy pierwszym uruchomieniu zgłoś mi błędy.

## Obserwowanie i tożsamości społecznościowe (etap 24)
Tożsamość to osobny klucz Ed25519 aplikacji (publiczna, prywatna, anonimowa). Akcje: `social.profile`, `social.follow` (z PoW), `social.decide` (zatwierdzenie/odrzucenie prośby albo usunięcie obserwującego), `social.block`.
Odczyt: `/v1/social/profile|followers|following|requests|search|notifs`. Konto publiczne i anonimowe: obserwowanie bez zgody. Konto prywatne: prośba, którą właściciel zatwierdza.
Granice, bez złudzeń:
- Operator przekaźnika WIDZI krawędzie grafu (klucz obserwującego -> klucz obserwowanego), prośby i profile. Ukrycie list i liczników działa tylko w odpowiedziach przekaźnika, to nie kryptografia.
- Zablokowanie nie jest tajne wobec operatora; zablokowany dostaje ten sam komunikat co przy braku profilu.
- Wyciszenie, bliscy znajomi, ulubione i ograniczenia są tylko lokalne w aplikacji (nie trafiają do przekaźnika).
- Wpisy z ograniczonym odbiorcą (obserwujący, bliscy znajomi) i ich szyfrowanie nie są jeszcze zaimplementowane.
