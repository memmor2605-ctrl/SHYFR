#!/usr/bin/env python3
"""
SHYFR przekaźnik publiczny (relay) v1.

Przechowuje PUBLICZNE treści: społeczności, kanały, wpisy, komentarze, reakcje, zgłoszenia.
Nie widzi prywatnych rozmów (te idą P2P przez Tor, osobnym protokołem).

Model tożsamości: każdy rekord jest podpisany kluczem Ed25519 wyprowadzonym przez klienta
OSOBNO DLA KAŻDEJ SPOŁECZNOŚCI. Przekaźnik nie zna globalnego identyfikatora (SID), adresu onion
ani żadnego innego stałego identyfikatora użytkownika i nie loguje adresów połączeń.

Zależności: tylko biblioteka standardowa Pythona. Jeśli dostępna jest biblioteka `cryptography`,
weryfikacja podpisów jest szybsza; w przeciwnym razie używana jest implementacja z RFC 8032.
Uruchomienie: python3 shyfr_relay.py   (zmienne: SHYFR_RELAY_DB, SHYFR_RELAY_PORT, SHYFR_POW_BITS)
"""
import base64, hashlib, json, os, re, sqlite3, sys, threading, time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

VERSION = 1
MAX_BODY = 110 * 1024  # wpisy mają własne, mniejsze limity; większy rozmiar dotyczy tylko skrzynek (mbox)
MAX_TEXT = 2000
SKEW_MS = 10 * 60 * 1000

# ---------------------------------------------------------------- Ed25519 (weryfikacja)
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature

    def ed_verify(pub: bytes, sig: bytes, msg: bytes) -> bool:
        try:
            Ed25519PublicKey.from_public_bytes(pub).verify(sig, msg)
            return True
        except (InvalidSignature, ValueError):
            return False
except ImportError:  # implementacja referencyjna RFC 8032 (tylko weryfikacja)
    _p = 2 ** 255 - 19
    _d = -121665 * pow(121666, _p - 2, _p) % _p
    _q = 2 ** 252 + 27742317777372353535851937790883648493

    def _inv(x): return pow(x, _p - 2, _p)

    def _recover_x(y, sign):
        if y >= _p: return None
        x2 = (y * y - 1) * _inv(_d * y * y + 1) % _p
        if x2 == 0: return None if sign else 0
        x = pow(x2, (_p + 3) // 8, _p)
        if (x * x - x2) % _p != 0: x = x * pow(2, (_p - 1) // 4, _p) % _p
        if (x * x - x2) % _p != 0: return None
        if (x & 1) != sign: x = _p - x
        return x

    _gy = 4 * _inv(5) % _p
    _gx = _recover_x(_gy, 0)
    _G = (_gx, _gy, 1, _gx * _gy % _p)

    def _add(P, Q):
        A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
        B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
        C = 2 * P[3] * Q[3] * _d % _p
        D = 2 * P[2] * Q[2] % _p
        E, F, G, H = B - A, D - C, D + C, B + A
        return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)

    def _mul(s, P):
        Q = (0, 1, 1, 0)
        while s > 0:
            if s & 1: Q = _add(Q, P)
            P = _add(P, P); s >>= 1
        return Q

    def _eq(P, Q):
        return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0

    def _dec(s):
        if len(s) != 32: return None
        y = int.from_bytes(s, "little"); sign = y >> 255; y &= (1 << 255) - 1
        x = _recover_x(y, sign)
        return None if x is None else (x, y, 1, x * y % _p)

    def ed_verify(pub: bytes, sig: bytes, msg: bytes) -> bool:
        if len(pub) != 32 or len(sig) != 64: return False
        A = _dec(pub); R = _dec(sig[:32])
        if A is None or R is None: return False
        s = int.from_bytes(sig[32:], "little")
        if s >= _q: return False
        h = int.from_bytes(hashlib.sha512(sig[:32] + pub + msg).digest(), "little") % _q
        return _eq(_mul(s, _G), _add(R, _mul(h, A)))

# ---------------------------------------------------------------- protokół
def sigmsg(typ: str, *parts) -> bytes:
    """Bajty podpisywane przez klienta: SHYFR1|typ|b64url(część)|... (części to teksty UTF-8)."""
    enc = [base64.urlsafe_b64encode(str(p).encode("utf-8")).rstrip(b"=").decode() for p in parts]
    return ("SHYFR1|" + typ + "".join("|" + e for e in enc)).encode("utf-8")

def pow_ok(msg: bytes, nonce, bits: int) -> bool:
    if bits <= 0: return True
    try: n = int(nonce)
    except (TypeError, ValueError): return False
    if n < 0: return False
    h = hashlib.sha256(msg + b"|" + str(n).encode()).digest()
    v = int.from_bytes(h, "big")
    return v >> (256 - bits) == 0

FIELDS = {
    "community.create": ["cid", "name", "descr", "vis", "category", "ts"],
    "channel.create": ["cid", "name", "ckind", "ts"],
    "member.join": ["cid", "invite", "ts"],
    "member.leave": ["cid", "ts"],
    "mod.set": ["cid", "target", "role", "ts"],
    "invite.create": ["cid", "code", "uses", "expires", "ts"],
    "post.create": ["cid", "channel", "kind", "parent", "ref", "text", "nick", "ts"],
    "post.edit": ["cid", "post", "text", "ts"],
    "post.delete": ["cid", "post", "ts"],
    "post.pin": ["cid", "post", "on", "ts"],
    "react": ["cid", "post", "emoji", "on", "ts"],
    "report": ["cid", "post", "reason", "ts"],
    "contact.policy": ["cid", "mode", "xpub", "ts"],
    "contact.request": ["cid", "target", "epub", "box", "ts"],
    "contact.reply": ["cid", "req", "status", "box", "ts"],
    "contact.block": ["cid", "target", "ts"],
    "mbox.put": ["box", "data", "ts"],
    "mbox.ack": ["box", "upto", "ts"],
}
MBOX_MAX_ITEM = 90_000        # znaków base64 (ramka do ok. 64 kB)
MBOX_MAX_ITEMS = 500          # wiadomości na skrzynkę
MBOX_MAX_BYTES = 8_000_000    # bajtów na skrzynkę
MBOX_MAX_TOTAL = 200_000      # wiadomości na przekaźnik
MBOX_TTL_MS = 14 * 24 * 3600 * 1000
RE_B64 = re.compile(r"^[A-Za-z0-9_\-]+$")
POW_TYPES = {"post.create", "community.create", "member.join", "report", "contact.request"}
RE_CID = re.compile(r"^[0-9a-f]{16}$")
RE_PUB = re.compile(r"^[0-9a-f]{64}$")
RE_CHAN = re.compile(r"^[\w\-]{1,32}$")
RE_CODE = re.compile(r"^[A-Za-z0-9]{8,32}$")
RE_TAG = re.compile(r"#(\w{2,40})", re.UNICODE)
VIS = ("public", "private", "hidden")
CKINDS = ("discussion", "announce", "board")
KINDS = ("post", "comment", "repost", "quote")
STAFF = ("owner", "mod")

class Err(Exception):
    def __init__(self, code, msg): super().__init__(msg); self.code = code; self.msg = msg

SCHEMA = """
CREATE TABLE IF NOT EXISTS communities(cid TEXT PRIMARY KEY, name TEXT, descr TEXT, vis TEXT, category TEXT, created INTEGER);
CREATE TABLE IF NOT EXISTS channels(cid TEXT, name TEXT, kind TEXT, PRIMARY KEY(cid, name));
CREATE TABLE IF NOT EXISTS members(cid TEXT, pub TEXT, role TEXT, joined INTEGER, PRIMARY KEY(cid, pub));
CREATE TABLE IF NOT EXISTS invites(cid TEXT, code TEXT, uses_left INTEGER, expires INTEGER, PRIMARY KEY(cid, code));
CREATE TABLE IF NOT EXISTS posts(rowid INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE, cid TEXT, channel TEXT, kind TEXT,
  parent TEXT, ref TEXT, text TEXT, nick TEXT, pub TEXT, ts INTEGER, edited INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0, pinned INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_posts_cid ON posts(cid, parent, rowid);
CREATE INDEX IF NOT EXISTS idx_posts_ref ON posts(ref);
CREATE TABLE IF NOT EXISTS reactions(post TEXT, pub TEXT, emoji TEXT, rts INTEGER DEFAULT 0, PRIMARY KEY(post, pub, emoji));
CREATE TABLE IF NOT EXISTS contact_policy(cid TEXT, pub TEXT, mode TEXT, xpub TEXT, PRIMARY KEY(cid, pub));
CREATE TABLE IF NOT EXISTS contact_requests(id TEXT PRIMARY KEY, cid TEXT, target TEXT, requester TEXT, epub TEXT, box TEXT, status TEXT, reply TEXT, ts INTEGER);
CREATE INDEX IF NOT EXISTS idx_cr_target ON contact_requests(cid, target, status);
CREATE INDEX IF NOT EXISTS idx_cr_req ON contact_requests(cid, requester);
CREATE TABLE IF NOT EXISTS mbox(seq INTEGER PRIMARY KEY AUTOINCREMENT, box TEXT, data TEXT, ts INTEGER);
CREATE INDEX IF NOT EXISTS idx_mbox ON mbox(box, seq);
CREATE TABLE IF NOT EXISTS contact_blocks(cid TEXT, target TEXT, blocked TEXT, PRIMARY KEY(cid, target, blocked));
CREATE TABLE IF NOT EXISTS tags(post TEXT, tag TEXT);
CREATE INDEX IF NOT EXISTS idx_tags ON tags(tag);
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT, cid TEXT, post TEXT, pub TEXT, reason TEXT, ts INTEGER);
"""

class Relay:
    def __init__(self, db_path=":memory:", pow_bits=12, rate_per_min=20):
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.executescript(SCHEMA)
        if "rts" not in [r[1] for r in self.db.execute("PRAGMA table_info(reactions)")]:  # migracja starszych baz
            self.db.execute("ALTER TABLE reactions ADD COLUMN rts INTEGER DEFAULT 0")
        self.lock = threading.RLock()
        self.pow_bits = pow_bits
        self.rate = rate_per_min
        self.hits = {}

    # ------------------------------------------------------------ pomocnicze
    def now(self): return int(time.time() * 1000)

    def _rate(self, pub, limit=None):
        t = time.time(); q = self.hits.setdefault(pub, deque())
        while q and q[0] < t - 60: q.popleft()
        if len(q) >= (limit or self.rate): raise Err(429, "Za dużo akcji, spróbuj za chwilę.")
        q.append(t)
        if len(self.hits) > 5000: self.hits.clear()

    def role(self, cid, pub):
        r = self.db.execute("SELECT role FROM members WHERE cid=? AND pub=?", (cid, pub)).fetchone()
        return r[0] if r else None

    def community(self, cid):
        r = self.db.execute("SELECT cid,name,descr,vis,category,created FROM communities WHERE cid=?", (cid,)).fetchone()
        if not r: raise Err(404, "Nie ma takiej społeczności.")
        return dict(zip(("cid", "name", "descr", "vis", "category", "created"), r))

    def _need_text(self, s, mx, what, allow_empty=False):
        if not isinstance(s, str): raise Err(400, what + ": zły typ")
        if len(s) > mx or (not allow_empty and not s.strip()): raise Err(400, what + ": zła długość")

    # ------------------------------------------------------------ akcje (podpisane)
    def act(self, obj):
        with self.lock:
            return self._act(obj)

    def _act(self, obj):
        typ = obj.get("type")
        if typ not in FIELDS: raise Err(400, "Nieznany typ akcji.")
        pub_hex, sig_hex = obj.get("pub", ""), obj.get("sig", "")
        if not isinstance(pub_hex, str) or not RE_PUB.match(pub_hex): raise Err(400, "Zły klucz.")
        try: sig = bytes.fromhex(sig_hex)
        except (ValueError, TypeError): raise Err(400, "Zły podpis.")
        parts = []
        for f in FIELDS[typ]:
            if f not in obj: raise Err(400, "Brak pola " + f)
            v = obj[f]
            if isinstance(v, bool) or not isinstance(v, (str, int)): raise Err(400, "Zły typ pola " + f)
            parts.append(str(v))
        msg = sigmsg(typ, *parts)
        if not ed_verify(bytes.fromhex(pub_hex), sig, msg): raise Err(401, "Podpis nieprawidłowy.")
        f = dict(zip(FIELDS[typ], parts))
        try: ts = int(f["ts"])
        except ValueError: raise Err(400, "Zły czas.")
        if abs(ts - self.now()) > SKEW_MS: raise Err(400, "Czas poza dopuszczalnym oknem.")
        if typ in POW_TYPES and not pow_ok(msg, obj.get("pow"), self.pow_bits): raise Err(400, "Brak dowodu pracy (PoW).")
        self._rate(pub_hex, 300 if typ.startswith("mbox.") else None)
        if f.get("cid") is not None and not RE_CID.match(f["cid"]): raise Err(400, "Zły identyfikator społeczności.")
        res = getattr(self, "_do_" + typ.replace(".", "_"))(pub_hex, f, msg, ts)
        self.db.commit()
        return res

    def _writable_role(self, cid, pub):
        r = self.role(cid, pub)
        if r == "banned": raise Err(403, "Zablokowano w tej społeczności.")
        return r

    def _do_community_create(self, pub, f, msg, ts):
        cid = f["cid"]
        if self.db.execute("SELECT 1 FROM communities WHERE cid=?", (cid,)).fetchone(): raise Err(409, "Identyfikator zajęty.")
        self._need_text(f["name"], 60, "nazwa"); self._need_text(f["descr"], 500, "opis", True)
        self._need_text(f["category"], 32, "kategoria", True)
        if f["vis"] not in VIS: raise Err(400, "Zła widoczność.")
        self.db.execute("INSERT INTO communities VALUES(?,?,?,?,?,?)", (cid, f["name"], f["descr"], f["vis"], f["category"], ts))
        self.db.execute("INSERT INTO channels VALUES(?,?,?)", (cid, "ogólny", "discussion"))
        self.db.execute("INSERT INTO channels VALUES(?,?,?)", (cid, "ogłoszenia", "announce"))
        self.db.execute("INSERT INTO members VALUES(?,?,?,?)", (cid, pub, "owner", ts))
        return {"ok": True, "cid": cid}

    def _do_channel_create(self, pub, f, msg, ts):
        self.community(f["cid"])
        if self.role(f["cid"], pub) not in STAFF: raise Err(403, "Tylko administracja.")
        if not RE_CHAN.match(f["name"]) or f["ckind"] not in CKINDS: raise Err(400, "Zły kanał.")
        if self.db.execute("SELECT 1 FROM channels WHERE cid=? AND name=?", (f["cid"], f["name"])).fetchone(): raise Err(409, "Kanał istnieje.")
        n = self.db.execute("SELECT COUNT(*) FROM channels WHERE cid=?", (f["cid"],)).fetchone()[0]
        if n >= 20: raise Err(400, "Za dużo kanałów.")
        self.db.execute("INSERT INTO channels VALUES(?,?,?)", (f["cid"], f["name"], f["ckind"]))
        return {"ok": True}

    def _do_member_join(self, pub, f, msg, ts):
        c = self.community(f["cid"]); cid = c["cid"]
        r = self._writable_role(cid, pub)
        if r: return {"ok": True, "role": r}
        if c["vis"] != "public":
            code = f["invite"]
            row = self.db.execute("SELECT uses_left, expires FROM invites WHERE cid=? AND code=?", (cid, code)).fetchone()
            if not row or row[0] <= 0 or (row[1] and row[1] < self.now()): raise Err(403, "Zaproszenie jest nieprawidłowe lub wygasło.")
            self.db.execute("UPDATE invites SET uses_left=uses_left-1 WHERE cid=? AND code=?", (cid, code))
        self.db.execute("INSERT INTO members VALUES(?,?,?,?)", (cid, pub, "member", ts))
        return {"ok": True, "role": "member"}

    def _do_member_leave(self, pub, f, msg, ts):
        r = self.role(f["cid"], pub)
        if r == "owner": raise Err(400, "Właściciel nie może opuścić społeczności.")
        if r == "banned": return {"ok": True}  # blokada zostaje
        self.db.execute("DELETE FROM members WHERE cid=? AND pub=?", (f["cid"], pub))
        return {"ok": True}

    def _do_mod_set(self, pub, f, msg, ts):
        cid, target, role = f["cid"], f["target"], f["role"]
        mine = self.role(cid, pub)
        if mine not in STAFF: raise Err(403, "Tylko administracja.")
        if not RE_PUB.match(target) or role not in ("mod", "member", "banned"): raise Err(400, "Złe dane.")
        cur = self.role(cid, target)
        if cur == "owner": raise Err(403, "Nie można zmienić właściciela.")
        if role == "mod" and mine != "owner": raise Err(403, "Moderatorów ustawia tylko właściciel.")
        if cur == "mod" and mine != "owner": raise Err(403, "Moderatora zmienia tylko właściciel.")
        if cur is None: self.db.execute("INSERT INTO members VALUES(?,?,?,?)", (cid, target, role, ts))
        else: self.db.execute("UPDATE members SET role=? WHERE cid=? AND pub=?", (role, cid, target))
        return {"ok": True}

    def _do_invite_create(self, pub, f, msg, ts):
        cid = f["cid"]; self.community(cid)
        if self.role(cid, pub) not in STAFF: raise Err(403, "Tylko administracja.")
        if not RE_CODE.match(f["code"]): raise Err(400, "Zły kod.")
        try: uses = int(f["uses"]); exp = int(f["expires"])
        except ValueError: raise Err(400, "Złe liczby.")
        if not (1 <= uses <= 1000): raise Err(400, "Zła liczba użyć.")
        self.db.execute("INSERT OR REPLACE INTO invites VALUES(?,?,?,?)", (cid, f["code"], uses, exp))
        return {"ok": True}

    def _do_post_create(self, pub, f, msg, ts):
        cid = f["cid"]; c = self.community(cid)
        role = self._writable_role(cid, pub)
        if c["vis"] != "public" and role is None: raise Err(403, "Najpierw dołącz do społeczności.")
        ch = self.db.execute("SELECT kind FROM channels WHERE cid=? AND name=?", (cid, f["channel"])).fetchone()
        if not ch: raise Err(404, "Nie ma takiego kanału.")
        kind, parent, ref, text, nick = f["kind"], f["parent"], f["ref"], f["text"], f["nick"]
        if kind not in KINDS: raise Err(400, "Zły rodzaj wpisu.")
        self._need_text(text, MAX_TEXT, "treść", allow_empty=(kind == "repost"))
        self._need_text(nick, 32, "pseudonim", True)
        if kind == "comment":
            p = self.db.execute("SELECT deleted FROM posts WHERE id=? AND cid=?", (parent, cid)).fetchone()
            if not p or p[0]: raise Err(404, "Brak wpisu nadrzędnego.")
        else:
            if parent: raise Err(400, "Tylko komentarz ma rodzica.")
            if ch[0] == "announce" and role not in STAFF: raise Err(403, "W kanale ogłoszeń piszą tylko wybrane role.")
        if kind in ("repost", "quote"):
            r = self.db.execute("SELECT p.cid, c.vis, p.deleted FROM posts p JOIN communities c ON c.cid=p.cid WHERE p.id=?", (ref,)).fetchone()
            if not r or r[2] or (r[1] != "public" and r[0] != cid): raise Err(404, "Brak wpisu do udostępnienia.")
        elif ref: raise Err(400, "Tylko repost/cytat ma odniesienie.")
        pid = hashlib.sha256(msg + bytes.fromhex(pub)).hexdigest()[:32]
        try:
            self.db.execute("INSERT INTO posts(id,cid,channel,kind,parent,ref,text,nick,pub,ts) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            (pid, cid, f["channel"], kind, parent, ref, text, nick, pub, ts))
        except sqlite3.IntegrityError:
            raise Err(409, "Duplikat.")
        if role is None: self.db.execute("INSERT INTO members VALUES(?,?,?,?)", (cid, pub, "member", ts))
        for tag in set(t.lower() for t in RE_TAG.findall(text)):
            self.db.execute("INSERT INTO tags VALUES(?,?)", (pid, tag))
        return {"ok": True, "id": pid}

    def _post(self, cid, pid):
        r = self.db.execute("SELECT pub, deleted FROM posts WHERE id=? AND cid=?", (pid, cid)).fetchone()
        if not r: raise Err(404, "Brak wpisu.")
        return r

    def _do_post_edit(self, pub, f, msg, ts):
        author, deleted = self._post(f["cid"], f["post"])
        if author != pub or deleted: raise Err(403, "Edytować można tylko własny wpis.")
        self._need_text(f["text"], MAX_TEXT, "treść")
        self.db.execute("UPDATE posts SET text=?, edited=? WHERE id=?", (f["text"], ts, f["post"]))
        self.db.execute("DELETE FROM tags WHERE post=?", (f["post"],))
        for tag in set(t.lower() for t in RE_TAG.findall(f["text"])):
            self.db.execute("INSERT INTO tags VALUES(?,?)", (f["post"], tag))
        return {"ok": True}

    def _do_post_delete(self, pub, f, msg, ts):
        author, _ = self._post(f["cid"], f["post"])
        if author != pub and self.role(f["cid"], pub) not in STAFF: raise Err(403, "Brak uprawnień.")
        self.db.execute("UPDATE posts SET deleted=1, text='', nick='', pinned=0 WHERE id=?", (f["post"],))
        self.db.execute("DELETE FROM tags WHERE post=?", (f["post"],))
        return {"ok": True}

    def _do_post_pin(self, pub, f, msg, ts):
        if self.role(f["cid"], pub) not in STAFF: raise Err(403, "Tylko administracja.")
        self._post(f["cid"], f["post"])
        self.db.execute("UPDATE posts SET pinned=? WHERE id=? AND parent=''", (1 if f["on"] == "1" else 0, f["post"]))
        return {"ok": True}

    def _do_react(self, pub, f, msg, ts):
        cid = f["cid"]; c = self.community(cid)
        r = self._writable_role(cid, pub)
        if c["vis"] != "public" and r is None: raise Err(403, "Najpierw dołącz do społeczności.")
        _, deleted = self._post(cid, f["post"])
        if deleted: raise Err(404, "Wpis usunięty.")
        e = f["emoji"]
        if not (1 <= len(e) <= 8): raise Err(400, "Zła reakcja.")
        if f["on"] == "1": self.db.execute("INSERT OR IGNORE INTO reactions(post,pub,emoji,rts) VALUES(?,?,?,?)", (f["post"], pub, e, ts))
        else: self.db.execute("DELETE FROM reactions WHERE post=? AND pub=? AND emoji=?", (f["post"], pub, e))
        return {"ok": True}

    def _do_report(self, pub, f, msg, ts):
        self._post(f["cid"], f["post"]); self._need_text(f["reason"], 200, "powód", True)
        self.db.execute("INSERT INTO reports(cid,post,pub,reason,ts) VALUES(?,?,?,?,?)", (f["cid"], f["post"], pub, f["reason"], ts))
        return {"ok": True}

    # ------------------------------------------------------------ skrzynki (store-and-forward dla prywatnych rozmów)
    # Skrzynka to jednokierunkowa kolejka zaszyfrowanych ramek między DWOMA kontaktami. Jej identyfikator to klucz publiczny Ed25519
    # wyprowadzony przez obu rozmówców ze wspólnego sekretu: pisać i czytać może tylko ta para. Przekaźnik widzi szyfrogramy (Double Ratchet),
    # rozmiary i czasy, ale nie treść ani tożsamości (identyfikator skrzynki nie wiąże się z kluczem tożsamości ani adresem onion).
    def _do_mbox_put(self, pub, f, msg, ts):
        box, data = f["box"], f["data"]
        if pub != box: raise Err(403, "Skrzynka należy do kogoś innego.")
        if not data or len(data) > MBOX_MAX_ITEM or not RE_B64.match(data): raise Err(400, "Zła zawartość.")
        self.db.execute("DELETE FROM mbox WHERE ts<?", (self.now() - MBOX_TTL_MS,))
        n, size = self.db.execute("SELECT COUNT(*), COALESCE(SUM(LENGTH(data)),0) FROM mbox WHERE box=?", (box,)).fetchone()
        if n >= MBOX_MAX_ITEMS or size + len(data) > MBOX_MAX_BYTES: raise Err(429, "Skrzynka jest pełna.")
        if self.db.execute("SELECT COUNT(*) FROM mbox").fetchone()[0] >= MBOX_MAX_TOTAL: raise Err(503, "Przekaźnik jest przeciążony.")
        cur = self.db.execute("INSERT INTO mbox(box,data,ts) VALUES(?,?,?)", (box, data, ts))
        return {"ok": True, "seq": cur.lastrowid}

    def _do_mbox_ack(self, pub, f, msg, ts):
        if pub != f["box"]: raise Err(403, "Skrzynka należy do kogoś innego.")
        try: upto = int(f["upto"])
        except ValueError: raise Err(400, "Zły numer.")
        self.db.execute("DELETE FROM mbox WHERE box=? AND seq<=?", (f["box"], upto))
        return {"ok": True}

    def mbox_pull(self, items):
        """Jedno zapytanie dla wielu skrzynek; każda pozycja jest podpisana kluczem skrzynki (pub == box)."""
        if not isinstance(items, list) or len(items) > 60: raise Err(400, "Zła lista.")
        results = {}; budget = 400_000
        with self.lock:
            for it in items:
                if not isinstance(it, dict): continue
                box, after, ts, sig = it.get("box", ""), str(it.get("after", "0")), str(it.get("ts", "")), it.get("sig", "")
                try:
                    if not RE_PUB.match(box) or abs(int(ts) - self.now()) > SKEW_MS: continue
                    if not ed_verify(bytes.fromhex(box), bytes.fromhex(sig), sigmsg("pull", box, after, ts)): continue
                    after_i = int(after)
                except (ValueError, TypeError): continue
                rows = self.db.execute("SELECT seq,data,ts FROM mbox WHERE box=? AND seq>? ORDER BY seq LIMIT 20", (box, after_i)).fetchall()
                out = []
                for seq, data, t in rows:
                    if budget - len(data) < 0: break
                    budget -= len(data); out.append({"seq": seq, "data": data, "ts": t})
                if out: results[box] = out
        return {"results": results}

    # ------------------------------------------------------------ prośby o kontakt
    # Domyślnie KAŻDA prośba jest odrzucana (tryb „off”). Zobaczenie wpisu, polubienie czy członkostwo niczego nie otwiera:
    # autor musi świadomie włączyć przyjmowanie próśb, a potem każdą zaakceptować. Treść odpowiedzi (zaproszenie do czatu)
    # jest zaszyfrowana kluczem proszącego; przekaźnik widzi tylko zaszyfrowane bloby i stany.
    def _do_contact_policy(self, pub, f, msg, ts):
        self.community(f["cid"])
        if f["mode"] not in ("off", "members", "all"): raise Err(400, "Zły tryb.")
        if f["mode"] != "off" and not RE_PUB.match(f["xpub"]): raise Err(400, "Zły klucz skrzynki.")
        self.db.execute("INSERT OR REPLACE INTO contact_policy VALUES(?,?,?,?)",
                        (f["cid"], pub, f["mode"], f["xpub"] if f["mode"] != "off" else ""))
        return {"ok": True}

    def _do_contact_request(self, pub, f, msg, ts):
        cid, target = f["cid"], f["target"]; self.community(cid)
        if not RE_PUB.match(target) or target == pub or not RE_PUB.match(f["epub"]): raise Err(400, "Złe dane prośby.")
        if len(f["box"]) > 1500 or not f["box"]: raise Err(400, "Zły rozmiar wiadomości.")
        self._writable_role(cid, pub)
        row = self.db.execute("SELECT mode FROM contact_policy WHERE cid=? AND pub=?", (cid, target)).fetchone()
        mode = row[0] if row else "off"
        deny = Err(403, "Autor nie przyjmuje próśb o kontakt.")  # ten sam komunikat dla „off” i blokady (brak wycieku)
        if mode == "off": raise deny
        if self.db.execute("SELECT 1 FROM contact_blocks WHERE cid=? AND target=? AND blocked=?", (cid, target, pub)).fetchone(): raise deny
        if mode == "members" and self.role(cid, pub) not in ("owner", "mod", "member"): raise deny
        if self.db.execute("SELECT COUNT(*) FROM contact_requests WHERE cid=? AND target=? AND status='pending'", (cid, target)).fetchone()[0] >= 50:
            raise Err(429, "Autor ma za dużo oczekujących próśb.")
        if self.db.execute("SELECT COUNT(*) FROM contact_requests WHERE cid=? AND target=? AND requester=? AND status='pending'", (cid, target, pub)).fetchone()[0] >= 2:
            raise Err(429, "Masz już oczekującą prośbę do tego autora.")
        rid = hashlib.sha256(msg + bytes.fromhex(pub)).hexdigest()[:32]
        try:
            self.db.execute("INSERT INTO contact_requests VALUES(?,?,?,?,?,?,?,?,?)", (rid, cid, target, pub, f["epub"], f["box"], "pending", "", ts))
        except sqlite3.IntegrityError:
            raise Err(409, "Duplikat.")
        return {"ok": True, "id": rid}

    def _do_contact_reply(self, pub, f, msg, ts):
        r = self.db.execute("SELECT target, status FROM contact_requests WHERE id=? AND cid=?", (f["req"], f["cid"])).fetchone()
        if not r or r[0] != pub: raise Err(404, "Brak takiej prośby.")
        if r[1] != "pending": raise Err(409, "Prośba została już rozpatrzona.")
        if f["status"] not in ("accepted", "rejected"): raise Err(400, "Zły status.")
        if len(f["box"]) > 3000: raise Err(400, "Zły rozmiar.")
        self.db.execute("UPDATE contact_requests SET status=?, reply=? WHERE id=?", (f["status"], f["box"] if f["status"] == "accepted" else "", f["req"]))
        return {"ok": True}

    def _do_contact_block(self, pub, f, msg, ts):
        if not RE_PUB.match(f["target"]): raise Err(400, "Zły klucz.")
        self.db.execute("INSERT OR IGNORE INTO contact_blocks VALUES(?,?,?)", (f["cid"], pub, f["target"]))
        self.db.execute("UPDATE contact_requests SET status='rejected', reply='' WHERE cid=? AND target=? AND requester=? AND status='pending'", (f["cid"], pub, f["target"]))
        return {"ok": True}

    # ------------------------------------------------------------ odczyt
    def auth_pub(self, path_qs, headers):
        """Opcjonalne uwierzytelnienie odczytu: X-Pub, X-Ts, X-Sig = podpis sigmsg('read', ścieżka, ts)."""
        pub, ts, sig = headers.get("X-Pub"), headers.get("X-Ts"), headers.get("X-Sig")
        if not (pub and ts and sig): return None
        try:
            if not RE_PUB.match(pub) or abs(int(ts) - self.now()) > SKEW_MS: return None
            return pub if ed_verify(bytes.fromhex(pub), bytes.fromhex(sig), sigmsg("read", path_qs, ts)) else None
        except ValueError:
            return None

    def can_read(self, c, pub):
        if c["vis"] == "public": return True
        return pub is not None and self.role(c["cid"], pub) in ("owner", "mod", "member")

    def _counts(self, pid):
        reacts = {e: n for e, n in self.db.execute("SELECT emoji, COUNT(*) FROM reactions WHERE post=? GROUP BY emoji", (pid,))}
        comments = self.db.execute("SELECT COUNT(*) FROM posts WHERE parent=? AND deleted=0", (pid,)).fetchone()[0]
        reposts = self.db.execute("SELECT COUNT(*) FROM posts WHERE ref=? AND kind IN ('repost','quote') AND deleted=0", (pid,)).fetchone()[0]
        return reacts, comments, reposts

    def _out(self, row):
        (rowid, pid, cid, ch, kind, parent, ref, text, nick, pub, ts, edited, deleted, pinned) = row
        reacts, comments, reposts = self._counts(pid)
        o = {"id": pid, "cid": cid, "channel": ch, "kind": kind, "parent": parent, "ref": ref, "text": text, "nick": nick,
             "author": pub, "ts": ts, "edited": edited, "deleted": bool(deleted), "pinned": bool(pinned),
             "reactions": reacts, "comments": comments, "reposts": reposts, "cursor": rowid}
        if ref:
            r = self.db.execute("SELECT id,cid,text,nick,pub,deleted FROM posts WHERE id=?", (ref,)).fetchone()
            if r and not r[5]: o["ref_post"] = {"id": r[0], "cid": r[1], "text": r[2][:280], "nick": r[3], "author": r[4]}
        return o

    COLS = "rowid,id,cid,channel,kind,parent,ref,text,nick,pub,ts,edited,deleted,pinned"

    def info(self):
        return {"version": VERSION, "pow_bits": self.pow_bits, "max_text": MAX_TEXT}

    def list_communities(self, q, before, limit):
        limit = max(1, min(limit, 50))
        sql = ("SELECT c.cid,c.name,c.descr,c.category,c.created,(SELECT COUNT(*) FROM members m WHERE m.cid=c.cid AND m.role!='banned'),"
               "(SELECT COUNT(*) FROM posts p WHERE p.cid=c.cid AND p.deleted=0) FROM communities c WHERE c.vis='public'")
        args = []
        if q: sql += " AND (c.name LIKE ? OR c.descr LIKE ? OR c.category LIKE ?)"; args += ["%" + q + "%"] * 3
        sql += " ORDER BY 6 DESC, c.created DESC LIMIT ? OFFSET ?"; args += [limit, max(0, before)]
        rows = self.db.execute(sql, args).fetchall()
        return {"communities": [dict(zip(("cid", "name", "descr", "category", "created", "members", "posts"), r)) for r in rows],
                "next": (before + limit) if len(rows) == limit else None}

    def community_info(self, cid, pub):
        c = self.community(cid)
        r = self.role(cid, pub) if pub else None
        if c["vis"] == "hidden" and r not in ("owner", "mod", "member"): raise Err(404, "Nie ma takiej społeczności.")
        out = {k: c[k] for k in ("cid", "name", "descr", "vis", "category", "created")}
        out["role"] = r
        out["members"] = self.db.execute("SELECT COUNT(*) FROM members WHERE cid=? AND role!='banned'", (cid,)).fetchone()[0]
        out["rules"] = ""
        if self.can_read(c, pub):
            out["channels"] = [{"name": n, "kind": k} for n, k in self.db.execute("SELECT name, kind FROM channels WHERE cid=? ORDER BY rowid", (cid,))]
        else:
            out["channels"] = []
        return out

    def posts(self, cid, pub, channel="", parent="", sort="new", before=0, offset=0, limit=20):
        c = self.community(cid)
        if c["vis"] == "hidden" and self.role(cid, pub) not in ("owner", "mod", "member"): raise Err(404, "Nie ma takiej społeczności.")
        if not self.can_read(c, pub): raise Err(403, "To społeczność prywatna: dołącz z zaproszeniem.")
        limit = max(1, min(limit, 50))
        where = "cid=? AND parent=?"; args = [cid, parent]
        if channel: where += " AND channel=?"; args.append(channel)
        if sort == "top":
            sql = (f"SELECT {self.COLS} FROM posts WHERE {where} AND deleted=0 ORDER BY "
                   "((SELECT COUNT(*) FROM reactions r WHERE r.post=posts.id)+2*(SELECT COUNT(*) FROM posts x WHERE x.parent=posts.id AND x.deleted=0)"
                   "+2*(SELECT COUNT(*) FROM posts y WHERE y.ref=posts.id AND y.deleted=0)) DESC, rowid DESC LIMIT ? OFFSET ?")
            rows = self.db.execute(sql, args + [limit, max(0, offset)]).fetchall()
            nxt = (offset + limit) if len(rows) == limit else None
        else:
            asc = parent != ""  # komentarze od najstarszych
            if before > 0: where += " AND rowid" + (">" if asc else "<") + "?"; args.append(before)
            order = "rowid ASC" if asc else "pinned DESC, rowid DESC" if before == 0 else "rowid DESC"
            rows = self.db.execute(f"SELECT {self.COLS} FROM posts WHERE {where} ORDER BY {order} LIMIT ?", args + [limit]).fetchall()
            nxt = rows[-1][0] if len(rows) == limit else None
        return {"posts": [self._out(r) for r in rows], "next": nxt}

    def feed(self, cids, pub, before=0, limit=20):
        limit = max(1, min(limit, 50)); ok = []
        for cid in cids[:30]:
            if not RE_CID.match(cid): continue
            try: c = self.community(cid)
            except Err: continue
            if self.can_read(c, pub): ok.append(cid)
        if not ok: return {"posts": [], "next": None}
        ph = ",".join("?" * len(ok)); args = list(ok)
        where = f"cid IN ({ph}) AND parent='' AND deleted=0"
        if before > 0: where += " AND rowid<?"; args.append(before)
        rows = self.db.execute(f"SELECT {self.COLS} FROM posts WHERE {where} ORDER BY rowid DESC LIMIT ?", args + [limit]).fetchall()
        return {"posts": [self._out(r) for r in rows], "next": rows[-1][0] if len(rows) == limit else None}

    def search(self, q, cid, pub, limit=30):
        q = q.strip()
        if len(q) < 2: return {"posts": []}
        limit = max(1, min(limit, 50))
        base = f"SELECT {self.COLS} FROM posts WHERE deleted=0 AND "
        if q.startswith("#"):
            cond = "id IN (SELECT post FROM tags WHERE tag=?)"; args = [q[1:].lower()]
        else:
            cond = "text LIKE ?"; args = ["%" + q.replace("%", "").replace("_", "") + "%"]
        if cid:
            c = self.community(cid)
            if not self.can_read(c, pub): raise Err(403, "Brak dostępu.")
            cond += " AND cid=?"; args.append(cid)
        else:
            cond += " AND cid IN (SELECT cid FROM communities WHERE vis='public')"
        rows = self.db.execute(base + cond + " ORDER BY rowid DESC LIMIT ?", args + [limit]).fetchall()
        return {"posts": [self._out(r) for r in rows]}

    def one_post(self, cid, pid, pub):
        c = self.community(cid)
        if c["vis"] == "hidden" and self.role(cid, pub) not in ("owner", "mod", "member"): raise Err(404, "Nie ma takiej społeczności.")
        if not self.can_read(c, pub): raise Err(403, "Brak dostępu.")
        r = self.db.execute(f"SELECT {self.COLS} FROM posts WHERE id=? AND cid=?", (pid, cid)).fetchone()
        if not r: raise Err(404, "Brak wpisu.")
        return self._out(r)

    def _need_auth(self, pub):
        if pub is None: raise Err(401, "Wymagany podpis odczytu.")

    def policy(self, cid, target, pub):
        c = self.community(cid)
        if c["vis"] == "hidden" and self.role(cid, pub) not in ("owner", "mod", "member"): raise Err(404, "Nie ma takiej społeczności.")
        if not RE_PUB.match(target): raise Err(400, "Zły klucz.")
        r = self.db.execute("SELECT mode, xpub FROM contact_policy WHERE cid=? AND pub=?", (cid, target)).fetchone()
        return {"mode": r[0] if r else "off", "xpub": r[1] if r else ""}

    def inbox(self, cid, pub):
        self._need_auth(pub); self.community(cid)
        rows = self.db.execute("SELECT id,requester,epub,box,ts FROM contact_requests WHERE cid=? AND target=? AND status='pending' ORDER BY ts DESC LIMIT 100", (cid, pub)).fetchall()
        return {"requests": [dict(zip(("id", "requester", "epub", "box", "ts"), r)) for r in rows]}

    def outbox(self, cid, pub):
        self._need_auth(pub); self.community(cid)
        rows = self.db.execute("SELECT id,target,status,reply,ts FROM contact_requests WHERE cid=? AND requester=? ORDER BY ts DESC LIMIT 50", (cid, pub)).fetchall()
        return {"requests": [dict(zip(("id", "target", "status", "reply", "ts"), r)) for r in rows]}

    def activity(self, cid, pub, since):
        """Zdarzenia dotyczące moich wpisów w tej społeczności. Bez informacji, KTO zareagował."""
        self._need_auth(pub); self.community(cid)
        ev = []
        for pid, parent, text, nick, ts, kind in self.db.execute(
                "SELECT p.id,p.parent,p.text,p.nick,p.ts,p.kind FROM posts p JOIN posts m ON (m.id=p.parent OR m.id=p.ref) "
                "WHERE m.cid=? AND m.pub=? AND p.pub!=? AND p.deleted=0 AND p.ts>? ORDER BY p.ts DESC LIMIT 100", (cid, pub, pub, since)):
            ev.append({"type": kind, "id": pid, "post": parent or "", "text": text[:200], "nick": nick, "ts": ts})
        for post, emoji, ts in self.db.execute(
                "SELECT r.post,r.emoji,r.rts FROM reactions r JOIN posts m ON m.id=r.post WHERE m.cid=? AND m.pub=? AND r.pub!=? AND r.rts>? ORDER BY r.rts DESC LIMIT 100",
                (cid, pub, pub, since)):
            ev.append({"type": "reaction", "post": post, "emoji": emoji, "ts": ts})
        if self.role(cid, pub) in STAFF:
            for post, reason, ts in self.db.execute("SELECT post,reason,ts FROM reports WHERE cid=? AND ts>? ORDER BY ts DESC LIMIT 50", (cid, since)):
                ev.append({"type": "report", "post": post, "reason": reason, "ts": ts})
        ev.sort(key=lambda e: -e["ts"])
        return {"events": ev[:100]}

    def reports(self, cid, pub):
        if self.role(cid, pub) not in STAFF: raise Err(403, "Tylko administracja.")
        rows = self.db.execute("SELECT id,post,reason,ts FROM reports WHERE cid=? ORDER BY id DESC LIMIT 100", (cid,)).fetchall()
        return {"reports": [dict(zip(("id", "post", "reason", "ts"), r)) for r in rows]}

    def members(self, cid, pub):
        if self.role(cid, pub) not in STAFF: raise Err(403, "Tylko administracja.")
        rows = self.db.execute("SELECT pub, role, joined FROM members WHERE cid=? ORDER BY joined", (cid,)).fetchall()
        return {"members": [dict(zip(("pub", "role", "joined"), r)) for r in rows]}

# ---------------------------------------------------------------- HTTP
def make_handler(relay: Relay):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"
        server_version = "shyfr-relay"
        sys_version = ""

        def log_message(self, *a):  # celowo nic nie logujemy (prywatność)
            pass

        def _send(self, code, obj):
            b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers(); self.wfile.write(b)

        def _qs(self, qs, k, default=""):
            return qs.get(k, [default])[0]

        def _int(self, qs, k, default=0):
            try: return int(self._qs(qs, k, str(default)))
            except ValueError: return default

        def do_POST(self):
            try:
                path = urlparse(self.path).path
                if path not in ("/v1/act", "/v1/mbox/pull"): raise Err(404, "Nie znaleziono.")
                n = int(self.headers.get("Content-Length", "0"))
                if n <= 0 or n > MAX_BODY: raise Err(413, "Zły rozmiar.")
                try: obj = json.loads(self.rfile.read(n).decode("utf-8"))
                except (ValueError, UnicodeDecodeError): raise Err(400, "Zły JSON.")
                if not isinstance(obj, dict): raise Err(400, "Zły JSON.")
                if path == "/v1/mbox/pull": return self._send(200, relay.mbox_pull(obj.get("items")))
                self._send(200, relay.act(obj))
            except Err as e:
                self._send(e.code, {"ok": False, "error": e.msg})
            except Exception:
                self._send(500, {"ok": False, "error": "Błąd serwera."})

        def do_GET(self):
            try:
                u = urlparse(self.path); qs = parse_qs(u.query); p = u.path
                pub = relay.auth_pub(self.path, self.headers)
                with relay.lock:
                    if p == "/v1/info": return self._send(200, relay.info())
                    if p == "/v1/communities":
                        return self._send(200, relay.list_communities(self._qs(qs, "q"), self._int(qs, "before"), self._int(qs, "limit", 20)))
                    if p == "/v1/feed":
                        cids = [c for c in self._qs(qs, "cs").split(",") if c]
                        return self._send(200, relay.feed(cids, pub, self._int(qs, "before"), self._int(qs, "limit", 20)))
                    if p == "/v1/search":
                        return self._send(200, relay.search(self._qs(qs, "q"), self._qs(qs, "cid"), pub))
                    m1 = re.match(r"^/v1/c/([0-9a-f]{16})/post/([0-9a-f]{32})$", p)
                    if m1: return self._send(200, relay.one_post(m1.group(1), m1.group(2), pub))
                    m = re.match(r"^/v1/c/([0-9a-f]{16})(/posts|/reports|/members|/inbox|/outbox|/policy|/activity)?$", p)
                    if m:
                        cid, sub = m.group(1), m.group(2)
                        if sub is None: return self._send(200, relay.community_info(cid, pub))
                        if sub == "/posts":
                            return self._send(200, relay.posts(cid, pub, self._qs(qs, "channel"), self._qs(qs, "parent"), self._qs(qs, "sort", "new"),
                                                               self._int(qs, "before"), self._int(qs, "offset"), self._int(qs, "limit", 20)))
                        if sub == "/reports": return self._send(200, relay.reports(cid, pub))
                        if sub == "/inbox": return self._send(200, relay.inbox(cid, pub))
                        if sub == "/outbox": return self._send(200, relay.outbox(cid, pub))
                        if sub == "/policy": return self._send(200, relay.policy(cid, self._qs(qs, "target"), pub))
                        if sub == "/activity": return self._send(200, relay.activity(cid, pub, self._int(qs, "since")))
                        return self._send(200, relay.members(cid, pub))
                raise Err(404, "Nie znaleziono.")
            except Err as e:
                self._send(e.code, {"ok": False, "error": e.msg})
            except Exception:
                self._send(500, {"ok": False, "error": "Błąd serwera."})
    return H

def serve(relay: Relay, host="127.0.0.1", port=8787):
    srv = ThreadingHTTPServer((host, port), make_handler(relay))
    srv.daemon_threads = True
    return srv

if __name__ == "__main__":
    r = Relay(os.environ.get("SHYFR_RELAY_DB", "relay.db"), int(os.environ.get("SHYFR_POW_BITS", "12")))
    port = int(os.environ.get("SHYFR_RELAY_PORT", "8787"))
    print(f"SHYFR relay v{VERSION} nasłuchuje na 127.0.0.1:{port} (PoW {r.pow_bits} bitów). Wystaw go jako usługę onion (patrz README).")
    try: serve(r, "127.0.0.1", port).serve_forever()
    except KeyboardInterrupt: pass
