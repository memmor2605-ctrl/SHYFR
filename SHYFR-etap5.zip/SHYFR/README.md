# SHYFR 1.0.0

Anonimowy komunikator Android z szyfrowaniem end-to-end (Double Ratchet), przez sieć Tor. Bez serwerów, numerów telefonu i kont online. Dane zostają w zaszyfrowanej bazie (SQLCipher) na telefonie.

## Budowanie
- Android Studio (JDK 17), `minSdk 29`, `targetSdk 35`.
- Debug: `./gradlew assembleDebug`
- Wydanie: utwórz `keystore.properties` (storeFile, storePassword, keyAlias, keyPassword), potem `./gradlew bundleRelease` lub `assembleRelease`.

## Funkcje
Rozmowy 1:1 i grupy, zdjęcia, pliki, wiadomości głosowe, odpowiedzi (przeciągnięciem), reakcje, edycja i usuwanie u wszystkich, znikające wiadomości, motywy i pseudonimy rozmów, status aktywności, ochrona i powiadomienia o zrzutach ekranu, PIN/odcisk palca, hasło paniki, mosty Tor.

## Warstwa publiczna
Przekaźnik: `relay/` (Python, onion w Termux). Instrukcja i granice prywatności w `relay/README.md`. Testy: `python3 -m unittest test_relay` w katalogu `relay/`.
