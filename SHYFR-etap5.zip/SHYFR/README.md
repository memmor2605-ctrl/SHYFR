# SHYFR 1.0.0

Anonimowy komunikator Android z szyfrowaniem end-to-end (Double Ratchet), przez sieć Tor. Bez serwerów, numerów telefonu i kont online. Dane zostają w zaszyfrowanej bazie (SQLCipher) na telefonie.

## Budowanie
- Android Studio (JDK 17), `minSdk 29`, `targetSdk 35`.
- Debug: `./gradlew assembleDebug`
- Wydanie: utwórz `keystore.properties` (storeFile, storePassword, keyAlias, keyPassword), potem `./gradlew bundleRelease` lub `assembleRelease`.

## Funkcje
Rozmowy 1:1 i grupy, zdjęcia, pliki, wiadomości głosowe, odpowiedzi (przeciągnięciem), reakcje, edycja i usuwanie u wszystkich, znikające wiadomości, motywy i pseudonimy rozmów, status aktywności, ochrona i powiadomienia o zrzutach ekranu, PIN/odcisk palca, hasło paniki, mosty Tor.

## Warstwa publiczna
Przekaźnik: `relay/` (Python, onion w Termux). Instrukcja i granice prywatności w `relay/README.md`. Testy: `python3 -m unittest test_relay` w katalogu `relay/`.


## Publiczny feed na Nostr (etap 27)
Zakładka Feed → „Publiczny” działa na publicznych przekaźnikach Nostr, bez żadnej konfiguracji i bez serwera SHYFR. Kod: `app/src/main/java/com/shyfr/app/nostr/`.
- `Schnorr.kt`, `NostrEvent.kt`: podpisy BIP-340 (secp256k1) i zdarzenia NIP-01, czysty Kotlin. Testy na oficjalnych wektorach BIP-340 oraz na wynikach niezależnej implementacji w Pythonie.
- `RelayManager.kt`: jedyny zarządca połączeń. Lista startowa + zapamiętane udane przekaźniki; każdy kandydat jest sprawdzany w praktyce (połączenie, odpowiedź EOSE); pomijane są niedziałające, wymagające logowania (NIP-42) lub płatne; ponawianie z rosnącym opóźnieniem; uzupełnianie po awarii; reset po zmianie sieci. Publikacja do wielu przekaźników: sukces tylko, gdy co najmniej jeden potwierdzi. Odczyt z wielu przekaźników, bez duplikatów, z weryfikacją id i podpisu.
- `NostrHub.kt`: połączenie przez Tora (SOCKS, nazwy rozwiązuje Tor) i TLS z weryfikacją hosta; zarządca działa tylko, gdy ekran Feed go potrzebuje.
- `NostrFeedRepo.kt`: wpisy (kind 1), odpowiedzi (NIP-10), reakcje (kind 7), profile (kind 0), obserwowanie (NIP-02 tylko dla tożsamości publicznej). Każda tożsamość SHYFR ma własny klucz Nostr wyprowadzany z klucza konta.
Granice: wpisy są publiczne, a operatorzy przekaźników widzą treść i metadane (Tor ukrywa tylko IP). Wiele publicznych przekaźników blokuje Tora albo bywa niedostępnych: dlatego zarządca dobiera je na bieżąco i nic nie jest gwarantowane. Nie ma jeszcze: repostów, ankiet, wpisów z ograniczonym odbiorcą (wymagają szyfrowania), uwierzytelniania NIP-42, wyszukiwania pełnotekstowego.
Adresy w ustawieniach (serwer społeczności i skrzynki) są ukryte w normalnym interfejsie; pokazuje je tryb programisty (7 dotknięć wersji w Ustawieniach → O aplikacji albo build debug).
