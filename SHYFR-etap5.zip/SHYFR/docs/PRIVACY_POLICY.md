# Polityka prywatności SHYFR

Ostatnia aktualizacja: listopad 2026

**Twórca aplikacji nie zbiera Twoich danych.** SHYFR nie ma kont online ani analityki. Prywatne rozmowy nie przechodzą przez żadne serwery.

## Dane na Twoim telefonie
Kontakty, wiadomości, załączniki i klucze są przechowywane lokalnie w zaszyfrowanej bazie (SQLCipher), chronionej hasłem i kluczem sprzętowym urządzenia.

## Prywatne rozmowy
Wiadomości są szyfrowane end-to-end i wysyłane bezpośrednio między urządzeniami przez sieć Tor.

## Skrzynka na przekaźniku (opcjonalna)
Jeśli wpiszesz adres przekaźnika, SHYFR używa go także jako skrzynki dla wiadomości prywatnych, gdy bezpośrednie połączenie z kontaktem się nie uda (druga osoba offline albo w złej sieci). Do skrzynki trafia ta sama zaszyfrowana ramka end-to-end, którą wysłalibyśmy bezpośrednio. Przekaźnik widzi szyfrogram, jego rozmiar i czas, ale nie treść ani tożsamości. Identyfikator skrzynki jest znany tylko Tobie i danemu kontaktowi i nie wiąże się z Twoimi kluczami tożsamości ani adresem onion. Wiadomości w skrzynce są usuwane po odebraniu, najpóźniej po 14 dniach. Oba telefony muszą mieć ten sam przekaźnik.

## Społeczności i feed (opcjonalne)
Funkcja działa tylko, jeśli sam wpiszesz adres przekaźnika publicznego (usługa onion) w Ustawieniach. Bez tego nic nie jest wysyłane.
- Wpisy, komentarze, reakcje i zgłoszenia są **publiczne dla przekaźnika i jego operatora** i nie są szyfrowane end-to-end. Operator może je zobaczyć, usunąć lub zmienić.
- Każdy wpis jest podpisany kluczem wyprowadzonym osobno dla każdej społeczności. Przekaźnik nie otrzymuje Twojego adresu onion, identyfikatora konta ani adresu IP (połączenia idą przez Tor), a ten klucz nie łączy Twoich wpisów między społecznościami.
- Operator widzi czasy publikacji i może powiązać wpisy tego samego pseudonimu w jednej społeczności. Analiza stylu pisania lub czasu aktywności może powiązać też różne społeczności.
- Wpis możesz opublikować anonimowo („Anonimowy uczestnik”) albo pod pseudonimem ustawionym w danej społeczności.
- **Prośby o kontakt** są domyślnie wyłączone. Powitanie jest szyfrowane kluczem adresata; przekaźnik widzi tylko, że prośba istnieje i jej stan.
- Zgłoszenia nadużyć trafiają do moderatorów danej społeczności.
- Usunięcie wpisu zamazuje jego treść na przekaźniku, ale nie możemy zagwarantować, że ktoś wcześniej go nie skopiował.

## Status aktywności i powiadomienia o zrzutach
Jeśli je włączysz, Twoje kontakty (tylko one) otrzymują zaszyfrowany sygnał o Twojej aktywności lub zrzucie ekranu rozmowy. Możesz je wyłączyć w Ustawieniach.

## Kopia zapasowa
Obejmuje też listę Twoich społeczności, pseudonimy i zakładki (bez kluczy: te odtwarzają się z konta). Tworzona wyłącznie na Twoje żądanie, zapisywana w wybranym przez Ciebie miejscu i szyfrowana hasłem, którego nie znamy.

## Raport diagnostyczny
Generowany lokalnie, z zamaskowanymi adresami. Nigdy nie jest wysyłany automatycznie.

## Uprawnienia
Internet (Tor), kamera (skanowanie kodów QR), mikrofon (wiadomości głosowe), powiadomienia, usługa działająca w tle (utrzymanie połączenia Tor), wykrywanie zrzutów i nagrywania ekranu (powiadamianie rozmówcy).

## Kontakt
[adres e-mail do uzupełnienia przed publikacją]
