# Google Play: materiały do formularzy

## Usługa pierwszoplanowa (specialUse)
Uzasadnienie do Play Console: „Aplikacja jest komunikatorem peer-to-peer opartym na sieci Tor. Odbieranie wiadomości wymaga stale działającej, własnej usługi onion na urządzeniu użytkownika, bo nie ma serwera pośredniczącego. Bez usługi pierwszoplanowej system zatrzymałby proces i wiadomości nie mogłyby być odebrane. Usługa jest widoczna w powiadomieniu. Użytkownik może w Ustawieniach wyłączyć działanie w tle po blokadzie ekranu albo całkowicie zablokować aplikację, co zatrzymuje usługę.” Dołącz krótki film pokazujący powiadomienie i odbiór wiadomości przy wygaszonym ekranie.

## Data safety
- Dane zbierane przez twórcę: brak. Dane nie są przekazywane podmiotom trzecim.
- Dane przetwarzane na urządzeniu: wiadomości, kontakty, pliki, głos.
- Treści publiczne (wpisy w społecznościach) trafiają do przekaźnika wskazanego przez użytkownika, nie do twórcy aplikacji. Wskaż to w deklaracji.
- Szyfrowanie w tranzycie: tak. Możliwość usunięcia danych: tak (Ustawienia → Usuń konto).
- Zweryfikuj biblioteki (tor-android, ML Kit barcode, CameraX) pod kątem własnych deklaracji.

## Treści generowane przez użytkowników (UGC)
Warstwa społecznościowa (feed, społeczności) wymaga przekaźnika wskazanego przez użytkownika; aplikacja nie ma domyślnego serwera. Play wymaga mechanizmów dla UGC: w aplikacji są zgłaszanie wpisów, blokowanie autorów przez moderatorów, usuwanie własnych wpisów, wyciszanie i opuszczanie społeczności. Przygotuj opis tych mechanizmów do formularza.

## Uprawnienia: opisy
Kamera: tylko skanowanie QR zaproszeń. Mikrofon: tylko nagrywanie wiadomości głosowych. DETECT_SCREEN_CAPTURE/RECORDING: tylko powiadomienie rozmówcy.

## Do zrobienia ręcznie
Grafiki sklepu, ikona 512 px, opis, adres kontaktowy, URL polityki prywatności, ankieta treści, ścieżka testów zamkniętych.
