# SHYFR 2.0 — audyt i zakres etapu 1

## Stan projektu przed zmianami

- Aplikacja Android/Kotlin + Jetpack Compose, `applicationId` pozostaje `com.shyfr.app`.
- Lokalny sejf i baza SQLCipher są już obecne. `Db.open()` wykonuje idempotentne migracje do `user_version = 6`.
- Wiadomości tekstowe są szyfrowane przez istniejący ratchet; transport P2P działa przez Tor.
- Załączniki mają już osobny protokół `KIND_FILE_META` / `KIND_FILE_CHUNK`, limit `MAX_ATT_BYTES` (8 MiB) i zapis w istniejących tabelach `attachments` / `att_chunks`.
- Szybkie odblokowanie PIN-em i biometrią było częściowo zaimplementowane w `QuickUnlock.kt`.
- Archiwum nie zawiera Gradle Wrappera (`gradlew`) ani testów automatycznych.

## Usterki wykryte i poprawione w etapie 1

1. **PIN w ustawieniach był nieaktywny bez ponownego wpisania loginu i hasła.** Ekran ustawień jest dostępny już po odblokowaniu konta, a klucz główny znajduje się wtedy w `Session`. Teraz konfiguracja PIN-u/biometrii korzysta z kopii klucza bieżącej sesji; formularz loginu/hasła pozostaje ścieżką awaryjną.
2. **Obsługa wyniku PIN-u aktualizowała stan Compose z wątku roboczego.** Aktualizacje UI są teraz przenoszone na Main; dodano obsługę wyjątków i czyszczenie bufora PIN-u.
3. **Brak uprawnienia mikrofonu.** Dodano `RECORD_AUDIO` do manifestu i żądanie zgody w kontekście użycia.
4. **Wiadomości głosowe.** Dodano nagrywanie AAC w kontenerze M4A, anulowanie nagrania, wysyłanie przez istniejący szyfrowany kanał załączników oraz odtwarzanie pobranych załączników audio. Nie zmieniono formatu wiadomości ani schematu bazy — audio jest zwykłym załącznikiem z MIME `audio/mp4`.
5. **Warstwa wizualna.** Ujednolicono paletę na grafitową z dyskretnym akcentem lawendowym i poprawiono kontrast powierzchni/dymków.

## Kompatybilność

- Nie zmieniono `applicationId`, formatu `vault.bin`, kluczy Keystore, schematu SQLCipher ani wersji protokołu wiadomości.
- Wysyłanie głosu wykorzystuje istniejące typy ramek załączników, więc odbiorca nie musi aktualizować protokołu; starszy klient może jednak pokazać nagranie jako zwykły plik zamiast odtwarzacza audio.
- Wysyłanie nadal podlega istniejącemu limitowi 8 MiB.
- Zwiększono `versionCode` do 3 i oznaczono wydanie `2.0.0-alpha.1`. Aktualizacja istniejącej instalacji wymaga podpisania APK tym samym kluczem co poprzednie wydanie.

## Ograniczenia testowania w tym środowisku

Nie można było wykonać kompilacji Androida: dostarczone archiwum nie zawiera `gradlew`, a środowisko nie ma zainstalowanego polecenia `gradle` ani skonfigurowanego Android SDK. Wykonano przegląd statyczny zmienionych plików i kontrolę spójności manifestu/konfiguracji. Nie należy traktować tego jako potwierdzenia poprawnej kompilacji lub testu na urządzeniu.

## Testy wymagane na urządzeniu przed wydaniem

- Aktualizacja istniejącej instalacji z zachowaniem konta, kontaktów, historii i kluczy.
- Włączenie PIN-u z aktywnej sesji, wylogowanie, poprawny PIN, błędny PIN i wyłączenie po 5 błędach.
- Włączenie biometrii silnej, poprawne odblokowanie, anulowanie promptu oraz unieważnienie po zmianie zarejestrowanych danych biometrycznych.
- Nagranie krótkiego M4A, anulowanie, wysłanie, odbiór przez drugi telefon i odtworzenie.
- Weryfikacja wiadomości głosowej przy chwilowym braku sieci i późniejszym opróżnieniu outboxa Tor.
- Próba wysłania nagrania przekraczającego 8 MiB (musi zostać odrzucone bez awarii aplikacji).

## Kolejne etapy 2.0

- Etap 2: pełne uporządkowanie ekranów rozmów, listy kontaktów, profilu i ustawień; dostępność, stany puste/błędy/ładowanie.
- Etap 3: funkcje komunikatora (statusy wiadomości, wyszukiwanie, zarządzanie załącznikami, powiadomienia i synchronizacja).
- Etap 4: testy integracyjne protokołu, testy migracji SQLCipher, testy odporności na przerwanie procesu i audyt bezpieczeństwa.
