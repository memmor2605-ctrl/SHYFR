# SHYFR 2.0 — Alpha 2 UI/UX refresh

## Zakres
- Odświeżona paleta jasna/ciemna: chłodny grafit, stalowy błękit i jaśniejsze powierzchnie.
- Wspólne kształty Material 3 dla pól, kart i dialogów.
- Nowy nagłówek listy rozmów, lokalne filtrowanie kontaktów po nazwie/opisie/ostatniej wiadomości, liczniki kontaktów i wyróżnienie warstwy prywatności.
- Karty kontaktów z większymi odstępami, czytelniejsza hierarchia tekstu.
- Profil otrzymał nagłówek sekcji i kartę edycji; ustawienia — wyraźną hierarchię nagłówka.
- Zmiany dotyczą warstwy prezentacji. Nie zmieniano formatów danych, protokołu wiadomości, kluczy, KDF, ratcheta, szyfrowania załączników, PIN/biometrii ani transportu Tor.

## Pliki UI zmienione
- `ui/Components.kt`
- `ui/ShyfrApp.kt`
- `ui/ProfileScreen.kt`
- `ui/SettingsScreen.kt`

Pozostałe ekrany (w tym `ChatScreen.kt`, `QuickScreen.kt`, `Screens.kt`, `Invite`/`Join`) zachowują implementację Alpha 1 i korzystają z odświeżonego wspólnego motywu. To wydanie nie deklaruje pełnego przebudowania każdej kontrolki w tych ekranach.

## Kontrola jakości
W tym środowisku nie ma Gradle Wrappera, zainstalowanego Gradle ani Android SDK, dlatego nie można było wykonać kompilacji Android ani testów urządzeniowych.
Przed publikacją należy:
1. Otworzyć projekt w Android Studio i wykonać `assembleDebug` oraz `testDebugUnitTest`.
2. Przetestować logowanie i tworzenie konta, blokowanie aplikacji, PIN oraz biometrię.
3. Zweryfikować dodawanie kontaktu przez QR/link, wysyłanie tekstu, załączników i nagrań głosowych.
4. Sprawdzić Tor z mostami, restart i odzyskiwanie po błędzie sieci.
5. Sprawdzić tryb jasny/ciemny, małe ekrany, klawiaturę ekranową i dostępność (TalkBack/kontrast).

## Zasada bezpieczeństwa
Nie zmieniano kryptograficznych ani sieciowych plików Kotlin. To nie jest audyt bezpieczeństwa ani potwierdzenie odporności protokołu.
