# SHYFR – rebuild etap 1

## Co zostało zmienione

- Lokalny listener usługi onion jest teraz jawnie związany z `127.0.0.1`, zgodnie z adresem docelowym przekazywanym do `ADD_ONION`. Wcześniejsze `InetAddress.getLoopbackAddress()` mogło zwrócić IPv6 `::1` i odciąć ruch przekazywany przez Tor.
- Log startu zapisuje lokalny adres i port listenera.
- Dołączanie znajomego rozróżnia timeout podczas łączenia z usługą onion od timeoutu w trakcie handshake. Błąd transportu nie jest już opisywany jako dowód, że znajomy jest offline.
- Migracje SQLCipher sprawdzają `PRAGMA table_info` przed `ALTER TABLE`; ponowne otwarcie bazy nie generuje już serii błędów `duplicate column name`.
- Migracje są wykonywane w transakcji. Nieudana migracja zwraca czytelny błąd i zamyka uchwyt bazy zamiast po cichu kontynuować na częściowo zaktualizowanym schemacie.
- Pliki PIN-u i biometrii są zapisywane atomowo. Odczyt korzysta z `AtomicFile`, a błędy odblokowania sejfu są pokazywane użytkownikowi zamiast pozostawiać ekran bez informacji.
- Klucze i bufory tymczasowe związane z PIN-em są czyszczone po użyciu.
- Wersja aplikacji podniesiona do `0.2.0-rebuild`.

## Zachowane elementy

Kotlin, Jetpack Compose, SQLCipher, istniejący sejf i klucze, kontakty, wiadomości, Double Ratchet, zaproszenia QR/deep link, załączniki, profil, Tor i dotychczasowe ekrany.

## Ważne ograniczenie walidacji

W środowisku przygotowania paczki nie ma Android SDK ani Gradle/Gradle Wrapper, więc nie można uczciwie zadeklarować udanego buildu APK. Źródła wymagają kompilacji w Android Studio lub CI z dostępnym SDK. Nie usuwaj danych aplikacji przed testem – migracja ma zachować istniejącą bazę.

## Test dwóch urządzeń

1. Zainstaluj tę samą wersję na obu urządzeniach i odblokuj konta.
2. Poczekaj na stan `Online` na obu telefonach.
3. Na urządzeniu A wygeneruj nowe zaproszenie i pozostaw ekran/aplikację aktywną.
4. Na urządzeniu B dołącz przez link/QR.
5. Jeśli nie powiedzie się, pobierz raport diagnostyczny z obu telefonów. Sprawdź wpis `listener lokalny` – musi zaczynać się od `127.0.0.1:`.
6. Zachowaj pełny komunikat błędu `join` wraz z etapem: połączenie onion albo handshake.

## Następne etapy przebudowy

- Uwierzytelniony ping i model obecności online / ostatnio widziany / nieosiągalny.
- Niezawodna kolejka i potwierdzenia dostarczenia z retry/backoff.
- Wiadomości głosowe, kanały i grupy z osobnym projektem kluczy grupowych.
- Połączenia audio/wideo po zaprojektowaniu transportu odpornego na ograniczenia TCP/Tor.
