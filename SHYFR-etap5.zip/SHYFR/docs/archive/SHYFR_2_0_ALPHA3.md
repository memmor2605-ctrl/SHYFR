# SHYFR 2.0 — Alpha 3

## Poprawka krytyczna
- `Db.kt`: `rawQuery("PRAGMA ...", null)` w SQLCipher (varargs) przekazywało `[null]` i mogło przerwać otwarcie bazy. Zamienione na wywołania bez argumentów.

## Nowe funkcje (bez zmian protokołu i kryptografii)
- Przypinanie rozmów (📌) — przypięte zawsze na górze, reszta wg ostatniej wiadomości.
- Archiwum rozmów — filtr „Archiwum” na liście; archiwizacja nie usuwa danych.
- Menu rozmowy (przytrzymanie wiersza): przypnij, wycisz, archiwizuj.
- Szkice wiadomości — zapisywane w zaszyfrowanej bazie, widoczne na liście jako „Szkic: …”.
- Wyszukiwanie w rozmowie (ikona ⌕ w nagłówku czatu).
- Ochrona ekranu (Ustawienia): przełącznik FLAG_SECURE, domyślnie włączony.
- Migracja bazy: nowe kolumny `pinned`, `archived`, `draft` (idempotentnie).

## Walidacja
Nie zbudowano ani nie uruchomiono (brak Android SDK/Gradle w środowisku). Wymagane: `assembleDebug` w CI, test na dwóch urządzeniach.

## Nie zrobione (wymaga projektu protokołu — nie dopisywane „na ślepo”)
Grupy i kanały, połączenia głosowe/wideo, wiadomości jednorazowego wyświetlenia, kopia zapasowa/transfer na nowy telefon, wielourządzeniowość.

## Dodatek (alpha3b)
- Kopiowanie tekstu wiadomości.
- Przekazywanie wiadomości tekstowej do innego kontaktu (zwykła, nowa wiadomość szyfrowana jak każda inna).
- Oznaczanie wiadomości gwiazdką (★) i filtr „★” w wyszukiwarce rozmowy; kolumna `messages.starred`.
- Wyczyść historię rozmowy (zostaje kontakt, sesja szyfrowania i deduplikacja `seen`).
- „Oznacz jako nieprzeczytane” w menu rozmowy.

## Alpha 4 — rozszerzenie protokołu (zgodne wstecz)
Nowe rodzaje ramek wewnątrz sesji Double Ratchet (stare wersje traktują nieznany rodzaj jako pustą wiadomość i potwierdzają ją):
- `KIND_TTL = 10` — zmiana czasu znikania wiadomości jest synchronizowana z rozmówcą (dozwolone: 0, 1 godz., 24 godz., 7 dni; inne wartości odrzucane).
- `KIND_READ = 11` — potwierdzenie przeczytania (mid najnowszej przeczytanej wiadomości). Pokazuje ✓✓. Przełącznik w Ustawieniach (domyślnie włączony); wyłączony = nie wysyłasz i nie przetwarzasz cudzych.
- Baza: kolumna `contacts.rcpt` (ostatni potwierdzony mid, żeby nie wysyłać duplikatów), `messages.status=3` = przeczytane.
Uwaga: obie strony muszą mieć tę wersję, żeby funkcje działały. Nie zbudowano ani nie uruchomiono.

## Alpha 4b — formatowanie i linki (tylko UI)
- Formatowanie w dymkach: `*pogrubienie*`, `_kursywa_`, `~przekreślenie~`, `` `kod` ``; znaczniki działają na granicy słowa (snake_case bez zmian).
- Linki http(s) są podkreślone; „Otwórz link” w menu wiadomości pyta o potwierdzenie i ostrzega, że przeglądarka działa poza Torem (ujawnia IP).
- Treść wysyłana przez sieć się nie zmienia — formatowanie jest renderowane lokalnie, więc działa też ze starszymi wersjami (jako zwykłe znaki).

## Alpha 5 — grupy (model: osobny szyfrowany kanał do każdego członka)
Protokół: `KIND_GROUP = 12`, ramka wewnątrz zwykłej sesji Double Ratchet 1:1: `gid(8) mid(8) nameLen(1) name n(1) n*sid(16) tekst`. Brak wspólnego klucza grupowego — wiadomość jest szyfrowana osobno dla każdego członka, który jest Twoim kontaktem. Zachowuje to uwierzytelnienie nadawcy (przychodzi jego sesją), ale ma ograniczenia:
- Członek odpowiada tylko tym osobom z grupy, które sam ma w kontaktach (pozostali widoczni jako „Nieznany (xxxx)”).
- Grupa pojawia się u członków dopiero po pierwszej wysłanej wiadomości.
- Skład grupy jest ustalany przy tworzeniu (max 16 osób razem z Tobą); brak dodawania/usuwania członków i brak ról administratora.
- Bez załączników, reakcji, edycji i znikania w grupach (tylko tekst z formatowaniem).
- Bezpieczeństwo: ramka musi wymieniać odbiorcę i nadawcę wśród członków; dla znanej grupy nadawca musi być na jej zapisanej liście, więc osoba spoza grupy nie podmieni nazwy ani składu.
- Baza: tabele `chat_groups`, `group_msgs`. Zmiana jest zgodna wstecz (stare wersje ignorują nieznany rodzaj ramki).
Nie zbudowano ani nie uruchomiono.

## Alpha 6 — wygoda użytkowania
- **Notatki do siebie** (jak „Zapisane wiadomości”): lokalny czat tylko dla Ciebie, zawsze na górze listy; nic nie wychodzi do sieci.
- **Wyszukiwanie we wszystkich rozmowach** (od 2 znaków): wyniki z treści wiadomości, dotknięcie otwiera rozmowę.
- **Filtr „Nieprzeczytane”** i przycisk „Wszystko przeczytane”.
- **Domyślne znikanie wiadomości** dla nowych kontaktów (Ustawienia).
- **Rozmiar czcionki**: mała / normalna / duża / największa (Ustawienia, działa od razu w całej aplikacji).
- **Blokada „od razu”** dodana do opcji automatycznej blokady.
- **Eksport rozmowy do .txt** (panel Info) z ostrzeżeniem, że plik nie jest szyfrowany; tylko tekst, bez załączników.
Brak zmian w protokole sieciowym. Nowych kolumn nie dodano (tabela `chat_groups` z alpha5 przechowuje też notatki, gid `0000000000000000`). Nie zbudowano ani nie uruchomiono.
