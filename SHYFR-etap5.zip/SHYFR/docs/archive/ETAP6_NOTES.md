# SHYFR – etap 6

## Co dodano
1. **Zrzuty ekranu / eksport – powiadomienia i ustawienia per rozmowa**
   - Info → Prywatność → „Zrzuty ekranu w tej rozmowie”: *Jak w Ustawieniach* / *Blokuj* / *Zezwalaj + powiadom*.
   - *Blokuj*: FLAG_SECURE w tej rozmowie, eksport .txt wyłączony, treść wiadomości ukryta na liście rozmów i w wyszukiwarce („🔒 Rozmowa chroniona”).
   - Gdy zrzuty są dozwolone, rozmówca dostaje komunikat o: zrzucie ekranu (Android 14+), nagrywaniu ekranu (Android 15+), eksporcie rozmowy, zapisie pliku. U Ciebie zostaje ślad „Rozmówca został powiadomiony”.
   - Ustawienia → „Powiadamiaj o zrzutach i eksporcie” (globalny przełącznik).
   - Nowe uprawnienia (zwykłe): DETECT_SCREEN_CAPTURE, DETECT_SCREEN_RECORDING.
2. **Przeciągnięcie wiadomości w prawo = odpowiedź** (próg + wibracja, jak w Messengerze).
3. **Personalizacja rozmowy (wspólna dla obu stron)**: 8 motywów, szybkie emoji (przycisk obok pola wiadomości i pierwsza reakcja), pseudonimy (rozmówcy i Twój). Nowa ramka `KIND_LOOK`.
4. **Status aktywności**: „Aktywny teraz” / „Online” / „Ostatnio aktywny …”, zielona kropka na awatarze. Nowa ramka `PRES` (poza kolejką i ratchetem), uwierzytelniona HMAC z klucza pary (HKDF z X25519 tożsamości), odpowiedź związana z nonce, tolerancja czasu ±5 min. Odpytywanie tylko, gdy aplikacja jest na pierwszym planie (max 4 równolegle, co ~60 s). Ustawienia → „Status aktywności” (wyłączone = nie widzisz i nie jesteś widziany).
5. **UI**: separatory dni, grupowanie dymków, cytat z paskiem akcentu, reakcje jako pigułki, nowy pasek wpisywania, nowe wiersze listy (nazwa pogrubiona przy nieprzeczytanych, status).

## Zmiany w bazie (migracja idempotentna, user_version = 7)
contacts: theme, capmode, qemoji, cnick, mynick, peer_state, peer_active, peer_seen; messages: sys.

## Ograniczenia (uczciwie)
- **Kod nie był kompilowany ani uruchamiany** (brak Android SDK w środowisku). Zbuduj w Android Studio i zgłoś błędy kompilacji, jeśli jakieś będą.
- Powiadomienia o zrzucie to sygnał ostrzegawczy, nie zabezpieczenie: nie złapią zdjęcia drugim telefonem ani zmodyfikowanej aplikacji po drugiej stronie. Tylko *Blokuj* (FLAG_SECURE) realnie uniemożliwia zrzut na tym telefonie.
- W trybie *Zezwalaj + powiadom* miniatura w przełączniku aplikacji nie jest ukrywana.
- Poniżej Androida 14 nie ma API wykrywania zrzutów (działa tylko blokada).
- „Online” = węzeł Tor osiągalny, „Aktywny” = aplikacja na pierwszym planie na odblokowanym koncie.
- Grupy: bez zmian (brak odpowiedzi/motywów/statusu w grupach – kolejny etap).
