# Stan SHYFR względem wymagań (audyt kodu, listopad 2026)

Legenda: ✅ jest w kodzie, 🟡 częściowo, ❌ brak. **Żadna pozycja nie została zweryfikowana na urządzeniu ani przez kompilację w środowisku, w którym powstał kod.** „✅” oznacza: kod jest napisany i przejrzany; przekaźnik (Python) ma 41 uruchomionych testów.

## Wiadomości
| Funkcja | Stan |
|---|---|
| Rozmowy 1:1, grupy | ✅ |
| Wiadomości głosowe (nagrywanie, odtwarzanie) | ✅; fala dźwięku i prędkość odtwarzania ❌ |
| Zdjęcia, pliki (w tym wideo jako plik), podgląd | ✅ |
| Edycja, usuwanie, odpowiedzi, reakcje, przekazywanie dalej | ✅ |
| Przypinanie, wiadomości oznaczone gwiazdką | ✅ |
| Wyszukiwanie w rozmowie | 🟡 (tekst + filtr „oznaczone”) |
| Znikające wiadomości, status dostarczenia/odczytu, szkice | ✅ |
| Ankiety w rozmowie 1:1 | ✅ (w grupach ❌) |
| Wiadomości zaplanowane, wskaźnik „pisze…” | ❌ |
| Kolejka offline, deduplikacja, skrzynka na przekaźniku | ✅ |
## Rozmowy audio/wideo (w tym grupowe)
❌ Nie zaimplementowane. Wymagają wyboru architektury (WebRTC z serwerami STUN/TURN albo strumień przez Tora z dużym opóźnieniem) i infrastruktury; nie symulujemy ich.
## Bezpieczeństwo
| Element | Stan |
|---|---|
| E2EE z własną implementacją Double Ratchet (`crypto/Ratchet.kt`) | ✅ kod; **bez niezależnego audytu**; własna implementacja, nie libsignal |
| SQLCipher, Argon2id, klucz sprzętowy, PIN, biometria, auto-blokada | ✅ |
| Szyfrowana kopia zapasowa, usunięcie konta | ✅ |
| Ostrzeżenie o zmianie klucza rozmówcy | ❌ |
| Sesje/urządzenia (wielourządzeniowość) | ❌ (jedno konto = jedno urządzenie) |
| Ochrona przed spamem w czatach prywatnych i złośliwymi załącznikami | 🟡 (blokowanie kontaktu, zaproszenia jednorazowe; brak skanowania załączników) |
| Obsługa uszkodzonej bazy (odzysk) | ❌ |
## Tor i sieć
Onion service, obsługa zmiany sieci, diagnoza, mosty, skrzynka z **do 3 przekaźnikami (failover)**: ✅. Automatyczne wyszukiwanie przekaźników ❌ (adres wpisywany lub wbudowany). Failover warstwy publicznej (feed) ❌ (społeczność żyje na jednym przekaźniku).
## Warstwa społecznościowa
| Funkcja | Stan |
|---|---|
| Społeczności publiczne/prywatne/ukryte, kanały, role (właściciel, moderator), zaproszenia kodem, regulamin, zgłoszenia | ✅ |
| Wpisy tekstowe, komentarze i odpowiedzi (wątki), reakcje, reposty, cytaty, zakładki, hashtagi, szukanie, ankiety, przypinanie | ✅ |
| Tożsamość: anonimowa / pseudonim / profil publiczny, prośby o kontakt | ✅ |
| Zdjęcia i wideo we wpisach, galerie | ❌ |
| Obserwowanie, trendy, filtry treści | ❌ (obserwowanie świadomie pominięte: ryzyko dla anonimowości) |
| Kody QR zaproszeń do społeczności, wydarzenia, historia moderacji | ❌ |
| Awatary, banery, nazwa użytkownika, weryfikacja profili | ❌ |
## Powiadomienia
Wiadomości, aktywność (reakcje, komentarze, prośby), tryb nie przeszkadzać, prywatne podglądy, wyciszanie per społeczność: ✅. Połączenia, wzmianki, własne dźwięki, grupowanie, kategorie: ❌.
## UI i dostępność
System projektowy opisany (`docs/DESIGN_SYSTEM.md`); nawigacja i główne przyciski ikonowe mają opisy TalkBack; pozostałe ikony i test TalkBack ❌.
## Testy
Jednostkowe (JVM): protokół publiczny, kontakty, skrzynka, ankiety, DND, mosty. Przekaźnik: 41 testów (uruchomione). Brak testów UI, integracyjnych i migracji bazy po stronie aplikacji.
## Priorytety
- **P0:** pierwszy build i naprawa błędów kompilacji; test na dwóch telefonach; ostrzeżenie o zmianie klucza; odzysk uszkodzonej bazy; audyt kryptografii.
- **P1:** wspólny przekaźnik wbudowany i stale działający; testy migracji bazy; wskaźnik „pisze…”.
- **P2:** zdjęcia we wpisach, QR zaproszeń, awatary, dostępność pozostałych ekranów, ankiety w grupach.
- **P3:** połączenia audio/wideo, wiadomości zaplanowane, fala dźwięku.
