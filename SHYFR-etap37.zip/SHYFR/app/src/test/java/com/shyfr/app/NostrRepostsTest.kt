package com.shyfr.app

import com.shyfr.app.nostr.NostrEvent
import com.shyfr.app.nostr.NostrReposts
import org.junit.Assert.*
import org.junit.Test

class NostrRepostsTest {
    private fun sk(n: Int) = ByteArray(32).also { it[31] = n.toByte() }
    private val aux = ByteArray(32)
    private val orig = NostrEvent.create(sk(3), 1, listOf(listOf("t", "shyfr")), "hej", 1_700_000_000, aux)
    private fun repost(inner: NostrEvent = orig, ts: Long = 1_700_000_100, tags: List<List<String>> = listOf(listOf("e", inner.id, ""), listOf("p", inner.pubkey)), content: String = inner.toWireJson()) =
        NostrEvent.create(sk(5), 6, tags, content, ts, aux)

    @Test fun validRepostYieldsTheOriginal() = assertEquals(orig, NostrReposts.unwrap(repost()))

    @Test fun tamperedEmbeddedEventIsRejected() =
        assertNull(NostrReposts.unwrap(repost(content = orig.copy(content = "zmienione").toWireJson())))

    @Test fun embeddedEventMustMatchTheReferencedId() {
        val other = NostrEvent.create(sk(3), 1, emptyList(), "inny", 1_700_000_050, aux)
        assertNull(NostrReposts.unwrap(repost(tags = listOf(listOf("e", other.id, "")), content = orig.toWireJson())))
    }

    @Test fun garbageAndWrongKindsAreIgnored() {
        assertNull(NostrReposts.unwrap(repost(content = "to nie json")))
        assertNull(NostrReposts.unwrap(repost(content = "{}")))
        assertNull(NostrReposts.unwrap(orig))
    }

    @Test fun flattenDeduplicatesAndRemembersWhoReposted() {
        val r = repost(); val flat = NostrReposts.flatten(listOf(r))
        assertEquals(listOf(orig.id), flat.notes.map { it.id }); assertEquals(r.pubkey, flat.via[orig.id])
    }

    @Test fun noteSeenDirectlyHasNoRepostAttribution() {
        val flat = NostrReposts.flatten(listOf(orig, repost()))
        assertEquals(1, flat.notes.size); assertNull(flat.via[orig.id])
    }

    @Test fun listIsOrderedByLatestActivity() {
        val older = NostrEvent.create(sk(3), 1, emptyList(), "starszy", 1_700_000_001, aux)
        val flat = NostrReposts.flatten(listOf(older, orig, repost(ts = 1_700_000_900)))
        assertEquals(listOf(orig.id, older.id), flat.notes.map { it.id })
    }

    @Test fun forgedRepostDoesNotAppearInTheFeed() {
        val forged = repost(content = orig.copy(content = "fałsz").toWireJson())
        assertTrue(NostrReposts.flatten(listOf(forged)).notes.isEmpty())
    }
}
