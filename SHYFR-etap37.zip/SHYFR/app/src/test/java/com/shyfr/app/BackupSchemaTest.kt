package com.shyfr.app

import com.shyfr.app.vault.Backup
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class BackupSchemaTest {
    private fun dbSource(): String {
        val f = listOf("src/main/java/com/shyfr/app/vault/Db.kt", "app/src/main/java/com/shyfr/app/vault/Db.kt").map(::File).first { it.exists() }
        return f.readText()
    }
    private val schemaTables get() = Regex("CREATE TABLE IF NOT EXISTS (\\w+)").findAll(dbSource()).map { it.groupValues[1] }.toSet()

    @Test fun everyTableInTheSchemaIsEitherBackedUpOrExplicitlyExcluded() {
        val missing = schemaTables - Backup.TABLES.toSet() - Backup.EXCLUDED
        assertTrue("Tabele poza kopią zapasową (dodaj do Backup.TABLES albo świadomie do EXCLUDED): $missing", missing.isEmpty())
    }

    @Test fun backupDoesNotListTablesThatDoNotExist() {
        val unknown = Backup.TABLES.toSet() - schemaTables
        assertTrue("Backup.TABLES zawiera nieistniejące tabele: $unknown", unknown.isEmpty())
    }

    @Test fun socialIdentitiesSurviveBackup() =
        assertTrue(Backup.TABLES.containsAll(listOf("soc_identity", "soc_draft", "soc_graph")))

    @Test fun sendQueueIsNotBackedUpOnPurpose() {
        assertTrue("outbox" in Backup.EXCLUDED); assertFalse("outbox" in Backup.TABLES)
    }

    @Test fun noTableIsListedTwice() = assertEquals(Backup.TABLES.size, Backup.TABLES.toSet().size)
}
