package com.shyfr.app

import com.shyfr.app.net.Reach
import org.junit.Assert.*
import org.junit.Test

class ReachTest {
    @Test fun timeoutNeverMeansReachable() {
        assertEquals(Reach.UNKNOWN, Reach.afterTimeout(false))
        assertEquals(Reach.UNREACHABLE, Reach.afterTimeout(true))
        for (b in listOf(true, false)) assertFalse(Reach.afterTimeout(b).confirmed)
    }

    @Test fun onlyReachableIsConfirmed() {
        assertTrue(Reach.REACHABLE.confirmed)
        assertEquals(listOf(Reach.CHECKING, Reach.UNREACHABLE, Reach.UNKNOWN), Reach.entries.filter { !it.confirmed })
    }

    @Test fun onlyAConfirmedStateIsLabelledOnline() {
        assertEquals("Online", Reach.REACHABLE.label())
        for (r in Reach.entries.filter { it != Reach.REACHABLE }) assertNotEquals("Online", r.label())
        assertEquals(Reach.entries.size, Reach.entries.map { it.label() }.toSet().size)
    }
}
