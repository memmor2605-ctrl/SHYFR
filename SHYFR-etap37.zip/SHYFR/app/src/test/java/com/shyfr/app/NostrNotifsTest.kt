package com.shyfr.app

import com.shyfr.app.nostr.NostrEvent
import com.shyfr.app.nostr.NostrNotifs
import com.shyfr.app.nostr.NotifType
import org.junit.Assert.*
import org.junit.Test

class NostrNotifsTest {
    private val me = "aa".repeat(32); private val bob = "bb".repeat(32); private val eve = "ee".repeat(32)
    private var n = 0
    private fun ev(kind: Int, by: String, ts: Long, tags: List<List<String>>, content: String = "") =
        NostrEvent("%064x".format(++n), by, ts, kind, tags, content, "00")

    @Test fun replyReactionMentionAndFollowAreRecognised() {
        val items = NostrNotifs.classify(listOf(
            ev(1, bob, 10, listOf(listOf("e", "x", "", "reply"), listOf("p", me)), "dzięki"),
            ev(7, bob, 20, listOf(listOf("e", "x"), listOf("p", me)), "+"),
            ev(1, eve, 30, listOf(listOf("p", me)), "cześć @ty"),
            ev(3, bob, 40, listOf(listOf("p", me)))
        ), me)
        assertEquals(listOf(NotifType.FOLLOW, NotifType.MENTION, NotifType.REACTION, NotifType.REPLY), items.map { it.type })
        assertEquals("x", items.first { it.type == NotifType.REPLY }.noteId)
    }

    @Test fun ownEventsAndEventsNotAddressedToMeAreIgnored() {
        assertTrue(NostrNotifs.classify(listOf(
            ev(1, me, 1, listOf(listOf("p", me))),
            ev(7, bob, 2, listOf(listOf("p", eve))),
            ev(1, bob, 3, emptyList(), "bez tagu")
        ), me).isEmpty())
    }

    @Test fun dislikeIsNotANotification() =
        assertTrue(NostrNotifs.classify(listOf(ev(7, bob, 5, listOf(listOf("e", "x"), listOf("p", me)), "-")), me).isEmpty())

    @Test fun oneFollowNotificationPerPersonEvenWhenTheirListWasUpdatedManyTimes() {
        val items = NostrNotifs.classify(listOf(ev(3, bob, 1, listOf(listOf("p", me))), ev(3, bob, 2, listOf(listOf("p", me), listOf("p", eve))), ev(3, eve, 3, listOf(listOf("p", me)))), me)
        assertEquals(2, items.size); assertEquals(setOf(bob, eve), items.map { it.actor }.toSet())
        assertEquals("zostaje najnowsza", 2L, items.first { it.actor == bob }.ts)
    }

    @Test fun duplicatesFromSeveralRelaysCountOnce() {
        val e = ev(7, bob, 9, listOf(listOf("e", "x"), listOf("p", me)), "+")
        assertEquals(1, NostrNotifs.classify(listOf(e, e.copy()), me).size)
    }

    @Test fun reactionEmojiIsShortenedAndEmptyBecomesPlus() {
        val items = NostrNotifs.classify(listOf(ev(7, bob, 1, listOf(listOf("p", me)), ""), ev(7, eve, 2, listOf(listOf("p", me)), "❤")), me)
        assertEquals(listOf("❤", "+"), items.map { it.text })
    }

    @Test fun longMentionIsTruncated() =
        assertEquals(140, NostrNotifs.classify(listOf(ev(1, bob, 1, listOf(listOf("p", me)), "x".repeat(500))), me).first().text.length)

    @Test fun unreadCountUsesTheLastSeenTimestamp() {
        val items = NostrNotifs.classify(listOf(ev(7, bob, 10, listOf(listOf("p", me)), "+"), ev(7, eve, 20, listOf(listOf("p", me)), "+")), me)
        assertEquals(2, NostrNotifs.unreadCount(items, 0)); assertEquals(1, NostrNotifs.unreadCount(items, 10)); assertEquals(0, NostrNotifs.unreadCount(items, 20))
    }
}
