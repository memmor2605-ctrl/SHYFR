package com.shyfr.app

import com.shyfr.app.net.Delivery
import org.junit.Assert.*
import org.junit.Test

class DeliveryTest {
    @Test fun mailboxAcceptanceIsNotDelivery() {
        assertEquals(Delivery.ON_SERVER, Delivery.afterMailboxAccept(Delivery.SENDING))
        assertNotEquals(Delivery.DELIVERED, Delivery.afterMailboxAccept(Delivery.SENDING))
    }

    @Test fun mailboxNeverDowngradesAnAlreadyConfirmedMessage() {
        for (s in listOf(Delivery.DELIVERED, Delivery.READ, Delivery.FAILED)) assertEquals(s, Delivery.afterMailboxAccept(s))
    }

    @Test fun onlyRecipientConfirmationMeansDelivered() {
        assertEquals(Delivery.DELIVERED, Delivery.afterDirectAck(Delivery.SENDING))
        assertEquals(Delivery.DELIVERED, Delivery.afterDirectAck(Delivery.ON_SERVER))
        assertEquals("przeczytane zostaje przeczytane", Delivery.READ, Delivery.afterDirectAck(Delivery.READ))
    }

    @Test fun readReceiptUpgradesEverythingThatWasSentButNotFailed() {
        for (s in listOf(Delivery.SENDING, Delivery.DELIVERED, Delivery.ON_SERVER)) assertEquals(Delivery.READ, Delivery.afterReadReceipt(s))
        assertEquals(Delivery.FAILED, Delivery.afterReadReceipt(Delivery.FAILED))
        assertEquals(Delivery.READ, Delivery.afterReadReceipt(Delivery.READ))
    }

    @Test fun sqlConditionMatchesTheKotlinRule() {
        val inSql = Regex("\\((.*)\\)").find(Delivery.SQL_BEFORE_READ)!!.groupValues[1].split(',').map { it.trim().toInt() }.toSet()
        val viaKotlin = (0..4).filter { Delivery.afterReadReceipt(it) == Delivery.READ && it != Delivery.READ }.toSet()
        assertEquals(viaKotlin, inSql)
    }

    @Test fun onlyUnsentMessagesCanBeRetractedLocally() {
        assertTrue(Delivery.canRetractLocally(Delivery.SENDING)); assertTrue(Delivery.canRetractLocally(Delivery.FAILED))
        for (s in listOf(Delivery.DELIVERED, Delivery.READ, Delivery.ON_SERVER)) assertFalse(Delivery.canRetractLocally(s))
    }

    @Test fun everyStatusHasAnHonestLabel() {
        for (s in 0..4) assertTrue(Delivery.label(s).isNotEmpty())
        assertFalse(Delivery.label(Delivery.ON_SERVER).contains("Dostarczono"))
    }
}
