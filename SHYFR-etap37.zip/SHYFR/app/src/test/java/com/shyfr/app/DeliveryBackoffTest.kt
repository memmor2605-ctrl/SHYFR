package com.shyfr.app

import com.shyfr.app.net.DeliveryBackoff
import org.junit.Assert.*
import org.junit.Test

class DeliveryBackoffTest {
    private var t = 1_000_000L
    private val b = DeliveryBackoff(30_000, 300_000) { t }

    @Test fun freshContactIsTriedImmediately() = assertTrue(b.shouldTryDirect(1))

    @Test fun failureBlocksDirectAttemptsUntilTheDelayPasses() {
        b.onFailure(1)
        assertFalse(b.shouldTryDirect(1))
        t += 29_999; assertFalse(b.shouldTryDirect(1))
        t += 1; assertTrue(b.shouldTryDirect(1))
    }

    @Test fun delayDoublesAndIsCapped() {
        val waits = ArrayList<Long>()
        repeat(7) {
            b.onFailure(1)
            var w = 0L; while (!b.shouldTryDirect(1)) { t += 1_000; w += 1_000 }
            waits += w
        }
        assertEquals(listOf(30_000L, 60_000L, 120_000L, 240_000L, 300_000L, 300_000L, 300_000L), waits)
    }

    @Test fun successForgetsFailures() {
        b.onFailure(1); b.onFailure(1); b.onSuccess(1)
        assertTrue(b.shouldTryDirect(1)); assertEquals(0, b.failures(1))
        b.onFailure(1); t += 30_000; assertTrue("po sukcesie zaczynamy od najkrótszego opóźnienia", b.shouldTryDirect(1))
    }

    @Test fun contactsAreIndependent() {
        b.onFailure(1)
        assertFalse(b.shouldTryDirect(1)); assertTrue(b.shouldTryDirect(2))
    }

    @Test fun networkChangeResetsEverything() {
        b.onFailure(1); b.onFailure(2); b.reset()
        assertTrue(b.shouldTryDirect(1)); assertTrue(b.shouldTryDirect(2))
    }

    @Test fun newMessageShortensLongDelayToTheBaseIntervalButNeverBelowIt() {
        repeat(4) { b.onFailure(1); t += 1 }      // karencja ok. 240 s
        assertFalse(b.shouldTryDirect(1))
        b.expedite(1)
        assertFalse("nie wcześniej niż po podstawowym odstępie", b.shouldTryDirect(1))
        t += 30_000
        assertTrue(b.shouldTryDirect(1))
    }

    @Test fun expediteDoesNothingForContactsWithoutFailures() {
        b.expedite(5); assertTrue(b.shouldTryDirect(5))
    }
}
