package com.shyfr.app

import com.shyfr.app.vault.ABANDONED_ATT_MS
import com.shyfr.app.vault.ATT_CHUNK
import com.shyfr.app.vault.MAX_ATT_BYTES
import org.junit.Assert.*
import org.junit.Test

/** Stałe nadawcy muszą mieścić się w limitach, które odbiorca egzekwuje (Messenger: total 1..200, kawałek <= ATT_CHUNK, ramka <= 65 000 B). */
class AttachmentLimitsTest {
    private fun chunks(size: Int) = (size + ATT_CHUNK - 1) / ATT_CHUNK

    @Test fun biggestAllowedFileFitsTheReceiversChunkLimit() = assertTrue(chunks(MAX_ATT_BYTES) in 1..200)

    @Test fun chunkFrameFitsTheFrameSizeLimit() = assertTrue("id(8) + indeks(2) + dane", 8 + 2 + ATT_CHUNK <= 65_000)

    @Test fun chunkBoundariesCoverTheFileExactly() {
        for (size in listOf(1, ATT_CHUNK - 1, ATT_CHUNK, ATT_CHUNK + 1, 2 * ATT_CHUNK, MAX_ATT_BYTES)) {
            val total = chunks(size)
            var covered = 0
            for (i in 0 until total) covered += minOf(size, i * ATT_CHUNK + ATT_CHUNK) - i * ATT_CHUNK
            assertEquals("rozmiar $size", size, covered)
        }
    }

    @Test fun abandonedTransfersAreCleanedOnlyAfterAGenerousDelay() = assertTrue(ABANDONED_ATT_MS >= 24 * 3_600_000L)
}
