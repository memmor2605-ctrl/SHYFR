package com.shyfr.app

import com.shyfr.app.nostr.NostrEvent
import com.shyfr.app.nostr.NostrReports
import com.shyfr.app.nostr.ReportReason
import org.junit.Assert.*
import org.junit.Test

class NostrReportsTest {
    private val note = NostrEvent("ab".repeat(32), "cd".repeat(32), 1, 1, emptyList(), "x", "00")

    @Test fun reportPointsAtTheNoteAndItsAuthorWithTheReason() {
        val t = NostrReports.tags(note, ReportReason.SPAM)
        assertEquals(listOf("e", note.id, "spam"), t[0]); assertEquals(listOf("p", note.pubkey, "spam"), t[1])
    }

    @Test fun reasonCodesAreUniqueAndFollowNip56Vocabulary() {
        assertEquals(ReportReason.entries.size, ReportReason.entries.map { it.code }.toSet().size)
        assertTrue(ReportReason.entries.map { it.code }.containsAll(listOf("spam", "nudity", "illegal", "impersonation")))
        assertTrue(ReportReason.entries.all { it.label.isNotBlank() })
    }
}
