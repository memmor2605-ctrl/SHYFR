package com.shyfr.app.net

/**
 * Czy nasz adres onion jest faktycznie osiągalny z zewnątrz. Zielony stan „Online” wolno pokazać tylko po
 * potwierdzonym teście własnego adresu. Brak potwierdzenia to NIE jest osiągalność.
 */
enum class Reach {
    CHECKING,      // test trwa
    REACHABLE,     // test własnego adresu się powiódł
    UNREACHABLE,   // test działał wcześniej, a teraz nie przechodzi
    UNKNOWN;       // test nigdy nie przeszedł (może nie działać w tej wersji Tora): nie wiemy

    val confirmed get() = this == REACHABLE

    fun label() = when (this) {
        CHECKING -> "Sprawdzam dostępność"; REACHABLE -> "Online"
        UNREACHABLE -> "Niedostępny z zewnątrz"; UNKNOWN -> "Bez potwierdzenia dostępności"
    }

    companion object {
        /** Stan po wyczerpaniu czasu testu. Nigdy nie zakładamy, że adres jest osiągalny. */
        fun afterTimeout(testEverWorked: Boolean) = if (testEverWorked) UNREACHABLE else UNKNOWN
    }
}
