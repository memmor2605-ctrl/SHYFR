package com.shyfr.app.nostr

enum class NotifType { REPLY, REACTION, MENTION, FOLLOW }
data class NostrNotif(val type: NotifType, val actor: String, val eventId: String, val noteId: String?, val text: String, val ts: Long)

/** Zamienia zdarzenia, które wskazują na nas (tag „p”), w powiadomienia. Czysta funkcja, bez sieci i bazy. */
object NostrNotifs {
    fun classify(events: List<NostrEvent>, me: String): List<NostrNotif> {
        val out = ArrayList<NostrNotif>()
        val followers = HashSet<String>()
        val seenIds = HashSet<String>()
        for (e in events.sortedByDescending { it.createdAt }) {
            if (e.pubkey == me || me !in e.tagValues("p") || !seenIds.add(e.id)) continue
            when (e.kind) {
                7 -> if (e.content != "-") out += NostrNotif(NotifType.REACTION, e.pubkey, e.id, e.tagValues("e").lastOrNull(), e.content.take(8).ifBlank { "+" }, e.createdAt)
                1 -> {
                    val ref = e.tagValues("e").lastOrNull()
                    out += NostrNotif(if (ref != null) NotifType.REPLY else NotifType.MENTION, e.pubkey, e.id, ref, e.content.take(140), e.createdAt)
                }
                3 -> if (followers.add(e.pubkey)) out += NostrNotif(NotifType.FOLLOW, e.pubkey, e.id, null, "", e.createdAt)   // jedna pozycja na osobę
            }
        }
        return out
    }

    fun unreadCount(items: List<NostrNotif>, seenTs: Long) = items.count { it.ts > seenTs }
}
