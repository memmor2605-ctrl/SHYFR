package com.shyfr.app.net

import java.util.concurrent.ConcurrentHashMap

/**
 * Opóźnienia ponawiania bezpośredniego połączenia z kontaktem, który jest nieosiągalny. Bez tego każda pętla (co 30 s)
 * czeka na przekroczenie czasu Tora dla każdego kontaktu offline po kolei i opóźnia wiadomości do kontaktów online.
 * Dla kontaktu w „karencji” wiadomość idzie od razu skrzynką na serwerze (jeśli jest włączona).
 */
class DeliveryBackoff(
    private val baseMs: Long = 30_000, private val maxMs: Long = 300_000, private val now: () -> Long = System::currentTimeMillis
) {
    private val fails = ConcurrentHashMap<Long, Int>()
    private val lastFail = ConcurrentHashMap<Long, Long>()
    private val until = ConcurrentHashMap<Long, Long>()

    fun shouldTryDirect(id: Long): Boolean = now() >= (until[id] ?: 0L)

    fun onFailure(id: Long) {
        val n = (fails[id] ?: 0) + 1
        fails[id] = n
        lastFail[id] = now()
        until[id] = now() + minOf(maxMs, baseMs shl minOf(n - 1, 10))
    }

    fun onSuccess(id: Long) { fails.remove(id); lastFail.remove(id); until.remove(id) }

    /** Nowa wiadomość użytkownika: skraca karencję do podstawowego odstępu od ostatniej porażki (nigdy nie przyspiesza w pętli). */
    fun expedite(id: Long) {
        val last = lastFail[id] ?: return
        val soonest = last + baseMs
        until.computeIfPresent(id) { _, u -> minOf(u, soonest) }
    }

    /** Zmiana sieci: dotychczasowe porażki nic nie mówią o nowej sieci. */
    fun reset() { fails.clear(); lastFail.clear(); until.clear() }

    fun failures(id: Long) = fails[id] ?: 0
}
