package com.shyfr.app.net

import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow

/** Współdzielony stan węzła (transport Tor, adres onion, sygnały odświeżania). */
object NodeRuntime {
    @Volatile var transport: TorTransport? = null
    @Volatile var onion: String? = null
    val contactsVersion = MutableStateFlow(0)
    val messagesVersion = MutableStateFlow(0)
    /** Budzi pętlę wysyłki, gdy pojawi się nowa wiadomość w kolejce. */
    val kick = Channel<Unit>(Channel.CONFLATED)
    /** Liczba nowych rzeczy w zakładce Aktywność (kropka przy ikonie). */
    val activityUnread = MutableStateFlow(0)
    /** Budzi pętlę pobierania ze skrzynki na przekaźniku (np. po zmianie sieci). */
    val mailboxKick = Channel<Unit>(Channel.CONFLATED)
    /** true, gdy własny adres onion odpowiada (albo minął limit sprawdzania). */
    /** Prawda wyłącznie po potwierdzonym teście własnego adresu. */
    val reachable = MutableStateFlow(false)
    val reachState = MutableStateFlow(Reach.CHECKING)
    /** true, gdy test własnego adresu onion kiedykolwiek się powiódł na tym urządzeniu (wtedy jego porażka po zmianie sieci wymusza restart). */
    @Volatile var selfTestEverOk = false
    @Volatile var onIncoming: (() -> Unit)? = null
}
