package com.shyfr.app.nostr

/** Powody zgłoszenia wpisu (NIP-56, kind 1984). */
enum class ReportReason(val code: String, val label: String) {
    SPAM("spam", "Spam"),
    NUDITY("nudity", "Treści nieodpowiednie (nagość)"),
    ILLEGAL("illegal", "Treści nielegalne"),
    IMPERSONATION("impersonation", "Podszywanie się"),
    OTHER("other", "Inny powód")
}

object NostrReports {
    /** Tagi zgłoszenia: wpis i jego autor z powodem. */
    fun tags(note: NostrEvent, reason: ReportReason): List<List<String>> =
        listOf(listOf("e", note.id, reason.code), listOf("p", note.pubkey, reason.code))
}
