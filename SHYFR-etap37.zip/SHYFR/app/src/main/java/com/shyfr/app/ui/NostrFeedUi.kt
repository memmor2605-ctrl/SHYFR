package com.shyfr.app.ui

import android.content.Context
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.nostr.*
import com.shyfr.app.social.IdentityKind
import com.shyfr.app.social.SocialIdentity
import com.shyfr.app.social.SocialState
import com.shyfr.app.social.SocialStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val WARN_ALL = "„Wszystko” to niefiltrowany strumień z całej publicznej sieci. Mogą pojawić się treści nieodpowiednie i spam. SHYFR nie moderuje cudzych serwerów."

/** Publiczny feed. Połączenia z serwerami sieci dobiera i podtrzymuje aplikacja, użytkownik niczego nie konfiguruje. */
@Composable
fun PublicFeed(ctx: Context) {
    val mgr = remember { NostrHub.acquire(ctx) }
    DisposableEffect(Unit) { onDispose { NostrHub.release(ctx) } }
    val repo = remember { NostrFeedRepo(ctx, mgr) }
    val status by mgr.status.collectAsState()
    val activeId by SocialState.active.collectAsState()
    val scope = rememberCoroutineScope()

    var identity by remember { mutableStateOf<SocialIdentity?>(null) }
    var me by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(FeedKind.SHYFR) }
    var notes by remember { mutableStateOf<List<NostrEvent>>(emptyList()) }
    var names by remember { mutableStateOf<Map<String, NostrProfile>>(emptyMap()) }
    var reacts by remember { mutableStateOf<Map<String, Reactions>>(emptyMap()) }
    var follows by remember { mutableStateOf<Set<String>>(emptySet()) }
    var loading by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var canMore by remember { mutableStateOf(false) }
    var loadedOnce by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var posting by remember { mutableStateOf(false) }
    var replyTarget by remember { mutableStateOf<NostrEvent?>(null) }
    var askAll by remember { mutableStateOf(false) }
    var tagQuery by remember { mutableStateOf("") }
    var activeTag by remember { mutableStateOf("") }
    var via by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var saved by remember { mutableStateOf<Set<String>>(emptySet()) }
    var deleteTarget by remember { mutableStateOf<NostrEvent?>(null) }
    var showProfile by remember { mutableStateOf(false) }
    var moreTarget by remember { mutableStateOf<NostrEvent?>(null) }
    var reportTarget by remember { mutableStateOf<NostrEvent?>(null) }
    var showHidden by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }

    suspend fun enrich(list: List<NostrEvent>, id: SocialIdentity) {
        names = names + repo.profiles(list.map { it.pubkey } + via.values)
        reacts = reacts + repo.reactions(list.map { it.id }, me)
        follows = withContext(Dispatchers.IO) { list.map { it.pubkey }.filter { repo.isFollowing(id, it) }.toSet() }
        saved = withContext(Dispatchers.IO) { repo.savedIds(id) }
    }

    LaunchedEffect(tab, activeId, tick, activeTag) {
        loading = true
        try {
            val id = withContext(Dispatchers.IO) { SocialStore(ctx).ensureDefaults("") }
            identity = id; me = repo.pubOf(id)
            val page = repo.feed(tab, id, tag = activeTag)
            notes = page.notes; via = page.via; canMore = page.notes.size >= 10 && tab != FeedKind.SAVED
            info = when {
                tab == FeedKind.SAVED || tab == FeedKind.TAG && activeTag.isBlank() -> null
                tab == FeedKind.FOLLOWING && page.asked == 0 && page.notes.isEmpty() -> null
                page.asked == 0 -> "Sieć publiczna jest chwilowo niedostępna. Łączę ponownie…"
                else -> null
            }
            enrich(page.notes, id)
        } catch (e: CancellationException) { throw e } catch (e: Exception) { info = "Nie udało się wczytać wpisów. Spróbuję ponownie." }
        loadedOnce = true
        loading = false
    }
    // Automatyczne ponawianie, gdy nic się nie wczytało (np. sieć dopiero się łączy).
    LaunchedEffect(Unit) { while (true) { delay(20_000); if (notes.isEmpty() && !loading && tab != FeedKind.FOLLOWING) tick++ } }
    LaunchedEffect(status.state) { if (status.state == NetState.ONLINE && notes.isEmpty() && !loading && loadedOnce && tab != FeedKind.FOLLOWING) tick++ }

    val canPost = identity?.kind != IdentityKind.PRIVATE
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(16.dp)) {
                OutlinedTextField(text, { text = it.take(2000) }, enabled = canPost && !posting, placeholder = { Text("Co nowego?") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 6)
                Spacer(Modifier.height(6.dp))
                identity?.let { id ->
                    Text(if (canPost) "Publikujesz jako: ${id.name} (${id.kind.label.lowercase()})" else "Tożsamość prywatna nie publikuje w sieci publicznej. Wpisy tylko dla obserwujących wymagają szyfrowania, którego jeszcze nie ma. Przełącz na publiczną lub anonimową w Profilu.",
                        fontSize = 12.sp, color = ShMuted)
                }
                Text("Wpis jest publiczny: serwery sieci mogą go odczytać. Tor ukrywa tylko Twój adres IP.", fontSize = 11.sp, color = ShMuted)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(info ?: if (status.state == NetState.CONNECTING) "Łączenie…" else "", fontSize = 12.sp, color = ShMuted, modifier = Modifier.weight(1f))
                    Button(enabled = canPost && !posting && text.isNotBlank() && identity != null, onClick = {
                        val id = identity ?: return@Button
                        posting = true
                        scope.launch {
                            try {
                                val p = repo.publishNote(id, text)
                                if (p.result.success) {
                                    text = ""; info = "Opublikowano."; notes = listOf(p.event) + notes; me = p.event.pubkey
                                    try { repo.ensureProfile(id); names = names + repo.profiles(listOf(me)) } catch (x: CancellationException) { throw x } catch (_: Exception) { }
                                }
                                else info = if (p.result.noConnection) "Sieć publiczna jest chwilowo niedostępna. Spróbuj za chwilę." else "Nie udało się opublikować. Spróbuj ponownie."
                            } catch (e: CancellationException) { throw e }
                            catch (e: IllegalArgumentException) { info = e.message }
                            catch (e: Exception) { info = "Nie udało się opublikować. Spróbuj ponownie." }
                            posting = false
                        }
                    }) { Text(if (posting) "Wysyłanie…" else "Opublikuj") }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(tagQuery, { tagQuery = it.take(40) }, singleLine = true, placeholder = { Text("Szukaj #hashtag") }, modifier = Modifier.fillMaxWidth(),
                    trailingIcon = { IconTap(Ic.Search, "Szukaj", ShMuted, 40.dp, 20.dp) {
                        val t = tagQuery.trim().removePrefix("#").lowercase()
                        if (t.length >= 2) { activeTag = t; tab = FeedKind.TAG; tick++ } else if (tab == FeedKind.TAG) { activeTag = ""; tab = FeedKind.SHYFR }
                    } })
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillTab("SHYFR", tab == FeedKind.SHYFR) { tab = FeedKind.SHYFR }
                    PillTab("Obserwowani", tab == FeedKind.FOLLOWING) { tab = FeedKind.FOLLOWING }
                    PillTab("Wszystko", tab == FeedKind.ALL) { if (tab != FeedKind.ALL) askAll = true }
                    PillTab("Zapisane", tab == FeedKind.SAVED) { tab = FeedKind.SAVED }
                    PillTab("Mój profil", false) { showProfile = true }
                    PillTab("Ukryci autorzy", false) { showHidden = true }
                    if (canPost) PillTab("Mój profil", false) { showProfile = true }
                    PillTab("Odśwież", false) { tick++ }
                }
            }
            HorizontalDivider(color = ShLine, thickness = 0.5.dp)
        }
        if (notes.isEmpty() && !loading) item {
            Text(if (tab == FeedKind.FOLLOWING) "Nikogo jeszcze nie obserwujesz. Wybierz „Obserwuj” przy wpisie w zakładce SHYFR." else if (tab == FeedKind.SAVED) "Nic jeszcze nie zapisano. Wybierz „Zapisz” przy wpisie; zapisane wpisy są tylko na tym telefonie." else if (tab == FeedKind.TAG) "Brak wpisów z tym hashtagiem." else "Brak wpisów do pokazania.", color = ShMuted, modifier = Modifier.padding(24.dp))
        }
        if (loading && notes.isEmpty()) item { Text("Wczytywanie…", color = ShMuted, modifier = Modifier.padding(24.dp)) }
        items(notes, key = { it.id }) { e ->
            NoteRow(e, names[e.pubkey]?.name?.ifBlank { null } ?: (e.pubkey.take(8) + "…"), reacts[e.id], e.pubkey == me, e.pubkey in follows,
                via[e.id]?.let { v -> names[v]?.name?.ifBlank { null } ?: (v.take(8) + "…") }, e.id in saved,
                onRepost = { scope.launch { try { val id = identity ?: return@launch; info = if (repo.repost(id, e).success) "Udostępniono." else "Nie udało się udostępnić. Spróbuj ponownie." } catch (x: CancellationException) { throw x } catch (_: Exception) { info = "Nie udało się udostępnić." } } },
                onSave = { identity?.let { id -> val now = repo.toggleSave(id, e); saved = if (now) saved + e.id else saved - e.id; if (tab == FeedKind.SAVED && !now) notes = notes.filter { it.id != e.id } } },
                onDelete = { deleteTarget = e }, onMore = { moreTarget = e },
                onLike = { scope.launch { try { val id = identity ?: return@launch; if (repo.react(id, e).success) reacts = reacts + (e.id to Reactions((reacts[e.id]?.count ?: 0) + 1, true)) } catch (x: CancellationException) { throw x } catch (_: Exception) { } } },
                onReply = { replyTarget = e },
                onFollow = { scope.launch { try { val id = identity ?: return@launch; val on = e.pubkey !in follows; repo.setFollow(id, e.pubkey, on); follows = if (on) follows + e.pubkey else follows - e.pubkey } catch (x: CancellationException) { throw x } catch (_: Exception) { } } })
        }
        if (canMore && notes.isNotEmpty()) item {
            TextButton(modifier = Modifier.fillMaxWidth(), enabled = !loading, onClick = {
                val id = identity ?: return@TextButton
                loading = true
                scope.launch {
                    try {
                        val page = repo.feed(tab, id, until = notes.last().createdAt - 1, tag = activeTag)
                        val known = notes.map { it.id }.toSet()
                        val fresh = page.notes.filter { it.id !in known }
                        notes = notes + fresh; canMore = fresh.size >= 5; enrich(fresh, id)
                    } catch (e: CancellationException) { throw e } catch (_: Exception) { info = "Nie udało się wczytać starszych wpisów." }
                    loading = false
                }
            }) { Text("Starsze wpisy") }
        }
    }

    if (showProfile) identity?.let { id ->
        ProfileDialog(repo, id, names[me]) { saved -> if (saved != null) names = names + (me to saved); showProfile = false }
    }
    deleteTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null }, title = { Text("Usunąć wpis?") },
            text = { Text("Wyślemy do serwerów sieci prośbę o usunięcie. Nie mają obowiązku jej spełnić, a kopie mogły już zostać zapisane przez innych.", fontSize = 14.sp) },
            confirmButton = {
                TextButton(onClick = {
                    deleteTarget = null
                    scope.launch {
                        try {
                            val id = identity ?: return@launch
                            if (repo.deleteNote(id, t).success) { notes = notes.filter { it.id != t.id }; info = "Wysłano prośbę o usunięcie." } else info = "Nie udało się usunąć. Spróbuj ponownie."
                        } catch (x: CancellationException) { throw x } catch (_: Exception) { info = "Nie udało się usunąć." }
                    }
                }) { Text("Usuń", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Anuluj") } }
        )
    }
    if (showProfile) identity?.let { id -> PublicProfileDialog(repo, id, me, canPost) { changed -> showProfile = false; if (changed) tick++ } }
    moreTarget?.let { t ->
        val author = names[t.pubkey]?.name?.ifBlank { null } ?: (t.pubkey.take(8) + "…")
        fun hide(rel: com.shyfr.app.social.Rel, msg: String) {
            moreTarget = null
            scope.launch {
                try { val id = identity ?: return@launch; repo.setHidden(id, t.pubkey, rel, true); notes = notes.filter { it.pubkey != t.pubkey }; info = msg }
                catch (x: CancellationException) { throw x } catch (_: Exception) { info = "Nie udało się zapisać." }
            }
        }
        AlertDialog(
            onDismissRequest = { moreTarget = null }, title = { Text(author, maxLines = 1) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { hide(com.shyfr.app.social.Rel.MUTE, "Autor wyciszony. Cofniesz to w „Ukryci autorzy”.") }) { Text("Wycisz autora") }
                    TextButton(onClick = { hide(com.shyfr.app.social.Rel.BLOCK, "Autor zablokowany. Cofniesz to w „Ukryci autorzy”.") }) { Text("Zablokuj autora") }
                    TextButton(onClick = { reportTarget = t; moreTarget = null }) { Text("Zgłoś wpis") }
                    Text("Wyciszenie i blokada działają tylko u Ciebie: autor się o nich nie dowie i nadal może pisać publicznie. Zgłoszenie jest publiczne i nie gwarantuje usunięcia wpisu.", fontSize = 12.sp, color = ShMuted)
                }
            },
            confirmButton = { TextButton(onClick = { moreTarget = null }) { Text("Zamknij") } }
        )
    }
    reportTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { reportTarget = null }, title = { Text("Powód zgłoszenia") },
            text = {
                Column {
                    ReportReason.entries.forEach { r ->
                        TextButton(onClick = {
                            reportTarget = null
                            scope.launch {
                                try { val id = identity ?: return@launch; info = if (repo.report(id, t, r).success) "Zgłoszenie wysłane." else "Nie udało się wysłać zgłoszenia." }
                                catch (x: CancellationException) { throw x } catch (_: Exception) { info = "Nie udało się wysłać zgłoszenia." }
                            }
                        }) { Text(r.label) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { reportTarget = null }) { Text("Anuluj") } }
        )
    }
    if (showHidden) identity?.let { id -> HiddenDialog(repo, id, names) { showHidden = false; tick++ } }
    if (askAll) AlertDialog(
        onDismissRequest = { askAll = false }, title = { Text("Strumień niefiltrowany") }, text = { Text(WARN_ALL, fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = { askAll = false; tab = FeedKind.ALL }) { Text("Pokaż") } },
        dismissButton = { TextButton(onClick = { askAll = false }) { Text("Anuluj") } }
    )
    replyTarget?.let { t -> identity?.let { id -> ReplyDialog(repo, id, t, names[t.pubkey]?.name ?: (t.pubkey.take(8) + "…"), canPost) { replyTarget = null } } }
}

@Composable
private fun NoteRow(e: NostrEvent, author: String, r: Reactions?, mine: Boolean, following: Boolean, viaName: String?, saved: Boolean, onLike: () -> Unit, onReply: () -> Unit, onFollow: () -> Unit, onRepost: () -> Unit, onSave: () -> Unit, onDelete: () -> Unit, onMore: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        if (viaName != null) Text("Udostępnił(a): $viaName", fontSize = 11.sp, color = ShMuted)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(author, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Text(fmtTime(e.createdAt * 1000), fontSize = 12.sp, color = ShMuted)
        }
        Spacer(Modifier.height(4.dp))
        Text(e.content, fontSize = 15.sp, maxLines = 14)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onLike, enabled = r?.mine != true) { Text("Lubię" + (r?.count?.takeIf { it > 0 }?.let { " $it" } ?: ""), fontSize = 13.sp, color = if (r?.mine == true) MaterialTheme.colorScheme.primary else ShMuted) }
            TextButton(onClick = onReply) { Text("Odpowiedz", fontSize = 13.sp, color = ShMuted) }
            TextButton(onClick = onRepost) { Text("Udostępnij", fontSize = 13.sp, color = ShMuted) }
            TextButton(onClick = onSave) { Text(if (saved) "Zapisano" else "Zapisz", fontSize = 13.sp, color = if (saved) MaterialTheme.colorScheme.primary else ShMuted) }
            if (!mine) TextButton(onClick = onFollow) { Text(if (following) "Obserwujesz" else "Obserwuj", fontSize = 13.sp, color = ShMuted) }
            if (mine) TextButton(onClick = onDelete) { Text("Usuń", fontSize = 13.sp, color = MaterialTheme.colorScheme.error) }
            if (!mine) TextButton(onClick = onMore) { Text("Więcej", fontSize = 13.sp, color = ShMuted) }
        }
    }
    HorizontalDivider(color = ShLine, thickness = 0.5.dp)
}

@Composable
private fun ReplyDialog(repo: NostrFeedRepo, id: SocialIdentity, note: NostrEvent, author: String, canPost: Boolean, onClose: () -> Unit) {
    var replies by remember { mutableStateOf<List<NostrEvent>?>(null) }
    var names by remember { mutableStateOf<Map<String, NostrProfile>>(emptyMap()) }
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(note.id) {
        try { val r = repo.replies(note, id); replies = r; names = repo.profiles(r.map { it.pubkey }) }
        catch (e: CancellationException) { throw e } catch (_: Exception) { replies = emptyList() }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Odpowiedzi do: $author", maxLines = 1) },
        text = {
            Column(Modifier.verticalScrollCompat(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(note.content, fontSize = 14.sp, color = ShMuted, maxLines = 4)
                HorizontalDivider(color = ShLine, thickness = 0.5.dp)
                val l = replies
                if (l == null) Text("Wczytywanie…", color = ShMuted)
                else if (l.isEmpty()) Text("Brak odpowiedzi.", color = ShMuted)
                else l.forEach { r -> Column { Text(names[r.pubkey]?.name?.ifBlank { null } ?: (r.pubkey.take(8) + "…"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text(r.content, fontSize = 14.sp) } }
                if (canPost) OutlinedTextField(text, { text = it.take(2000) }, placeholder = { Text("Twoja odpowiedź") }, enabled = !busy, modifier = Modifier.fillMaxWidth())
                msg?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            if (canPost) TextButton(enabled = !busy && text.isNotBlank(), onClick = {
                busy = true; msg = null
                scope.launch {
                    try {
                        val p = repo.publishNote(id, text, note)
                        if (p.result.success) { replies = (replies ?: emptyList()) + p.event; text = "" } else msg = "Nie udało się wysłać odpowiedzi. Spróbuj ponownie."
                    } catch (e: CancellationException) { throw e } catch (_: Exception) { msg = "Nie udało się wysłać odpowiedzi." }
                    busy = false
                }
            }) { Text("Odpowiedz") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Zamknij") } }
    )
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier = this.then(Modifier.verticalScroll(rememberScrollState()))


/** Podgląd stanu sieci publicznej dla programisty: który serwer jest połączony i z jakiego powodu pozostałe nie. */
@Composable
fun NostrDiagDialog(ctx: Context, onClose: () -> Unit) {
    val mgr = remember { NostrHub.acquire(ctx) }
    DisposableEffect(Unit) { onDispose { NostrHub.release(ctx) } }
    val status by mgr.status.collectAsState()
    var rows by remember { mutableStateOf(mgr.diagnostics()) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { while (true) { rows = mgr.diagnostics(); delay(2_000) } }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Sieć publiczna: ${status.connected} połączonych") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(when (status.state) { NetState.ONLINE -> "Stan: połączono"; NetState.CONNECTING -> "Stan: łączenie…"; NetState.OFFLINE -> "Stan: brak połączenia" }, fontSize = 13.sp)
                rows.forEach { r ->
                    Column {
                        Text(r.url.removePrefix("wss://"), fontSize = 13.sp, fontWeight = if (r.connected) FontWeight.SemiBold else FontWeight.Normal)
                        Text(when {
                            r.connected -> "połączony"
                            r.banned -> "pominięty: ${r.lastError}"
                            r.failures > 0 -> "błąd (${r.failures}): ${r.lastError}, kolejna próba za ${r.retryInMs / 1000} s"
                            else -> "jeszcze nie próbowano"
                        }, fontSize = 11.sp, color = ShMuted)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { scope.launch { mgr.networkChanged(); runCatching { mgr.ensure() } } }) { Text("Połącz od nowa") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Zamknij") } }
    )
}


/** Publiczna nazwa i opis tożsamości w sieci publicznej (Nostr, kind 0). Są widoczne dla wszystkich. */
@Composable
private fun ProfileDialog(repo: NostrFeedRepo, id: SocialIdentity, current: NostrProfile?, onClose: (NostrProfile?) -> Unit) {
    var name by remember { mutableStateOf(current?.name?.ifBlank { null } ?: id.name) }
    var about by remember { mutableStateOf(current?.about ?: "") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onClose(null) },
        title = { Text("Mój profil publiczny") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Tożsamość: ${id.name} (${id.kind.label.lowercase()}). Nazwa i opis są publiczne, a serwery sieci mogą je zachować.", fontSize = 12.sp, color = ShMuted)
                OutlinedTextField(name, { name = it.take(40) }, label = { Text("Nazwa") }, singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(about, { about = it.take(300) }, label = { Text("Opis") }, enabled = !busy, modifier = Modifier.fillMaxWidth())
                msg?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && name.isNotBlank(), onClick = {
                busy = true; msg = null
                scope.launch {
                    try {
                        if (repo.setProfile(id, name, about).success) onClose(NostrProfile(name.trim(), about.trim())) else msg = "Nie udało się zapisać profilu. Spróbuj ponownie."
                    } catch (x: CancellationException) { throw x } catch (_: Exception) { msg = "Nie udało się zapisać profilu." }
                    busy = false
                }
            }) { Text("Zapisz") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = { onClose(null) }) { Text("Anuluj") } }
    )
}


/** Profil publiczny aktywnej tożsamości (nazwa i opis). Publikowany w sieci dopiero po Twoim potwierdzeniu. */
@Composable
private fun PublicProfileDialog(repo: NostrFeedRepo, id: SocialIdentity, me: String, canPost: Boolean, onClose: (changed: Boolean) -> Unit) {
    var name by remember(id.id) { mutableStateOf(id.name) }
    var about by remember(id.id) { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(me) {
        if (me.isNotEmpty()) try { repo.profiles(listOf(me))[me]?.let { name = it.name.ifBlank { name }; about = it.about } } catch (e: CancellationException) { throw e } catch (_: Exception) { }
    }
    AlertDialog(
        onDismissRequest = { if (!busy) onClose(false) },
        title = { Text("Profil publiczny: ${id.kind.label.lowercase()}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!canPost) Text("Tożsamość prywatna nie ma profilu w sieci publicznej. Przełącz na publiczną lub anonimową w Profilu.", fontSize = 13.sp, color = ShMuted)
                OutlinedTextField(name, { name = it.take(40) }, label = { Text(if (id.kind == IdentityKind.ANON) "Pseudonim" else "Nazwa") }, singleLine = true, enabled = canPost && !busy, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(about, { about = it.take(300) }, label = { Text("Opis") }, enabled = canPost && !busy, modifier = Modifier.fillMaxWidth())
                Text(if (id.kind == IdentityKind.ANON) "Profil anonimowy ma własny klucz i nie wskazuje Twoich innych tożsamości. Wszystko, co tu wpiszesz, jest publiczne." else "Nazwa i opis są publiczne: serwery sieci mogą je odczytać.", fontSize = 12.sp, color = ShMuted)
                msg?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = canPost && !busy && name.isNotBlank(), onClick = {
                busy = true; msg = null
                scope.launch {
                    try { if (repo.setProfile(id, name, about).success) onClose(true) else msg = "Nie udało się zapisać profilu. Spróbuj ponownie." }
                    catch (e: CancellationException) { throw e } catch (_: Exception) { msg = "Nie udało się zapisać profilu." }
                    busy = false
                }
            }) { Text(if (busy) "Zapisywanie…" else "Opublikuj profil") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = { onClose(false) }) { Text("Anuluj") } }
    )
}


/** Lista wyciszonych i zablokowanych autorów tej tożsamości, z możliwością cofnięcia. */
@Composable
private fun HiddenDialog(repo: NostrFeedRepo, id: SocialIdentity, names: Map<String, NostrProfile>, onClose: () -> Unit) {
    var rows by remember { mutableStateOf<List<Pair<String, com.shyfr.app.social.Rel>>?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(tick) { rows = try { repo.hidden(id) } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() } }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Ukryci autorzy") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                val l = rows
                if (l == null) Text("Wczytywanie…", color = ShMuted)
                else if (l.isEmpty()) Text("Nikogo nie wyciszono ani nie zablokowano.", color = ShMuted)
                else l.forEach { (pub, rel) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(names[pub]?.name?.ifBlank { null } ?: (pub.take(12) + "…"), fontSize = 14.sp, maxLines = 1)
                            Text(if (rel == com.shyfr.app.social.Rel.BLOCK) "zablokowany" else "wyciszony", fontSize = 11.sp, color = ShMuted)
                        }
                        TextButton(onClick = { scope.launch { try { repo.setHidden(id, pub, rel, false); tick++ } catch (e: CancellationException) { throw e } catch (_: Exception) { } } }) { Text("Cofnij") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Zamknij") } }
    )
}
