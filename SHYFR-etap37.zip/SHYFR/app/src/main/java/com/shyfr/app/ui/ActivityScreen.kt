package com.shyfr.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.Deeplink
import com.shyfr.app.feed.ActivityEvent
import com.shyfr.app.feed.Incoming
import com.shyfr.app.feed.Outgoing
import com.shyfr.app.feed.PublicRepo
import com.shyfr.app.session.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.shape.CircleShape
import com.shyfr.app.nostr.NostrFeedRepo
import com.shyfr.app.nostr.NostrHub
import com.shyfr.app.nostr.NostrNotif
import com.shyfr.app.nostr.NostrProfile
import com.shyfr.app.nostr.NotifType
import com.shyfr.app.social.IdentityKind
import com.shyfr.app.social.SocialIdentity
import com.shyfr.app.social.SocialState
import com.shyfr.app.social.SocialStore

/**
 * Aktywność: prośby o kontakt (tylko za zgodą autora, akceptujesz każdą z osobna), odpowiedzi na Twoje prośby
 * oraz zdarzenia przy Twoich wpisach (reakcje, komentarze, reposty, zgłoszenia dla moderatorów). Dane pochodzą z przekaźnika.
 */
@Composable
private fun CommunityActivity(ctx: Context, onOpenSettings: () -> Unit) {
    val repo = remember { PublicRepo(ctx) }
    val scope = rememberCoroutineScope()
    val configured = repo.relayConfigured()
    val seen = remember { Prefs.activitySeen(ctx) }
    var tick by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var incoming by remember { mutableStateOf<List<Incoming>>(emptyList()) }
    var outgoing by remember { mutableStateOf<List<Outgoing>>(emptyList()) }
    var events by remember { mutableStateOf<List<ActivityEvent>>(emptyList()) }
    var failed by remember { mutableIntStateOf(0) }
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    LaunchedEffect(configured, tick) {
        if (!configured) return@LaunchedEffect
        loading = true; error = null
        try {
            val s = repo.activitySnapshot(0L)
            incoming = s.incoming; outgoing = s.outgoing; events = s.events; failed = s.failed
        } catch (e: Exception) { error = e.message ?: "Błąd sieci" }
        loading = false
    }
    DisposableEffect(Unit) { onDispose { Prefs.setActivitySeen(ctx, System.currentTimeMillis()); com.shyfr.app.net.NodeRuntime.activityUnread.value = 0 } }

    fun act(ok: String, block: suspend () -> Unit) {
        scope.launch { try { block(); toast(ok); tick++ } catch (e: Exception) { toast(e.message ?: "Błąd") } }
    }

    when {
        !configured -> EmptyState("Aktywność jest niedostępna", "Ta wersja aplikacji nie ma jeszcze serwera społeczności, więc nie ma czego pokazać.")
        loading && incoming.isEmpty() && outgoing.isEmpty() && events.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        error != null -> EmptyState("Nie udało się wczytać", error ?: "", "Ponów") { tick++ }
        incoming.isEmpty() && outgoing.isEmpty() && events.isEmpty() -> EmptyState("Cisza", "Tu zobaczysz prośby o kontakt, reakcje i komentarze przy swoich wpisach. Prośby przyjmujesz tylko, jeśli włączysz to w ustawieniach społeczności.")
        else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp, top = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (failed > 0) item { Text("Nie udało się odświeżyć $failed społeczności.", fontSize = 12.sp, color = ShMuted) }
            if (incoming.isNotEmpty()) item { Text("Prośby o kontakt", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = ShMuted) }
            items(incoming, key = { "i" + it.id }) { r ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(ShSurface.copy(alpha = .85f)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Anonimowa prośba w „${r.community}”", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text(r.greeting, fontSize = 14.sp)
                    Text(fmtTime(r.ts), fontSize = 11.sp, color = ShMuted)
                    Text("Akceptacja utworzy jednorazowe zaproszenie do prywatnego czatu P2P przez Tor. Rozmówca nie pozna Twojego pseudonimu z tej społeczności.", fontSize = 11.sp, color = ShMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { act("Wysłano zaproszenie do czatu") { repo.answerContact(r, true) } }) { Text("Akceptuj") }
                        TextButton(onClick = { act("Odrzucono") { repo.answerContact(r, false) } }) { Text("Odrzuć") }
                        TextButton(onClick = { act("Zablokowano") { repo.blockRequester(r) } }) { Text("Zablokuj", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            if (outgoing.isNotEmpty()) item { Text("Twoje prośby", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = ShMuted) }
            items(outgoing, key = { "o" + it.id }) { o ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(ShSurface.copy(alpha = .85f)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("„${o.community}” · " + when (o.status) { "accepted" -> "zaakceptowana"; "rejected" -> "odrzucona"; else -> "oczekuje na decyzję" }, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text(fmtTime(o.ts), fontSize = 11.sp, color = ShMuted)
                    if (o.status == "accepted") {
                        if (o.invite != null) TextButton(onClick = {
                            scope.launch { repo.markRequestHandled(o.id); Deeplink.pending.value = o.invite }
                        }) { Text("Dołącz do czatu") }
                        else Text("Zaakceptowano, ale nie można odczytać zaproszenia. Wyślij prośbę ponownie.", fontSize = 12.sp, color = ShMuted)
                    }
                    if (o.status == "rejected") TextButton(onClick = { scope.launch { repo.markRequestHandled(o.id); tick++ } }) { Text("Ukryj") }
                }
            }
            if (events.isNotEmpty()) item { Text("Przy Twoich wpisach", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = ShMuted) }
            items(events) { e ->
                val fresh = e.ts > seen
                val line = when (e.type) {
                    "reaction" -> "Reakcja ${e.emoji} na Twój wpis"
                    "comment" -> "Komentarz: " + (if (e.nick.isNotBlank()) e.nick else "Anonimowy uczestnik") + ": " + e.text
                    "repost" -> "Ktoś udostępnił Twój wpis dalej"
                    "quote" -> "Cytat Twojego wpisu: " + e.text
                    "report" -> "Zgłoszenie do moderacji: " + e.reason.ifBlank { "(bez powodu)" }
                    else -> e.type
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (fresh) ShSurfaceHi.copy(alpha = .9f) else ShSurface.copy(alpha = .7f)).padding(12.dp)) {
                    Text(line, fontSize = 14.sp)
                    Text("${e.community} · ${fmtTime(e.ts)}", fontSize = 11.sp, color = ShMuted)
                }
            }
        }
    }
}


/** Aktywność: powiadomienia z sieci publicznej albo z Twoich społeczności. */
@Composable
fun ActivityScreen(ctx: Context, onOpenSettings: () -> Unit) {
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillTab("Sieć publiczna", mode == 0) { mode = 0 }
            PillTab("Społeczności", mode == 1) { mode = 1 }
        }
        HorizontalDivider(color = ShLine, thickness = 0.5.dp)
        Box(Modifier.weight(1f).fillMaxWidth()) { if (mode == 0) PublicActivity(ctx) else CommunityActivity(ctx, onOpenSettings) }
    }
}

/** Powiadomienia z publicznej sieci dla aktywnej tożsamości. Sprawdzane po otwarciu zakładki; nie ma powiadomień push w tle. */
@Composable
private fun PublicActivity(ctx: Context) {
    val mgr = remember { NostrHub.acquire(ctx) }
    DisposableEffect(Unit) { onDispose { NostrHub.release(ctx) } }
    val repo = remember { NostrFeedRepo(ctx, mgr) }
    val activeId by SocialState.active.collectAsState()
    var identity by remember { mutableStateOf<SocialIdentity?>(null) }
    var items by remember { mutableStateOf<List<NostrNotif>?>(null) }
    var names by remember { mutableStateOf<Map<String, NostrProfile>>(emptyMap()) }
    var seenAtOpen by remember { mutableLongStateOf(0L) }
    var err by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(activeId, tick) {
        err = null
        try {
            val id = withContext(Dispatchers.IO) { SocialStore(ctx).ensureDefaults("") }
            identity = id
            if (id.kind == IdentityKind.PRIVATE) { items = emptyList(); return@LaunchedEffect }
            seenAtOpen = repo.notifSeen(id)
            val list = repo.notifications(id)
            items = list
            names = repo.profiles(list.map { it.actor })
            repo.markNotifsSeen(id, list)
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { err = "Nie udało się wczytać powiadomień. Spróbuj ponownie."; items = items ?: emptyList() }
    }

    val list = items
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(16.dp)) {
                Text(if (identity?.kind == IdentityKind.PRIVATE) "Tożsamość prywatna nie bierze udziału w sieci publicznej, więc nie ma tu powiadomień. Przełącz tożsamość w Profilu."
                else "Powiadomienia z ostatnich 14 dni. Nowe sprawdzamy po otwarciu tej zakładki; w tle nie przychodzą żadne powiadomienia.", fontSize = 12.sp, color = ShMuted)
                err?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
                PillTab("Odśwież", false) { tick++ }
            }
            HorizontalDivider(color = ShLine, thickness = 0.5.dp)
        }
        if (list == null) item { Text("Wczytywanie…", color = ShMuted, modifier = Modifier.padding(24.dp)) }
        else if (list.isEmpty() && identity?.kind != IdentityKind.PRIVATE) item { Text("Brak nowych powiadomień.", color = ShMuted, modifier = Modifier.padding(24.dp)) }
        else items(list, key = { it.eventId }) { n ->
            val who = names[n.actor]?.name?.ifBlank { null } ?: (n.actor.take(8) + "…")
            val text = when (n.type) {
                NotifType.REPLY -> "Odpowiedź od $who: ${n.text}"
                NotifType.REACTION -> "Reakcja od $who: ${n.text}"
                NotifType.MENTION -> "Wzmianka od $who: ${n.text}"
                NotifType.FOLLOW -> "Nowy obserwujący: $who"
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.padding(top = 6.dp, end = 12.dp).size(8.dp).clip(CircleShape).background(if (n.ts > seenAtOpen) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent))
                Column {
                    Text(text, fontSize = 14.sp, maxLines = 3)
                    Text(fmtTime(n.ts * 1000), fontSize = 11.sp, color = ShMuted)
                }
            }
            HorizontalDivider(color = ShLine, thickness = 0.5.dp)
        }
    }
}
