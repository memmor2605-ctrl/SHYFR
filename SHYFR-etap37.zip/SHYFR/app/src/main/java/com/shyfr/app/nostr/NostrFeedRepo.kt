package com.shyfr.app.nostr

import android.content.Context
import com.shyfr.app.session.Session
import com.shyfr.app.social.IdentityKind
import com.shyfr.app.social.Rel
import com.shyfr.app.social.SocialIdentity
import com.shyfr.app.social.SocialStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

enum class FeedKind { SHYFR, FOLLOWING, ALL, TAG, SAVED }
data class NostrProfile(val name: String, val about: String)
data class FeedPage(val notes: List<NostrEvent>, val asked: Int, val answered: Int, val via: Map<String, String> = emptyMap())
data class Reactions(val count: Int, val mine: Boolean)
data class Published(val event: NostrEvent, val result: PublishResult)

/**
 * Publiczny feed na Nostr. Wpisy są PUBLICZNE: operatorzy przekaźników widzą treść i metadane, a Tor ukrywa tylko adres IP.
 * Każda tożsamość SHYFR ma własny klucz Nostr (wyprowadzany z klucza konta), więc anonimowa nie łączy się z publiczną.
 * Obserwowania wpisuje się do listy publicznej (NIP-02) tylko dla tożsamości publicznej; dla prywatnej i anonimowej lista zostaje lokalna.
 */
class NostrFeedRepo(private val ctx: Context, private val mgr: RelayManager) {
    private val store = SocialStore(ctx)
    private val profiles = HashMap<String, NostrProfile>()
    private val sp = ctx.getSharedPreferences("shyfr_nostr", Context.MODE_PRIVATE)

    private fun secret(id: SocialIdentity): ByteArray = NostrKeys.secretFor(Session.get() ?: error("Konto zablokowane"), id.kind.code, id.idx)
    suspend fun pubOf(id: SocialIdentity): String = withContext(Dispatchers.Default) { NostrKeys.publicHex(secret(id)) }

    private val hashtag = Regex("(?<![\\p{L}\\p{N}_])#([\\p{L}\\p{N}_]{2,40})")

    private suspend fun sign(id: SocialIdentity, kind: Int, tags: List<List<String>>, content: String): NostrEvent =
        withContext(Dispatchers.Default) { NostrEvent.create(secret(id), kind, tags, content) }

    /** Reguły NIP-10: odpowiedź wskazuje wątek (root) i wpis, na który odpowiada (reply). */
    private fun replyTags(to: NostrEvent): List<List<String>> {
        val root = to.tags.firstOrNull { it.size >= 4 && it[0] == "e" && it[3] == "root" }?.get(1)
        return if (root == null) listOf(listOf("e", to.id, "", "root"), listOf("p", to.pubkey))
        else listOf(listOf("e", root, "", "root"), listOf("e", to.id, "", "reply"), listOf("p", to.pubkey))
    }

    suspend fun publishNote(id: SocialIdentity, text: String, replyTo: NostrEvent? = null): Published {
        val body = text.trim()
        require(body.isNotEmpty() && body.length <= 2000) { "Wpis ma od 1 do 2000 znaków." }
        val tags = ArrayList<List<String>>()
        tags += listOf("t", "shyfr"); tags += listOf("client", "SHYFR")
        hashtag.findAll(body).map { it.groupValues[1].lowercase() }.distinct().filter { it != "shyfr" }.take(10).forEach { tags += listOf("t", it) }
        if (replyTo != null) tags += replyTags(replyTo)
        val ev = sign(id, 1, tags, body)
        return Published(ev, mgr.publish(ev))
    }

    suspend fun feed(kind: FeedKind, id: SocialIdentity, until: Long? = null, limit: Int = 40, tag: String = ""): FeedPage {
        if (kind == FeedKind.SAVED) return FeedPage(savedEvents(id), 0, 0)
        if (kind == FeedKind.TAG && tag.isBlank()) return FeedPage(emptyList(), 0, 0)
        val base = when (kind) {
            FeedKind.TAG -> Filter(kinds = listOf(1), tags = mapOf("t" to listOf(tag)), until = until, limit = limit)
            FeedKind.SAVED -> error("obsłużone wyżej")
            FeedKind.SHYFR -> Filter(kinds = listOf(1), tags = mapOf("t" to listOf("shyfr")), until = until, limit = limit)
            FeedKind.ALL -> Filter(kinds = listOf(1, 6), until = until, limit = limit)
            FeedKind.FOLLOWING -> {
                val authors = withContext(Dispatchers.IO) { store.peers(id.id, Rel.FOLLOW) }.take(200)
                if (authors.isEmpty()) return FeedPage(emptyList(), 0, 0)
                Filter(kinds = listOf(1, 6), authors = authors, until = until, limit = limit)
            }
        }
        val r = mgr.query(listOf(base))
        val hidden = withContext(Dispatchers.IO) { (store.peers(id.id, Rel.BLOCK) + store.peers(id.id, Rel.MUTE)).toSet() }
        val flat = NostrReposts.flatten(r.events)
        val notes = flat.notes.filter { e -> e.pubkey !in hidden && e.tags.none { it.firstOrNull() == "e" } }   // tylko wpisy główne, bez odpowiedzi
        return FeedPage(notes, r.asked, r.answered, flat.via.filterKeys { k -> notes.any { it.id == k } })
    }

    suspend fun replies(note: NostrEvent, id: SocialIdentity? = null): List<NostrEvent> {
        val hidden = if (id == null) emptySet() else withContext(Dispatchers.IO) { (store.peers(id.id, Rel.BLOCK) + store.peers(id.id, Rel.MUTE)).toSet() }
        return mgr.query(listOf(Filter(kinds = listOf(1), tags = mapOf("e" to listOf(note.id)), limit = 100))).events
            .filter { e -> e.pubkey !in hidden && e.tags.any { it.size >= 2 && it[0] == "e" && it[1] == note.id } }.sortedBy { it.createdAt }
    }

    suspend fun profiles(pubs: Collection<String>): Map<String, NostrProfile> {
        val need = pubs.filter { it !in profiles }.distinct().take(100)
        if (need.isNotEmpty()) {
            val ev = mgr.query(listOf(Filter(kinds = listOf(0), authors = need, limit = need.size * 2))).events
            ev.groupBy { it.pubkey }.forEach { (pub, list) ->
                val newest = list.maxByOrNull { it.createdAt } ?: return@forEach
                runCatching { JSONObject(newest.content) }.getOrNull()?.let { j ->
                    profiles[pub] = NostrProfile(j.optString("name").take(40), j.optString("about").take(300))
                }
            }
        }
        return pubs.mapNotNull { p -> profiles[p]?.let { p to it } }.toMap()
    }

    suspend fun setProfile(id: SocialIdentity, name: String, about: String): PublishResult {
        val content = JSONObject().put("name", name.trim().take(40)).put("about", about.trim().take(300)).toString()
        return mgr.publish(sign(id, 0, emptyList(), content)).also {
            if (it.success) { profiles[pubOf(id)] = NostrProfile(name.trim(), about.trim()); sp.edit().putBoolean("profile_set_" + id.id, true).apply() }
        }
    }

    /** Po pierwszym wpisie publikuje profil z nazwą tożsamości, żeby inni nie widzieli samego skrótu klucza. Nazwa jest ta sama, którą widać w oknie pisania. */
    suspend fun ensureProfile(id: SocialIdentity) {
        if (sp.getBoolean("profile_set_" + id.id, false)) return
        setProfile(id, id.name, "")
    }

    suspend fun reactions(ids: List<String>, me: String): Map<String, Reactions> {
        if (ids.isEmpty()) return emptyMap()
        val ev = mgr.query(listOf(Filter(kinds = listOf(7), tags = mapOf("e" to ids.take(100)), limit = 500))).events.filter { it.content != "-" }
        val out = HashMap<String, Reactions>()
        for (id in ids) {
            val mine = ev.filter { e -> e.tags.any { it.size >= 2 && it[0] == "e" && it[1] == id } }
            out[id] = Reactions(mine.distinctBy { it.pubkey }.size, mine.any { it.pubkey == me })
        }
        return out
    }

    suspend fun react(id: SocialIdentity, note: NostrEvent): PublishResult =
        mgr.publish(sign(id, 7, listOf(listOf("e", note.id), listOf("p", note.pubkey)), "+"))

    fun notifSeen(id: SocialIdentity): Long = sp.getLong("seen_" + id.id, 0L)

    /** Powiadomienia z ostatnich 14 dni (odpowiedzi, reakcje, wzmianki, nowi obserwujący), bez zablokowanych i wyciszonych. */
    suspend fun notifications(id: SocialIdentity): List<NostrNotif> {
        val me = pubOf(id)
        val since = System.currentTimeMillis() / 1000 - 14 * 86_400
        val r = mgr.query(listOf(Filter(kinds = listOf(1, 7, 3), tags = mapOf("p" to listOf(me)), since = since, limit = 100)))
        val known = sp.getStringSet("followers_" + id.id, emptySet()) ?: emptySet()
        val hidden = withContext(Dispatchers.IO) { (store.peers(id.id, Rel.BLOCK) + store.peers(id.id, Rel.MUTE)).toSet() }
        return NostrNotifs.classify(r.events, me).filter { it.actor !in hidden && (it.type != NotifType.FOLLOW || it.actor !in known) }
    }

    /** Oznacza wszystko jako przeczytane i zapamiętuje obserwujących, żeby ich nie ogłaszać ponownie po aktualizacji ich listy. */
    fun markNotifsSeen(id: SocialIdentity, items: List<NostrNotif>) {
        val ts = maxOf(items.maxOfOrNull { it.ts } ?: 0L, notifSeen(id))
        val known = (sp.getStringSet("followers_" + id.id, emptySet()) ?: emptySet()) + items.filter { it.type == NotifType.FOLLOW }.map { it.actor }
        sp.edit().putLong("seen_" + id.id, ts).putStringSet("followers_" + id.id, known.toSet()).apply()
    }

    /** Udostępnienie cudzego wpisu (NIP-18). Treść zawiera oryginał, żeby dało się go pokazać bez dodatkowego zapytania. */
    suspend fun repost(id: SocialIdentity, note: NostrEvent): PublishResult =
        mgr.publish(sign(id, 6, listOf(listOf("e", note.id, ""), listOf("p", note.pubkey)), note.toWireJson()))

    /** Prośba o usunięcie własnego wpisu (NIP-09). Serwery nie mają obowiązku jej spełnić, a kopie mogły już zostać zapisane. */
    suspend fun deleteNote(id: SocialIdentity, note: NostrEvent): PublishResult {
        require(note.pubkey == pubOf(id)) { "Można usuwać tylko własne wpisy." }
        return mgr.publish(sign(id, 5, listOf(listOf("e", note.id), listOf("k", "1")), ""))
    }

    private fun savedKey(id: SocialIdentity) = "saved_" + id.id
    fun savedEvents(id: SocialIdentity): List<NostrEvent> =
        (sp.getStringSet(savedKey(id), emptySet()) ?: emptySet()).mapNotNull { j -> runCatching { NostrWire.eventFrom(JSONObject(j)) }.getOrNull() }.sortedByDescending { it.createdAt }
    fun savedIds(id: SocialIdentity): Set<String> = savedEvents(id).map { it.id }.toSet()

    /** Zapisane wpisy są tylko lokalne (nigdzie nie są publikowane). Zwraca nowy stan. */
    fun toggleSave(id: SocialIdentity, note: NostrEvent): Boolean {
        val cur = (sp.getStringSet(savedKey(id), emptySet()) ?: emptySet()).toMutableSet()
        val existing = cur.firstOrNull { j -> runCatching { JSONObject(j).getString("id") == note.id }.getOrDefault(false) }
        val now = existing == null
        if (existing != null) cur.remove(existing) else { cur.add(note.toWireJson()); if (cur.size > 200) cur.remove(cur.minByOrNull { j -> runCatching { JSONObject(j).getLong("created_at") }.getOrDefault(0L) }!!) }
        sp.edit().putStringSet(savedKey(id), cur).apply()
        return now
    }

    /** Wyciszenie i blokada są wyłącznie lokalne: ukrywają autora u Ciebie, a autor się o tym nie dowiaduje i nadal może pisać publicznie. */
    suspend fun setHidden(id: SocialIdentity, pub: String, rel: Rel, on: Boolean) {
        require(rel == Rel.BLOCK || rel == Rel.MUTE)
        withContext(Dispatchers.IO) { store.setRel(id.id, pub, rel, on) }
    }

    /** Ukryci autorzy tej tożsamości: para (klucz, relacja). */
    suspend fun hidden(id: SocialIdentity): List<Pair<String, Rel>> = withContext(Dispatchers.IO) {
        store.peers(id.id, Rel.BLOCK).map { it to Rel.BLOCK } + store.peers(id.id, Rel.MUTE).map { it to Rel.MUTE }
    }

    /** Zgłoszenie PUBLICZNE (NIP-56): widzą je serwery sieci i inni, a usunięcie treści nie jest gwarantowane. */
    suspend fun report(id: SocialIdentity, note: NostrEvent, reason: ReportReason): PublishResult =
        mgr.publish(sign(id, 1984, NostrReports.tags(note, reason), ""))

    fun isFollowing(id: SocialIdentity, pub: String) = store.has(id.id, pub, Rel.FOLLOW)

    /** Obserwowanie zapisuje się lokalnie; dla tożsamości publicznej także na liście publicznej (NIP-02). */
    suspend fun setFollow(id: SocialIdentity, pub: String, on: Boolean): PublishResult? {
        withContext(Dispatchers.IO) { store.setRel(id.id, pub, Rel.FOLLOW, on) }
        if (id.kind != IdentityKind.PUBLIC) return null
        val all = withContext(Dispatchers.IO) { store.peers(id.id, Rel.FOLLOW) }
        return mgr.publish(sign(id, 3, all.map { listOf("p", it) }, ""))
    }
}
