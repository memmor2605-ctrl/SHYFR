package com.shyfr.app.nostr

import org.json.JSONObject

/** Udostępnienia (NIP-18, kind 6): treść zawiera oryginalne zdarzenie. Czyste funkcje, bez sieci. */
object NostrReposts {
    /** Oryginał z udostępnienia albo null, gdy to nie udostępnienie, zawartość jest błędna lub nie zgadza się z tagiem „e”. */
    fun unwrap(e: NostrEvent): NostrEvent? {
        if (e.kind != 6) return null
        val inner = try { NostrWire.eventFrom(JSONObject(e.content)) } catch (x: Exception) { null } ?: return null
        if (inner.kind != 1 || inner.id !in e.tagValues("e") || !inner.isValid()) return null   // podrobionego oryginału nie pokazujemy
        return inner
    }

    class Flat(val notes: List<NostrEvent>, val via: Map<String, String>)

    /** Zwykłe wpisy i rozpakowane udostępnienia w jednej liście, bez duplikatów, najnowsza aktywność pierwsza. via: id wpisu -> autor udostępnienia. */
    fun flatten(events: List<NostrEvent>): Flat {
        val best = LinkedHashMap<String, Pair<NostrEvent, Long>>()
        val via = HashMap<String, String>()
        for (e in events) {
            val orig = if (e.kind == 6) unwrap(e) else e.takeIf { it.kind == 1 }
            if (orig == null) continue
            val prev = best[orig.id]
            if (prev == null || e.createdAt > prev.second) best[orig.id] = orig to e.createdAt
            if (e.kind == 6) via.putIfAbsent(orig.id, e.pubkey)
        }
        // wpis widoczny także samodzielnie nie dostaje dopisku „udostępnił”
        events.filter { it.kind == 1 }.forEach { via.remove(it.id) }
        return Flat(best.values.sortedByDescending { it.second }.map { it.first }, via)
    }
}
