package com.shyfr.app.net

/**
 * Stany wiadomości wychodzącej. „Dostarczono" znaczy WYŁĄCZNIE, że urządzenie odbiorcy potwierdziło zapis (ACK).
 * Wiadomość przyjęta tylko przez skrzynkę na serwerze ma osobny stan [ON_SERVER] i nie jest pokazywana jako dostarczona.
 */
object Delivery {
    const val SENDING = 0     // w kolejce na tym telefonie
    const val DELIVERED = 1   // urządzenie odbiorcy potwierdziło odbiór
    const val FAILED = 2      // odbiorca odrzucił ramkę wielokrotnie
    const val READ = 3        // odbiorca przeczytał (potwierdzenie przeczytania)
    const val ON_SERVER = 4   // przyjęta przez serwer (skrzynka), brak potwierdzenia od odbiorcy

    /** Po zapisie w skrzynce: tylko wiadomość, która dotąd czekała, przechodzi na „na serwerze". */
    fun afterMailboxAccept(current: Int) = if (current == SENDING) ON_SERVER else current
    /** Po ACK od odbiorcy: nigdy nie cofamy „przeczytano". */
    fun afterDirectAck(current: Int) = if (current == READ) READ else DELIVERED
    /** Po potwierdzeniu przeczytania: obejmuje też wiadomości czekające na serwerze. */
    fun afterReadReceipt(current: Int) = if (current == SENDING || current == DELIVERED || current == ON_SERVER) READ else current
    /** Wiadomość można jeszcze cofnąć lokalnie tylko, gdy nigdzie nie wyszła. */
    fun canRetractLocally(current: Int) = current == SENDING || current == FAILED

    /** Ten sam warunek w SQL, żeby baza i testy używały jednej definicji. */
    const val SQL_BEFORE_READ = "status IN (0,1,4)"

    fun label(status: Int) = when (status) {
        SENDING -> "Wysyłanie"; DELIVERED -> "Dostarczono"; FAILED -> "Nie dostarczono"; READ -> "Przeczytano"
        ON_SERVER -> "Na serwerze, czeka na odbiorcę"; else -> ""
    }
}
