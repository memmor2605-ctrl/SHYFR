package com.shyfr.app.ui

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shyfr.app.net.Messenger
import com.shyfr.app.vault.Profile
import com.shyfr.app.vault.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ProfileScreen(ctx: Context) {
    var nick by remember { mutableStateOf("") }
    var about by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("") }
    var color by remember { mutableIntStateOf(0) }
    var photo by remember { mutableStateOf<ByteArray?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            runCatching {
                val st = Store(ctx)
                val p = st.profile()
                nick = p.nick; about = p.about; emoji = p.emoji; color = p.color
                photo = st.ownAvatar()
            }
        }
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            runCatching { Attachments.avatarJpeg(ctx, uri) }
                .onSuccess { photo = it; msg = null }
                .onFailure { msg = it.message ?: "Nie udało się wczytać zdjęcia." }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IdentityChip(ctx)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillTab("Komunikator", tab == 0) { tab = 0 }
            PillTab("Obserwowanie", tab == 1) { tab = 1 }
        }
        Spacer(Modifier.height(16.dp))
        if (tab == 1) { SocialHub(ctx); return@Column }
        Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large, color = ShSurface, tonalElevation = 1.dp) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Avatar(nick, color, emoji, 96.dp, photo)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pickPhoto.launch("image/*") }) { Text("Zmień zdjęcie") }
            if (photo != null) TextButton(onClick = { photo = null }) { Text("Usuń zdjęcie") }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AvatarColors.forEachIndexed { i, c ->
                Box(Modifier.size(34.dp).clip(CircleShape).background(c)
                    .border(2.dp, if (i == color) ShSilver else Color.Transparent, CircleShape)
                    .clickable { color = i })
            }
        }
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(nick, { if (it.length <= 24) nick = it }, label = { Text("Nick") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(emoji, { if (it.length <= 8) emoji = it }, label = { Text("Emoji awatara") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(about, { if (it.length <= 80) about = it }, label = { Text("Opis (opcjonalnie)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(modifier = Modifier.fillMaxWidth().height(52.dp), enabled = nick.isNotBlank(), onClick = {
            scope.launch(Dispatchers.IO) {
                runCatching {
                    val st = Store(ctx)
                    st.saveProfile(Profile(nick.trim(), color, emoji.trim(), about.trim()))
                    st.setOwnAvatar(photo)
                    Messenger(ctx).broadcastProfile()
                }.onSuccess { msg = "Zapisano" }
                    .onFailure { msg = "Nie udało się zapisać profilu." }
            }
        }) { Text("Zapisz") }
        msg?.let { Spacer(Modifier.height(10.dp)); Text(it, color = ShMuted, fontSize = 13.sp) }
            }
        }
    }
}
