package com.shyfr.app.net

import android.content.Context
import com.shyfr.app.crypto.Keys
import com.shyfr.app.crypto.Ratchet
import com.shyfr.app.vault.ATT_CHUNK
import com.shyfr.app.vault.AttMeta
import com.shyfr.app.vault.Contact
import com.shyfr.app.vault.GroupFrame
import com.shyfr.app.vault.MAX_ATT_BYTES
import com.shyfr.app.session.Prefs
import com.shyfr.app.vault.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withPermit
import com.shyfr.app.vault.OutFrame
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap

/**
 * Wiadomości E2E przez Tor.
 * Ramka: MSG(1) | sid(16) | dh(32) | pn(4) | n(4) | len(4) | szyfrogram
 * Odbiorca odpowiada ACK (zapisano) lub NACK. Nadawca trzyma gotowe ramki w outboxie,
 * dopóki odbiorca nie potwierdzi, więc wiadomości do osoby offline czekają na jej powrót.
 * Zdjęcia i pliki: wiadomość META (opis) + kolejne wiadomości CHUNK po ok. 48 KB, każda szyfrowana osobno.
 */
class Messenger(private val ctx: Context) {
    private val store = Store(ctx)

    fun enqueueText(contactId: Long, text: String): Boolean = sendText(contactId, text, null)

    fun enqueue(contactId: Long, kind: Int, text: String): Boolean =
        enqueueBody(contactId, kind, text.toByteArray(), if (kind == KIND_TEXT) text else null, 0L)

    private fun enqueueBody(contactId: Long, kind: Int, body: ByteArray, text: String?, ackMsgId: Long, mid: String? = null, replyMid: String? = null): Boolean = synchronized(lockFor(contactId)) {
        if (body.size > 65_000) return@synchronized false
        val c = store.contact(contactId) ?: return@synchronized false
        val state = store.loadSession(contactId) ?: return@synchronized false
        val (_, myPub) = store.keys()
        val r = Ratchet.deserialize(state)
        val (h, ct) = try {
            r.encrypt(pad(kind, body), Keys.pairAd(myPub, c.pubkey))
        } catch (e: IllegalStateException) { return@synchronized false } // zapraszający czeka na pierwszą wiadomość
        store.commitOutgoing(contactId, r.serialize(), frame(Keys.sid(myPub), h, ct), text, c.ttl, ackMsgId, mid, replyMid)
        NodeRuntime.messagesVersion.update { it + 1 }
        backoff.expedite(contactId)
        NodeRuntime.kick.trySend(Unit)
        true
    }

    /** Wysyła zdjęcie lub plik. Zwraca komunikat błędu albo null. */
    fun sendAttachment(contactId: Long, name: String, mime: String, data: ByteArray, isImage: Boolean): String? {
        if (data.isEmpty()) return "Pusty plik."
        if (data.size > MAX_ATT_BYTES) return "Plik jest za duży (max 8 MB)."
        val c = store.contact(contactId) ?: return "Brak kontaktu."
        val idBytes = ByteArray(8).also { SecureRandom().nextBytes(it) }
        val id = hex(idBytes)
        val total = (data.size + ATT_CHUNK - 1) / ATT_CHUNK
        val cleanName = cleanFileName(name)
        val meta = AttMeta(id, cleanName, mime.take(100), data.size, total, isImage)
        val label = if (isImage) "🖼 Zdjęcie" else "📎 $cleanName"
        val msgId = store.addOutgoingAttachment(contactId, meta, data, label, c.ttl)

        val mb = meta.mime.toByteArray(); val nb = meta.name.toByteArray()
        val mo = ByteArrayOutputStream(); val md = DataOutputStream(mo)
        md.write(idBytes); md.writeShort(total); md.writeInt(data.size); md.writeByte(if (isImage) 1 else 0)
        md.writeByte(mb.size); md.write(mb); md.writeByte(nb.size); md.write(nb)
        if (!enqueueBody(contactId, KIND_FILE_META, mo.toByteArray(), null, 0L)) {
            store.discardOutgoingAttachment(msgId, id)
            return "Szyfrowanie jeszcze się ustala. Spróbuj za chwilę, gdy znajomy będzie online."
        }
        for (i in 0 until total) {
            val from = i * ATT_CHUNK
            val to = minOf(data.size, from + ATT_CHUNK)
            val bo = ByteArrayOutputStream(); val o = DataOutputStream(bo)
            o.write(idBytes); o.writeShort(i); o.write(data, from, to - from)
            // status "dostarczono" ustawia dopiero potwierdzenie ostatniego kawałka
            if (!enqueueBody(contactId, KIND_FILE_CHUNK, bo.toByteArray(), null, if (i == total - 1) msgId else 0L)) {
                // Metadane i poprzednie kawałki już są w kolejce i dojdą (odbiorca dostanie niekompletny plik, który sam wygaśnie
                // po 7 dniach). Lokalnie nie udajemy sukcesu ani nie zostawiamy wiadomości w stanie „wysyłanie" na zawsze.
                store.discardOutgoingAttachment(msgId, id)
                return "Nie udało się zakolejkować całego pliku. Wyślij go ponownie."
            }
        }
        return null
    }

    private fun midBytes(mid: String): ByteArray = ByteArray(8) { mid.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    /** Wiadomość tekstowa: mid(8) | odpowiedź-na(8, zera = brak) | tekst. */
    fun sendText(contactId: Long, text: String, replyMid: String?): Boolean {
        if (text.isBlank() || text.length > 8000) return false
        val idBytes = ByteArray(8).also { SecureRandom().nextBytes(it) }
        val reply = if (replyMid != null && MID_RE.matches(replyMid)) midBytes(replyMid) else ByteArray(8)
        val bo = ByteArrayOutputStream()
        bo.write(idBytes); bo.write(reply); bo.write(text.toByteArray())
        val rm = if (reply.all { it == 0.toByte() }) null else replyMid
        return enqueueBody(contactId, KIND_TEXT2, bo.toByteArray(), text, 0L, hex(idBytes), rm)
    }

    /** Ankieta w rozmowie prywatnej (2-6 opcji). Zwykła wiadomość tekstowa ze znacznikiem, patrz PollCodec. */
    fun sendPoll(contactId: Long, question: String, options: List<String>): Boolean {
        val body = PollCodec.encode(question, options) ?: return false
        return sendText(contactId, body, null)
    }

    /** Głos w ankiecie (ramka: 8 bajtów mid ankiety + 1 bajt numeru opcji). */
    fun votePoll(contactId: Long, mid: String, opt: Int): Boolean {
        if (!MID_RE.matches(mid) || opt !in 0 until PollCodec.MAX_OPTIONS) return false
        val ok = enqueueBody(contactId, KIND_VOTE, midBytes(mid) + byteArrayOf(opt.toByte()), null, 0L)
        if (ok) { store.setPollVote(contactId, mid, true, opt); NodeRuntime.messagesVersion.update { it + 1 } }
        return ok
    }

    /** Reakcja emoji na wiadomość (null = zdejmij reakcję). */
    fun react(contactId: Long, mid: String, emoji: String?): Boolean {
        if (!MID_RE.matches(mid)) return false
        val e = emoji?.let { clean(it, 8) }?.ifEmpty { null }
        val ok = enqueueBody(contactId, KIND_REACT, midBytes(mid) + (e?.toByteArray() ?: ByteArray(0)), null, 0L)
        if (ok) { store.setReaction(contactId, mid, true, e); NodeRuntime.messagesVersion.update { it + 1 } }
        return ok
    }

    /** Przypięcie/odpięcie wiadomości u obu stron (ramka: 8 bajtów mid + 1 bajt 0/1). */
    fun pin(contactId: Long, mid: String, on: Boolean): Boolean {
        if (!MID_RE.matches(mid)) return false
        val ok = enqueueBody(contactId, KIND_PIN, midBytes(mid) + byteArrayOf(if (on) 1 else 0), null, 0L)
        if (ok) { store.setPinned(contactId, mid, on); NodeRuntime.messagesVersion.update { it + 1 } }
        return ok
    }

    /** Edycja własnej wiadomości tekstowej u obu stron. */
    fun edit(contactId: Long, mid: String, newText: String): Boolean {
        if (!MID_RE.matches(mid) || newText.isBlank() || newText.length > 8000) return false
        val ok = enqueueBody(contactId, KIND_EDIT, midBytes(mid) + newText.toByteArray(), null, 0L)
        if (ok) { store.applyEdit(contactId, mid, newText, true); NodeRuntime.messagesVersion.update { it + 1 } }
        return ok
    }

    /** Usunięcie własnej wiadomości u obu stron (zostaje ślad "wiadomość usunięta"). */
    fun deleteForAll(contactId: Long, mid: String): Boolean {
        if (!MID_RE.matches(mid)) return false
        val ok = enqueueBody(contactId, KIND_DELETE, midBytes(mid), null, 0L)
        if (ok) { store.tombstone(contactId, mid, true); NodeRuntime.messagesVersion.update { it + 1 } }
        return ok
    }

    /** Synchronizuje czas znikania wiadomości z rozmówcą (4 bajty: sekundy). */
    fun sendTtl(contactId: Long, seconds: Int): Boolean {
        if (seconds !in TTL_ALLOWED) return false
        val b = byteArrayOf((seconds ushr 24).toByte(), (seconds ushr 16).toByte(), (seconds ushr 8).toByte(), seconds.toByte())
        return enqueueBody(contactId, KIND_TTL, b, null, 0L)
    }

    /** Informuje rozmówcę o zdarzeniu (zrzut ekranu, nagranie, eksport, zapis pliku) i zostawia ślad u mnie. */
    fun sendNotice(contactId: Long, code: Int): Boolean {
        if (code !in 1..4 || !Prefs.notifyCapture(ctx)) return false
        val ok = enqueueBody(contactId, KIND_NOTICE, byteArrayOf(code.toByte()), null, 0L)
        if (ok) { store.addSystemMessage(contactId, noticeText(code, true), true); NodeRuntime.messagesVersion.update { it + 1 } }
        return ok
    }

    /** Wspólna personalizacja: motyw, emoji, pseudonimy. Ramka: v1 US motyw US emoji US jak_nazywam_Ciebie US jak_nazywam_siebie. */
    fun sendLook(contactId: Long, theme: Int, emoji: String, nickOfPeer: String, nickOfMe: String): Boolean {
        val enc = listOf("c1", theme.coerceIn(0, 7).toString(), clean(emoji, 8), clean(nickOfPeer, 24), clean(nickOfMe, 24)).joinToString(SEP.toString())
        return enqueueBody(contactId, KIND_LOOK, enc.toByteArray(), null, 0L)
    }

    /** Potwierdzenie przeczytania (mid najnowszej przeczytanej wiadomości rozmówcy). */
    fun sendRead(contactId: Long, mid: String): Boolean {
        if (!MID_RE.matches(mid)) return false
        return enqueueBody(contactId, KIND_READ, midBytes(mid), null, 0L)
    }

    /**
     * Wysyła wiadomość do grupy: osobna ramka dla każdego członka, który jest moim kontaktem.
     * Zwraca (dostarczono do kolejki, osiągalnych) albo null przy błędnych danych.
     * Ramka: gid(8) mid(8) nameLen(1) name n(1) n*sid(16) tekst.
     */
    fun sendGroupText(gid: String, text: String): Pair<Int, Int>? {
        if (!GID_RE.matches(gid) || text.isBlank() || text.length > 8000) return null
        val g = store.group(gid) ?: return null
        val (_, myPub) = store.keys()
        val mySid = hex(Keys.sid(myPub))
        val members = g.members
        if (members.size > GROUP_MAX_MEMBERS || mySid !in members) return null
        val bySid = store.contacts().associateBy { hex(Keys.sid(it.pubkey)) }
        val targets = members.filter { it != mySid }.mapNotNull { bySid[it] }
        val idBytes = ByteArray(8).also { SecureRandom().nextBytes(it) }
        val name = g.name.toByteArray().let { if (it.size > 40) it.copyOf(40) else it }
        val bo = ByteArrayOutputStream()
        bo.write(midBytes(gid)); bo.write(idBytes); bo.write(name.size); bo.write(name); bo.write(members.size)
        members.forEach { bo.write(ByteArray(16) { i -> it.substring(i * 2, i * 2 + 2).toInt(16).toByte() }) }
        bo.write(text.toByteArray())
        val body = bo.toByteArray()
        var sent = 0
        for (c in targets) if (enqueueBody(c.id, KIND_GROUP, body, null, 0L)) sent++
        if (sent > 0) { store.addOutgoingGroupMsg(gid, hex(idBytes), text); NodeRuntime.messagesVersion.update { it + 1 } }
        return sent to targets.size
    }

    private fun parseGroup(b: ByteArray, off: Int, len: Int): GroupFrame? = try {
        val i = DataInputStream(ByteArrayInputStream(b, off, len))
        val gid = hex(ByteArray(8).also { i.readFully(it) })
        val mid = hex(ByteArray(8).also { i.readFully(it) })
        val nl = i.readUnsignedByte()
        val name = clean(String(ByteArray(nl).also { i.readFully(it) }), 40)
        val n = i.readUnsignedByte()
        if (n !in 2..GROUP_MAX_MEMBERS || name.isEmpty()) null else {
            val members = List(n) { hex(ByteArray(16).also { s -> i.readFully(s) }) }
            val text = String(i.readBytes())
            if (text.isBlank() || text.length > 8000) null else GroupFrame(gid, mid, name, members.distinct(), text)
        }
    } catch (e: Exception) { null }

    /** Próbuje dostarczyć wszystko z outboxa. Wywoływane cyklicznie i po nowej wiadomości. */
    suspend fun flushOutbox() = withContext(Dispatchers.IO) {
        val t = NodeRuntime.transport ?: return@withContext
        // Kontakty obsługujemy równolegle (do 3 naraz), żeby wolny albo offline kontakt nie blokował pozostałych.
        val gate = kotlinx.coroutines.sync.Semaphore(3)
        kotlinx.coroutines.coroutineScope {
            for (cid in store.outboxContacts()) launch { gate.withPermit { flushContact(t, cid) } }
        }
    }

    private suspend fun flushContact(t: TorTransport, cid: Long) {
        val c = store.contact(cid) ?: return
        val frames = store.outboxFrames(cid)
        if (frames.isEmpty()) return
        // Kontakt niedawno nieosiągalny: nie czekamy znów na limit czasu Tora, wiadomość idzie od razu skrzynką (jeśli jest).
        if (!backoff.shouldTryDirect(cid)) { viaMailbox(c, cid, frames, 0); return }
        var delivered = 0
        try {
            t.connect(c.onion, JoinService.TOR_PORT).use { s ->
                s.soTimeout = 60_000
                val out = DataOutputStream(s.getOutputStream())
                val inp = DataInputStream(s.getInputStream())
                for (f in frames) {
                    out.write(f.frame); out.flush()
                    val resp = inp.readUnsignedByte()
                    if (resp != ACK) {
                        if (resp == NACK) { store.nackOutbox(f); NodeRuntime.messagesVersion.update { it + 1 } }
                        break
                    }
                    store.ackOutbox(f); delivered++
                    runCatching { store.touchSeen(cid) }
                    NodeRuntime.messagesVersion.update { it + 1 }
                }
            }
            backoff.onSuccess(cid)
        } catch (e: kotlinx.coroutines.CancellationException) { throw e
        } catch (e: Exception) {
            backoff.onFailure(cid)
            // druga osoba offline albo problem z siecią: spróbujemy później; zapisujemy przyczynę (bez adresów), co 5 min na kontakt
            val now = System.currentTimeMillis()
            if (now - (lastDeliveryLog[cid] ?: 0L) > 300_000L) {
                lastDeliveryLog[cid] = now
                com.shyfr.app.Trace.log("dostarczanie (kontakt $cid): ${e.javaClass.simpleName}: ${(e.message ?: "").take(80)}; w kolejce ${frames.size}; sieć: ${NetMonitor.description}")
            }
            viaMailbox(c, cid, frames, delivered)
        }
    }

    /** Druga droga: skrzynka na przekaźniku. Zapis w skrzynce to NIE dostarczenie: wiadomość dostaje stan „na serwerze”. */
    private suspend fun viaMailbox(c: Contact, cid: Long, frames: List<OutFrame>, delivered: Int) {
        if (!Mailbox.enabled(ctx)) return
        var viaBox = 0
        for (f in frames.drop(delivered).take(30)) {
            if (!Mailbox(ctx).put(c, f.frame)) break
            store.ackOutboxViaMailbox(f); viaBox++
        }
        if (viaBox > 0) {
            com.shyfr.app.Trace.log("skrzynka: wysłano $viaBox ramek (kontakt $cid)")
            NodeRuntime.messagesVersion.update { it + 1 }
        }
    }

    /** Wysyła swój profil (i zdjęcie profilowe, jeśli jest) jednemu kontaktowi. */
    fun sendOwnProfile(contactId: Long) {
        enqueue(contactId, KIND_PROFILE, encodeProfile(store.profile()))
        store.ownAvatar()?.let { enqueueBody(contactId, KIND_AVATAR, it, null, 0L) }
    }

    /** Wysyła aktualny profil wszystkim kontaktom (po zmianie nicku, awatara itp.). Pusty awatar = usunięcie zdjęcia. */
    fun broadcastProfile() {
        val enc = encodeProfile(store.profile())
        val av = store.ownAvatar() ?: ByteArray(0)
        for (c in store.contacts()) {
            store.setPsent(c.id)
            enqueue(c.id, KIND_PROFILE, enc)
            enqueueBody(c.id, KIND_AVATAR, av, null, 0L)
        }
    }

    /** Odbiór: pierwszy bajt (MSG) został już przeczytany przez router. */
    fun handleMessages(sock: Socket, inp: DataInputStream) {
        sock.use {
            val out = DataOutputStream(sock.getOutputStream())
            val (_, myPub) = store.keys()
            while (true) {
                val sid = ByteArray(16).also { inp.readFully(it) }
                val dh = ByteArray(32).also { inp.readFully(it) }
                val pn = inp.readInt(); val n = inp.readInt(); val len = inp.readInt()
                if (len !in 16..MAX_CT) return
                val ct = ByteArray(len).also { inp.readFully(it) }
                val c = store.contactBySid(sid) ?: return
                val ok = synchronized(lockFor(c.id)) { process(c, myPub, Ratchet.Header(dh, pn, n), ct) }
                if (ok) { backoff.onSuccess(c.id); NodeRuntime.kick.trySend(Unit) }   // kontakt właśnie sam się połączył: jest osiągalny
                out.writeByte(if (ok) ACK else NACK); out.flush()
                if (!ok) return
                try { if (inp.readUnsignedByte() != MSG) return } catch (e: java.io.IOException) { return }
            }
        }
    }

    /**
     * Przetwarza jedną ramkę odebraną inną drogą niż gniazdo (skrzynka na przekaźniku). Format jak w strumieniu P2P:
     * [MSG][sid16][dh32][pn][n][len][szyfrogram]. Zwraca true, jeśli ramka została zapisana albo była duplikatem.
     */
    fun handleFrameBlob(blob: ByteArray): Boolean = try {
        val inp = DataInputStream(java.io.ByteArrayInputStream(blob))
        if (inp.readUnsignedByte() != MSG) false else {
            val sid = ByteArray(16).also { inp.readFully(it) }
            val dh = ByteArray(32).also { inp.readFully(it) }
            val pn = inp.readInt(); val n = inp.readInt(); val len = inp.readInt()
            if (len !in 16..MAX_CT) false else {
                val ct = ByteArray(len).also { inp.readFully(it) }
                val c = store.contactBySid(sid)
                if (c == null) false else {
                    val (_, myPub) = store.keys()
                    synchronized(lockFor(c.id)) { process(c, myPub, Ratchet.Header(dh, pn, n), ct) }
                }
            }
        }
    } catch (e: Exception) { false }

    private fun process(c: Contact, myPub: ByteArray, h: Ratchet.Header, ct: ByteArray): Boolean {
        val hid = Keys.sha256(h.bytes()).copyOf(16)
        if (store.seen(c.id, hid)) return true // duplikat (ACK zginął w drodze): potwierdzamy bez ponownego zapisu
        val state = store.loadSession(c.id) ?: return false
        val r = Ratchet.deserialize(state)
        val plain = try { r.decrypt(h, ct, Keys.pairAd(myPub, c.pubkey)) } catch (e: Exception) { return false }
        val kind = plain[0].toInt() and 0xff
        val len = ((plain[1].toInt() and 0xff) shl 8) or (plain[2].toInt() and 0xff)
        if (3 + len > plain.size) return false
        val newState = r.serialize()

        // Zawartość niepoprawna: stan sesji i tak musi się przesunąć, a nadawca dostaje ACK.
        fun noop(): Boolean { store.commitIncoming(c.id, newState, hid, null, c.ttl); return true }
        // Zablokowany kontakt: sesja się przesuwa (żeby nie zablokować kolejki nadawcy), treść jest odrzucana po cichu.
        if (c.blocked) return noop()

        when (kind) {
            KIND_TEXT2 -> {
                if (len < 17) return noop()
                val mid = hex(plain.copyOfRange(3, 11))
                val rb = plain.copyOfRange(11, 19)
                val reply = if (rb.all { it == 0.toByte() }) null else hex(rb)
                store.commitIncoming(c.id, newState, hid, String(plain, 19, len - 16), c.ttl, mid, reply)
                NodeRuntime.messagesVersion.update { it + 1 }; if (!c.muted) NodeRuntime.onIncoming?.invoke()
                return true
            }
            KIND_REACT -> {
                if (len < 8) return noop()
                val emoji = if (len == 8) null else clean(String(plain, 11, len - 8), 8).ifEmpty { null }
                store.commitIncomingReaction(c.id, newState, hid, hex(plain.copyOfRange(3, 11)), emoji)
                NodeRuntime.messagesVersion.update { it + 1 }
                return true
            }
            KIND_VOTE -> {
                if (len != 9) return noop()
                val opt = plain[11].toInt()
                if (opt !in 0 until PollCodec.MAX_OPTIONS) return noop()
                store.commitIncomingVote(c.id, newState, hid, hex(plain.copyOfRange(3, 11)), opt)
                NodeRuntime.messagesVersion.update { it + 1 }
                return true
            }
            KIND_PIN -> {
                if (len != 9) return noop()
                store.commitIncomingPin(c.id, newState, hid, hex(plain.copyOfRange(3, 11)), plain[11].toInt() == 1)
                NodeRuntime.messagesVersion.update { it + 1 }
                return true
            }
            KIND_EDIT -> {
                if (len < 9) return noop()
                store.commitIncomingEdit(c.id, newState, hid, hex(plain.copyOfRange(3, 11)), String(plain, 11, len - 8))
                NodeRuntime.messagesVersion.update { it + 1 }
                return true
            }
            KIND_DELETE -> {
                if (len < 8) return noop()
                store.commitIncomingDelete(c.id, newState, hid, hex(plain.copyOfRange(3, 11)))
                NodeRuntime.messagesVersion.update { it + 1 }
                return true
            }
            KIND_TTL -> {
                if (len != 4) return noop()
                val s = ((plain[3].toInt() and 0xff) shl 24) or ((plain[4].toInt() and 0xff) shl 16) or
                    ((plain[5].toInt() and 0xff) shl 8) or (plain[6].toInt() and 0xff)
                if (s !in TTL_ALLOWED) return noop()
                store.commitIncomingTtl(c.id, newState, hid, s)
                NodeRuntime.contactsVersion.update { it + 1 }
                return true
            }
            KIND_READ -> {
                if (len != 8 || !Prefs.readReceipts(ctx)) return noop()
                store.commitIncomingRead(c.id, newState, hid, hex(plain.copyOfRange(3, 11)))
                NodeRuntime.messagesVersion.update { it + 1 }
                return true
            }
            KIND_NOTICE -> {
                if (len != 1) return noop()
                val code = plain[3].toInt() and 0xff
                if (code !in 1..4) return noop()
                store.commitIncomingNotice(c.id, newState, hid, noticeText(code, false))
                NodeRuntime.messagesVersion.update { it + 1 }; if (!c.muted) NodeRuntime.onIncoming?.invoke()
                return true
            }
            KIND_LOOK -> {
                val a = String(plain, 3, len).split(SEP)
                if (a.size < 5 || a[0] != "c1") return noop()
                store.commitIncomingLook(c.id, newState, hid, (a[1].toIntOrNull() ?: 0).coerceIn(0, 7), clean(a[2], 8), clean(a[3], 24), clean(a[4], 24))
                NodeRuntime.contactsVersion.update { it + 1 }
                return true
            }
            KIND_GROUP -> {
                val g = parseGroup(plain, 3, len) ?: return noop()
                val mySid = hex(Keys.sid(myPub))
                val notify = store.commitIncomingGroup(c.id, newState, hid, g, hex(Keys.sid(c.pubkey)), mySid)
                NodeRuntime.messagesVersion.update { it + 1 }; NodeRuntime.contactsVersion.update { it + 1 }
                if (notify && !c.muted) NodeRuntime.onIncoming?.invoke()
                return true
            }
            KIND_FILE_META -> {
                val m = parseMeta(plain, 3, len) ?: return noop()
                store.commitIncomingMeta(c.id, newState, hid, m)
                return true
            }
            KIND_FILE_CHUNK -> {
                if (len < 10) return noop()
                val id = hex(plain.copyOfRange(3, 11))
                val idx = ((plain[11].toInt() and 0xff) shl 8) or (plain[12].toInt() and 0xff)
                val data = plain.copyOfRange(13, 3 + len)
                if (len < 11 || data.size > ATT_CHUNK) return noop()
                val done = store.commitIncomingChunk(c.id, newState, hid, id, idx, data, c.ttl)
                if (done) { NodeRuntime.messagesVersion.update { it + 1 }; if (!c.muted) NodeRuntime.onIncoming?.invoke() }
                return true
            }
            KIND_AVATAR -> {
                if (len > AVATAR_MAX) return noop()
                store.commitIncomingAvatar(c.id, newState, hid, if (len == 0) null else plain.copyOfRange(3, 3 + len))
                NodeRuntime.contactsVersion.update { it + 1 }
                return true
            }
        }

        val text = if (kind == KIND_TEXT || kind == KIND_PROFILE) String(plain, 3, len) else null
        val body = if (kind == KIND_TEXT) text else null
        store.commitIncoming(c.id, newState, hid, body, c.ttl)
        if (kind == KIND_PROFILE) decodeProfile(text!!)?.let { store.applyProfile(c.id, it); NodeRuntime.contactsVersion.update { v -> v + 1 } }
        if (body != null) { NodeRuntime.messagesVersion.update { it + 1 }; if (!c.muted) NodeRuntime.onIncoming?.invoke() }
        // Pierwsza wiadomość od nowego kontaktu: odsyłamy swój profil (raz).
        if ((kind == KIND_PROFILE || kind == KIND_HELLO) && !c.psent) {
            store.setPsent(c.id)
            sendOwnProfile(c.id)
        }
        return true
    }

    private fun parseMeta(b: ByteArray, off: Int, len: Int): AttMeta? = try {
        val i = DataInputStream(ByteArrayInputStream(b, off, len))
        val id = hex(ByteArray(8).also { i.readFully(it) })
        val total = i.readUnsignedShort()
        val size = i.readInt()
        val image = i.readUnsignedByte() == 1
        val mime = String(ByteArray(i.readUnsignedByte()).also { i.readFully(it) })
        val name = cleanFileName(String(ByteArray(i.readUnsignedByte()).also { i.readFully(it) }))
        if (total !in 1..200 || size !in 1..MAX_ATT_BYTES) null else AttMeta(id, name, mime.take(100), size, total, image)
    } catch (e: Exception) { null }

    /** [rodzaj(1)][długość(2)][treść][wypełnienie do wielokrotności 256 B]: ukrywa długość wiadomości. */
    private fun pad(kind: Int, body: ByteArray): ByteArray {
        val total = ((3 + body.size + 255) / 256) * 256
        val b = ByteArray(total)
        b[0] = kind.toByte(); b[1] = (body.size shr 8).toByte(); b[2] = body.size.toByte()
        System.arraycopy(body, 0, b, 3, body.size)
        return b
    }

    private fun frame(sid: ByteArray, h: Ratchet.Header, ct: ByteArray): ByteArray {
        val bo = ByteArrayOutputStream(); val o = DataOutputStream(bo)
        o.writeByte(MSG); o.write(sid); o.write(h.dh); o.writeInt(h.pn); o.writeInt(h.n)
        o.writeInt(ct.size); o.write(ct)
        return bo.toByteArray()
    }

    companion object {
        /** Opóźnienia ponawiania połączeń bezpośrednich (jedno na aplikację; zerowane po zmianie sieci). */
        val backoff = DeliveryBackoff()
        private val lastDeliveryLog = java.util.concurrent.ConcurrentHashMap<Long, Long>()
        const val MSG = 4; const val ACK = 5; const val NACK = 6
        const val KIND_TEXT = 0; const val KIND_HELLO = 1; const val KIND_PROFILE = 2
        const val KIND_AVATAR = 3; const val KIND_FILE_META = 4; const val KIND_FILE_CHUNK = 5
        const val KIND_TEXT2 = 6; const val KIND_REACT = 7; const val KIND_EDIT = 8; const val KIND_DELETE = 9
        const val KIND_TTL = 10; const val KIND_READ = 11; const val KIND_GROUP = 12
        const val KIND_NOTICE = 13; const val KIND_LOOK = 14; const val KIND_PIN = 15; const val KIND_VOTE = 16
        const val NOTICE_SCREENSHOT = 1; const val NOTICE_RECORDING = 2; const val NOTICE_EXPORT = 3; const val NOTICE_SAVED = 4
        private val GID_RE = Regex("^[0-9a-f]{16}$")
        private const val GROUP_MAX_MEMBERS = 16
        private val TTL_ALLOWED = setOf(0, 3600, 86400, 604800)
        private val MID_RE = Regex("^[0-9a-f]{16}$")
        private const val AVATAR_MAX = 30_000
        private const val SEP = '\u001F'
        private fun clean(s: String, max: Int) = s.filter { it >= ' ' && it != SEP }.trim().take(max)
        private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
        private fun cleanFileName(s: String) = s.filter { it >= ' ' && it !in "/\\:*?\"<>|" }.trim().take(40).ifEmpty { "plik" }

        fun encodeProfile(p: com.shyfr.app.vault.Profile): String =
            listOf("v1", clean(p.nick, 24), p.color.toString(), clean(p.emoji, 8), clean(p.about, 80)).joinToString(SEP.toString())

        fun decodeProfile(s: String): com.shyfr.app.vault.Profile? {
            val a = s.split(SEP)
            if (a.size < 5 || a[0] != "v1") return null
            return com.shyfr.app.vault.Profile(clean(a[1], 24), (a[2].toIntOrNull() ?: 0).coerceIn(0, 7), clean(a[3], 8), clean(a[4], 80))
        }

        fun noticeText(code: Int, mine: Boolean): String = when (code) {
            NOTICE_SCREENSHOT -> if (mine) "📸 Zrobiłeś zrzut ekranu. Rozmówca został powiadomiony." else "📸 Rozmówca zrobił zrzut ekranu tej rozmowy."
            NOTICE_RECORDING -> if (mine) "🔴 Nagrywasz ekran. Rozmówca został powiadomiony." else "🔴 Rozmówca nagrywa ekran z tą rozmową."
            NOTICE_EXPORT -> if (mine) "📤 Wyeksportowałeś rozmowę. Rozmówca został powiadomiony." else "📤 Rozmówca wyeksportował tę rozmowę do pliku."
            else -> if (mine) "💾 Zapisałeś plik z rozmowy. Rozmówca został powiadomiony." else "💾 Rozmówca zapisał plik z tej rozmowy."
        }

        private const val MAX_CT = 70_000
        private val locks = ConcurrentHashMap<Long, Any>()
        private fun lockFor(id: Long): Any = locks.getOrPut(id) { Any() }
    }
}
