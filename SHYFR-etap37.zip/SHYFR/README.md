# SHYFR 1.0.0

Anonimowy komunikator Android z szyfrowaniem end-to-end (Double Ratchet), przez sieć Tor. Bez serwerów, numerów telefonu i kont online. Dane zostają w zaszyfrowanej bazie (SQLCipher) na telefonie.

## Budowanie
- Android Studio (JDK 17), `minSdk 29`, `targetSdk 35`.
- Debug: `./gradlew assembleDebug`
- Wydanie: utwórz `keystore.properties` (storeFile, storePassword, keyAlias, keyPassword), potem `./gradlew bundleRelease` lub `assembleRelease`.

## Funkcje
Rozmowy 1:1 i grupy, zdjęcia, pliki, wiadomości głosowe, odpowiedzi (przeciągnięciem), reakcje, edycja i usuwanie u wszystkich, znikające wiadomości, motywy i pseudonimy rozmów, status aktywności, ochrona i powiadomienia o zrzutach ekranu, PIN/odcisk palca, hasło paniki, mosty Tor.

## Warstwa publiczna
Przekaźnik: `relay/` (Python, onion w Termux). Instrukcja i granice prywatności w `relay/README.md`. Testy: `python3 -m unittest test_relay` w katalogu `relay/`.


## Publiczny feed na Nostr (etap 27)
Zakładka Feed → „Publiczny” działa na publicznych przekaźnikach Nostr, bez żadnej konfiguracji i bez serwera SHYFR. Kod: `app/src/main/java/com/shyfr/app/nostr/`.
- `Schnorr.kt`, `NostrEvent.kt`: podpisy BIP-340 (secp256k1) i zdarzenia NIP-01, czysty Kotlin. Testy na oficjalnych wektorach BIP-340 oraz na wynikach niezależnej implementacji w Pythonie.
- `RelayManager.kt`: jedyny zarządca połączeń. Lista startowa + zapamiętane udane przekaźniki; każdy kandydat jest sprawdzany w praktyce (połączenie, odpowiedź EOSE); pomijane są niedziałające, wymagające logowania (NIP-42) lub płatne; ponawianie z rosnącym opóźnieniem; uzupełnianie po awarii; reset po zmianie sieci. Publikacja do wielu przekaźników: sukces tylko, gdy co najmniej jeden potwierdzi. Odczyt z wielu przekaźników, bez duplikatów, z weryfikacją id i podpisu.
- `NostrHub.kt`: połączenie przez Tora (SOCKS, nazwy rozwiązuje Tor) i TLS z weryfikacją hosta; zarządca działa tylko, gdy ekran Feed go potrzebuje.
- `NostrFeedRepo.kt`: wpisy (kind 1), odpowiedzi (NIP-10), reakcje (kind 7), profile (kind 0), obserwowanie (NIP-02 tylko dla tożsamości publicznej). Każda tożsamość SHYFR ma własny klucz Nostr wyprowadzany z klucza konta.
Granice: wpisy są publiczne, a operatorzy przekaźników widzą treść i metadane (Tor ukrywa tylko IP). Wiele publicznych przekaźników blokuje Tora albo bywa niedostępnych: dlatego zarządca dobiera je na bieżąco i nic nie jest gwarantowane. Nie ma jeszcze: repostów, ankiet, wpisów z ograniczonym odbiorcą (wymagają szyfrowania), uwierzytelniania NIP-42, wyszukiwania pełnotekstowego.
Adresy w ustawieniach (serwer społeczności i skrzynki) są ukryte w normalnym interfejsie; pokazuje je tryb programisty (7 dotknięć wersji w Ustawieniach → O aplikacji albo build debug).

## Powiadomienia z sieci publicznej (etap 32)
Aktywność → „Sieć publiczna”: odpowiedzi (NIP-10), reakcje (NIP-25), wzmianki i nowi obserwujący (NIP-02, tylko gdy obserwujący użyje tożsamości publicznej) z ostatnich 14 dni, dla aktywnej tożsamości. Klasyfikacja jest czystą funkcją (`NostrNotifs`, testy `NostrNotifsTest`). Nowe powiadomienia sprawdzamy po otwarciu zakładki; **nie ma powiadomień push w tle** (wymagałoby stale działającej usługi albo serwera push). Zablokowani i wyciszeni są pomijani, a nowy obserwujący jest ogłaszany raz, także po aktualizacji jego listy.

## Interakcje we Feedzie (etap 33)
Udostępnianie (NIP-18, kind 6; oryginał jest sprawdzany: id i podpis, więc podrobionego nie pokażemy), prośba o usunięcie własnego wpisu (NIP-09; serwery nie mają obowiązku jej spełnić, a kopie mogły już zostać zapisane), zapisywanie wpisów (tylko lokalnie w telefonie, do 200) i wyszukiwanie po hashtagu (tag „t”). Reguły udostępnień są w `NostrReposts` i mają testy. Nie ma: edycji wpisów (Nostr ich nie przewiduje), obrazów i wideo (wymagają zewnętrznego serwera plików), ankiet.

## Profil publiczny (etap 34)
Feed → „Mój profil”: nazwa i opis aktywnej tożsamości publikowane jako profil Nostr (kind 0), po jawnym potwierdzeniu. Każda tożsamość ma osobny profil; anonimowa nie wskazuje innych. Nazwa i opis są publiczne. (W projekcie działa też `ensureProfile`: po pierwszym wpisie publikuje profil z nazwą tożsamości widoczną w oknie pisania.)

## Moderacja po stronie użytkownika (etap 35)
We Feedzie: „Więcej” → wycisz autora, zablokuj autora, zgłoś wpis; „Ukryci autorzy” → lista z możliwością cofnięcia. Wyciszenie i blokada są **lokalne**: ukrywają autora w feedzie, odpowiedziach i powiadomieniach tej tożsamości, ale autor o tym nie wie i nadal może pisać publicznie (w sieci publicznej nie da się go zablokować). Zgłoszenie (NIP-56, kind 1984) jest **publiczne** i nie gwarantuje usunięcia: serwery sieci nie mają obowiązku reagować. Reguły tagów zgłoszeń mają testy (`NostrReportsTest`).
