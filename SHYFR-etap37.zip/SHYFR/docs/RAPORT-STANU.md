# Raport stanu (etap 37): co jest zrobione, co sprawdzone, co blokuje

Legenda: **Zaimplementowane** = kod istnieje. **Test jednostkowy** = napisany test; wykonany tylko tam, gdzie zaznaczono. **Urządzenia** = sprawdzone na prawdziwych telefonach. Żadnego testu na telefonach nie wykonano, a żadnej niezależnej oceny bezpieczeństwa nie przeprowadzono.

| Obszar | Zaimplementowane | Sprawdzone | Blokady |
|---|---|---|---|
| Build Androida | tak (CI, Gradle 8.9 przypięty w workflow) | budował się u właściciela do etapu 33; etapów 34–37 nie budowano | brak Gradle Wrappera (wymaga uruchomienia `gradle wrapper` na maszynie z Gradle) |
| CI/CD | build, testy Kotlina i Pythona, lint (informacyjnie), APK i raporty jako artefakty, commit w podsumowaniu | workflow nieuruchomiony przeze mnie | brak podpisanego wydania (AAB), brak sekretów podpisu |
| Wiadomości | outbox, ACK/NACK, deduplikacja, stan „na serwerze" osobno od „dostarczono" | testy stanów napisane, nie wykonane | brak testów na telefonach |
| Dostarczanie między sieciami | bezpośrednio przez Tor + skrzynka na przekaźniku | nie sprawdzano | wymaga działającego przekaźnika i testów A–D |
| Dostarczanie offline | skrzynka, ponawianie z opóźnieniem per kontakt | testy opóźnień napisane, nie wykonane | Doze/oszczędzanie baterii nie sprawdzone |
| Usługi w tle | foreground service, pętle wysyłki i skrzynki | nie sprawdzano | zachowanie po zabiciu procesu i restarcie telefonu nieznane |
| Załączniki i głos | kawałki 48 kB, walidacja po stronie odbiorcy, sprzątanie porzuconych po 7 dniach, brak fałszywego sukcesu przy częściowym zakolejkowaniu | testy stałych napisane, nie wykonane | przerwany transfer, maksymalny plik i powtórka nie przetestowane na telefonach |
| Baza | migracje `CREATE IF NOT EXISTS` + dopisywanie kolumn | brak testów migracji ze starych wersji | brak testów migracji z wersji 10–12 |
| Kopia i odzyskiwanie | kopia obejmuje teraz wszystkie tabele (test pilnuje zgodności ze schematem), spójna migawka, import w jednej transakcji, oczekujące wysyłki po imporcie oznaczane jako niedostarczone | `BackupSchemaTest` napisany, nie wykonany; relacja z kopią na telefonach nie sprawdzona | **cofnięcie stanu szyfrowania po przywróceniu** (patrz niżej); brak protokołu resetu sesji |
| PIN i biometria | istnieją (sejf, odblokowanie, limity prób) | nie sprawdzano w tej serii | pełny cykl życia nietestowany |
| Tor i przekaźniki | Tor w tle, przekaźnik SHYFR, publiczne przekaźniki Nostr z automatycznym wyborem, jawne stany osiągalności | testy zarządcy (atrapa) i stanów napisane; przekaźnik Pythona: 61 testów wykonanych i zielonych | żadnego prawdziwego przekaźnika Nostr przez Tor nie sprawdzono; domyślny przekaźnik SHYFR trzeba wdrożyć |
| Kryptografia | Double Ratchet (istniejący), Schnorr BIP-340 (sprawdzony na oficjalnych wektorach w Pythonie), koperta konta AES-GCM | testy Kotlina napisane, nie wykonane | **brak niezależnego audytu** |
| Feed publiczny | wpisy, odpowiedzi, reakcje, udostępnienia, profile, zapisane, hashtagi, usuwanie (prośba) | testy czystej logiki napisane, nie wykonane | brak obrazów, ankiet; nie sprawdzono na telefonach |
| Społeczności | istniejący system na przekaźniku SHYFR | testy przekaźnika wykonane | prywatne/ukryte chroni tylko zaufanie do operatora |
| Moderacja | wyciszenie, blokada (lokalne), zgłoszenie (publiczne), lista ukrytych | test tagów zgłoszeń napisany | brak regulaminu i zgody użytkownika, brak narzędzi moderatora w feedzie publicznym |
| UI/UX | nowa paleta, nawigacja, ikony, prostsze ustawienia | nie oceniano na urządzeniu w tej serii | dostępność (TalkBack) nieprzeglądana systematycznie |
| Prywatność | `docs/PRYWATNOSC-I-TOR.md` | przegląd dokumentu względem kodu | polityka prywatności bez kontaktu, nieopublikowana |
| Google Play | dokumenty w `docs/` | nie sprawdzano | **brak usuwania konta** (lokalnego i zdalnego), brak regulaminu, brak adresu żądania usunięcia, brak podpisanego AAB |

## Błędy znalezione i naprawione w etapie 37
1. **Kopia pomijała tabele tożsamości** (`soc_identity`, `soc_draft`, `soc_graph`), które dodałem w etapie 22: po przywróceniu tożsamości by zniknęły. Dodano je. Dodano test, który porównuje schemat z listą kopii.
2. **Wiadomości w stanie „wysyłanie" po przywróceniu** zostawały takie na zawsze (kolejka nie jest przywracana). Teraz są oznaczane jako niedostarczone i można je wysłać ponownie.
3. **Eksport kopii nie był spójną migawką**: sesje szyfrowania i wiadomości mogły pochodzić z różnych chwil. Teraz eksport odbywa się w jednej transakcji.
4. **`selfCheck()` po 6 minutach bez potwierdzenia ustawiał „osiągalny"**. Teraz są jawne stany (sprawdzam, osiągalny, niedostępny, bez potwierdzenia), a zielone „Online" pokazujemy tylko po potwierdzonym teście.
5. **`sendAttachment()` zwracał sukces, gdy kawałek pliku nie trafił do kolejki.** Teraz zwraca błąd, a lokalna wiadomość jest usuwana. Niedokończone odbiory są sprzątane po 7 dniach.
6. **CI nie zapisywał APK** i nie pokazywał commita. Teraz zapisuje APK jako artefakt, pokazuje commit, wersję i stan domyślnego przekaźnika, a numer commita jest w Ustawieniach.

## Ryzyko nienaprawione: cofnięcie stanu szyfrowania po przywróceniu kopii
Kopia zawiera stan Double Ratchet z chwili jej utworzenia. Jeśli po utworzeniu kopii wymieniono wiadomości, przywrócony stan jest „starszy" niż stan rozmówcy. Nasze nowe wiadomości mogą wtedy używać numerów, które rozmówca już widział, więc jego aplikacja uzna je za duplikaty, potwierdzi i **odrzuci bez wyświetlenia**, a my zobaczymy „dostarczono". Bezpieczne rozwiązanie wymaga protokołu resetu sesji z uwierzytelnieniem starym kluczem tożsamości i ostrzeżeniem o zmianie klucza dla rozmówcy (patrz `docs/ODZYSKIWANIE-KONTA.md`). Do tego czasu aplikacja ostrzega przy przywracaniu, żeby używać kopii tylko na nowym telefonie.

## Gotowość: na podstawie bramek, nie procentów z liczby funkcji
Bramki zamkniętej bety: (1) build przechodzi: **spełniona** wg właściciela do etapu 33; (2) testy A–D na dwóch telefonach: **niespełnione**; (3) domyślny przekaźnik wdrożony i stale działający: **nieznane**; (4) usuwanie konta: **niespełnione**; (5) regulamin i polityka prywatności z kontaktem: **niespełnione**; (6) przywracanie kopii sprawdzone na telefonach: **niespełnione**; (7) migracje ze starych wersji przetestowane: **niespełnione**; (8) podstawowa moderacja treści użytkowników: **częściowo**. To jedna z ośmiu bramek spełniona i jedna częściowo. Publiczne wydanie wymaga ponadto niezależnego audytu kryptografii i podpisanego AAB, a żadne z nich nie istnieje.

## P0 (blokują zamkniętą betę)
Testy A–D na telefonach; wdrożony przekaźnik; usuwanie konta (lokalne i zdalne: koperta, profile na przekaźniku); regulamin i polityka z kontaktem; protokół resetu sesji albo wyraźne ograniczenie przywracania do nowego telefonu.
## P1
Migracje ze starych wersji (test), praca w tle (Doze, restart), cykl życia PIN i biometrii, Gradle Wrapper, TalkBack, narzędzia moderatora w feedzie publicznym, przerwane transfery załączników na telefonach.

## Pięć najważniejszych następnych zadań
1. Przejść testy A–D z `docs/AUDYT-DOSTARCZANIA.md` na dwóch telefonach i wpisać wyniki.
2. Wdrożyć przekaźnik i ustawić `SHYFR_DEFAULT_RELAY` w CI.
3. Zaimplementować usuwanie konta (lokalnie, kopertę na serwerze, profile i obserwowania na przekaźniku) i adres żądania usunięcia.
4. Napisać regulamin i uzupełnić politykę prywatności o kontakt oraz zgodę przy tworzeniu konta.
5. Zaprojektować i oddać do przeglądu protokół resetu sesji.
