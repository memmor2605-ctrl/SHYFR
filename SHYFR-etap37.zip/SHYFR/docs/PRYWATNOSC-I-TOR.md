# Model prywatności SHYFR: co jest chronione, a co nie

Opis oparty na tym, co faktycznie jest w kodzie. Nie jest to audyt bezpieczeństwa ani certyfikat. Szyfrowanie rozmów (Double Ratchet) i pozostałe elementy kryptograficzne **nie przeszły niezależnego przeglądu** i wymagają go przed szerokim udostępnieniem.

## Co robi Tor, a czego nie
Tor ukrywa przed serwerami i przed Twoim dostawcą internetu, z kim się łączysz, i ukrywa Twój adres IP przed serwerami. **Nie** czyni treści prywatną (publiczny wpis zostaje publiczny), **nie** chroni przed kimś, kto obserwuje oba końce ruchu i porównuje czasy, i **nie** ukrywa samego faktu używania Tora przed dostawcą internetu (bez mostów). Użycie Tora nie oznacza, że cała aplikacja jest anonimowa.

## Rozmowy prywatne
- Szyfrowane end-to-end (Double Ratchet). Idą bezpośrednio przez Tor między telefonami (usługi onion).
- Gdy odbiorca jest offline, zaszyfrowana ramka czeka w skrzynce na przekaźniku. Operator widzi szyfrogram, rozmiar i czas, nie treść. Zapis w skrzynce nie jest dostarczeniem: w aplikacji ma stan „na serwerze".
- Dostarczanie między różnymi sieciami offline wymaga stale działającego przekaźnika (patrz `relay/README.md`).
- Nie chroni przed: przejęciem odblokowanego telefonu, zrzutami ekranu przez rozmówcę, ani utratą rozmów po zgubieniu telefonu bez pliku kopii zapasowej.

## Publiczny feed (Nostr)
- Wpisy, profile, reakcje, udostępnienia i listy obserwowanych tożsamości publicznej są **publiczne**. Operatorzy niezależnych serwerów widzą treść i metadane (klucz autora, czas). Tor ukrywa tylko adres IP.
- Każda tożsamość ma osobny klucz. Anonimowa nie wskazuje innych tożsamości, ale styl pisania i godziny aktywności mogą je powiązać.
- Wyciszenie i blokada działają tylko lokalnie. Zgłoszenie jest publiczne i nie gwarantuje usunięcia. Prośba o usunięcie wpisu nie musi zostać spełniona.
- Serwery sieci mogą zniknąć, zablokować Tora albo przestać przechowywać dane. Nic nie jest gwarantowane.

## Obserwowanie i społeczności na przekaźniku SHYFR
- Operator przekaźnika widzi, który klucz obserwuje który klucz, prośby o obserwację i treść społeczności. „Ukryte” listy i liczniki to ukrycie w odpowiedziach przekaźnika, nie szyfrowanie. Społeczności „prywatne” i „ukryte” chroni zaufanie do operatora, nie kryptografia.

## Konto i odzyskiwanie
- Kopia klucza głównego na przekaźniku jest zaszyfrowana hasłem (Argon2id). Operator może próbować zgadywać hasło offline, więc hasło musi być długie i niepowtarzalne. Zapomniane hasło oznacza brak odzyskania.
- Odzyskanie przywraca klucze i tożsamości społecznościowe, **nie** rozmowy, kontakty ani adres onion (patrz `docs/ODZYSKIWANIE-KONTA.md`).
- Lokalne dane są w bazie SQLCipher; dostęp chroni hasło, PIN i biometria; kolejne błędne próby wymazują dane (zgodnie z ustawieniami).

## Czego nie ma (bez udawania)
Wpisów tylko dla obserwujących (wymagają szyfrowania treści), połączeń głosowych i wideo, zdjęć i wideo w feedzie, powiadomień push w tle, wielu urządzeń naraz na jednym koncie, niezależnego audytu kryptografii.
