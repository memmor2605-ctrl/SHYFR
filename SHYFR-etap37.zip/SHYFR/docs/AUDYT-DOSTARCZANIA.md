# Audyt dostarczania wiadomości (etap 29)

Zakres: odczyt kodu `net/Messenger.kt`, `net/Mailbox.kt`, `vault/Store.kt` (outbox, statusy), odbiór (`handleMessages`, `handleFrameBlob`, `process`). **Nie uruchamiano aplikacji na telefonach.** Wnioski pochodzą z czytania kodu i z testów jednostkowych.

## Zweryfikowane w kodzie
- **Trwała kolejka:** ramki czekają w tabeli `outbox` zaszyfrowanej bazy (przeżywają restart i zabicie procesu). Odbiorca potwierdza zapis bajtem ACK; dopiero wtedy ramka schodzi z kolejki.
- **Duplikaty:** odbiorca zapamiętuje skrót nagłówka ramki (`seen`). Powtórzona ramka (ACK zginął po drodze) jest potwierdzana bez ponownego zapisu, więc nie ma podwójnych wiadomości ani fałszywego „nie dostarczono".
- **Odrzucenie (NACK):** po 5 próbach ramka jest porzucana, a wiadomość dostaje stan „nie dostarczono".
- **Druga droga:** gdy bezpośrednie połączenie z odbiorcą zawiedzie, ramki idą do skrzynki na przekaźniku (jeśli skrzynka jest włączona).

## Błąd znaleziony i naprawiony
Zapis w skrzynce na serwerze był traktowany jak potwierdzenie odbioru: wiadomość dostawała stan „dostarczona" (✓), choć odbiorca mógł jej nigdy nie zobaczyć. Naprawa: nowy stan **„na serwerze"** (`Delivery.ON_SERVER`). „Dostarczono" oznacza teraz wyłącznie ACK od urządzenia odbiorcy. Potwierdzenie przeczytania podnosi do „przeczytano" także wiadomości czekające na serwerze. Reguły są w `net/Delivery.kt` i testach `DeliveryTest`.

## Drugi błąd: ponawianie blokowało kolejkę (naprawiony w etapie 30)
Pętla wysyłki (co 30 s) obsługiwała kontakty po kolei, a każdy kontakt offline czekał na limit czasu Tora (do ok. 45–60 s). Przy kilku nieosiągalnych kontaktach wiadomości do osób online mogły czekać minutami. Naprawa:
- kontakty są obsługiwane równolegle (do 3 naraz),
- nieosiągalny kontakt dostaje rosnące opóźnienie bezpośrednich prób (30 s, 60 s, 120 s, 240 s, potem co 5 min), a w tym czasie wiadomość idzie od razu skrzynką na serwerze (jeśli jest włączona),
- nowa wiadomość skraca opóźnienie do 30 s od ostatniej porażki, połączenie przychodzące od kontaktu je zeruje, a zmiana sieci zeruje wszystkie,
- reguły są w `net/DeliveryBackoff.kt` i testach `DeliveryBackoffTest`.
Efekt uboczny: gdy skrzynka jest wyłączona, a kontakt wraca do sieci bez kontaktowania się z nami, wiadomość może czekać do 5 minut (wcześniej do 30 s, ale kosztem blokowania innych).

## Znane luki (nienaprawione)
- Przez skrzynkę nie wraca potwierdzenie doręczenia. Jeśli odbiorca wyłączy potwierdzenia przeczytania, wiadomość zostaje w stanie „na serwerze", nawet po odbiorze.
- Nie sprawdzano: zachowania pod Doze i oszczędzaniem baterii, zabijania procesu przez system ani porządku wiadomości po zmianie sieci (to wymaga testów na telefonach).
- Odbiór ze skrzynki zależy od tego, czy oba telefony używają tego samego przekaźnika (domyślnego, wbudowanego w wersję).

## Wymagana infrastruktura
Dostarczanie do odbiorcy offline między różnymi sieciami wymaga **stale dostępnego przekaźnika** (usługa onion z `relay/shyfr_relay.py`) wbudowanego w wersję (`shyfrDefaultRelay`). Bez niego działa tylko bezpośrednie połączenie, gdy oba telefony są jednocześnie online. Przekaźnik może działać na małym serwerze (VPS) albo domowym komputerze; wymaga ciągłej pracy. Skrzynka przechowuje wyłącznie zaszyfrowane ramki, ale operator widzi metadane (kiedy i do jakiej skrzynki).

## Macierz testów ręcznych (A–L): nie wykonano
| Test | Stan |
|---|---|
| A. Dwa telefony, różne Wi-Fi | nie wykonano |
| B. Wi-Fi i dane komórkowe | nie wykonano |
| C. Nadawca online, odbiorca offline | nie wykonano |
| D. Odbiorca wraca i dostaje zaległe | nie wykonano |
| E. Zabicie procesu i ponowne uruchomienie | nie wykonano |
| F. Zmiana sieci w trakcie rozmowy | nie wykonano |
| G. Wiadomości grupowe | nie wykonano |
| H. Załączniki i wiadomości głosowe | nie wykonano |
| I. Kopia zapasowa i przywrócenie | nie wykonano |
| J. Społeczność: tworzenie, dołączanie, moderacja | nie wykonano |
| K. Feed: wpis, komentarze, reakcje | nie wykonano |
| L. Powiadomienia w tle | nie wykonano |
