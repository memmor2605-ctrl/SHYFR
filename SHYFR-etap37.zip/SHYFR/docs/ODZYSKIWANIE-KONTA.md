# Odzyskiwanie konta: co wraca i dlaczego nie wszystko

## Stan (etap 26)
Koperta na serwerze zawiera klucz główny konta. Z niego wyprowadzane są: tożsamości społecznościowe (publiczna, prywatna, anonimowa), klucze Nostr i klucze społeczności. Po zalogowaniu na nowym telefonie wracają więc profile i obserwowania w sieci publicznej.

## Czego koperta nie obejmuje (sprawdzone w kodzie)
- **Adres onion i klucz tożsamości szyfrowania są losowe**, zapisane tylko w zaszyfrowanej bazie na telefonie (`identity.onion_key`, `identity.x_priv`). Nie wynikają z klucza głównego, więc nowy telefon dostaje NOWY adres i NOWY klucz tożsamości.
- **Stan szyfrowania każdej rozmowy** (Double Ratchet) leży w tabeli `sessions` i zmienia się z każdą wiadomością. Nie da się go odtworzyć z kopii sprzed utraty telefonu.

## Dlaczego sama migawka kluczy i kontaktów nie wystarczy
Nawet po przywróceniu adresu onion i klucza tożsamości rozmówcy szyfrują dalej do stanu sesji, którego nowy telefon nie ma. Żeby rozmowy ruszyły, trzeba **protokołu resetu sesji**: nowy telefon uwierzytelnia się starym kluczem tożsamości i zawiera z każdym kontaktem nową sesję, a kontakt widzi ostrzeżenie o zmianie urządzenia i może zweryfikować numer bezpieczeństwa.

To zmiana kryptograficzna w sercu komunikatora. Nie powinna powstać bez: projektu protokołu, przeglądu przez osobę znającą kryptografię, testów na dwóch urządzeniach i migracji dla istniejących kontaktów. Do tego czasu odzyskiwanie online przywraca konto społecznościowe, a **pełną kopię rozmów daje plik kopii zapasowej** (Dane).
